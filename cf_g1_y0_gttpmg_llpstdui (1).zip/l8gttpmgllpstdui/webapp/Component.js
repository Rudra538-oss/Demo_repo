sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "l8gttpmgllpstdui/model/models",
    "sap/ui/model/odata/v2/ODataModel",
    "sap/ui/model/json/JSONModel"
], function(UIComponent, Device, models, ODataModel, JSONModel) {
    "use strict";
    var apikey,username,sysali;

    return UIComponent.extend("l8gttpmgllpstdui.Component", {
        metadata: {
            manifest: "json"
        },

        init: function() {
            // Call the base component's init function
            UIComponent.prototype.init.apply(this, arguments);

            // Enable routing
            this.getRouter().initialize();

            // Set the device model
            this.setModel(models.createDeviceModel(), "device");
            var currentURL = window.location.href;
            var url = new URL(currentURL);
            var host = url.host;
            console.log(host);
            var oResourceBundle = this.getModel("util").getResourceBundle();
            if (host.startsWith("dev") || host.startsWith("poc")){
                apikey = oResourceBundle.getText("apiKey_Dev");
                username = oResourceBundle.getText("techincalUser_Dev");
                sysali = oResourceBundle.getText("systemAlias_Dev");
            } else if (host.startsWith("ppd")){
                apikey = oResourceBundle.getText("apiKey_PPD");
                username = oResourceBundle.getText("technicalUser_PPD");
                sysali = oResourceBundle.getText("systemAlias_PPD");
            } else{
                apikey = oResourceBundle.getText("apiKey_PRD");
                username = oResourceBundle.getText("technicalUser_PRD");
                sysali = oResourceBundle.getText("systemAlias_PRD");
            }


            // Create and set the OData v2 model
            var sServiceUrlV2 = "YGTPT_LINE_LABOUR_STN_SRV/V2";
            var oODataModel = new ODataModel(sServiceUrlV2, {
                useBatch: false,
                headers: {
                    "apikey": apikey,
                    "username": username,
                    "sysali": sysali
                               }
            });
            this.setModel(oODataModel);

            // Create and set the global JSON model
            var oGlobalModel = new JSONModel();
            this.setModel(oGlobalModel, "globalResponseModel");
        }
    });
});