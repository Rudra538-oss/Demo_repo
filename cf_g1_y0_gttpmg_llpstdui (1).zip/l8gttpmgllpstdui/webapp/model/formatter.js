sap.ui.define([], () => {
	"use strict";

	return {
		statusText(sStatus) {
			const oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			switch (sStatus) {
				case "Appr -In Exec":
					return "Success";

				case "Under Appr":
					return "Warning";
				case "Re-Work":
					return "Error";



				case "Approved":
					return "Success";
				case "Under-Appr":
					return "Warning";
				case "Re-work":
					return "Error";
				case "Modified":
					return "Information";
				case "Created":
					return "Success";
				case "Ready to use":
					return "Success";
				case "Appr-InExec":
					return "Information";
				case "Archived - SAP Del":
					return "Information";


				// case "Approved":
				// 	return "Indication14";
				// case "Under-Review":
				// 	return "Indication13";
				// case "Re-work":
				// 	return "Error";
				default:
					return "Indication12";
			}
		},
		

		fnReworkIcon: function (s) {

		},
		bottleneckText(sStatus) {
			const oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			switch (sStatus) {
				case "YES":
					return "Success";

				case "NO":
					return "Error";

				// case "Approved":
				// 	return "Indication14";
				// case "Under-Review":
				// 	return "Indication13";
				// case "Re-work":
				// 	return "Error";
				default:
					return "Success";
			}
		},
		fnDatFormat: function (val) {
			if (val != null) {
				var iDay = ('0' + parseInt(val.substring(8, 10), 10)).slice(-2);
				var iMonth = ('0' + val.substring(5, 7)).slice(-2);
				var iYear = parseInt(val.substring(0, 4));

				return iDay + "-" + iMonth + "-" + iYear;
			}

		},

		formatDate(dateVal) {
			var regex = /^\d{4}-\d{2}-\d{2}$/;

			if (regex.test(dateVal)) {
				var parts = dateVal.split("-");
				var year = parts[0];
				var month = parts[1];
				var day = parts[2];

				// Format to "dd-MM-yyyy"
				return day + "-" + month + "-" + year;
			}
			else {

				var date = new Date(dateVal);
				var day = ("0" + date.getDate()).slice(-2);
				var month = ("0" + (date.getMonth() + 1)).slice(-2);
				var year = date.getFullYear();

				return day + "-" + month + "-" + year;
			}
		},
		formatDate1: function (dateVal) {
			var parts = dateVal.split("-");
			var year = parts[0];
			var month = parts[1];
			var day = parts[2];

			// Format to "dd-MM-yyyy"
			return day + "-" + month + "-" + year;
		},

		fnNumberFixed: function (val) {
			if (val != null) {
				return Number(val.toFixed(3));
			}
			else {
				return null
			}

		},
		getPhaseValue(sPhaseType,sPhaseIdentifier) {
			if(sPhaseIdentifier === "X"){
				if (sPhaseType === "Q") {
				return "Quality Phase";
			} else if (sPhaseType === "D") {
				return "Downtime Phase";
			} else if (sPhaseType === "C") {
				return "DMO Comoponents";
			} else if (sPhaseType === "R") {
				return "Runtime Phase";
			} 
		}else {

				return "Operation";
			}
		}


	};
});