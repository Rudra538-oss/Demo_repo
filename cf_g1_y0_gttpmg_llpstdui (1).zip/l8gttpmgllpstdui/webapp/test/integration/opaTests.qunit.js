/* global QUnit */

sap.ui.require(["l8gttpmgllpstdui/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
