sap.ui.define([
	"l8gttpmgllpstdui/test/unit/controller/App.controller"
], function () {
	"use strict";
});
