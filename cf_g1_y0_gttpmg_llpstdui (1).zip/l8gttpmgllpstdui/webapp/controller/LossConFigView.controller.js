sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	'sap/ui/core/BusyIndicator',
	'sap/m/MessageToast',
	"l8gttpmgllpstdui/controller/BaseController",
	],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function (Controller, History, BusyIndicator, MessageToast,BaseController) {
	"use strict";
	var tableIndex,oODataModel, mHeaders = [];
	return BaseController.extend("l8gttpmgllpstdui.controller.LossConFigView", {
		onInit: function () {
			const oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			const oHistory = sap.ui.core.routing.History.getInstance();
			const sPreviousHash = oHistory.getPreviousHash();
			oRouter.getRoute("LossConFigView").attachPatternMatched(this._onObjectMatched, this);
			// If there is no previous hash, navigate to HomeView
			if (sPreviousHash === undefined) {
				oRouter.navTo("RouteHomeView", true);
			} else {
				oRouter.getRoute("LineStandardView").attachPatternMatched(this.onObjectMatched, this);
			}
			this.oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},
		_onObjectMatched(oEvent) {
			var that = this;
			oODataModel = this.getOwnerComponent().getModel();

			this.getView().byId("idLossConfigTable").clearSelection();
			//this.getView().byId("idLossConfigDelete").setEnabled(true);
			this.getView().byId("idLossConfigEdit").setVisible(true);
			this.getView().byId("idLossConfigSubmit").setVisible(false);
			this.getView().byId("idLossConfigCancel").setVisible(false);
			this.getView().byId("idLossConfigDelete").setEnabled(false);
			this.getView().byId("idLossConfigAdd").setEnabled(true);

			BusyIndicator.show();
			var url = "/ETY_PLANT_SHSet";
			if (oODataModel) {
				oODataModel.read(url, {
					headers: mHeaders,
					success: function(oData) {
						var oModelPlant = new sap.ui.model.json.JSONModel();
						oModelPlant.setData(oData);
						oModelPlant.setSizeLimit(3000);							   
						that.getView().setModel(oModelPlant, "plantModel1");
						that.fnReadLossCatConfigurationData();
					}.bind(this),
					error: function(oError) {
						// Handle errors
						MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
					}
				});
			} else {
				MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
			}            

		},

		// function to enable edit and delete button,called when a row is selected in the table 
		fnLossConfigTableRowSelected: function (evt) {               
			var aRowSelected = this.getView().byId("idLossConfigTable").getSelectedIndices();
			if (aRowSelected.length > 0) {
				this.getView().byId("idLossConfigEdit").setEnabled(true);
				this.getView().byId("idLossConfigDelete").setEnabled(true);
				this.getView().byId("idLossConfigAdd").setEnabled(false);
			} else {
				this.getView().byId("idLossConfigEdit").setEnabled(false);
				this.getView().byId("idLossConfigDelete").setEnabled(false);
				this.getView().byId("idLossConfigAdd").setEnabled(true);
			}

		},

		// function to read data for the Loss/Sub configuration table
		fnReadLossCatConfigurationData: function () {
			var that=this;
			var aPlants=this.getView().getModel("plantModel1").getProperty("/results");
			var aPlantValue=[];
			for(var i=0;i<aPlants.length; i++)
			{
				aPlantValue.push(aPlants[i].Werks);
			}
			var oPostData={
					"plants":aPlantValue
			};

			//POST
			BusyIndicator.show();
			$.ajax({
				url: "odata/v4/data-services/getLossCatByPlant",
				type: "POST",
				data: JSON.stringify(oPostData),
				contentType: "application/json",
				dataType: "json",
			})
			.done(function (response) {
				BusyIndicator.hide();                          
				MessageToast.show(that.oResourceBundle.getText("CONFIG_LOSS_CONFIG_LOADED_SUCCESS"));
				var oTableModel = new sap.ui.model.json.JSONModel(response)
				that.getView().setModel(oTableModel, "lossCatModel");
				//Setting model at component level
				that.getOwnerComponent().setModel(oTableModel, "lossCatModel");                          
				///////////////////////////////////    After successful POSt, read call to fetch data///////////////////////////

			})
			.fail(function (xhr, status, error) {
				BusyIndicator.hide();
				MessageToast.show(that.oResourceBundle.getText("CONFIG_LOSS_CONFIG_LOADED_FAIL"));            

			});
			///////////////////////////////////////////////////////////////////////            

		},
		onNavBack: function (oEvent) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("RouteHomeView", true);

		},
		// function to navigate to specific config view
		fnMenu: function (evt) {

			var tableIndex = evt.getSource().getBindingContext("configModel").sPath.slice(7);               
			var sSelectedConfigNo = this.getView().getModel("configModel").getProperty("/value/" + tableIndex[0] + "/configNo");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("specificConFigView", { configNo: sSelectedConfigNo }, true);
		},
		fnAdd: function (evt) {
			if (!this._oPopover4) {
				this._oPopover4 = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.LossConfigCreate", this);                   
				this.getView().addDependent(this._oPopover4);
			}

			this._oPopover4.open();

		},

		onResourceSelection: function () {
			var resource = sap.ui.getCore().byId("idConfigResource").getSelectedItem().getKey();
			var plant = sap.ui.getCore().byId("idConfigPlant").getSelectedItem().getKey();
			var url = `sap/opu/odata/GLB/YGTPT_LINE_LABOUR_STN_SRV/ETY_CostCentre_ValueHelpSet(Werks='${plant}',Arbpl='${resource}')?$format=json`;
			var oModelCostcenter = new sap.ui.model.json.JSONModel();
			oModelCostcenter.loadData(url);
			this.getView().setModel(oModelCostcenter, "costcenterModel");
		},

		// Configuration screen create function           
		fnCreateLossCategory: function (evt) {
			var that = this;
			var splant = sap.ui.getCore().byId("idLossCreatePlant").getValue();
			var sLossCategory = sap.ui.getCore().byId("idLossCreateLossCategory").getValue();
			var sSubCategory = sap.ui.getCore().byId("idLossCreateSubCategory").getValue();

			if (splant != "" && sLossCategory != "" && sSubCategory != "") {
				var postData = {
						"plant": splant,
						"lossCat": sLossCategory,
						"subCat": sSubCategory

				};
				//POST
				BusyIndicator.show();
				$.ajax({
					url: "odata/v4/data-services/LineRelatedLossCatDB",
					type: "POST",
					data: JSON.stringify(postData),
					contentType: "application/json",
					dataType: "json",
				}).done(function (response) {
					BusyIndicator.hide();                            
					MessageToast.show(that.oResourceBundle.getText("NEW_LOSSCONFIG_CREATED_SUCCESS"));
					var message = that.oResourceBundle.getText("NEW_LOSSCONFIG_CREATED_SUCCESS") + "\n Plant :"+response.plant+", Loss :"+response.lossCat+", Sub :"+response.subCat;
					that.onShowSuccess(message);                            
					that.fnReadLossCatConfigurationData();
				}).fail(function (xhr, status, error) {
					BusyIndicator.hide();
					MessageToast.show(that.oResourceBundle.getText("NEW_LOSSCONFIG_CREATED_FAIL"));
					var message = that.oResourceBundle.getText("NEW_LOSSCONFIG_CREATED_FAIL") + "\n"+ xhr.responseJSON.error.code + ":" + xhr.responseJSON.error.message;
					that.onShowError(message);                       
				});

				this._oPopover4.close();
				sap.ui.getCore().byId("idLossCreatePlant").setValue("");
				sap.ui.getCore().byId("idLossCreateLossCategory").setValue("");
				sap.ui.getCore().byId("idLossCreateSubCategory").setValue("");

				sap.ui.getCore().byId("idLossCreatePlant").setValueState("None");
				sap.ui.getCore().byId("idLossCreateLossCategory").setValueState("None");
				sap.ui.getCore().byId("idLossCreateSubCategory").setValueState("None");                  
			}
			else {
				if (splant == "") {
					sap.ui.getCore().byId("idLossCreatePlant").setValueState("Error");
					sap.ui.getCore().byId("idLossCreatePlant").setValueStateText(this.oResourceBundle.getText("ENTER_CONFIG_PLANT_ERROR"));
				} else {
					sap.ui.getCore().byId("idLossCreatePlant").setValueState("None");
				}
				if (sLossCategory == "") {
					sap.ui.getCore().byId("idLossCreateLossCategory").setValueState("Error");
					sap.ui.getCore().byId("idLossCreateLossCategory").setValueStateText(this.oResourceBundle.getText("ERROR_CONFIG_LOSSCATEGORY"));
				} else {
					sap.ui.getCore().byId("idLossCreateLossCategory").setValueState("None");
				}
				if (sSubCategory == "") {
					sap.ui.getCore().byId("idLossCreateSubCategory").setValueState("Error");
					sap.ui.getCore().byId("idLossCreateSubCategory").setValueStateText(this.oResourceBundle.getText("ERROR_CONFIG_SUBCATEGORY"));
				} else {
					sap.ui.getCore().byId("idLossCreateSubCategory").setValueState("None");
				}                   

			}
		},
		handleCloseButton: function (oEvent) {
			if (this._oPopoverDeleteRow) {
				this._oPopoverDeleteRow.close();
			}

			if (this._oPopover4) {
				sap.ui.getCore().byId("idLossCreatePlant").setValue("");
				sap.ui.getCore().byId("idLossCreateLossCategory").setValue("");
				sap.ui.getCore().byId("idLossCreateSubCategory").setValue("");

				sap.ui.getCore().byId("idLossCreatePlant").setValueState("None");
				sap.ui.getCore().byId("idLossCreateLossCategory").setValueState("None");
				sap.ui.getCore().byId("idLossCreateSubCategory").setValueState("None");
				this._oPopover4.close();

			}

		},
		onView: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("specificConFigView", true);
		},
		fnEdit: function (oEvent) {                 
			var tableIndex = this.getView().byId("idLossConfigTable").getSelectedIndices();
			for (var i = 0; i < tableIndex.length; i++) {
				this.getView().getModel("lossCatModel").setProperty("/value/" + tableIndex[i] + "/enable", true);
				this.getView().getModel("lossCatModel").setProperty("/value/" + tableIndex[i] + "/edit", true);
			}

			this.getView().byId("idLossConfigEdit").setVisible(false);
			this.getView().byId("idLossConfigSubmit").setVisible(true);
			this.getView().byId("idLossConfigCancel").setVisible(true);
			this.getView().byId("idLossConfigDelete").setEnabled(false);
			this.getView().byId("idLossConfigAdd").setEnabled(false);
		},
		// function called on click of submit button to update configurations
		fnSubmit: function () {
			var that = this;

			///////////////////////////////////New Payload for Multi Update////////////////////////////////////////////
			var tableIndex = this.getView().byId("idLossConfigTable").getSelectedIndices();
			var aUpdateData = [];
			var iLossCat=0,iSubCat=0;
			for (var i = 0; i < tableIndex.length; i++) {
				var currentObj = {};      

				currentObj.ID = this.getView().getModel("lossCatModel").getProperty("/value/" + tableIndex[i] + "/ID");
				currentObj.lossCat = this.getView().getModel("lossCatModel").getProperty("/value/" + tableIndex[i] + "/lossCat");
				currentObj.subCat = this.getView().getModel("lossCatModel").getProperty("/value/" + tableIndex[i] + "/subCat");

				if(currentObj.lossCat=="")
				{
					this.getView().getModel("lossCatModel").setProperty("/value/" + tableIndex[i] + "/lossCatValueState","Error");
					this.getView().getModel("lossCatModel").setProperty("/value/" + tableIndex[i] + "/lossCatValueStateText",this.oResourceBundle.getText("ERROR_LOSS_CATEGORY"));
					iLossCat=1;
				}
				if(currentObj.subCat=="")
				{
					this.getView().getModel("lossCatModel").setProperty("/value/" + tableIndex[i] + "/subCatValueState","Error");
					this.getView().getModel("lossCatModel").setProperty("/value/" + tableIndex[i] + "/subCatValueStateText",this.oResourceBundle.getText("ERROR_SUB_CATEGORY"));    
					iSubCat=1;
				}
				if(iLossCat ==0 && iSubCat ==0)
				{
					this.getView().getModel("lossCatModel").setProperty("/value/" + tableIndex[i] + "/edit", false);

				}                   
				aUpdateData.push(currentObj);

			}

			var oPayload = { "updateData": aUpdateData };
			if(iLossCat ==0 && iSubCat ==0)
			{
				this.getView().byId("idLossConfigEdit").setVisible(true);
				this.getView().byId("idLossConfigSubmit").setVisible(false);
				this.getView().byId("idLossConfigCancel").setVisible(false);
				this.getView().byId("idLossConfigDelete").setEnabled(true);
				this.getView().byId("idLossConfigAdd").setEnabled(true);               
				var updateUrl = "odata/v4/data-services/updateLineLossCatItems";
				////////////////////////////////////New Payload for Multi Update/////////////////////////////////////////////
				BusyIndicator.show()
				$.ajax({
					url: updateUrl,
					type: "POST",
					contentType: "application/json",
					data: JSON.stringify(oPayload)
				}).done(function (data) {
					BusyIndicator.hide();  
					that.getView().byId("idLossConfigTable").clearSelection();                 
					MessageToast.show(that.oResourceBundle.getText("LOSS_CONFIG_UPDATED"));
					var message = that.oResourceBundle.getText("SELECT_LOSS_CONFIG_UPDATED");
					that.onShowSuccess(message);                     
					that.fnReadLossCatConfigurationData();                   

				}).fail(function (xhr, status, error) {
					MessageToast.show(that.oResourceBundle.getText("LOSS_CONFIG_NOTUPDATED"));
					var message = that.oResourceBundle.getText("SELECT_LOSS_CONFIG_NOTUPDATED");
					that.onShowError(message); 
					BusyIndicator.hide();                   
					that.fnReadConfigurationData();

				});

			}

		},
		fnCancel: function () {
			this.getView().byId("idLossConfigDelete").setEnabled(true);
			this.getView().byId("idLossConfigEdit").setVisible(true);
			this.getView().byId("idLossConfigSubmit").setVisible(false);
			this.getView().byId("idLossConfigCancel").setVisible(false);
			this.getView().byId("idLossConfigDelete").setEnabled(true);
			this.getView().byId("idLossConfigAdd").setEnabled(true);
			this.getView().byId("idLossConfigTable").clearSelection();
			tableIndex = this.getView().byId("idLossConfigTable").getSelectedIndices();

			for (var i = 0; i < tableIndex.length; i++) {
				this.getView().getModel("lossCatModel").setProperty("/value/" + tableIndex[i] + "/edit", false);
			}
			this.fnReadLossCatConfigurationData();

		},
		fnDelete: function () {
			if (!this._oPopoverDeleteRow) {
				this._oPopoverDeleteRow = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.PopoverDeleteRecordsLine", this);
				this.getView().addDependent(this._oPopoverDeleteRow);
			}
			this._oPopoverDeleteRow.open();
		},

		//function to delete rows in the table
		handleAcceptButton: function () {   

			var deleteUrl = "odata/v4/data-services/deleteLineLossCatItems";
			var tableIndex = this.getView().byId("idLossConfigTable").getSelectedIndices();
			var aRowID = [];
			for (var i = 0; i < tableIndex.length; i++) {
				aRowID.push(this.getView().getModel("lossCatModel").getProperty("/value/" + tableIndex[i] + "/ID"));
			}

			var oPayload = { "IDs": aRowID };
			var that = this;
			BusyIndicator.show();
			$.ajax({
				url: deleteUrl,
				type: "POST",
				contentType: "application/json",
				data: JSON.stringify(oPayload)
			}).done(function (data) {                        
				MessageToast.show(that.oResourceBundle.getText("SELECT_LOSS_CONFIG_DELETED"));
				var message = that.oResourceBundle.getText("SELECT_LOSS_CONFIG_DELETED");
				that.onShowSuccess(message);                       
				BusyIndicator.hide();
				that.fnReadLossCatConfigurationData();
			}).fail(function (xhr, status, error) {
				BusyIndicator.hide();
				MessageToast.show(that.oResourceBundle.getText("SELECT_LOSS_CONFIG_DELETEFAIL"));
				var message = that.oResourceBundle.getText("SELECT_LOSS_CONFIG_DELETEFAIL");
				that.onShowError(message);                       
			});               
			this._oPopoverDeleteRow.close()

		},       

		onShowWarning: function(message) {
			sap.m.MessageBox.warning(
					message, {
						title: "Warning",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function() {}
					}
			);
		},
		onShowSuccess: function(message) {
			sap.m.MessageBox.success(
					message, {
						title: "Success",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function() {}
					}
			);
		},
		onShowError: function(message) {
			sap.m.MessageBox.error(
					message, {
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function() {}
					}
			);
		},

	});
});
