sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	'sap/ui/core/BusyIndicator',
	'sap/m/MessageToast',
	"l8gttpmgllpstdui/controller/BaseController",
	 "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
	"sap/m/MessageBox"
	],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function (Controller, History, BusyIndicator, MessageToast,BaseController,Filter,FilterOperator,MessageBox) {
	"use strict";
	var tableIndex, sConfigNo,oODataModel,sPlant,iUserSelectedIndex,flag;
	var mHeaders = [];
	return BaseController.extend("l8gttpmgllpstdui.controller.SpecificConFigView", {
		onInit: function () {
			const oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			const oHistory = sap.ui.core.routing.History.getInstance();
			const sPreviousHash = oHistory.getPreviousHash();
			oRouter.getRoute("specificConFigView").attachPatternMatched(this.onObjectMatched, this);
			// If there is no previous hash, navigate to HomeView
			if (sPreviousHash === undefined) {
				oRouter.navTo("RouteHomeView", true);
			} else {
				oRouter.getRoute("LineStandardView").attachPatternMatched(this.onObjectMatched, this);
			}
			this.oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},
		onObjectMatched(oEvent) {
			oODataModel = this.getOwnerComponent().getModel();
			var newData = sap.ui.getCore().getModel("loginUserModel").getData().results;
			var nbId = newData[0].Username;
			var zone = newData[0].Zone;
			var currentURL = window.location.href;
			var url = new URL(currentURL);
			var host = url.host;
			var oResourceBundle = this.getView().getModel("util").getResourceBundle();
			if (host.startsWith("dev") || host.startsWith("poc")) {
				var apikey = oResourceBundle.getText("apiKey_Dev");
			} else if (host.startsWith("ppd")) {
				var apikey = oResourceBundle.getText("apiKey_PPD");
			} else {
				var apikey = oResourceBundle.getText("apiKey_PRD");
			}
			var alias = zone === "AOA" ? oResourceBundle.getText("zoneAOA_Alias") :
				zone === "EUR" ? oResourceBundle.getText("zoneEUR_Alias") :
					zone === "AMS" ? oResourceBundle.getText("zoneAMS_Alias") :
						"";

					mHeaders = {
							"apikey": apikey,
							"username": nbId,
							"sysali": alias
					};
			// initial setting for the table
			this.getView().byId("idSpecificConfigTable").clearSelection();
			this.getView().byId("idExecuterConfigTable").clearSelection();
			this.getView().byId("idPhaseConfigTable").clearSelection();
			this.getView().byId("idtab2Edit").setVisible(true);
			this.getView().byId("idtab2Delete").setVisible(true);
			this.getView().byId("idtab2Submit").setVisible(false);
			this.getView().byId("idtab2Cancel").setVisible(false);
			this.getView().byId("idtab2Create").setEnabled(true);

			this.getView().byId("idtab1Edit").setVisible(true);
			this.getView().byId("idtab1Delete").setVisible(true);
			this.getView().byId("idtab1Submit").setVisible(false);
			this.getView().byId("idtab1Cancel").setVisible(false);
			this.getView().byId("idtab1Create").setEnabled(true);

			this.getView().byId("idtab10Edit").setVisible(true);
			this.getView().byId("idtab10Delete").setVisible(true);
			this.getView().byId("idtab10Submit").setVisible(false);
			this.getView().byId("idtab10Cancel").setVisible(false);
			this.getView().byId("idtab10Create").setEnabled(true);


			sConfigNo = oEvent.getParameter("arguments").configNo;
			var aConfigData = this.getOwnerComponent().getModel("configModel").getData().value;
			var aSpecificConfigHeaderData = aConfigData.filter(function (val) {
				if (val.configNo == sConfigNo)
					return val;
			});
			sPlant = aSpecificConfigHeaderData[0].plant;
			aSpecificConfigHeaderData[0].standardType === "Product Standard" ? this.getView().byId("idPhaseConfigTabSeparator").setVisible(true):this.getView().byId("idPhaseConfigTabSeparator").setVisible(false);
			aSpecificConfigHeaderData[0].standardType === "Product Standard" ? this.getView().byId("idPhaseConfigTabFilter").setVisible(true):this.getView().byId("idPhaseConfigTabFilter").setVisible(false);
			this.getView().byId("idConfigPlant").setText(aSpecificConfigHeaderData[0].plant);
			this.getView().byId("idConfigResource").setText(aSpecificConfigHeaderData[0].resource);
			this.getView().byId("idConfigCostCenter").setText(aSpecificConfigHeaderData[0].costCenter);
			this.getView().byId("idConfigStandardType").setText(aSpecificConfigHeaderData[0].standardType);
			this.getView().byId("idConfigCreatedOn").setText(this._fnDatFormat(aSpecificConfigHeaderData[0].auditInfoCreatedOn));
			this.getView().byId("idConfigModifiedOn").setText(this._fnDatFormat(aSpecificConfigHeaderData[0].auditInfoModifiedOn));

			this.fnReadApproverConfigurationData();
			this.fnReadExecutorConfigurationData();
			this.fnReadPhaseConfigurationData();

		},

		_fnDatFormat: function (val) {
			if (val != null) {
				var iDay = parseInt(val.substring(8, 10));
				var iMonth = val.substring(5, 7);
				var iYear = parseInt(val.substring(0, 4));
				return iDay + "-" + iMonth + "-" + iYear;
			}
		},

		fnReadApproverConfigurationData: function () {    
			var that = this;
			BusyIndicator.show();
			$.get("odata/v4/data-services/ConfigurationApproversDB?$filter=configNo eq '" + sConfigNo + "'").done(function (data) {

				BusyIndicator.hide();
				// Process or display the 'data' object as needed
				var oTableModel = new sap.ui.model.json.JSONModel(data)
				that.getView().setModel(oTableModel, "approverConfigModel");
				//Setting model at component level
				that.getOwnerComponent().setModel(oTableModel, "approverConfigModel");
				var approverConfigCount = that.getView().getModel("approverConfigModel").getData().value.length;
				that.getView().byId("idApproverConfigTabFilter").setCount(approverConfigCount);
				MessageToast.show(that.oResourceBundle.getText("APPR_CONFIG_LOAD_SUCCESS"));
				// alert(JSON.stringify(data)); // Convert data to string for alert
			}).fail(function (xhr, status, error) {
				BusyIndicator.hide();
				// Handle errors if the request fails
				MessageToast.show(that.oResourceBundle.getText("CONFIG_LOADING_FAIL"));

			});
		},

		fnReadExecutorConfigurationData: function () {

			var that = this;
			BusyIndicator.show();
			$.get("odata/v4/data-services/ConfigurationExecutorsDB?$filter=configNo eq '" + sConfigNo + "'&$orderby=auditInfoModifiedOn desc").done(function (data) {
				// 'data' here should contain the response from the OData endpoint

				BusyIndicator.hide();
				// Process or display the 'data' object as needed
				var oTableModel = new sap.ui.model.json.JSONModel(data)
				that.getView().setModel(oTableModel, "executorConfigModel");
				//Setting model at component level
				that.getOwnerComponent().setModel(oTableModel, "executorConfigModel");
				var executorConfigCount = that.getView().getModel("executorConfigModel").getData().value.length;
				that.getView().byId("idExecutorConfigTabFilter").setCount(executorConfigCount);
				MessageToast.show(that.oResourceBundle.getText("EXE_CONFIG_LOAD_SUCCESS"));
				// alert(JSON.stringify(data)); // Convert data to string for alert
			}).fail(function (xhr, status, error) {
				BusyIndicator.hide();
				// Handle errors if the request fails
				MessageToast.show(that.oResourceBundle.getText("CONFIG_LOADING_FAIL"));

			});
		},
		fnReadPhaseConfigurationData: function () {

			var that = this;
			BusyIndicator.show();
			$.get("odata/v4/data-services/PhaseDB?$filter=configNo eq '" + sConfigNo + "'&$orderby=auditInfoModifiedOn desc").done(function (data) {
				// 'data' here should contain the response from the OData endpoint

				BusyIndicator.hide();
				// Process or display the 'data' object as needed
				var oTableModel = new sap.ui.model.json.JSONModel(data)
				that.getView().setModel(oTableModel, "phaseConfigModel");
				//Setting model at component level
				that.getOwnerComponent().setModel(oTableModel, "phaseConfigModel");
				var phaseConfigCount = that.getView().getModel("phaseConfigModel").getData().value.length;
				that.getView().byId("idPhaseConfigTabFilter").setCount(phaseConfigCount);
				MessageToast.show(that.oResourceBundle.getText("PHASE_CONFIG_LOAD_SUCCESS"));
				// alert(JSON.stringify(data)); // Convert data to string for alert
			}).fail(function (xhr, status, error) {
				BusyIndicator.hide();
				// Handle errors if the request fails
				MessageToast.show(that.oResourceBundle.getText("CONFIG_LOADING_FAIL"));

			});
			var url = "/ETY_CONTROL_DESTSet";
			BusyIndicator.show(0);
			var oFilterPlant = new Filter({
				filters: [
					new Filter("WERKS", FilterOperator.EQ, sPlant)
					]
			});
			if (oODataModel) {
				oODataModel.read(url, {
					headers: mHeaders,
					filters: [oFilterPlant],
					success: function (oData) {
						BusyIndicator.hide();
						// Create and set the JSONModel with the data received
						var oModelDestination = new sap.ui.model.json.JSONModel();
						oModelDestination.setData(oData);
						that.getView().setModel(oModelDestination, "destinationModel");
					}.bind(this),
					error: function (jqXHR) {
						BusyIndicator.hide();
						let errorMessage = jqXHR.responseText ?
								JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
								// Handle errors
								MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
					}
				});
			} else {
				MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
			}
			var url_1 = "/ETY_CONTROL_KEYSet";
					if (oODataModel) {
						oODataModel.read(url_1, {
							headers: mHeaders,
							success: function (oData) {
								BusyIndicator.hide();
								var oModelControlKey = new sap.ui.model.json.JSONModel();
								oModelControlKey.setData(oData);
								that.getView().setModel(oModelControlKey, "controlKeyModel");
							}.bind(this),
							error: function (jqXHR) {
								BusyIndicator.hide();
								let errorMessage = jqXHR.responseText ?
										JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
										// Handle errors
										MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
										BusyIndicator.hide();
									}
						});
					} else {
						MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
					}
					$.get("odata/v4/data-services/ListOptionTxt?$filter=setId eq 'PHASE_TYPE'&$orderby=auditInfoCreatedOn asc&$select=label,itemCode").done(function (data) {
						// 'data' here should contain the response from the OData endpoint
	
						BusyIndicator.hide();
						// Process or display the 'data' object as needed
						var oPhaseTypeModel = new sap.ui.model.json.JSONModel(data)
						that.getView().setModel(oPhaseTypeModel, "oPhaseTypeModel");
					}).fail(function (xhr, status, error) {
						BusyIndicator.hide();
						MessageToast.show(that.oResourceBundle.getText("CONFIG_LOADING_FAIL"));
	
					});
		},

		fnIconTabFilterSelected: function () {
			var oTab = this.getView().byId("idConfigTab");																										
			var aTableIndex = this.getView().byId("idSpecificConfigTable").getSelectedIndices();
			for (var i = 0; i < aTableIndex.length; i++) {
				this.getView().getModel("approverConfigModel").setProperty("/value/" + aTableIndex[i] + "/edit", false);
			}

			var aTableIndex = this.getView().byId("idExecuterConfigTable").getSelectedIndices();
			for (var i = 0; i < aTableIndex.length; i++) {
				this.getView().getModel("executorConfigModel").setProperty("/value/" + aTableIndex[i] + "/edit", false);
			}
			var aTableIndex = this.getView().byId("idPhaseConfigTable").getSelectedIndices();
			for (var i = 0; i < aTableIndex.length; i++) {
				this.getView().getModel("phaseConfigModel").setProperty("/value/" + aTableIndex[i] + "/edit", false);
			}
			this.getView().byId("idSpecificConfigTable").clearSelection();
			this.getView().byId("idExecuterConfigTable").clearSelection();
			this.getView().byId("idPhaseConfigTable").clearSelection();
			this.getView().byId("idtab2Edit").setVisible(true);
			this.getView().byId("idtab2Delete").setVisible(true);
			this.getView().byId("idtab2Create").setEnabled(true);
			this.getView().byId("idtab2Submit").setVisible(false);
			this.getView().byId("idtab2Cancel").setVisible(false);

			this.getView().byId("idtab1Edit").setVisible(true);
			this.getView().byId("idtab1Delete").setVisible(true);
			this.getView().byId("idtab1Create").setEnabled(true);
			this.getView().byId("idtab1Submit").setVisible(false);
			this.getView().byId("idtab1Cancel").setVisible(false);

			this.getView().byId("idtab10Edit").setVisible(true);
			this.getView().byId("idtab10Delete").setVisible(true);
			this.getView().byId("idtab10Create").setEnabled(true);
			this.getView().byId("idtab10Submit").setVisible(false);
			this.getView().byId("idtab10Cancel").setVisible(false);

			var mainTabKey = oTab.getSelectedKey();
			if (mainTabKey == "Executers configurations") {
				var that = this;
				BusyIndicator.show();
				$.get("odata/v4/data-services/ConfigurationExecutorsDB?$filter=configNo eq '" + sConfigNo + "'&$orderby=auditInfoModifiedOn desc").done(function (data) {
					// 'data' here should contain the response from the OData endpoint

					BusyIndicator.hide();
					// Process or display the 'data' object as needed
					var oTableModel = new sap.ui.model.json.JSONModel(data)
					that.getView().setModel(oTableModel, "executorConfigModel");
					//Setting model at component level
					that.getOwnerComponent().setModel(oTableModel, "executorConfigModel");
					var executorConfigCount = that.getView().getModel("executorConfigModel").getData().value.length;

					that.getView().byId("idExecutorConfigTabFilter").setCount(executorConfigCount);
					MessageToast.show(that.oResourceBundle.getText("EXE_CONFIG_LOAD_SUCCESS"));
					// alert(JSON.stringify(data)); // Convert data to string for alert
				}).fail(function (xhr, status, error) {
					BusyIndicator.hide();
					// Handle errors if the request fails
					MessageToast.show(that.oResourceBundle.getText("CONFIG_LOADING_FAIL"));

				});
	 

												 

			} else if (mainTabKey == "Phase configurations"){
				var that = this;
				BusyIndicator.show();
				$.get("odata/v4/data-services/PhaseDB?$filter=configNo eq '" + sConfigNo + "'&$orderby=auditInfoModifiedOn desc").done(function (data) {
					// 'data' here should contain the response from the OData endpoint

					BusyIndicator.hide();
					// Process or display the 'data' object as needed
					var oTableModel = new sap.ui.model.json.JSONModel(data)
					that.getView().setModel(oTableModel, "phaseConfigModel");
					//Setting model at component level
					that.getOwnerComponent().setModel(oTableModel, "phaseConfigModel");
					var phaseConfigCount = that.getView().getModel("phaseConfigModel").getData().value.length;

					that.getView().byId("idPhaseConfigTabFilter").setCount(phaseConfigCount);
					MessageToast.show(that.oResourceBundle.getText("PHASE_CONFIG_LOAD_SUCCESS"));
				}).fail(function (xhr, status, error) {
					BusyIndicator.hide();
										  
					MessageToast.show(that.oResourceBundle.getText("CONFIG_LOADING_FAIL"));

				});
	 

			}else{
				MessageToast.show(this.oResourceBundle.getText("APPR_CONFIG_LOAD_SUCCESS"));
			}
		},

		onNavBack: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ConFigView", true);
		},
		onMenu: function (evt) {
			if (!this._oPopover5) {
				this._oPopover5 = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.PopoverSpecificConfig", this);
				this.getView().addDependent(this._oPopover5);
			}
			tableIndex = this.getView().byId("idSpecificConfigTable").getSelectedIndex();
			this._oPopover5.openBy(evt.getSource());
		},
		onAdd: function (evt) {
			if (!this._oPopoverApproverConfigCreate) {
				this._oPopoverApproverConfigCreate = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.ApproverConfigCreate", this);
				this.getView().addDependent(this._oPopoverApproverConfigCreate);
			}

			this._oPopoverApproverConfigCreate.open();
												  
																											 
	 
																  
																  

		},
		onAddExecutor: function (Event) {
			if (!this._oPopover7) {
				this._oPopover7 = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.ExecuterConfigCreate", this);
				this.getView().addDependent(this._oPopover7);
			}
			this._oPopover7.open();
		},
		handleCloseButton1: function (oEvent) {
			this._oPopoverApproverConfigCreate.close();
			sap.ui.getCore().byId("idApproverCreate").setValue("");
			sap.ui.getCore().byId("idApp2").setValue("");
			sap.ui.getCore().byId("idApp3").setValue("");
			sap.ui.getCore().byId("idApproverLevel").setValue("");

			sap.ui.getCore().byId("idApproverCreate").setValueState("None");
			sap.ui.getCore().byId("idApproverLevel").setValueState("None");															

		},
		handleCloseButton2: function (oEvent) {
			this._oPopover7.close();																						  
			sap.ui.getCore().byId("idExecutername").setValue("");
			sap.ui.getCore().byId("idExecuterbackup").setValue("");
			sap.ui.getCore().byId("idExecStep").setValue("");
			sap.ui.getCore().byId("idExecutername").setValueState("None");	 
		},

		onEdit: function () {
			var oTab = this.getView().byId("idConfigTab");
			var mainTabKey = oTab.getSelectedKey();
			if (mainTabKey == "Approvers configurations") {
				var oTable = this.getView().byId("idSpecificConfigTable");
				var aTableIndex = this.getView().byId("idSpecificConfigTable").getSelectedIndices();
				for (var i = 0; i < aTableIndex.length; i++) {
					//fetch the data of selected rows by index
					var tableContext = oTable.getContextByIndex(aTableIndex[i]);
					var data = oTable.getModel("approverConfigModel").getProperty(tableContext.getPath());
					this.getView().getModel("approverConfigModel").setProperty(tableContext.getPath() + "/edit", true);
				}
				this.getView().byId("idtab1Submit").setVisible(true);
				this.getView().byId("idtab1Cancel").setVisible(true);
				this.getView().byId("idtab1Edit").setVisible(false);
				this.getView().byId("idtab1Delete").setEnabled(false);
				this.getView().byId("idtab1Create").setEnabled(false);
			} else if (mainTabKey == "Executers configurations") {
				var aTableIndex = this.getView().byId("idExecuterConfigTable").getSelectedIndices();
				for (var i = 0; i < aTableIndex.length; i++) {
					this.getView().getModel("executorConfigModel").setProperty("/value/" + aTableIndex[i] + "/edit", true);
				}
				this.getView().byId("idtab2Submit").setVisible(true);
				this.getView().byId("idtab2Cancel").setVisible(true);
				this.getView().byId("idtab2Edit").setVisible(false);
				this.getView().byId("idtab2Delete").setEnabled(false);
				this.getView().byId("idtab2Create").setEnabled(false);

											  

			}else{
				var aTableIndex = this.getView().byId("idPhaseConfigTable").getSelectedIndices();
				for (var i = 0; i < aTableIndex.length; i++) {
					this.getView().getModel("phaseConfigModel").setProperty("/value/" + aTableIndex[i] + "/edit", true);
												  
				}
				this.getView().byId("idtab10Submit").setVisible(true);
				this.getView().byId("idtab10Cancel").setVisible(true);
				this.getView().byId("idtab10Edit").setVisible(false);
				this.getView().byId("idtab10Delete").setEnabled(false);
				this.getView().byId("idtab10Create").setEnabled(false);
			}													  

		},
		onSubmit: function () {
			var that = this;
			var oTab = this.getView().byId("idConfigTab");
			var mainTabKey = oTab.getSelectedKey();

			//Executor Submit functionality
			if (mainTabKey == "Approvers configurations") {

				var oTable = this.getView().byId("idSpecificConfigTable");
				var aTableIndex = this.getView().byId("idSpecificConfigTable").getSelectedIndices();
				var iApprovalLevelCorrect = 0;
				var aUpdateData = [];
																						 
				for (var i = 0; i < aTableIndex.length; i++) {
					var currentObj = {};
					var tableContext = oTable.getContextByIndex(aTableIndex[i]);
					currentObj.ID = this.getView().getModel("approverConfigModel").getProperty(tableContext.getPath() + "/ID");
					currentObj.approver = this.getView().getModel("approverConfigModel").getProperty(tableContext.getPath() + "/approver");
					if (currentObj.approver == "") {
						this.getView().getModel("approverConfigModel").setProperty(tableContext.getPath() + "/approverValueState", "Error");
						this.getView().getModel("approverConfigModel").setProperty(tableContext.getPath() + "/approverValueStateText", this.oResourceBundle.getText("ENTER_APPROVER"));
						iApprovalLevelCorrect = iApprovalLevelCorrect + 1;
					}
					currentObj.approverJob = this.getView().getModel("approverConfigModel").getProperty(tableContext.getPath() + "/approverJob");
					currentObj.approverBkp = this.getView().getModel("approverConfigModel").getProperty(tableContext.getPath() + "/approverBkp");
					currentObj.approverLvl = this.getView().getModel("approverConfigModel").getProperty(tableContext.getPath() + "/approverLvl");
					if (currentObj.approverLvl == "") {
						this.getView().getModel("approverConfigModel").setProperty(tableContext.getPath() + "/approverLvlValueState", "Error");
						this.getView().getModel("approverConfigModel").setProperty(tableContext.getPath() + "/approverLvlValueStateText", this.oResourceBundle.getText("APPR_LEVEL_ERROR"));
						iApprovalLevelCorrect = iApprovalLevelCorrect + 1;

																											 
					}
					currentObj.approverLvl = Number(currentObj.approverLvl);
					////////////////////////////////////////////////////test 2/////////////////////////////////////////////////////////////////////////////////////////
					const aApprDataAsc = this.getView().getModel("approverConfigModel").getProperty("/value");
					// aApprDataAsc.sort((a, b) => a.approverLvl - b.approverLvl);
					var iApprDataLen = aApprDataAsc.length;
					var iLargestNum = aApprDataAsc[iApprDataLen - 1].approverLvl;
					//  if (iApprDataLen < iLargestNum && currentObj.approverLvl < iLargestNum) {
					for (var j = 0; j < iApprDataLen-1; j++) {
						if(j != Number(tableContext.getPath().slice(7)))
						{                              
							if (aApprDataAsc[j].approverLvl == currentObj.approverLvl || currentObj.approverLvl > iApprDataLen) {
								//dont add
								this.getView().getModel("approverConfigModel").setProperty(tableContext.getPath() + "/approverLvlValueState", "Error");
								this.getView().getModel("approverConfigModel").setProperty(tableContext.getPath() + "/approverLvlValueStateText", this.oResourceBundle.getText("AAPR_LEVEL_SEQ_ERROR"));                                                       
								iApprovalLevelCorrect = iApprovalLevelCorrect + 1;
							} else {
								iApprovalLevelCorrect = iApprovalLevelCorrect + 0;

							}                        
						}
					}                   
					// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

					aUpdateData.push(currentObj);	
				} 
				if (iApprovalLevelCorrect == 0) {

					this.getView().byId("idtab1Submit").setVisible(false);
					this.getView().byId("idtab1Cancel").setVisible(false);
					this.getView().byId("idtab1Edit").setVisible(true);
					this.getView().byId("idtab1Delete").setEnabled(false);
					this.getView().byId("idtab1Create").setEnabled(true);
					this.getView().byId("idSpecificConfigTable").clearSelection();
					var oPayload = { "updateData": aUpdateData };
					var updateUrl = "odata/v4/data-services/updateApproverItems";
					////////////////////////////////////New Payload for Multi Update/////////////////////////////////////////////
					BusyIndicator.show()
					$.ajax({
						url: updateUrl,
						type: "POST",
						contentType: "application/json",
						data: JSON.stringify(oPayload)
					}).done(function (data) {
						BusyIndicator.hide();
						MessageToast.show(that.oResourceBundle.getText("CONFIG_UPDATED"));
						var message = that.oResourceBundle.getText("CONFIG_UPDATE_SUCCESS");
						that.onShowSuccess(message);
						that.fnReadApproverConfigurationData();
						var aApproverData = that.getView().getModel("approverConfigModel").getProperty("/value");
						for (var i = 0; i < aApproverData.length; i++) {
							that.getView().getModel("approverConfigModel").setProperty("/value/" + i + "/edit", false);
						}

					}).fail(function (xhr, status, error) {
						MessageToast.show(that.oResourceBundle.getText("CONFIG_NOT_UPDATED"));
						BusyIndicator.hide();
						that.fnReadApproverConfigurationData();
						var message = that.oResourceBundle.getText("CONFIG_UPDATE_FAIL");
						that.onShowError(message);
					});
				}


			} else if (mainTabKey == "Executers configurations") {

				var aTableIndex = this.getView().byId("idExecuterConfigTable").getSelectedIndices();
				var aUpdateData = [];
				var iExecutorName = 0;																				
				for (var i = 0; i < aTableIndex.length; i++) {
					var currentObj = {};
					currentObj.ID = this.getView().getModel("executorConfigModel").getProperty("/value/" + aTableIndex[i] + "/ID");
					currentObj.executor = this.getView().getModel("executorConfigModel").getProperty("/value/" + aTableIndex[i] + "/executor");
					if (currentObj.executor == "") {
						this.getView().getModel("executorConfigModel").setProperty("/value/" + aTableIndex[i] + "/executorValueState", "Error");
						this.getView().getModel("executorConfigModel").setProperty("/value/" + aTableIndex[i] + "/executorValueStateText",this.oResourceBundle.getText("ENTER_EXECUTOR"));
						iExecutorName = 1;
					}
					if (iExecutorName == 0) {
						this.getView().getModel("executorConfigModel").setProperty("/value/" + aTableIndex[i] + "/edit", false);
					}
					currentObj.executorBkp = this.getView().getModel("executorConfigModel").getProperty("/value/" + aTableIndex[i] + "/executorBkp");
					currentObj.executorStpDesc = this.getView().getModel("executorConfigModel").getProperty("/value/" + aTableIndex[i] + "/executorStpDesc");
					aUpdateData.push(currentObj);

				}
				if (iExecutorName == 0) {
					var oPayload = { "updateData": aUpdateData };
					var updateUrl = "odata/v4/data-services/updateExecutorItems";
					////////////////////////////////////New Payload for Multi Update/////////////////////////////////////////////
					BusyIndicator.show()
					$.ajax({
						url: updateUrl,
						type: "POST",
						contentType: "application/json",
						data: JSON.stringify(oPayload)
					}).done(function (data) {
						BusyIndicator.hide();
						MessageToast.show(that.oResourceBundle.getText("CONFIG_UPDATED"));
						var message = that.oResourceBundle.getText("CONFIG_EXE_UPDATE_SUCCESS");
						that.onShowSuccess(message);
						that.fnIconTabFilterSelected();
						that.getView().byId("idtab2Submit").setVisible(false);
						that.getView().byId("idtab2Cancel").setVisible(false);
						that.getView().byId("idtab2Edit").setVisible(true);
						that.getView().byId("idtab2Delete").setEnabled(false);
						that.getView().byId("idtab2Create").setEnabled(true);
						that.getView().byId("idExecuterConfigTable").clearSelection();

					}).fail(function (xhr, status, error) {
						MessageToast.show( that.oResourceBundle.getText("CONFIG_NOT_UPDATED"));
						BusyIndicator.hide();
						that.fnIconTabFilterSelected();
						var message = that.oResourceBundle.getText("CONFIG_EXE_UPDATE_FAIL");
						that.onShowError(message);
						that.getView().byId("idtab2Submit").setVisible(false);
						that.getView().byId("idtab2Cancel").setVisible(false);
						that.getView().byId("idtab2Edit").setVisible(true);
						that.getView().byId("idtab2Delete").setEnabled(false);
						that.getView().byId("idtab2Create").setEnabled(true);
						that.getView().byId("idExecuterConfigTable").clearSelection();
					});
				}
				
			}else{
				var aTableIndex = this.getView().byId("idPhaseConfigTable").getSelectedIndices();
				var aUpdateData = [];
				for (var i = 0; i < aTableIndex.length; i++) {
					var currentObj = {};
					currentObj.ID = this.getView().getModel("phaseConfigModel").getProperty("/value/" + aTableIndex[i] + "/ID");
					currentObj.phaseName = this.getView().getModel("phaseConfigModel").getProperty("/value/" + aTableIndex[i] + "/phaseName");
					currentObj.phaseControlKey = this.getView().getModel("phaseConfigModel").getProperty("/value/" + aTableIndex[i] + "/phaseControlKey");
					currentObj.beforeRunTimePhase = this.getView().getModel("phaseConfigModel").getProperty("/value/" + aTableIndex[i] + "/beforeRunTimePhase");
					currentObj.afterRunTimePhase = this.getView().getModel("phaseConfigModel").getProperty("/value/" + aTableIndex[i] + "/afterRunTimePhase");
					currentObj.destinationKey = this.getView().getModel("phaseConfigModel").getProperty("/value/" + aTableIndex[i] + "/destinationKey");
					currentObj.phaseType = this.getView().getModel("phaseConfigModel").getProperty("/value/" + aTableIndex[i] + "/phaseType");
					aUpdateData.push(currentObj);

				}
				if (currentObj.phaseType ==="Q"){
					if(currentObj.phaseControlKey.startsWith("Q")){
						var proceedFlag = 1;
						
					}else{
						var proceedFlag = 0;
						var message = this.oResourceBundle.getText("PHASE_CONFIG_TYPE_ERROR");
						this.onShowError(message);
					}
				}
				else if(currentObj.phaseType !=="Q"){
					if(currentObj.phaseControlKey.startsWith("Q")){
						var proceedFlag = 0;
						var message = this.oResourceBundle.getText("PHASE_CONFIG_TYPE_ERROR");
						this.onShowError(message);	
				}else{
					var proceedFlag = 1;
				}
			}
				
				if (proceedFlag===1){
					var oPayload = { "updateData": aUpdateData };
					var updateUrl = "odata/v4/data-services/updatePhaseItems";
					////////////////////////////////////New Payload for Multi Update/////////////////////////////////////////////
					BusyIndicator.show()
					$.ajax({
						url: updateUrl,
						type: "POST",
						contentType: "application/json",
						data: JSON.stringify(oPayload)
					}).done(function (data) {
						BusyIndicator.hide();
						var message = that.oResourceBundle.getText("CONFIG_PHASE_UPDATE_SUCCESS");
						that.onShowSuccess(message);
						that.fnIconTabFilterSelected();
						that.getView().byId("idtab10Submit").setVisible(false);
						that.getView().byId("idtab10Cancel").setVisible(false);
						that.getView().byId("idtab10Edit").setVisible(true);
						that.getView().byId("idtab10Delete").setEnabled(false);
						that.getView().byId("idtab10Create").setEnabled(true);
						that.getView().byId("idPhaseConfigTable").clearSelection();

					}).fail(function (xhr, status, error) {
						BusyIndicator.hide();
						that.fnIconTabFilterSelected();
						var message = that.oResourceBundle.getText("CONFIG_PHASE_UPDATE_FAIL");
						that.onShowError(message);
						that.getView().byId("idtab10Submit").setVisible(false);
						that.getView().byId("idtab10Cancel").setVisible(false);
						that.getView().byId("idtab10Edit").setVisible(true);
						that.getView().byId("idtab10Delete").setEnabled(false);
						that.getView().byId("idtab10Create").setEnabled(true);
						that.getView().byId("idPhaseConfigTable").clearSelection();
					});
				}	
				
			}
		},
		onCancel: function () {
			var oTab = this.getView().byId("idConfigTab");
			var mainTabKey = oTab.getSelectedKey();
			if (mainTabKey == "Approvers configurations") {
				var aTableIndex = this.getView().byId("idSpecificConfigTable").getSelectedIndices();
				for (var i = 0; i < aTableIndex.length; i++) {
					this.getView().getModel("approverConfigModel").setProperty("/value/" + aTableIndex[i] + "/edit", false);
																   
				}
				this.fnReadApproverConfigurationData();										   
				this.getView().byId("idtab1Submit").setVisible(false);
				this.getView().byId("idtab1Cancel").setVisible(false);
				this.getView().byId("idtab1Edit").setVisible(true);										 
				this.getView().byId("idtab1Delete").setEnabled(false);
				this.getView().byId("idtab1Create").setEnabled(true);
				this.getView().byId("idSpecificConfigTable").clearSelection();
			} else if (mainTabKey == "Executers configurations"){
				var aTableIndex = this.getView().byId("idExecuterConfigTable").getSelectedIndices();
				for (var i = 0; i < aTableIndex.length; i++) {
					this.getView().getModel("executorConfigModel").setProperty("/value/" + aTableIndex[i] + "/edit", false);
				}
				this.fnIconTabFilterSelected();

				this.getView().byId("idtab2Submit").setVisible(false);
				this.getView().byId("idtab2Cancel").setVisible(false);
				this.getView().byId("idtab2Edit").setVisible(true);
				this.getView().byId("idtab2Delete").setEnabled(false);
				this.getView().byId("idtab1Create").setEnabled(true);
				this.getView().byId("idExecuterConfigTable").clearSelection();
			}else{
				var aTableIndex = this.getView().byId("idPhaseConfigTable").getSelectedIndices();
				for (var i = 0; i < aTableIndex.length; i++) {
					this.getView().getModel("phaseConfigModel").setProperty("/value/" + aTableIndex[i] + "/edit", false);
				}
				this.fnIconTabFilterSelected();
																												  
													 

				this.getView().byId("idtab10Submit").setVisible(false);
				this.getView().byId("idtab10Cancel").setVisible(false);
				this.getView().byId("idtab10Edit").setVisible(true);
				this.getView().byId("idtab10Delete").setEnabled(false);
				this.getView().byId("idtab10Create").setEnabled(true);
				this.getView().byId("idPhaseConfigTable").clearSelection();
			}
		},
	
		// function to enable edit and delete button in the Approver config,called when a row is selected in the table 
		fnApproverConfigTableRowSelected: function (evt) {

			var aRowSelected = this.getView().byId("idSpecificConfigTable").getSelectedIndices();
			if (aRowSelected.length > 0) {
				this.getView().byId("idtab1Edit").setEnabled(true);
				this.getView().byId("idtab1Delete").setEnabled(true);
				this.getView().byId("idtab1Create").setEnabled(false);

				this.getView().byId("idtab1Submit").setVisible(false);
				this.getView().byId("idtab1Cancel").setVisible(false);
				var aTableIndex = this.getView().getModel("approverConfigModel").getProperty("/value");
				for (var i = 0; i < aTableIndex.length; i++) {
					this.getView().getModel("approverConfigModel").setProperty("/value/" + aTableIndex[i] + "/edit", false);
				}
			} else {
				this.getView().byId("idtab1Edit").setEnabled(false);
				this.getView().byId("idtab1Delete").setEnabled(false);
				this.getView().byId("idtab1Create").setEnabled(true);
	  
																			 
																		 
											   
						
																	 

				this.getView().byId("idtab1Submit").setVisible(false);
								   
				this.getView().byId("idtab1Cancel").setVisible(false);

			}
		},
		// function to enable edit and delete button in the Executor config,called when a row is selected in the table 
		fnExecutorConfigTableRowSelected: function (evt) {
																															
		 
													

			var aRowSelected = this.getView().byId("idExecuterConfigTable").getSelectedIndices();
			if (aRowSelected.length > 0) {
				this.getView().byId("idtab2Edit").setEnabled(true);
				this.getView().byId("idtab2Delete").setEnabled(true);
				this.getView().byId("idtab2Create").setEnabled(false);
									   
								  
																		   
																				  
									 
									   
							  
												
												  
							  
																			   
																			   
								   

				this.getView().byId("idtab2Submit").setVisible(false);
				this.getView().byId("idtab2Cancel").setVisible(false);
			} else {
				this.getView().byId("idtab2Edit").setEnabled(false);
				this.getView().byId("idtab2Delete").setEnabled(false);
				this.getView().byId("idtab2Create").setEnabled(true);

				this.getView().byId("idtab2Submit").setVisible(false);
				this.getView().byId("idtab2Cancel").setVisible(false);
			}
		},
		fnPhaseConfigTableRowSelected: function (evt) {

			var aRowSelected = this.getView().byId("idPhaseConfigTable").getSelectedIndices();
			if (aRowSelected.length > 0) {
				this.getView().byId("idtab10Edit").setEnabled(true);
				this.getView().byId("idtab10Delete").setEnabled(true);
				this.getView().byId("idtab10Create").setEnabled(false);

				this.getView().byId("idtab10Submit").setVisible(false);
				this.getView().byId("idtab10Cancel").setVisible(false);
			} else {
				this.getView().byId("idtab10Edit").setEnabled(false);
				this.getView().byId("idtab10Delete").setEnabled(false);
				this.getView().byId("idtab10Create").setEnabled(true);

				this.getView().byId("idtab10Submit").setVisible(false);
				this.getView().byId("idtab10Cancel").setVisible(false);
			}
		},
			OnApprovalConfigViewDelete: function () {
				sap.m.MessageBox.confirm(
					this.oResourceBundle.getText("DELETE_CONFIRMATION"), // Message
					{
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
						onClose: function (sAction) { // Callback when the dialog is closed
							if (sAction === MessageBox.Action.YES) {
								var that = this;
								var deleteUrl = "odata/v4/data-services/deleteApproverItems";

								var aTableIndex = this.getView().byId("idSpecificConfigTable").getSelectedIndices();
								var aApproverConfigId = [];
								var oTable = this.getView().byId("idSpecificConfigTable");

								for (var i = 0; i < aTableIndex.length; i++) {
									//fetch the data of selected rows by index
									var tableContext = oTable.getContextByIndex(aTableIndex[i]);
									oTable.getModel("approverConfigModel").getProperty(tableContext.getPath());
									aApproverConfigId.push(this.getView().getModel("approverConfigModel").getProperty(tableContext.getPath() + "/ID"));
								}
								var oPayload = { "IDs": aApproverConfigId };

								BusyIndicator.show();
								$.ajax({
									url: deleteUrl,
									type: "POST",
									contentType: "application/json",
									data: JSON.stringify(oPayload)
								}).done(function (_data) {
									MessageToast.show(that.oResourceBundle.getText("CONFIG_DELETED"));
									var message = that.oResourceBundle.getText("CONFIG_APPR_DELETE_SUCCESS");
									that.onShowSuccess(message);
									// alert("DELETE successful");
									BusyIndicator.hide();
									that.fnReadApproverConfigurationData();
								}).fail(function (_xhr, _status, _error) {
									BusyIndicator.hide();
									MessageToast.show(that.oResourceBundle.getText("CONFIG_DEELTE_FAIL"));
									var message = that.oResourceBundle.getText("CONFIG_APPR_DELETE_FAIL");
									that.onShowError(message);

														  
														  
		   
														
														  
														 

								});
														  
	
	
												 

																					 
								 
														
														  
														   

							}
						}.bind(this)
					}
														 
														   
				);

			},
			OnExecutorConfigViewDelete: function () {
				sap.m.MessageBox.confirm(
					this.oResourceBundle.getText("DELETE_CONFIRMATION"), // Message
					{
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
						onClose: function (sAction) { // Callback when the dialog is closed
							if (sAction === MessageBox.Action.YES) {
                                var that = this;
								var deleteUrl = "odata/v4/data-services/deleteExecutorItems";
								var aTableIndex = this.getView().byId("idExecuterConfigTable").getSelectedIndices();
								var aExecutorConfigId = [];
								for (var i = 0; i < aTableIndex.length; i++) {
									aExecutorConfigId.push(this.getView().getModel("executorConfigModel").getProperty("/value/" + aTableIndex[i] + "/ID"));
								}
								var oPayload = { "IDs": aExecutorConfigId };

								BusyIndicator.show();
								$.ajax({
									url: deleteUrl,
									type: "POST",
									contentType: "application/json",
									data: JSON.stringify(oPayload)
								}).done(function (_data) {
									MessageToast.show(that.oResourceBundle.getText("CONFIG_DELETED"));
									var message = that.oResourceBundle.getText("CONFIG_EXE_DELETE_SUCCESS");
									that.onShowSuccess(message);
									BusyIndicator.hide();
									that.fnIconTabFilterSelected();
								}).fail(function (_xhr, _status, _error) {
									BusyIndicator.hide();
									MessageToast.show(that.oResourceBundle.getText("CONFIG_DEELTE_FAIL"));
									var message = that.oResourceBundle.getText("CONFIG_EXE_DELETE_FAIL");
									that.onShowError(message);
								});

												  
											   
																 
																						   
																														
	 
												

							}
						}.bind(this)
					}
				  
									 
								   
							 
																	   
																			  
								 
								   
						  
											
										   
						  
																		   
																		   
				);

			},
			OnPhaseConfigViewDelete: function () {
				sap.m.MessageBox.confirm(
					this.oResourceBundle.getText("DELETE_CONFIRMATION"), // Message
					{
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
						onClose: function (sAction) { // Callback when the dialog is closed
							if (sAction === MessageBox.Action.YES) {
                                var that = this;
								var deleteUrl = "odata/v4/data-services/deletePhaseItems";
				var aTableIndex = this.getView().byId("idPhaseConfigTable").getSelectedIndices();
				var aPhaseConfigId = [];
				for (var i = 0; i < aTableIndex.length; i++) {
					aPhaseConfigId.push(this.getView().getModel("phaseConfigModel").getProperty("/value/" + aTableIndex[i] + "/ID"));
				}
				var oPayload = { "IDs": aPhaseConfigId };

				BusyIndicator.show();
				$.ajax({
					url: deleteUrl,
					type: "POST",
					contentType: "application/json",
					data: JSON.stringify(oPayload)
				}).done(function (data) {
					var message = that.oResourceBundle.getText("CONFIG_PHASE_DELETE_SUCCESS");
					that.onShowSuccess(message);
					BusyIndicator.hide();
					that.fnIconTabFilterSelected();
				}).fail(function (xhr, status, error) {
					BusyIndicator.hide();
					var message = that.oResourceBundle.getText("CONFIG_PHASE_DELETE_FAIL");
					that.onShowError(message);

			});

												  
											   
																 
																						   
																														
	 
												

							}
						}.bind(this)
					}
				  
									 
								   
							 
																	   
																			  
								 
								   
						  
											
										   
						  
																		   
																		   
				);

			},
		// handleAcceptButton: function () {
																			 
																		 
											   
		// 	var that = this;
																	 
		// 	var oTab = this.getView().byId("idConfigTab");
		// 	var mainTabKey = oTab.getSelectedKey();
		// 	this._oPopover21.close();
		// 	if (mainTabKey == "Approvers configurations") {
		// 		////////////////// Approver Configuration multi delete///////////////////////////////
		// 		var deleteUrl = "odata/v4/data-services/deleteApproverItems";

		// 		var aTableIndex = this.getView().byId("idSpecificConfigTable").getSelectedIndices();
		// 		var aApproverConfigId = [];
		// 		var oTable = this.getView().byId("idSpecificConfigTable");
					  
										 
									   
								  
																		   
																				 
									 
							  
										
												  
							  
																			   
																			  
								   
		   

		// 		for (var i = 0; i < aTableIndex.length; i++) {
		// 			//fetch the data of selected rows by index
		// 			var tableContext = oTable.getContextByIndex(aTableIndex[i]);
		// 			var data = oTable.getModel("approverConfigModel").getProperty(tableContext.getPath());
		// 			aApproverConfigId.push(this.getView().getModel("approverConfigModel").getProperty(tableContext.getPath() + "/ID"));
		// 		}
		// 		var oPayload = { "IDs": aApproverConfigId };

		// 		BusyIndicator.show();
		// 		$.ajax({
		// 			url: deleteUrl,
		// 			type: "POST",
		// 			contentType: "application/json",
		// 			data: JSON.stringify(oPayload)
		// 		}).done(function (data) {
		// 			MessageToast.show(that.oResourceBundle.getText("CONFIG_DELETED"));
		// 			var message = that.oResourceBundle.getText("CONFIG_APPR_DELETE_SUCCESS");
		// 			that.onShowSuccess(message);
		// 			// alert("DELETE successful");
		// 			BusyIndicator.hide();
		// 			that.fnReadApproverConfigurationData();
		// 		}).fail(function (xhr, status, error) {
		// 			BusyIndicator.hide();
		// 			MessageToast.show(that.oResourceBundle.getText("CONFIG_DEELTE_FAIL"));
		// 			var message = that.oResourceBundle.getText("CONFIG_APPR_DELETE_FAIL");
		// 			that.onShowError(message);

	 
									   
					   
													 
											  
								
													  
																							 
																	 

		// 		});
								   
																  

													  
												   
																	 
																							   
																															
		 
													

		// 	} else if (mainTabKey == "Executers configurations"){
		// 		var deleteUrl = "odata/v4/data-services/deleteExecutorItems";
		// 		var aTableIndex = this.getView().byId("idExecuterConfigTable").getSelectedIndices();
		// 		var aExecutorConfigId = [];
		// 		for (var i = 0; i < aTableIndex.length; i++) {
		// 			aExecutorConfigId.push(this.getView().getModel("executorConfigModel").getProperty("/value/" + aTableIndex[i] + "/ID"));
		// 		}
		// 		var oPayload = { "IDs": aExecutorConfigId };
																				  
									 
									   
							  
												
											   
							  
																			   
																			   
								   

		// 		BusyIndicator.show();
		// 		$.ajax({
		// 			url: deleteUrl,
		// 			type: "POST",
		// 			contentType: "application/json",
		// 			data: JSON.stringify(oPayload)
		// 		}).done(function (data) {
		// 			MessageToast.show(that.oResourceBundle.getText("CONFIG_DELETED"));
		// 			var message = that.oResourceBundle.getText("CONFIG_EXE_DELETE_SUCCESS");
		// 			that.onShowSuccess(message);
		// 			BusyIndicator.hide();
		// 			that.fnIconTabFilterSelected();
		// 		}).fail(function (xhr, status, error) {
		// 			BusyIndicator.hide();
		// 			MessageToast.show(that.oResourceBundle.getText("CONFIG_DEELTE_FAIL"));
		// 			var message = that.oResourceBundle.getText("CONFIG_EXE_DELETE_FAIL");
		// 			that.onShowError(message);

		   

		// 		});
		// 	}else{
		// 		var deleteUrl = "odata/v4/data-services/deletePhaseItems";
		// 		var aTableIndex = this.getView().byId("idPhaseConfigTable").getSelectedIndices();
		// 		var aPhaseConfigId = [];
		// 		for (var i = 0; i < aTableIndex.length; i++) {
		// 			aPhaseConfigId.push(this.getView().getModel("phaseConfigModel").getProperty("/value/" + aTableIndex[i] + "/ID"));
		// 		}
		// 		var oPayload = { "IDs": aPhaseConfigId };

		// 		BusyIndicator.show();
		// 		$.ajax({
		// 			url: deleteUrl,
		// 			type: "POST",
		// 			contentType: "application/json",
		// 			data: JSON.stringify(oPayload)
		// 		}).done(function (data) {
		// 			var message = that.oResourceBundle.getText("CONFIG_PHASE_DELETE_SUCCESS");
		// 			that.onShowSuccess(message);
		// 			BusyIndicator.hide();
		// 			that.fnIconTabFilterSelected();
		// 		}).fail(function (xhr, status, error) {
		// 			BusyIndicator.hide();
		// 			var message = that.oResourceBundle.getText("CONFIG_PHASE_DELETE_FAIL");
		// 			that.onShowError(message);

		// 	});
		// }
		// 	this._oPopover21.close();
					  
										 
									   
								 
																		   
																				 
									 
							  
										
											   
							  
																			   
																			  
								   

		// },
		handleCloseButton: function () {
			if (this._oPopover21) {
				this._oPopover21.close();
			}
			var oTab = this.getView().byId("idConfigTab");
			var mainTabKey = oTab.getSelectedKey();
			if (mainTabKey == "Approvers configurations") {
				tableIndex = this.getView().byId("idSpecificConfigTable").setSelectedIndex(-1);
			} else {
				tableIndex = this.getView().byId("idExecuterConfigTable").setSelectedIndex(-1);
			}
		},

		onCreateApprover: function (evt) {
			var that = this;
			var iApprovalLevelCorrect = 0;
			var sApprover = sap.ui.getCore().byId("idApproverCreate").getValue();
			var sApproverJob = sap.ui.getCore().byId("idApp2").getValue();
			var sApproverBackup = sap.ui.getCore().byId("idApp3").getValue();
			var sApproverLevel = Number(sap.ui.getCore().byId("idApproverLevel").getValue());
			var aApproverData;

			if (this.getView().getModel("approverConfigModel") == undefined || this.getView().getModel("approverConfigModel").getProperty("/value").length == 0) {
				if (sApproverLevel == 1) {
					iApprovalLevelCorrect = 1;
							  
	 
												  
										   
												   
																					
				} else {
					sap.ui.getCore().byId("idApproverLevel").setValueState("Error");
					sap.ui.getCore().byId("idApproverLevel").setValueStateText(this.oResourceBundle.getText("CREATE_APPR_LEVEL1"));
				}
	 

			} else if (this.getView().getModel("approverConfigModel").getProperty("/value").length == 1) {
				aApproverData = this.getView().getModel("approverConfigModel").getProperty("/value");
				var approverCurrentHighLvl = aApproverData[0].approverLvl;
				////////////////////////////////////////////
				if (approverCurrentHighLvl != aApproverData.length) {
					for (var i = 0; i < approverCurrentHighLvl; i++) {
						if (approverCurrentHighLvl != i + 1) {
							if (sApproverLevel == i + 1) {
								iApprovalLevelCorrect = 1;
							}

						}
					}
				} else {
					if (sApproverLevel == 2) {
						iApprovalLevelCorrect = 1;
					} else {
						sap.ui.getCore().byId("idApproverLevel").setValueState("Error");
						sap.ui.getCore().byId("idApproverLevel").setValueStateText(this.oResourceBundle.getText("CREATE_APPR_LEVEL2"));
	  

																								  
																						  
															   
												 
														  
														
											 
									  
								   
		 

		
	   
			 
								
								 
			  
																	   
																													  
	   
					}


				}


																							  
																 
																						
														  
														
											 
									  
								   
			}

			if (this.getView().getModel("approverConfigModel").getProperty("/value").length > 1) {
				var aApproverData = this.getView().getModel("approverConfigModel").getProperty("/value");
				aApproverData.sort((a, b) => a.approverLvl - b.approverLvl);
				var approverCurrentHighLvl = aApproverData[(aApproverData.length) - 1].approverLvl;
				if (approverCurrentHighLvl != aApproverData.length) {
					for (var i = 0; i < approverCurrentHighLvl; i++) {
						if (approverCurrentHighLvl != i + 1) {
							if (sApproverLevel == i + 1) {
								iApprovalLevelCorrect = 1;
							}

						}
					}
				}
				else {


					if (sApproverLevel == Number(aApproverData[(aApproverData.length) - 1].approverLvl) + 1) {
						iApprovalLevelCorrect = 1;
					} else {
						iApprovalLevelCorrect = 0;
	   
					}

				}
																				

			}
			if (sApprover != "" && sApproverLevel != "" && iApprovalLevelCorrect == 1) {


				var postData = {
						configNo: sConfigNo,
						approver: sApprover,
						approverJob: sApproverJob,
						approverBkp: sApproverBackup,
						approverLvl: parseInt(sApproverLevel)

	   

				};
						  
			 
															 
				   
									 
									  
					   
	   
								 
							
																			  
																																						   
																									   
								   
											  
		
											 
							
																				  
																																						 
								 

				//POST
				BusyIndicator.show();
				$.ajax({
					url: "odata/v4/data-services/ConfigurationApproversDB",
					type: "POST",
					data: JSON.stringify(postData),
					contentType: "application/json",
					dataType: "json",
				})
				.done(function (response) {
					BusyIndicator.hide();
					MessageToast.show(that.oResourceBundle.getText("APPR_CONFIG_CREATED"));
					var message = that.oResourceBundle.getText("APPR_CONFIG_CREATE_SUCCESS") + "\nfor Approver :" + response.approver + ", Job :" + response.approverJob
					+ ",\n Approver Backup :" + response.approverBkp + ", Approver Level :" + response.approverLvl;
					that.onShowSuccess(message);
					that.fnReadApproverConfigurationData();
				})
				.fail(function (xhr, _status, _error) {
					BusyIndicator.hide();
					MessageToast.show(that.oResourceBundle.getText("APPR_CONFIG_NOT_CREATED"));
					var message = that.oResourceBundle.getText("APPR_CONFIG_CREATE_FAIL") + "\n" + xhr.responseJSON.error.code + ":" + xhr.responseJSON.error.message;
					that.onShowError(message);

		 
															
												  
												  
														   
							   

				});
				sap.ui.getCore().byId("idApproverCreate").setValue("");
				sap.ui.getCore().byId("idApp2").setValue("");
				sap.ui.getCore().byId("idApp3").setValue("");
				sap.ui.getCore().byId("idApproverLevel").setValue("");
				this.handleCloseButton1();

						   
																	   
																														 
			}
			else {
	  

				if (sApprover == "") {
					sap.ui.getCore().byId("idApproverCreate").setValueState("Error");
					sap.ui.getCore().byId("idApproverCreate").setValueStateText(this.oResourceBundle.getText("ENTER_APPR_NAME_ERROR"));
				} else {
					sap.ui.getCore().byId("idApproverCreate").setValueState("None");
				}

				if (sApproverLevel == "") {
																														 
			 
																	 
	  

									  
					sap.ui.getCore().byId("idApproverLevel").setValueState("Error");
					sap.ui.getCore().byId("idApproverLevel").setValueStateText(this.oResourceBundle.getText("ENTER_APPR_LEVEL_ERROR"));
				} else {
					sap.ui.getCore().byId("idApproverLevel").setValueState("None");
				}

				if (iApprovalLevelCorrect == 0) {
					sap.ui.getCore().byId("idApproverLevel").setValueState("Error");
					sap.ui.getCore().byId("idApproverLevel").setValueStateText(this.oResourceBundle.getText("ENTER_APPR_LEVEL_ERROR"));

				} else {
					sap.ui.getCore().byId("idApproverLevel").setValueState("None");
				}

			}


		},
		onCreateExecutor: function (evt) {
			var that = this;
			var sExecutor = sap.ui.getCore().byId("idExecutername").getValue();
			var sExecutorBackup = sap.ui.getCore().byId("idExecuterbackup").getValue();
			var sExecutorDescription = sap.ui.getCore().byId("idExecStep").getValue();
			if (sExecutor != "") {
				var postData = {
						configNo: sConfigNo,
						executor: sExecutor,
						executorBkp: sExecutorBackup,
						executorStpDesc: sExecutorDescription,
				};

				//POST
				BusyIndicator.show();
				$.ajax({
					url: "odata/v4/data-services/ConfigurationExecutorsDB",
					type: "POST",
					data: JSON.stringify(postData),
					contentType: "application/json",
					dataType: "json",
				})
				.done(function (response) {
					BusyIndicator.hide();

					MessageToast.show(that.oResourceBundle.getText("EXE_CONFIG_CREATED"));
					var message = that.oResourceBundle.getText("EXE_CONFIG_CREATE_SUCCESS")+ "\n for Executor :" + response.executor + ",Executor Backup :" + response.executorBkp + ", Description :" + response.executorStpDesc;
					that.onShowSuccess(message);

					that.fnIconTabFilterSelected();
				})
				.fail(function (xhr, _status, _error) {
					BusyIndicator.hide();
					MessageToast.show(that.oResourceBundle.getText("APPR_CONFIG_NOT_CREATED"));

					var message = that.oResourceBundle.getText("EXE_CONFIG_CREATE_FAIL")+ "\n" + xhr.responseJSON.error.code + ":" + xhr.responseJSON.error.message;
					that.onShowError(message);

				});

				sap.ui.getCore().byId("idExecutername").setValue("");
				sap.ui.getCore().byId("idExecuterbackup").setValue("");
				sap.ui.getCore().byId("idExecStep").setValue("");

				this.handleCloseButton2();

			}
			else {
				if (sExecutor == "") {
					sap.ui.getCore().byId("idExecutername").setValueState("Error");
					sap.ui.getCore().byId("idExecutername").setValueStateText(that.oResourceBundle.getText("ENTER_CORRECT_EXECUTOR"));
				} else {
					sap.ui.getCore().byId("idExecutername").setValueState("None");
				}
			}

		},
		// Configuration screen create function       

		onShowWarning: function (message) {
			sap.m.MessageBox.warning(
					message, {
						title: "Warning",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function () { }
					}
			);
		},
		onShowSuccess: function (message) {
			sap.m.MessageBox.success(
					message, {
						title: "Success",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function () { }
					}
			);
		},
		onShowError: function (message) {
			sap.m.MessageBox.error(
					message, {
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function () { }
					}
			);
		},
		onEditUserValueHelp:function(oEvent){
			var oTab = this.getView().byId("idConfigTab");
			var mainTabKey = oTab.getSelectedKey();
			var oInput = oEvent.getSource();
			var oContext = mainTabKey === "Approvers configurations"? oInput.getBindingContext("approverConfigModel"): oInput.getBindingContext("executorConfigModel");
			iUserSelectedIndex = oContext.getPath().split("/").pop();
			if (!this._oApproverHelp) {
				this._oApproverHelp = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.ApproverExecutorConfigValueHelp", this);
				this.getView().addDependent(this._oApproverHelp);
			}
			this._oApproverHelp.open();
			flag = 1;
		 	mainTabKey === "Approvers configurations"? sap.ui.getCore().byId("idApprExecValuehelpDialog").setTitle("Authorized Approver Display") : sap.ui.getCore().byId("idApprExecValuehelpDialog").setTitle("Authorized Executor Display"); 
			sap.ui.getCore().byId("userDetailsTable").clearSelection();
			
			
		},
		onUserValueHelp: function(){
			if (!this._oApproverHelp) {
				this._oApproverHelp = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.ApproverExecutorConfigValueHelp", this);
				this.getView().addDependent(this._oApproverHelp);
			}
			this._oApproverHelp.open();
			
			var oTab = this.getView().byId("idConfigTab");
			var mainTabKey = oTab.getSelectedKey();
		 	mainTabKey === "Approvers configurations"? sap.ui.getCore().byId("idApprExecValuehelpDialog").setTitle("Authorized Approver Display") : sap.ui.getCore().byId("idApprExecValuehelpDialog").setTitle("Authorized Executor Display"); 
			if(this.getView().getModel("userHelpModel") !== undefined){
			this.getView().getModel("userHelpModel").setData({ results: [] });
			sap.ui.getCore().byId("firstName").setValue();
			sap.ui.getCore().byId("nbID").setValue();
			sap.ui.getCore().byId("lastName").setValue();
			}
			flag = 0;	
		},
		onSearchUser: function(){
			var nbId = sap.ui.getCore().byId("nbID").getValue();
			var firstName = sap.ui.getCore().byId("firstName").getValue().toLowerCase();
			var LastName = sap.ui.getCore().byId("lastName").getValue().toLowerCase();
			var plant = sPlant;
			var oTab = this.getView().byId("idConfigTab");
			var mainTabKey = oTab.getSelectedKey();
			var userType = mainTabKey === "Approvers configurations"? "A" : "E"
			var userUrl = "/ETY_APPROVER_EXECUTOR_VHSet";
			BusyIndicator.show(0);
			var oNBID = new Filter({
				filters: [
					new Filter("UserName", FilterOperator.EQ, nbId)
					]
			});
			var ofirstName = new Filter({
				filters: [
					new Filter("Name_First", FilterOperator.EQ, firstName)
					]
			});
			var oLastName = new Filter({
				filters: [
					new Filter("Name_Last", FilterOperator.EQ, LastName)
					]
			});
			var oPlant = new Filter({
				filters: [
					new Filter("Plant", FilterOperator.EQ, plant)
					]
			});
			var oUserType = new Filter({
				filters: [
					new Filter("User_Type", FilterOperator.EQ, userType)
					]
			});
			

			if (oODataModel) {
				oODataModel.read(userUrl, {
					headers: mHeaders,
					filters: [oNBID, ofirstName, oLastName, oPlant, oUserType],
					headers: mHeaders,
					success: function (oData) {
						if(oData.results.length>0){
							if(oData.results[0].Record_Exceed === ""){
						var oUserHelpModel = new sap.ui.model.json.JSONModel();
						oUserHelpModel.setData(oData);
						this.getView().setModel(oUserHelpModel, "userHelpModel");
						BusyIndicator.hide();
							}else{
							var message = this.oResourceBundle.getText("USER_ADDITIONAL_DEATILS_REQUIRED");
							this.onShowWarning(message);
							BusyIndicator.hide();
							}
						}else{
							var message = this.oResourceBundle.getText("NO_RECORDS_FOUND");
							this.onShowWarning(message);
							BusyIndicator.hide();
						}
						
					}.bind(this),
					error: function (jqXHR) {
						let errorMessage = jqXHR.responseText ?
								JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
								// Handle errors
								MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
								BusyIndicator.hide();
							}
				});
			} else {
				MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
			}

		},
		fnUserTableSelected: function(){
			var oTable = sap.ui.getCore().byId("userDetailsTable");
			var iSelectedIndex = oTable.getSelectedIndex();
			if (sap.ui.getCore().byId("userDetailsTable").getSelectedIndices().length === 1){
				var oModel = this.getView().getModel("userHelpModel");
				
				var oTab = this.getView().byId("idConfigTab");
				var mainTabKey = oTab.getSelectedKey();
				
					if (flag === 1){
						mainTabKey === "Approvers configurations"?
						this.getView().getModel("approverConfigModel").setProperty("/value/" + iUserSelectedIndex + "/approver", oModel.getData().results[iSelectedIndex].UserName):
						this.getView().getModel("executorConfigModel").setProperty("/value/" + iUserSelectedIndex + "/executor", oModel.getData().results[iSelectedIndex].UserName);
					} else{
						mainTabKey === "Approvers configurations"?
					sap.ui.getCore().byId("idApproverCreate").setValue(oModel.getData().results[iSelectedIndex].UserName):
				
					sap.ui.getCore().byId("idExecutername").setValue(oModel.getData().results[iSelectedIndex].UserName);
					}
					this._oApproverHelp.close();
				}
			
		},
		handleUserCancelDialog: function(){
			if(this._oApproverHelp){
			this._oApproverHelp.close();
			}
		},
		onAddPhase: function () {
			if (!this._oPhasePopover) {
				this._oPhasePopover = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.PhaseConfigCreate", this);
				this.getView().addDependent(this._oPhasePopover);
			}
			this._oPhasePopover.open();
		},
		onPhaseTypeChange: function(oEvent){
			var oComboBox = oEvent.getSource();
   			var oSelectedItem = oComboBox.getSelectedItem();
    		var sItemCode = oSelectedItem.getAdditionalText();
			sap.ui.getCore().byId("idPhaseType").setValue(sItemCode);
		},

		handlePhaseConfigCloseButton: function(){
			if (this._oPhasePopover){
				this._oPhasePopover.close();
				sap.ui.getCore().byId("idPhaseName").setValue("");
				sap.ui.getCore().byId("idPhaseCtrlKey").setValue("");
				sap.ui.getCore().byId("idBeforeRTPhase").setSelected(false);
			sap.ui.getCore().byId("idAfterRTPhase").setSelected(false);
			sap.ui.getCore().byId("idAfterRTPhase").setEditable(true);
			sap.ui.getCore().byId("idBeforeRTPhaseLbl").setRequired(true);
			sap.ui.getCore().byId("idBeforeRTPhase").setEditable(true);
			sap.ui.getCore().byId("idAfterRTPhaseLbl").setRequired(true);

				sap.ui.getCore().byId("idPhaseDestKey").setValue("");
				sap.ui.getCore().byId("idPhaseType").setValue("");
			}
		},
		onBeforePhaseFlagSelection: function(){
			if (sap.ui.getCore().byId("idBeforeRTPhase").getSelected() === true){
				sap.ui.getCore().byId("idAfterRTPhase").setEditable(false);
				sap.ui.getCore().byId("idAfterRTPhaseLbl").setRequired(false);
			} else{
				sap.ui.getCore().byId("idAfterRTPhase").setEditable(true);
				sap.ui.getCore().byId("idAfterRTPhaseLbl").setRequired(true);
			}
		},
		onAfterPhaseFlagSelection: function(){
			if (sap.ui.getCore().byId("idAfterRTPhase").getSelected() === true){
				sap.ui.getCore().byId("idBeforeRTPhase").setEditable(false);
				sap.ui.getCore().byId("idBeforeRTPhaseLbl").setRequired(false);
			} else{
				sap.ui.getCore().byId("idBeforeRTPhase").setEditable(true);
				sap.ui.getCore().byId("idBeforeRTPhaseLbl").setRequired(true);
			}
		},
		onCreatePhase: function () {			
			var that = this;
			var oPhaseName = sap.ui.getCore().byId("idPhaseName").getValue();
			var oPhaseCtrlKey = sap.ui.getCore().byId("idPhaseCtrlKey").getValue();
			var oBeforePhaseFlag = sap.ui.getCore().byId("idBeforeRTPhase").getSelected();
			var oAfterPhaseFlag = sap.ui.getCore().byId("idAfterRTPhase").getSelected();
			var oPhaseDestKey = sap.ui.getCore().byId("idPhaseDestKey").getValue();
			var oPhaseType = sap.ui.getCore().byId("idPhaseType").getValue();
			if (oPhaseType === "Q"){
				if (oPhaseCtrlKey.startsWith("Q")){
					var proceedFlag = 1;
				}else{
					var proceedFlag = 0;
					var message = this.oResourceBundle.getText("PHASE_CONFIG_TYPE_ERROR");
					this.onShowError(message);
				}
			}
			else if (oPhaseType !== "Q"){
				if (oPhaseCtrlKey.startsWith("Q")){
					var proceedFlag = 0;
					var message = this.oResourceBundle.getText("PHASE_CONFIG_TYPE_ERROR");
					this.onShowError(message);
			}else{
				var proceedFlag = 1;
			}
		}
			if (proceedFlag ===1){
			if (oPhaseName !== "" && oPhaseCtrlKey !== "" && ((oBeforePhaseFlag !== false && oAfterPhaseFlag === false) ||(oBeforePhaseFlag === false && oAfterPhaseFlag !== false) )  && oPhaseDestKey!== "" && oPhaseType!=="") {
				var postData = {
						configNo: sConfigNo,
						phaseName: oPhaseName,
						phaseControlKey: oPhaseCtrlKey,
						beforeRunTimePhase: oBeforePhaseFlag,
						afterRunTimePhase: oAfterPhaseFlag,
						destinationKey: oPhaseDestKey,
						phaseType: oPhaseType,
				};

				//POST
				BusyIndicator.show();
				$.ajax({
					url: "odata/v4/data-services/PhaseDB",
					type: "POST",
					data: JSON.stringify(postData),
					contentType: "application/json",
					dataType: "json",
				})
				.done(function (response) {
					BusyIndicator.hide();
					var message = that.oResourceBundle.getText("PHASE_CONFIG_CREATE_SUCCESS");
					that.onShowSuccess(message);

					that.fnIconTabFilterSelected();
				})
				.fail(function (xhr, _status, _error) {
					BusyIndicator.hide();
					var message = that.oResourceBundle.getText("PHASE_CONFIG_CREATE_FAIL")+ "\n" + xhr.responseJSON.error.code + ":" + xhr.responseJSON.error.message;
					that.onShowError(message);

				});

			sap.ui.getCore().byId("idPhaseName").setValue("");
			sap.ui.getCore().byId("idPhaseCtrlKey").setValue("");
			sap.ui.getCore().byId("idBeforeRTPhase").setSelected(false);
			sap.ui.getCore().byId("idAfterRTPhase").setSelected(false);
			sap.ui.getCore().byId("idAfterRTPhase").setEditable(true);
			sap.ui.getCore().byId("idBeforeRTPhaseLbl").setRequired(true);
			sap.ui.getCore().byId("idBeforeRTPhase").setEditable(true);
			sap.ui.getCore().byId("idAfterRTPhaseLbl").setRequired(true);
			sap.ui.getCore().byId("idPhaseDestKey").setValue("");
			sap.ui.getCore().byId("idPhaseType").setValue("");
			this.handlePhaseConfigCloseButton();
				
			}
			else {
				if (oPhaseName === "") {
					sap.ui.getCore().byId("idPhaseName").setValueState("Error");
					sap.ui.getCore().byId("idPhaseName").setValueStateText(that.oResourceBundle.getText("ENTER_CORRECT_PHASE"));
				} if (oPhaseCtrlKey === "") {
					sap.ui.getCore().byId("idPhaseCtrlKey").setValueState("Error");
					sap.ui.getCore().byId("idPhaseCtrlKey").setValueStateText(that.oResourceBundle.getText("ENTER_CORRECT_PHASECTRKEY"));
				}
				if (oBeforePhaseFlag === false && oAfterPhaseFlag === false ) {
					sap.ui.getCore().byId("idBeforeRTPhase").setValueState("Error");
					sap.ui.getCore().byId("idBeforeRTPhase").setValueStateText(that.oResourceBundle.getText("ENTER_CORRECT_BEFOREFLAG"));
					sap.ui.getCore().byId("idAfterRTPhase").setValueState("Error");
					sap.ui.getCore().byId("idAfterRTPhase").setValueStateText(that.oResourceBundle.getText("ENTER_CORRECT_AFTERFLAG"));
					
										   
							 
				}
				if (oPhaseDestKey === "") {
					sap.ui.getCore().byId("idPhaseDestKey").setValueState("Error");
					sap.ui.getCore().byId("idPhaseDestKey").setValueStateText(that.oResourceBundle.getText("ENTER_CORRECT_PHASEDESTKEY"));
				}
				if (oPhaseType === "") {
					sap.ui.getCore().byId("idPhaseType").setValueState("Error");
					sap.ui.getCore().byId("idPhaseType").setValueStateText(that.oResourceBundle.getText("ENTER_CORRECT_PHASETYPE"));
				}
				
			}

		}
	}


	});
});
