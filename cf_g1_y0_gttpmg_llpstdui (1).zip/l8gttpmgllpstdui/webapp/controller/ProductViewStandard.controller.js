sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	'sap/ui/core/BusyIndicator',
	'sap/m/MessageToast',
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"l8gttpmgllpstdui/controller/BaseController",
	"sap/m/MessageBox"
	],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function(Controller, History, BusyIndicator, MessageToast, Filter, FilterOperator,BaseController, MessageBox) {
	"use strict";
	var tableIndex, oODataModel,prdStdNo, plant, selectedVariant,selectedPlant, ID, matUom, plantsParam,globalRoleVal,selectedZone,userId, iMatSelectedIndex, desc, resource, costCenter, lotSize, mrNo, mrCounter, chargeQty, operationQty, percentageAI, validFrom, validTo, bottleneckCorrect,apikey;
	var deleteProdStdMaterialData = [];
	var deleteProdStdVarDtData = [];
	var deleteProdStdSecResData = [];
	var prodBttlnckControlKeyData = [];
	var deleteProdStdBottleneckData = [];
	var mHeaders = [];
	var aMaterialData, aSecResData, aVariableDtData, aBottlenecDbData;
	return BaseController.extend("l8gttpmgllpstdui.controller.ProductViewStandard", {

		onInit: function() {
			const oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("onProductViewStandard").attachPatternMatched(this.onObjectMatched, this);
			this.oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();																					 
		},
		onObjectMatched(oEvent) { 
			prdStdNo = oEvent.getParameter("arguments").prdStdNo;
			ID = oEvent.getParameter("arguments").ID;
			selectedPlant = oEvent.getParameter("arguments").selectedPlant;
			globalRoleVal = oEvent.getParameter("arguments").globalRoleVal;
			selectedZone = oEvent.getParameter("arguments").selectedZone;
			userId = oEvent.getParameter("arguments").userId;
			selectedVariant = oEvent.getParameter("arguments").selectedVariant;
			this.oglobalResponseModel = this.getOwnerComponent().getModel("globalResponseModel");
			oODataModel = this.getOwnerComponent().getModel();
			var currentURL = window.location.href;
			var url = new URL(currentURL);
			var host = url.host;
			var oResourceBundle = this.getView().getModel("util").getResourceBundle();
			if (host.startsWith("poc") || host.startsWith("dev") ){
				apikey = oResourceBundle.getText("apiKey_Dev");

			} else if (host.startsWith("ppd")){
				apikey = oResourceBundle.getText("apiKey_PPD");
			} else{
				apikey = oResourceBundle.getText("apiKey_PRD");
			}
			var alias = selectedZone === "AOA" ? oResourceBundle.getText("zoneAOA_Alias") :
				selectedZone === "EUR" ? oResourceBundle.getText("zoneEUR_Alias") :
					selectedZone === "AMS" ? oResourceBundle.getText("zoneAMS_Alias") :
						"";
					mHeaders = {
							"apikey": apikey,
							"username": userId,
							"sysali": alias
					};
					this.getProdStdDbData();
					var url = "/ETY_PLANT_SHSet";
					if (oODataModel) {
						oODataModel.read(url, {
							headers: mHeaders,
							success: function(oData) {
								var oModelPlant = new sap.ui.model.json.JSONModel();
								oModelPlant.setData(oData);
								this.getView().setModel(oModelPlant, "plantModel1");
								var aPlantData = this.getView().getModel("plantModel1").getData().results;
								var plantIds = [];
								for (var i = 0; i < aPlantData.length; i++) {
									var plant = aPlantData[i].Werks;
									plantIds.push(plant);
								}
								plantsParam = plantIds.join(',');
							}.bind(this),
							error: function(oError) {
								// Handle errors
								MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
							}
						});
					} else {
						MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
					}
					var url = "/ETY_SPEED_UOMSet";
					var oFilterSpeed = new Filter({
						filters: [
							new Filter("DIMID", FilterOperator.EQ, "SPEED")
							]
					});
					if (oODataModel) {
						oODataModel.read(url, {
							headers: mHeaders,
							filters: [oFilterSpeed],
							success: function(oData) {
								var oUomModel = new sap.ui.model.json.JSONModel();
								oUomModel.setData(oData);
								oUomModel.setSizeLimit(3000);
								this.getView().setModel(oUomModel, "uomModel")
							}.bind(this),
							error: function(oError) {
								// Handle errors
								MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
							}
						});
					} else {
						MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
					}
					var url = "/ETY_CONTROL_KEYSet";
					if (oODataModel) {
						oODataModel.read(url, {
							headers: mHeaders,
							success: function(oData) {
								var oModelControlKey = new sap.ui.model.json.JSONModel();
								oModelControlKey.setData(oData);
								this.getView().setModel(oModelControlKey, "controlKeyModel");
							}.bind(this),
							error: function(oError) {
								// Handle errors
								MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
							}
						});
					} else {
						MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
					}
					var url = "/ETY_RESOURCE_SHSet";
					var oFilterPlant = new Filter({
						filters: [
							new Filter("Werks", FilterOperator.EQ, selectedPlant)
							]
					});
					if (oODataModel) {
						oODataModel.read(url, {
							headers: mHeaders,
							filters: [oFilterPlant],
							success: function(response) {
								// Create and set the JSONModel with the data received
								var oModelResource = new sap.ui.model.json.JSONModel();
								oModelResource.setData(response);
								this.getView().setModel(oModelResource, "resourceModel");
							}.bind(this),
							error: function(xhr, status, error) {
								let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
										xhr.responseJSON.error.message :
											this.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
								MessageToast.show(this.oResourceBundle.getText("PROD_VIEW_RES_FETCH_FAIL")+ " " + errorMessage);
							}.bind(this),
						})
					} else {
						MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
					}
					// var url = "/ETY_MATERIAL_LISTSet";
					// var oFilterPlant = new Filter({
					// 	filters: [
					// 		new Filter("WERKS", FilterOperator.EQ, selectedPlant)
					// 		]
					// });

					// if (oODataModel) {
					// 	oODataModel.read(url, {
					// 		headers: mHeaders,
					// 		filters: [oFilterPlant],
					// 		success: function(oData) {
					// 			var oModelMaterial = new sap.ui.model.json.JSONModel();
					// 			oModelMaterial.setData(oData);
					// 			this.getView().setModel(oModelMaterial, "materialModel");
					// 		}.bind(this),
					// 		error: function(xhr, status, error) {
					// 			// Handle errors
					// 			BusyIndicator.hide();
					// 			let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
					// 					xhr.responseJSON.error.message :
					// 						this.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
					// 			MessageToast.show(this.oResourceBundle.getText("MATERIAL_DB_FAIL") + " " + errorMessage);
					// 		}.bind(this),
					// 	})
					// } else {
					// 	MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
					// }
					var url = "/ETY_CONTROL_DESTSet";
					var oFilterPlant = new Filter({
						filters: [
							new Filter("WERKS", FilterOperator.EQ, selectedPlant)
							]
					});
					if (oODataModel) {
						oODataModel.read(url, {
							headers: mHeaders,
							filters: [oFilterPlant],
							success: function(response) {
								// Create and set the JSONModel with the data received
								var oModelDestination = new sap.ui.model.json.JSONModel();
								oModelDestination.setData(response);
								this.getView().setModel(oModelDestination, "destinationModel");
							}.bind(this),
							error: function(xhr, status, error) {
								let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
										xhr.responseJSON.error.message :
											this.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
								MessageToast.show(this.oResourceBundle.getText("DESTINATION_KEY_FETCH_FAIL")+ " " + errorMessage);
							}.bind(this),
						})
					} else {
						MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
					}
					var filterModel = new sap.ui.model.json.JSONModel();
					filterModel.setData({
						"Resource": [{
							Machine: "Filler",
						},
						{
							Machine: "Mixer",
						},
						{
							Machine: "Grinder",
						},
						{
							Machine: "Packer",
						}
						],
					});
					this.getView().setModel(filterModel, "filterModel");
					if (globalRoleVal === "View") {
						this.getView().byId("idtabBottleneckEdit").setVisible(false);
						this.getView().byId("idtabBottleneckDelete").setVisible(false);
						this.getView().byId("idtabSecondaryEdit").setVisible(false);
						this.getView().byId("idtabSecondaryDelete").setVisible(false);
						this.getView().byId("idtab5Edit").setVisible(false);
						this.getView().byId("idtab5Delete").setVisible(false);
						this.getView().byId("idtab6Edit").setVisible(false);
						this.getView().byId("idtab6Delete").setVisible(false);
					} else {
						this.getView().byId("idtabBottleneckEdit").setVisible(true);
						this.getView().byId("idtabBottleneckDelete").setVisible(false);
						this.getView().byId("idtabSecondaryEdit").setVisible(true);
						this.getView().byId("idtabSecondaryDelete").setVisible(true);
						this.getView().byId("idtab5Edit").setVisible(true);
						this.getView().byId("idtab5Delete").setVisible(true);
						this.getView().byId("idtab6Edit").setVisible(true);
						this.getView().byId("idtab6Delete").setVisible(true);
						this.getView().byId("idtabBottleneckEdit").setEnabled(false);
						this.getView().byId("idtabBottleneckDelete").setEnabled(false);
						this.getView().byId("idtabSecondaryEdit").setEnabled(false);
						this.getView().byId("idtabSecondaryDelete").setEnabled(false);
						this.getView().byId("idtab5Edit").setEnabled(false);
						this.getView().byId("idtab5Delete").setEnabled(false);
						this.getView().byId("idtab6Edit").setEnabled(false);
						this.getView().byId("idtab6Delete").setEnabled(false);
					}
		},
		onCopyCapacityValueChange: function(oEvent) {
			var oModel = this.getView().getModel("globalResponseModel");
			var sPath = oEvent.getSource().getBindingContext("globalResponseModel").getPath();
			var index = sPath.split("/").pop();
			var resource = oModel.getData().standardCycleData[index].resource;
			var sValue = oEvent.getParameter("value");
			var oInput = oEvent.getSource();
			var url = "/ETY_CAPACITY_NUMBERSet";
			var oFilterPlant = new Filter({
				filters: [
					new Filter("Werks", FilterOperator.EQ, selectedPlant)
					]
			});
			var oFilterResource = new Filter({
				filters: [
					new Filter("Arbpl", FilterOperator.EQ, resource)
					]
			});
			if (oODataModel) {
				oODataModel.read(url, {
					headers: mHeaders,
					filters: [oFilterPlant, oFilterResource],
					success: function(oData) {
						// Create and set the JSONModel with the data received
						var oModelCapacity = new sap.ui.model.json.JSONModel();
						oModelCapacity.setData(oData);
						var data = oModelCapacity.getData();
						if (data && data.results && data.results.length > 0) {
							var maxCapacityValue = data.results[0].Aznor;
						}
						if (parseFloat(sValue) > parseFloat(maxCapacityValue)) {
							oInput.setValueState(sap.ui.core.ValueState.Error);
							oInput.setValueStateText(this.oResourceBundle.getText("CAPACITY_VALUE_ERROR")+ " " + maxCapacityValue);
						} else {
							oInput.setValueState(sap.ui.core.ValueState.None);
							oInput.setValueStateText("");
						}
					}.bind(this),
					error: function(oError) {
						// Handle errors
						MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
					}
				});
			} else {
				MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
			}
		},
		onUpdateControlKeySelectionChange: function(oEvent) {
			var oComboBox = oEvent.getSource();
			var sSelectedKey = oComboBox.getSelectedKey();
			var oModel = this.getView().getModel("globalResponseModel");
			var oContext = oComboBox.getBindingContext("globalResponseModel");
			var index = oContext.getPath().split("/").pop();
			var previousControlKey = prodBttlnckControlKeyData[index].steus;
			var sPath = oContext.getPath();
			if (sSelectedKey === "YBN1" || sSelectedKey === "YBN2" || sSelectedKey === "YBN3") {
				oComboBox.setSelectedKey(previousControlKey);
				var message = this.oResourceBundle.getText("SELECT_CNTRL_KEY_ERROR"); // Clear the controlKey value for custom input
				this.onShowWarning(message);
			}
		},
		getProdViewMaterialDB: function(oEvent) {
			var that = this;
			var oInput = oEvent.getSource();
			var oContext = oInput.getBindingContext("globalResponseModel");
			iMatSelectedIndex = oContext.getPath().split("/").pop();
			if (!this._oMaterialDialog) {
				this._oMaterialDialog = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.ProductStandardMaterialDialog", this);
				this.getView().addDependent(this._oMaterialDialog);
			}
			this.getAssignedMaterialList();
			
			sap.ui.getCore().byId("addMRcomponentMat").setVisible(false);
			sap.ui.getCore().byId("updateMRcomponentMat").setVisible(true);
			sap.ui.getCore().byId("addCopyMRcomponentMat").setVisible(false);
			if (sap.ui.getCore().byId("searchField").getValue() !== "") {
				sap.ui.getCore().byId("searchField").setValue();
				sap.ui.getCore().byId("idMaterialDialogDB").clearSelection();
				var url = "/ETY_MATERIAL_LISTSet";
				BusyIndicator.show(0);
				var oFilterPlant = new Filter({
					filters: [
						new Filter("WERKS", FilterOperator.EQ, selectedPlant)
						]
				});
				var oFilterUom = new Filter({
					filters: [
						new Filter("MEINH", FilterOperator.EQ, matUom)
						]
				});

				if (oODataModel) {
					oODataModel.read(url, {
						headers: mHeaders,
						filters: [oFilterPlant,oFilterUom],
						success: function(oData) {
							// var results = oData.results;

							// var filteredResults = results.filter(function(item) {
							// 	return item.MEINH === matUom;
							// });

							// Create and set the JSONModel with the data received
							var oModelMaterial = new sap.ui.model.json.JSONModel();
							oModelMaterial.setData(oData);
							oModelMaterial.setSizeLimit(10000);
							this.getView().setModel(oModelMaterial, "materialModel");
							BusyIndicator.hide();

						}.bind(this),
						error: function(xhr, _status, _error) {
							// Handle errors
							BusyIndicator.hide();
							let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
									xhr.responseJSON.error.message :
										that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
							MessageToast.show(that.oResourceBundle.getText("MATERIAL_DB_FAIL")+ " " + errorMessage);
						}
					});
				} else {
					MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
					BusyIndicator.hide();
				}
			}
		},
		getAssignedMaterialList: function(){
			var url = "/ETY_MATERIAL_LISTSet";
				BusyIndicator.show(0);
				var oFilterPlant = new Filter({
					filters: [
						new Filter("WERKS", FilterOperator.EQ, selectedPlant)
						]
				});
				var oFilterUom = new Filter({
					filters: [
						new Filter("MEINH", FilterOperator.EQ, matUom)
						]
				});

				if (oODataModel) {
					oODataModel.read(url, {
						headers: mHeaders,
						filters: [oFilterPlant,oFilterUom],
						success: function(oData) {
							// var results = oData.results;

							// var filteredResults = results.filter(function(item) {
							// 	return item.MEINH === matUom;
							// });

							// Create and set the JSONModel with the data received
							var oModelMaterial = new sap.ui.model.json.JSONModel();
							oModelMaterial.setData(oData);
							oModelMaterial.setSizeLimit(10000);
							this.getView().setModel(oModelMaterial, "materialModel");
							this._oMaterialDialog.open();
							BusyIndicator.hide();

						}.bind(this),
						error: function(xhr, status, error) {
							// Handle errors
							BusyIndicator.hide();
							let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
									xhr.responseJSON.error.message :
										that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
							MessageToast.show(that.oResourceBundle.getText("MATERIAL_DB_FAIL")+ " " + errorMessage);
						}
					});
				} else {
					MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
					BusyIndicator.hide();
				}
			},
		UpdateMaterialDB: function() {
			var oMatTable = sap.ui.getCore().byId("idMaterialDialogDB");
			var matIndex = oMatTable.getSelectedIndices();
			if (matIndex.length == 0) {
				var message = this.oResourceBundle.getText("SELECT_MATERIAL_UPDATE_ERROR")
				this.onShowWarning(message);
			} else if (matIndex.length == 1) {
				var material = oMatTable.getContextByIndex(matIndex).getProperty("MATNR");
				var materialDesc = oMatTable.getContextByIndex(matIndex).getProperty("MAKTX");
				var oModel = this.getView().getModel("globalResponseModel");
				oModel.setProperty("/materialData/" + iMatSelectedIndex + "/material", material);
				oModel.setProperty("/materialData/" + iMatSelectedIndex + "/materialDesc", materialDesc);
				this.getView().byId("idMaterialDB5").setModel(oModel, "globalResponseModel");
			} else {
				var matmessage = this.oResourceBundle.getText("SELECT_SINGLE_MATERIAL_ERROR")
				this.onShowWarning(matmessage);
			}
			this._oMaterialDialog.close();
			this._oMaterialDialog.destroy();  
			this._oMaterialDialog = null;
		},
		handleCloseMatDialogButton: function() {
			this._oMaterialDialog.close();
			this._oMaterialDialog.destroy();  
			this._oMaterialDialog = null;
			sap.ui.getCore().byId("searchField").setValue();
		},
		backToMatWizardContent: function() {
			this._oMaterialDialog.close();
			this._oMaterialDialog.destroy();  
			this._oMaterialDialog = null;
			sap.ui.getCore().byId("searchField").setValue();
		},
		onMatSearch: function(oEvent) {
			var sQuery = oEvent.getParameter("query") || oEvent.getParameter("newValue");
			var oTable = sap.ui.getCore().byId("idMaterialDialogDB");
			var oBinding = oTable.getBinding("rows");
			var aFilters = [];
			if (sQuery && sQuery.length > 0) {
				// Create a filter for each column
				var oFilter = new Filter({
					filters: [
						new Filter("MATNR", FilterOperator.Contains, sQuery),
						new Filter("MAKTX", FilterOperator.Contains, sQuery)
						],
						and: false
				});
				aFilters.push(oFilter);
			}
			// Apply filters to the table binding
			oBinding.filter(aFilters);
		},
		getProdStdDbData: function() {
			var that = this;
			BusyIndicator.show();
			var url = `odata/v4/data-services/ProductRelStandardHeadersDB(ID=${ID},prodStdNo='${prdStdNo}')?$expand=ProdStdToProdBttlnckDataNav,ProdStdToProdSecResDataNav,ProdStdToProdVarDtDataNav,ProdStdToProdMatrAllDataNav`;
			$.ajax({
				url : url,
				method: 'GET',
				headers: {
					'x-username' : userId,
					'x-zone': selectedZone,
					'x-plants': plantsParam,
					'x-role': "Creator/Editor"
				},
				success: function(response) {
					BusyIndicator.hide();
					MessageToast.show(that.oResourceBundle.getText("PROD_STD_DB_SUCCESS"));
					var prodBttlnckData = response.ProdStdToProdBttlnckDataNav.map(item => ({
						...item,
						edit: false,
						enable: true
					}));
					var prodSecResData = response.ProdStdToProdSecResDataNav.map(item => ({
						...item,
						edit: false,
						enable: true
					}));
					var prodVarDtData = response.ProdStdToProdVarDtDataNav.map(item => ({
						...item,
						edit: false,
						enable: true
					}));
					var prodMatrData = response.ProdStdToProdMatrAllDataNav.map(item => ({
						...item,
						edit: false,
						enable: true
					}));
					that.oglobalResponseModel.setData({
						standardCycleData: prodBttlnckData,
						variableDtData: prodVarDtData,
						materialData: prodMatrData,
						SecondaryResData: prodSecResData,
						plant: response.plant,
						resource: response.bottleneckResource,
						prodStdNo: response.prodStdNo,
						costCenter: response.costCenter,
						status: response.status,
						validFrom: response.validFrom,
						modifiedFrom: response.modifiedFrom,
						validTo: response.validTo,
						desc: response.masterRecipeDesc,
						lotSize: response.procOrdrSizeOrCostingLotSize,
						mrGroup: response.mrGroup,
						mrCounter: response.mrCounter,
						percentageAI: response.pctAI,
						lineEfficiency: response.lineEfficiency,
						chargeQty: response.chargeQty,
						operationQty: response.operationQty,
						createdOn: response.createdOn,
						bottleneckCorrect: response.bottleneckCorrect,
						ecn:response.ecm,
						auditInfoChannel:response.auditInfoChannel
						                
					});
					for (var i = 0; i < prodBttlnckData.length; i++) {
						prodBttlnckControlKeyData.push({
							"steus": prodBttlnckData[i].controlKey
						})
					}
					that.byId("idPlant").setProperty("text", response.plant);
					matUom = response.nsUom;
					that.byId("idRes").setProperty("text", response.bottleneckResource);
					that.byId("idStandard").setProperty("text", response.prodStdNo);
					that.byId("idCostCenter").setProperty("text", response.costCenter);
					that.byId("idStatus").setProperty("text", response.status);
					that.byId("idValidTo").setProperty("text", that.fnConvertDbResponseDateFormat(response.validTo));
					that.byId("idValidFrom").setProperty("text", that.fnConvertDbResponseDateFormat(response.validFrom));
					that.byId("idModifiedOn").setProperty("text", that.fnConvertDbResponseDateFormat(response.modifiedFrom));
					that.byId("idLastChange").setProperty("text", that.getDateFormat(response.lastChangedOn));
					that.byId("idCreatedOn").setProperty("text", that.getDateFormat(response.createdOn));
					var specificConfigCount = response.ProdStdToProdVarDtDataNav.length;
					that.getView().byId("idVariableDBTab").setCount(specificConfigCount);
					specificConfigCount = response.ProdStdToProdMatrAllDataNav.length;
					that.getView().byId("idMaterialDBTab").setCount(specificConfigCount);
					specificConfigCount = response.ProdStdToProdSecResDataNav.length;
					that.getView().byId("idResourceDBTab").setCount(specificConfigCount);
					specificConfigCount = response.ProdStdToProdBttlnckDataNav.length;
					that.getView().byId("idBottleneckDbTab").setCount(specificConfigCount);
					aMaterialData = that.getView().getModel("globalResponseModel").getProperty("/materialData");
					aSecResData = that.getView().getModel("globalResponseModel").getProperty("/SecondaryResData");
					aVariableDtData = that.getView().getModel("globalResponseModel").getProperty("/variableDtData");
					aBottlenecDbData = that.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
					for(var k = 0; k<aBottlenecDbData.length; k++){
						var resource = aBottlenecDbData[k].resource;
						var validDate = response.modifiedFrom; 
						var url = "/ETY_Machine_DetailsSet";
						var oFilterPlant = new Filter({
							filters: [
								new Filter("Plant", FilterOperator.EQ, response.plant)
								]
						});
						var oFilterResource = new Filter({
							filters: [
								new Filter("ResourceName", FilterOperator.EQ, resource)
								]
						});
						var oFilterValidDate = new Filter({
							filters: [
								new Filter("ValidDate", FilterOperator.EQ, validDate)
							]
						});
						if (oODataModel) {
							oODataModel.read(url, {
								headers: mHeaders,
								filters: [oFilterPlant, oFilterResource, oFilterValidDate],
								success: function (oData) {
									var oModelMachine = new sap.ui.model.json.JSONModel(); 
									oModelMachine.setData(oData); 
									var machineData = oData.results;
									for (var j = 0; j < machineData.length; j++) {
										oModelMachine.setProperty("/results/" + j + "/FunctionalLoc", machineData[j].FunctionalLoc); 
									}
									that.getView().setModel(oModelMachine, "machineModel");
									
									that.SetMachineDataComboBox(oData,that);
								},
								error: function (oError) {
									// Handle errors
									MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
								}
							});
						}
						else {
							MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
						}
					}
				},
				error: function(xhr, status, error) {
					BusyIndicator.hide();
					let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
							xhr.responseJSON.error.message :
								that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
					MessageToast.show(that.oResourceBundle.getText("PROD_STD_DB_FAIL")+ " " + errorMessage);
				}
			});
		},
		SetMachineDataComboBox: function (oData,that){
		var standardCycleData = that.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
									var machineData = oData.results;
									var ResourceName = machineData[0].ResourceName
									for (var x = 0; x < standardCycleData.length; x++) {
										if (ResourceName === standardCycleData[x].resource) {
											var index = x;
											console.log(ResourceName + "-" + index);
											standardCycleData[index].machineModel = [];
											for (var j = 0; j < machineData.length; j++) {
												var machinename = machineData[j].FunctionalLoc;
												standardCycleData[index].machineModel.push({
													FunctionalLoc: machinename
												});
											}
										}
									}
									that.getView().getModel("globalResponseModel").setProperty("/standardCycleData", standardCycleData);
								},
		onTabSelect: function(oEvent) {
			var selectedTabKey = oEvent.getParameter("key");
			switch (selectedTabKey) {
			case "Bottleneck DB":
				this.getView().getModel("globalResponseModel").setProperty("/standardCycleData", aBottlenecDbData);
				break;
			case "SecondaryResource":
				this.getView().getModel("globalResponseModel").setProperty("/SecondaryResData", aSecResData);
				break;
			case "VariableDTDB":
				this.getView().getModel("globalResponseModel").setProperty("/variableDtData", aVariableDtData);
				break;
			default:
				this.getView().getModel("globalResponseModel").setProperty("/materialData", aMaterialData);
			}
		},
		fnConvertDbResponseDateFormat: function(val) {
			var dateParts = val.split("-");
			var date = new Date(dateParts[0], dateParts[1] - 1, dateParts[2]);
			var day = String(date.getDate()).padStart(2, '0');
			var month = String(date.getMonth() + 1).padStart(2, '0');
			var year = date.getFullYear();
			return `${day}-${month}-${year}`;
		},
		getDateFormat: function(val) {
			var iDay = parseInt((val.substring(8, 10)),10);
			var iMonth = val.substring(5, 7);
			var iYear = parseInt((val.substring(0, 4)),10);
			return iDay + "-" + iMonth + "-" + iYear;
		},
		getProductStdHeaderData: function() {
			var that = this;
			var url = "odata/v4/data-services/ProductRelStandardHeadersDB";
			BusyIndicator.show();
			$.ajax({
				url : url,
				method: 'GET',
				headers: {
					'x-username' : userId,
					'x-zone': selectedZone,
					'x-plants': plantsParam,
					'x-role': "Creator/Editor"
				},
				success: function(data) {
					BusyIndicator.hide();
					that.getOwnerComponent().getModel("productModel").setData(data);
				},
				error:function(xhr, status, error) {
					BusyIndicator.hide();
					let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
							xhr.responseJSON.error.message :
								that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
					MessageToast.show(that.oResourceBundle.getText("PROD_STD_DB_FAIL")+ " " + errorMessage);
				}
			});
		},
		fnMatTableRowSelected: function() {
			var aRowSelected = this.getView().byId("idMaterialDB5").getSelectedIndices();
			if (aRowSelected.length > 0) {
				this.getView().byId("idtab5Edit").setEnabled(true);
				this.getView().byId("idtab5Delete").setEnabled(true);
			} else {
				this.getView().byId("idtab5Edit").setEnabled(false);
				this.getView().byId("idtab5Delete").setEnabled(false);
			}
		},
		fnVarDtTableRowSelected: function() {
			var aRowSelected = this.getView().byId("idVariableDtDB").getSelectedIndices();
			if (aRowSelected.length > 0) {
				this.getView().byId("idtab6Edit").setEnabled(true);
				this.getView().byId("idtab6Delete").setEnabled(true);
			} else {
				this.getView().byId("idtab6Edit").setEnabled(false);
				this.getView().byId("idtab6Delete").setEnabled(false);
			}
		},
		fnSecResTableRowSelected: function() {
			var aRowSelected = this.getView().byId("idSecondaryResourceDB").getSelectedIndices();
			if (aRowSelected.length > 0) {
				this.getView().byId("idtabSecondaryEdit").setEnabled(true);
				this.getView().byId("idtabSecondaryDelete").setEnabled(true);
			} else {
				this.getView().byId("idtabSecondaryEdit").setEnabled(false);
				this.getView().byId("idtabSecondaryDelete").setEnabled(false);
			}
		},
		fnBottleneckTableRowSelected: function() {
			var aRowSelected = this.getView().byId("idStandardBottleneck").getSelectedIndices();
			if (aRowSelected.length > 0) {
				this.getView().byId("idtabBottleneckEdit").setEnabled(true);
				this.getView().byId("idtabBottleneckDelete").setEnabled(false);
			} else {
				this.getView().byId("idtabBottleneckEdit").setEnabled(false);
				this.getView().byId("idtabBottleneckDelete").setEnabled(false);
			}
		},
		onNavBack: function() {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			if (sPreviousHash !== undefined) {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("ProductStandardView", true);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("RouteHomeView", true);
			}
		},
		onMenu: function(evt) {
			if (!this._oPopover2) {
				this._oPopover2 = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.PopoverStandard", this);
				this.getView().addDependent(this._oPopover2);
			}
			this._oPopover2.openBy(evt.getSource());
			tableIndex = this.getView().byId("idSecificStandard").getSelectedIndex();
		},
		onMenu2: function(evt) {
			if (!this._oPopover22) {
				this._oPopover22 = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.PopoverStandard", this);
				this.getView().addDependent(this._oPopover22);
			}
			sap.ui.getCore().byId("idStandPopoverEdit").setVisible(false);
			sap.ui.getCore().byId("idStandPopoverDelete").setVisible(false);
			sap.ui.getCore().byId("idStandPopoverSecRes").setVisible(true);
			this._oPopover22.openBy(evt.getSource());
		},
		onSecRes: function(evt) {
			if (!this._oDialog) {
				var oView = this.getView();
				this._oDialog = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.ProductStandardResource", this);
				oView.addDependent(this._oDialog);
			}
			this._oDialog.open();
		},
		handleCloseButton: function(oEvent) {
			this._oPopover22.close();
			this.getView().getModel("bottleneckDBModel").setProperty("/lineData/" + tableIndex + "/edit", false);
			sap.ui.getCore().byId("idStandPopoveronSecRes").setVisible(true);
		},
		onCloseDialog: function(oEvent) {
			if (this._oDialog) {
				this._oDialog.close();
			}
		},
		onSubmitDialog: function() {
			var oSelect = sap.ui.getCore().byId(this.getView().getId() + "--selectResource");
			var selectedKey = oSelect.getSelectedKey();
			tableIndex = this.getView().byId("idStandardBottleneck").getSelectedIndex();
			this.getView().getModel("bottleneckDBModel").setProperty("/bottleneckdata/" + tableIndex + "/resourceValue", selectedKey);
			this._oDialog.close();
		},
		onEdit: function() {
			this.getView().getModel("cycleDBModel").setProperty("/lineData/" + tableIndex + "/enable", true);
			this.getView().getModel("cycleDBModel").setProperty("/lineData/" + tableIndex + "/edit", true);
			sap.ui.getCore().byId("idStandPopoverEdit").setVisible(false);
			sap.ui.getCore().byId("idStandPopoverSubmit").setVisible(true);
			sap.ui.getCore().byId("idStandPopoverDelete").setVisible(false);
			sap.ui.getCore().byId("idStandPopoverCancel").setVisible(true);
		},
		OnProdStdViewEdit: function() {
			var oTab = this.getView().byId("idProductViewStdTab");
			var mainTabKey = oTab.getSelectedKey();
			if (mainTabKey == "Bottleneck DB") {
				tableIndex = this.getView().byId("idStandardBottleneck").getSelectedIndices();
				var oModel = this.getView().getModel("globalResponseModel");
				var aData = oModel.getProperty("/standardCycleData");
				for (var i = 0; i < tableIndex.length; i++) {
					oModel.setProperty("/standardCycleData/" + tableIndex[i] + "/enable", true);
					oModel.setProperty("/standardCycleData/" + tableIndex[i] + "/edit", true);
				}
				oModel.setProperty("/standardCycleData", aData);
				this.getView().byId("idProductBottleneckSubmit").setVisible(true);
				this.getView().byId("idProductBottleneckCancel").setVisible(true);
				this.getView().byId("idtabBottleneckEdit").setVisible(false);
				this.getView().byId("idtabBottleneckDelete").setEnabled(false);
			} else if (mainTabKey == "SecondaryResource") {
				tableIndex = this.getView().byId("idSecondaryResourceDB").getSelectedIndices();
				for (var i = 0; i < tableIndex.length; i++) {
					this.getView().getModel("globalResponseModel").setProperty("/SecondaryResData/" + tableIndex[i] + "/enable", true);
					this.getView().getModel("globalResponseModel").setProperty("/SecondaryResData/" + tableIndex[i] + "/edit", true);
				}
				this.getView().byId("idProductSecondarySubmit").setVisible(true);
				this.getView().byId("idProductSecondaryCancel").setVisible(true);
				this.getView().byId("idtabSecondaryEdit").setVisible(false);
				this.getView().byId("idtabSecondaryDelete").setEnabled(false);
			} else if (mainTabKey == "MaterialDB") {
				tableIndex = this.getView().byId("idMaterialDB5").getSelectedIndices();
				for (var i = 0; i < tableIndex.length; i++) {
					this.getView().getModel("globalResponseModel").setProperty("/materialData/" + tableIndex[i] + "/enable", true);
					this.getView().getModel("globalResponseModel").setProperty("/materialData/" + tableIndex[i] + "/edit", true);
				}
				this.getView().byId("idtab3Submit").setVisible(true);
				this.getView().byId("idtab3Cancel").setVisible(true);
				this.getView().byId("idtab5Edit").setVisible(false);
				this.getView().byId("idtab5Delete").setEnabled(false);
			} else {
				tableIndex = this.getView().byId("idVariableDtDB").getSelectedIndices();
				for (var i = 0; i < tableIndex.length; i++) {
					this.getView().getModel("globalResponseModel").setProperty("/variableDtData/" + tableIndex[i] + "/enable", true);
					this.getView().getModel("globalResponseModel").setProperty("/variableDtData/" + tableIndex[i] + "/edit", true);
				}
				this.getView().byId("idtab4Submit").setVisible(true);
				this.getView().byId("idtab4Cancel").setVisible(true);
				this.getView().byId("idtab6Edit").setVisible(false);
				this.getView().byId("idtab6Delete").setEnabled(false);
			}
		},
		onSubmit: function() {
			this.getView().getModel("cycleDBModel").setProperty("/lineData/" + tableIndex + "/edit", false);
			sap.ui.getCore().byId("idStandPopoverEdit").setVisible(true);
			sap.ui.getCore().byId("idStandPopoverSubmit").setVisible(false);
			sap.ui.getCore().byId("idStandPopoverDelete").setVisible(true);
			sap.ui.getCore().byId("idStandPopoverCancel").setVisible(false);
		},
		OnProdStdViewSubmit: function() {
			var oTab = this.getView().byId("idProductViewStdTab");
			var mainTabKey = oTab.getSelectedKey();
			if (mainTabKey == "Bottleneck DB") {
				tableIndex = this.getView().byId("idStandardBottleneck").getSelectedIndices();
				for (var i = 0; i < tableIndex.length; i++) {
					this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + tableIndex + "/edit", false);
					this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + tableIndex + "/enable", true);
				}
				this.getView().byId("idProductBottleneckSubmit").setVisible(false);
				this.getView().byId("idProductBottleneckCancel").setVisible(false);
				this.getView().byId("idtabBottleneckEdit").setVisible(true);
				this.getView().byId("idtabBottleneckDelete").setEnabled(false);
				this.getView().byId("idStandardBottleneck").clearSelection();
				this.onProductionStdDBUpdate();
			} else if (mainTabKey == "SecondaryResource") {
				tableIndex = this.getView().byId("idSecondaryResourceDB").getSelectedIndices();
				for (var i = 0; i < tableIndex.length; i++) {
					this.getView().getModel("globalResponseModel").setProperty("/SecondaryResData/" + tableIndex + "/edit", false);
					this.getView().getModel("globalResponseModel").setProperty("/SecondaryResData/" + tableIndex + "/enable", true);
				}
				this.getView().byId("idProductSecondarySubmit").setVisible(false);
				this.getView().byId("idProductSecondaryCancel").setVisible(false);
				this.getView().byId("idtabSecondaryEdit").setVisible(true);
				this.getView().byId("idtabSecondaryDelete").setEnabled(true);
				this.getView().byId("idSecondaryResourceDB").clearSelection();
				this.onProductionStdDBUpdate();
			} else if (mainTabKey == "MaterialDB") {
				tableIndex = this.getView().byId("idMaterialDB5").getSelectedIndices();
				for (var i = 0; i < tableIndex.length; i++) {
					this.getView().getModel("globalResponseModel").setProperty("/materialData/" + tableIndex + "/edit", false);
					this.getView().getModel("globalResponseModel").setProperty("/materialData/" + tableIndex + "/enable", true);
				}
				this.getView().byId("idtab3Submit").setVisible(false);
				this.getView().byId("idtab3Cancel").setVisible(false);
				this.getView().byId("idtab5Edit").setVisible(true);
				this.getView().byId("idtab5Delete").setEnabled(true);
				this.getView().byId("idMaterialDB5").clearSelection();
				this.onProductionStdDBUpdate();
			} else {
				tableIndex = this.getView().byId("idVariableDtDB").getSelectedIndices();
				for (var i = 0; i < tableIndex.length; i++) {
					this.getView().getModel("globalResponseModel").setProperty("/variableDtData/" + tableIndex + "/edit", false);
					this.getView().getModel("globalResponseModel").setProperty("/variableDtData/" + tableIndex + "/enable", true);
				}
				this.getView().byId("idtab4Submit").setVisible(false);
				this.getView().byId("idtab4Cancel").setVisible(false);
				this.getView().byId("idtab6Edit").setVisible(true);
				this.getView().byId("idtab6Delete").setEnabled(true);
				this.getView().byId("idVariableDtDB").clearSelection();
				this.onProductionStdDBUpdate();
			}
		},
		onDelete: function() {
			var oDeleteRow = this.getView().getModel("cycleDBModel").getProperty("/lineData").splice(tableIndex, );
			var aNewData = this.getView().getModel("cycleDBModel").getProperty("/lineData");
			this.getView().getModel("cycleDBModel").setProperty("/lineData", aNewData);
		},
		// OnProdStdViewDelete: function() {
		// 	if (!this._oPopover11) {
		// 		this._oPopover11 = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.PopoverDeleteRecords", this);
		// 		this.getView().addDependent(this._oPopover11);
		// 	}
		// 	this._oPopover11.open();
		// },
		OnProdStdViewBottleneckDBDelete: function () {
			sap.m.MessageBox.confirm(
				this.oResourceBundle.getText("DELETE_CONFIRMATION"), // Message
				{
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
					onClose: function (sAction) { // Callback when the dialog is closed
						if (sAction === MessageBox.Action.YES) {

							var table = this.getView().byId("idStandardBottleneck");
							var selectedIndices = table.getSelectedIndices();
							if (selectedIndices.length > 0) {
								var standardCycleData = this.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
								selectedIndices.sort((a, b) => b - a);
								for (var i = 0; i < selectedIndices.length; i++) {
									var contextPath = table.getContextByIndex(selectedIndices[i]).getPath();
									var selectedID = this.getView().getModel("globalResponseModel").getProperty(contextPath + "/ID");
									deleteProdStdBottleneckData.push({
										"ID": selectedID
									});
									standardCycleData.splice(selectedIndices[i], 1);
								}
								this.getView().getModel("globalResponseModel").setProperty("/standardCycleData", standardCycleData);
							} else {
								sap.m.MessageToast.show("No row selected!");
							}
						}
					}.bind(this)
				}
			);

		},
		OnProdStdViewSecondaryResourceDelete: function () {
			sap.m.MessageBox.confirm(
				this.oResourceBundle.getText("DELETE_CONFIRMATION"), // Message
				{
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
					onClose: function (sAction) { // Callback when the dialog is closed
						if (sAction === MessageBox.Action.YES) {
							var table = this.getView().byId("idSecondaryResourceDB");
							var selectedIndices = table.getSelectedIndices();
							if (selectedIndices.length > 0) {
								var SecondaryResData = this.getView().getModel("globalResponseModel").getProperty("/SecondaryResData");
								selectedIndices.sort((a, b) => b - a);
								for (var j = 0; j < selectedIndices.length; j++) {
									var contextPath = table.getContextByIndex(selectedIndices[j]).getPath();
									var selectedID = this.getView().getModel("globalResponseModel").getProperty(contextPath + "/ID");
									deleteProdStdSecResData.push({
										"ID": selectedID
									});
									SecondaryResData.splice(selectedIndices[j], 1);
								}
								this.getView().getModel("globalResponseModel").setProperty("/SecondaryResData", SecondaryResData);
							} else {
								sap.m.MessageToast.show(this.oResourceBundle.getText("SELECT_ROW_ERROR"));
							}


						}
					}.bind(this)
				}
			);

		},
		OnProdStdViewVariableDTDelete: function () {
			sap.m.MessageBox.confirm(
				this.oResourceBundle.getText("DELETE_CONFIRMATION"), // Message
				{
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
					onClose: function (sAction) { // Callback when the dialog is closed
						if (sAction === MessageBox.Action.YES) {
							var table = this.getView().byId("idVariableDtDB");
							var selectedIndices = table.getSelectedIndices();
							if (selectedIndices.length > 0) {
								var variableDtData = this.getView().getModel("globalResponseModel").getProperty("/variableDtData");
								selectedIndices.sort((a, b) => b - a);
								for (var y = 0; y < selectedIndices.length; y++) {
									var contextPath = table.getContextByIndex(selectedIndices[y]).getPath();
									var selectedID = this.getView().getModel("globalResponseModel").getProperty(contextPath + "/ID");
									deleteProdStdVarDtData.push({
										"ID": selectedID
									});
									variableDtData.splice(selectedIndices[y], 1);
								}
								this.getView().getModel("globalResponseModel").setProperty("/variableDtData", variableDtData);
							} else {
								sap.m.MessageToast.show(this.oResourceBundle.getText("SELECT_ROW_ERROR"));
							}

						}
					}.bind(this)
				}
			);

		},
		OnProdStdViewMaterialdbDelete: function () {
			sap.m.MessageBox.confirm(
				this.oResourceBundle.getText("DELETE_CONFIRMATION"), // Message
				{
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
					onClose: function (sAction) { // Callback when the dialog is closed
						if (sAction === MessageBox.Action.YES) {
							var table = this.getView().byId("idMaterialDB5");
							var selectedIndices = table.getSelectedIndices();
							if (selectedIndices.length > 0) {
								var materialData = this.getView().getModel("globalResponseModel").getProperty("/materialData");
								selectedIndices.sort((a, b) => b - a);
								for (var x = 0; x < selectedIndices.length; x++) {
									var contextPath = table.getContextByIndex(selectedIndices[x]).getPath();
									var selectedID = this.getView().getModel("globalResponseModel").getProperty(contextPath + "/ID");
									deleteProdStdMaterialData.push({
										"ID": selectedID
									});
									materialData.splice(selectedIndices[x], 1);
								}
								this.getView().getModel("globalResponseModel").setProperty("/materialData", materialData);
							} else {
								sap.m.MessageToast.show(this.oResourceBundle.getText("SELECT_ROW_ERROR"));
							}


						}
					}.bind(this)
				}
			);

		},
		// handleAcceptButton: function() {
		// 	var oTab = this.getView().byId("idProductViewStdTab");
		// 	var mainTabKey = oTab.getSelectedKey();
		// 	if (mainTabKey == "Bottleneck DB") {
		// 		var table = this.getView().byId("idStandardBottleneck");
		// 		var selectedIndices = table.getSelectedIndices();
		// 		if (selectedIndices.length > 0) {
		// 			var standardCycleData = this.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
		// 			selectedIndices.sort((a, b) => b - a);
		// 			for (var i = 0; i < selectedIndices.length; i++) {
		// 				var contextPath = table.getContextByIndex(selectedIndices[i]).getPath();
		// 				var selectedID = this.getView().getModel("globalResponseModel").getProperty(contextPath + "/ID");
		// 				deleteProdStdBottleneckData.push({
		// 					"ID": selectedID
		// 				});
		// 				standardCycleData.splice(selectedIndices[i], 1);
		// 			}
		// 			this.getView().getModel("globalResponseModel").setProperty("/standardCycleData", standardCycleData);
		// 		} else {
		// 			sap.m.MessageToast.show("No row selected!");
		// 		}
		// 	} else if (mainTabKey == "SecondaryResource") {
		// 		var table = this.getView().byId("idSecondaryResourceDB");
		// 		var selectedIndices = table.getSelectedIndices();
		// 		if (selectedIndices.length > 0) {
		// 			var SecondaryResData = this.getView().getModel("globalResponseModel").getProperty("/SecondaryResData");
		// 			selectedIndices.sort((a, b) => b - a);
		// 			for (var i = 0; i < selectedIndices.length; i++) {
		// 				var contextPath = table.getContextByIndex(selectedIndices[i]).getPath();
		// 				var selectedID = this.getView().getModel("globalResponseModel").getProperty(contextPath + "/ID");
		// 				deleteProdStdSecResData.push({
		// 					"ID": selectedID
		// 				});
		// 				SecondaryResData.splice(selectedIndices[i], 1);
		// 			}
		// 			this.getView().getModel("globalResponseModel").setProperty("/SecondaryResData", SecondaryResData);
		// 		} else {
		// 			sap.m.MessageToast.show(this.oResourceBundle.getText("SELECT_ROW_ERROR"));
		// 		}
		// 	} else if (mainTabKey == "MaterialDB") {
		// 		var table = this.getView().byId("idMaterialDB5");
		// 		var selectedIndices = table.getSelectedIndices();
		// 		if (selectedIndices.length > 0) {
		// 			var materialData = this.getView().getModel("globalResponseModel").getProperty("/materialData");
		// 			selectedIndices.sort((a, b) => b - a);
		// 			for (var i = 0; i < selectedIndices.length; i++) {
		// 				var contextPath = table.getContextByIndex(selectedIndices[i]).getPath();
		// 				var selectedID = this.getView().getModel("globalResponseModel").getProperty(contextPath + "/ID");
		// 				deleteProdStdMaterialData.push({
		// 					"ID": selectedID
		// 				});
		// 				materialData.splice(selectedIndices[i], 1);
		// 			}
		// 			this.getView().getModel("globalResponseModel").setProperty("/materialData", materialData);
		// 		} else {
		// 			sap.m.MessageToast.show(this.oResourceBundle.getText("SELECT_ROW_ERROR"));
		// 		}
		// 	} else {
		// 		var table = this.getView().byId("idVariableDtDB");
		// 		var selectedIndices = table.getSelectedIndices();
		// 		if (selectedIndices.length > 0) {
		// 			var variableDtData = this.getView().getModel("globalResponseModel").getProperty("/variableDtData");
		// 			selectedIndices.sort((a, b) => b - a);
		// 			for (var i = 0; i < selectedIndices.length; i++) {
		// 				var contextPath = table.getContextByIndex(selectedIndices[i]).getPath();
		// 				var selectedID = this.getView().getModel("globalResponseModel").getProperty(contextPath + "/ID");
		// 				deleteProdStdVarDtData.push({
		// 					"ID": selectedID
		// 				});
		// 				variableDtData.splice(selectedIndices[i], 1);
		// 			}
		// 			this.getView().getModel("globalResponseModel").setProperty("/variableDtData", variableDtData);
		// 		} else {
		// 			sap.m.MessageToast.show(this.oResourceBundle.getText("SELECT_ROW_ERROR"));
		// 		}
		// 	}
		// 	this.onProductionStdDBUpdate();
		// 	if(this._oPopover11 !== undefined){
		// 		this._oPopover11.close();
		// 	}
		// 	this.getProdStdDbData();
		// },
		onProductionStdDBUpdate: function() {
			var iRowCount = this.getView().getModel("globalResponseModel").getData().standardCycleData.length;
			for (var i = 0; i < iRowCount; i++) {
				if (["YBN1", "YBN2", "YBN3"].includes(this.getView().getModel("globalResponseModel").getData().standardCycleData[i].controlKey)) {
					var speedValue = this.getView().getModel("globalResponseModel").getData().standardCycleData[i].nominalSpeed;
					var bottleneckResource = this.getView().getModel("globalResponseModel").getData().standardCycleData[i].resource;
					var bottleneckSpeedUom = this.getView().getModel("globalResponseModel").getData().standardCycleData[i].nsUom;
					var lineEfficiency = this.getView().getModel("globalResponseModel").getData().standardCycleData[i].pctlineEfficiency;
					var capacityNumber = this.getView().getModel("globalResponseModel").getData().standardCycleData[i].capacityNo;
				}
			}
			var avariableDtData = this.getView().getModel("globalResponseModel").getProperty("/variableDtData");
			lotSize = this.getView().getModel("globalResponseModel").getProperty("/lotSize");
			var totalVariableDt = 0;
			for (var i = 0; i < avariableDtData.length; i++) {
				var frequency = avariableDtData[i].freqInProdUom;
				var duration = avariableDtData[i].durationInMin;
				var calcVariableDt = parseFloat((lotSize / frequency * duration / 60).toFixed(3));
				avariableDtData[i].totalVarDT = calcVariableDt;
				avariableDtData[i].procOrdrSizeOrCostingLotSize = lotSize;
				var totalVariableDt = (totalVariableDt + calcVariableDt);
			}
			var aStandardCycleData = this.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
			var totCrewSize = 0;
			for (var i = 0; i < aStandardCycleData.length; i++) {
				var updatedCrewTotSize = parseInt(aStandardCycleData[i].numOfPeople);
				var initCreSize = updatedCrewTotSize;
				totCrewSize = initCreSize + totCrewSize;
			}
			plant = this.getView().getModel("globalResponseModel").getProperty("/plant");
			desc = this.getView().getModel("globalResponseModel").getProperty("/desc");
			resource = this.getView().getModel("globalResponseModel").getProperty("/resource");
			validFrom = this.getView().getModel("globalResponseModel").getProperty("/validFrom");
			bottleneckCorrect = this.getView().getModel("globalResponseModel").getProperty("/bottleneckCorrect");
			validTo = this.getView().getModel("globalResponseModel").getProperty("/validTo");
			lotSize = this.getView().getModel("globalResponseModel").getProperty("/lotSize");
			mrNo = this.getView().getModel("globalResponseModel").getProperty("/mrGroup");
			mrCounter = this.getView().getModel("globalResponseModel").getProperty("/mrCounter");
			chargeQty = this.getView().getModel("globalResponseModel").getProperty("/chargeQty");
			operationQty = this.getView().getModel("globalResponseModel").getProperty("/operationQty");
			costCenter = this.getView().getModel("globalResponseModel").getProperty("/costCenter");
			validFrom = this.getView().getModel("globalResponseModel").getProperty("/validFrom");
			validTo = this.getView().getModel("globalResponseModel").getProperty("/validTo");
			var ecmNumber = this.getView().getModel("globalResponseModel").getProperty("/ecn");
			var formattedValidFrom = this.fnConvertDbResponseDateFormat(validFrom);
			var tempLineStdNo = "LR" + "_" + plant + "_" + bottleneckResource + "_" ;
			var url = `odata/v4/data-services/getProductionLoss(stdPrefix='${tempLineStdNo}',validFromDate=${validFrom})`;
			BusyIndicator.show();
			var that = this;
			$.get(url)
			.done(function(response) {
				var plannedDtLossVal = (response.value)/100;
				percentageAI = ((lotSize / speedValue) / ((lotSize / speedValue / lineEfficiency/100) + totalVariableDt / (1 - plannedDtLossVal))).toFixed(3);
				var updateProdStdHdrData = [{
					ID: ID,
					prodStdNo: prdStdNo,
					configNo: plant + "_" + "PR" + "_" + bottleneckResource + "_" + costCenter,
					plant: plant,
					status: "Modified",
					bottleneckResource: bottleneckResource,
					masterRecipeDesc: desc,
					capacityNumber: capacityNumber,
					variant: parseInt(selectedVariant,10),
					costCenter: costCenter,
					bottleneckCorrect: bottleneckCorrect,
					validFrom: validFrom,
					validTo: validTo,
					mrGroup: mrNo,
					mrCounter: mrCounter,
					nominalSpeed: speedValue,
					nsUom: bottleneckSpeedUom,
					crewSize: totCrewSize,
					lineEfficiency: lineEfficiency,
					procOrdrSizeOrCostingLotSize: lotSize,
					chargeQty: chargeQty,
					operationQty: operationQty,
					pctAI: percentageAI,
					ecm: ecmNumber,
					auditInfoChannel: selectedZone,
					stdApprLvl: 0,
					executionState: 0,
					executorsIDs: []
				}];
				// Get the table and its binding context
				var oMaterialTable = that.getView().byId("idMaterialDB5");
				var oMaterialTableModel = oMaterialTable.getModel("globalResponseModel");
				var aMaterialTableData = oMaterialTableModel.getProperty("/materialData");
				// Prepare the material data
				var updateProdStdMaterialData = [];
				aMaterialTableData.forEach(function(rowData) {
					updateProdStdMaterialData.push({
						ID: rowData.ID,
						prodStdNo: prdStdNo,
						material: parseInt(rowData.material),
						materialDesc: rowData.materialDesc,
						status: "Modified"
					});
				});
				// Get the table and its binding context
				var oVariableDtTable = that.getView().byId("idVariableDtDB");
				var oVariableDtTableModel = oVariableDtTable.getModel("globalResponseModel");
				var aVariableDtTableData = oVariableDtTableModel.getProperty("/variableDtData");
				// Prepare the Variable DT data
				var updateProdStdVarDtData = [];
				aVariableDtTableData.forEach(function(rowData) {
					updateProdStdVarDtData.push({
						ID: rowData.ID,
						prodStdNo: prdStdNo,
						varDtDesc: rowData.varDtDesc,
						durationInMin: rowData.durationInMin,
						freqInProdUom: rowData.freqInProdUom,
						status: "Modified",
						procOrdrSizeOrCostingLotSize: rowData.procOrdrSizeOrCostingLotSize,
						totalVarDT: rowData.totalVarDT
					});
				});
				// Get the table and its binding context
				var oSecResTable = that.getView().byId("idSecondaryResourceDB");
				var oSecResTableModel = oSecResTable.getModel("globalResponseModel");
				var aSecResTableData = oSecResTableModel.getProperty("/SecondaryResData");
				// Prepare the Secondary resource data
				var updateProdStdSecResData = [];
				aSecResTableData.forEach(function(rowData) {
					updateProdStdSecResData.push({
						ID: rowData.ID,
						prodStdNo: prdStdNo,
						resource: rowData.resource,
						machine: rowData.machine,
						secResource: rowData.secResource,
						status: "Modified",
						energy1Type: rowData.energy1Type,
						energy1Uom: rowData.energy1Uom,
						energy1QtyPerHr: isNaN(parseFloat(rowData.energy1QtyPerHr)) ? null : parseFloat(rowData.energy1QtyPerHr),
								energy2Type: rowData.energy2Type,
								energy2Uom: rowData.energy2Uom,
								energy2QtyPerHr: isNaN(parseFloat(rowData.energy2QtyPerHr)) ? null : parseFloat(rowData.energy2QtyPerHr),
										energy3Type: rowData.energy3Type,
										energy3Uom: rowData.energy3Uom,
										energy3QtyPerHr: isNaN(parseFloat(rowData.energy3QtyPerHr)) ? null : parseFloat(rowData.energy3QtyPerHr),
												energy4Type: rowData.energy4Type,
												energy4Uom: rowData.energy4Uom,
												energy4QtyPerHr: isNaN(parseFloat(rowData.energy4QtyPerHr)) ? null : parseFloat(rowData.energy4QtyPerHr),
														energy5Type: rowData.energy5Type,
														energy5Uom: rowData.energy5Uom,
														energy5QtyPerHr: isNaN(parseFloat(rowData.energy5QtyPerHr)) ? null : parseFloat(rowData.energy5QtyPerHr),
																energy6Type: rowData.energy6Type,
																energy6Uom: rowData.energy6Uom,
																energy6QtyPerHr: isNaN(parseFloat(rowData.energy6QtyPerHr)) ? null : parseFloat(rowData.energy6QtyPerHr),
					});
				});
				// Get the table and its binding context
				var oBottleneckTable = that.getView().byId("idStandardBottleneck");
				var oBottleneckTableModel = oBottleneckTable.getModel("globalResponseModel");
				var aBottleneckTableData = oBottleneckTableModel.getProperty("/standardCycleData");
				// Prepare the Bottleneck data
				var updateProdStdBottleneckData = [];
				aBottleneckTableData.forEach(function(rowData) {
					updateProdStdBottleneckData.push({
						ID: rowData.ID,
						prodStdNo: prdStdNo,
						resource: rowData.resource,
						status: "Modified",
						machine: rowData.machine,
						nominalSpeed: rowData.nominalSpeed,
						nsUom: rowData.nsUom,
						bottleNckInd: bottleneckCorrect,
						numOfPeople: rowData.numOfPeople,
						destinationKey: rowData.destinationKey,
						controlKey: rowData.controlKey,
						pctlineEfficiency: rowData.pctlineEfficiency,
						capacityNo: rowData.capacityNo
					});
				});
				// Create the payload
				var payload = {
						"updateProdStdHdrData": updateProdStdHdrData,
						"updateProdStdMaterialData": updateProdStdMaterialData,
						"updateProdStdVarDtData": updateProdStdVarDtData,
						"updateProdStdSecResData": updateProdStdSecResData,
						"updateProdStdBottleneckData": updateProdStdBottleneckData,
						"deleteProdStdMaterialData": deleteProdStdMaterialData,
						"deleteProdStdVarDtData": deleteProdStdVarDtData,
						"deleteProdStdSecResData": deleteProdStdSecResData,
						"deleteProdStdBottleneckData": deleteProdStdBottleneckData
				};
				var sUrl = "odata/v4/data-services/upsertProductStdItems";
				$.ajax({
					url: sUrl,
					type: "POST",
					data: JSON.stringify(payload),
					contentType: "application/json"
				})
				.done(function(response) {
					BusyIndicator.hide();
					var message = that.oResourceBundle.getText("PROD_STD_UPDATE_SUCCESS") + " " + plant + ", Resource :" + bottleneckResource + ", CostCenter :" + costCenter + ".";
					that.onShowSuccess(message);
					that.getProdStdDbData();
				})
				.fail(function(xhr, status, error) {
					BusyIndicator.hide();
					let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
							xhr.responseJSON.error.message :
								that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
					var message = that.oResourceBundle.getText("PROD_STD_UPDATE_FAIL")+ " " + errorMessage;
					that.onShowError(message);
					that.getProdStdDbData();
				});
			}).fail(function(xhr, status, error) {
				BusyIndicator.hide();
				let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
						xhr.responseJSON.error.message :
							that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
				MessageToast.show(that.oResourceBundle.getText("PLANNED_DT_RETRIEVE_FAIL")+ " " + errorMessage);
			});
		},
		handleMessageBoxCloseButton: function() {
			this._oPopover11.close();
			var oTab = this.getView().byId("idProductViewStdTab");
			var mainTabKey = oTab.getSelectedKey();
			if (mainTabKey == "Bottleneck DB") {
				tableIndex = this.getView().byId("idStandardBottleneck").setSelectedIndex(-1);
			} else if (mainTabKey == "SecondaryResource") {
				tableIndex = this.getView().byId("idSecondaryResourceDB").setSelectedIndex(-1);
			} else if (mainTabKey == "MaterialDB") {
				tableIndex = this.getView().byId("idMaterialDB").setSelectedIndex(-1);
			} else {
				tableIndex = this.getView().byId("idVariableDtDB").setSelectedIndex(-1);
			}
		},
		OnProdStdViewCancel: function() {
			var oTab = this.getView().byId("idProductViewStdTab");
			var mainTabKey = oTab.getSelectedKey();
			if (mainTabKey == "Bottleneck DB") {
				tableIndex = this.getView().byId("idStandardBottleneck").getSelectedIndices();
				var oModel = this.getView().getModel("globalResponseModel");
				var aData = oModel.getProperty("/standardCycleData");
				for (var i = 0; i < tableIndex.length; i++) {
					oModel.setProperty("/standardCycleData/" + tableIndex[i] + "/enable", true);
					oModel.setProperty("/standardCycleData/" + tableIndex[i] + "/edit", false);
				}
				this.getView().byId("idProductBottleneckSubmit").setVisible(false);
				this.getView().byId("idProductBottleneckCancel").setVisible(false);
				this.getView().byId("idtabBottleneckEdit").setVisible(true);
				this.getView().byId("idtabBottleneckDelete").setEnabled(false);
				this.getView().byId("idStandardBottleneck").clearSelection();
			} else if (mainTabKey == "SecondaryResource") {
				tableIndex = this.getView().byId("idSecondaryResourceDB").getSelectedIndices();
				for (var i = 0; i < tableIndex.length; i++) {
					this.getView().getModel("globalResponseModel").setProperty("/SecondaryResData/" + tableIndex[i] + "/enable", true);
					this.getView().getModel("globalResponseModel").setProperty("/SecondaryResData/" + tableIndex[i] + "/edit", false);
				}
				this.getView().byId("idProductSecondarySubmit").setVisible(false);
				this.getView().byId("idProductSecondaryCancel").setVisible(false);
				this.getView().byId("idtabSecondaryEdit").setVisible(true);
				this.getView().byId("idtabSecondaryDelete").setEnabled(true);
				this.getView().byId("idSecondaryResourceDB").clearSelection();
			} else if (mainTabKey == "MaterialDB") {
				tableIndex = this.getView().byId("idMaterialDB5").getSelectedIndices();
				for (var i = 0; i < tableIndex.length; i++) {
					this.getView().getModel("globalResponseModel").setProperty("/materialData/" + tableIndex[i] + "/enable", true);
					this.getView().getModel("globalResponseModel").setProperty("/materialData/" + tableIndex[i] + "/edit", false);
				}
				this.getView().byId("idtab3Submit").setVisible(false);
				this.getView().byId("idtab3Cancel").setVisible(false);
				this.getView().byId("idtab5Edit").setVisible(true);
				this.getView().byId("idtab5Delete").setEnabled(true);
				this.getView().byId("idMaterialDB5").clearSelection();
			} else {
				tableIndex = this.getView().byId("idVariableDtDB").getSelectedIndices();
				for (var i = 0; i < tableIndex.length; i++) {
					this.getView().getModel("globalResponseModel").setProperty("/variableDtData/" + tableIndex[i] + "/enable", true);
					this.getView().getModel("globalResponseModel").setProperty("/variableDtData/" + tableIndex[i] + "/edit", false);
				}
				this.getView().byId("idtab4Submit").setVisible(false);
				this.getView().byId("idtab4Cancel").setVisible(false);
				this.getView().byId("idtab6Edit").setVisible(true);
				this.getView().byId("idtab6Delete").setEnabled(true);
				this.getView().byId("idVariableDtDB").clearSelection();
			}
			this.getProdStdDbData();
		}
	});
});