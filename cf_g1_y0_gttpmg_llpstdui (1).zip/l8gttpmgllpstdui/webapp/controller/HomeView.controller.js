sap.ui.define([
	"l8gttpmgllpstdui/controller/BaseController",
	"sap/ui/core/mvc/Controller",
	"l8gttpmgllpstdui/model/formatter",
	'sap/ui/core/BusyIndicator',
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	'sap/m/MessageToast',
	],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function(BaseController, Controller, formatter, BusyIndicator,Filter, FilterOperator,MessageToast) {
	"use strict";
	var oODataModel,nbId,apikey;
	return BaseController.extend("l8gttpmgllpstdui.controller.HomeView", {
		formatter: formatter,
		onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);  
            oRouter.getRoute("RouteHomeView").attachMatched(this.onAfterRendering, this);
			this.oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			oODataModel = this.getOwnerComponent().getModel();
			var url = "odata/v4/data-services/getLoggedInUserId()";
			$.ajax({
				url: url,
				method: 'GET',
				success: function (_data, _textStatus, xhr) {
					BusyIndicator.hide();
					nbId = xhr.getResponseHeader('x-usernbid');

				},
				error: function (_xhr, _status, _error) {
					BusyIndicator.hide();
					var message = this.oResourceBundle.getText("USER_NOT_EXIST")
					MessageToast.show(message);    
				}.bind(this),
			});

			//Select standard
			var sStandardUrl = "odata/v4/data-services/ListOptionTxt?$filter=setId eq 'STANDARD_TYPE'&$orderby=auditInfoCreatedOn asc&$select=label,ID";
			$.ajax({
				url: sStandardUrl,
				method: "GET",
				success: function (oData) {
					// Prepare the model data
					var aStandardData = oData.value.map(function (item) {
						return { standard: item.label };
					});

					// Bind the data to the standardModel
					var oStandardModel = new sap.ui.model.json.JSONModel({ data: aStandardData });
					this.getView().setModel(oStandardModel, "standardModel");
					this.getOwnerComponent().setModel(oStandardModel, "standardModel");
				}.bind(this),
				error: function (oError) {
					console.error("Error fetching Standard Type data:", oError);
				}.bind(this),
			});
			//Select Zone
			var jsonZoneModel = new sap.ui.model.json.JSONModel();
			jsonZoneModel.setData({
				"data": [{
					zone: "AOA"
				}, {
					zone: "AMS"
				}, {
					zone: "EUR"
				}]
			});
			this.getView().setModel(jsonZoneModel, "zoneModel");
			this.getOwnerComponent().setModel(jsonZoneModel, "zoneModel");

		},
		onAfterRendering:function(){
            var oStandardComboBox = this.getView().byId("idSatandardSelection");
 
            // Clear the ComboBox if it exists
            if (oStandardComboBox) {
              oStandardComboBox.setSelectedKey("");
              oStandardComboBox.setValue("");        
            }
        },
		onConfiguration: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ConFigView");
		},
		onSelected: function(evt) {
			var sStandardSelected = evt.oSource.mProperties.value;
			var sStandardSelectedModel = new sap.ui.model.json.JSONModel();
			sStandardSelectedModel.setData({
				standardtype: sStandardSelected
			});
			this.getOwnerComponent().setModel(sStandardSelectedModel, "sStandardSelectedModel");
			if (evt.oSource.mProperties.value == "Line Standard") {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("LineStandardView");
			} else if (evt.oSource.mProperties.value == "Product Standard") {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);                
				oRouter.navTo("ProductStandardView");
			} else if (evt.oSource.mProperties.value == " ") {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("RouteHomeView");
			}
		},
		onZoneSelected: function(evt) {
			var sSelectedZone = evt.oSource.mProperties.value;
			this.getView().byId("idSatandardSelection").setValue();


			var currentURL = window.location.href;

			var url = new URL(currentURL);

			var host = url.host;

			var oResourceBundle = this.getView().getModel("util").getResourceBundle();

			if (host.startsWith("dev") || host.startsWith("poc")){

				apikey = oResourceBundle.getText("apiKey_Dev");

			} else if (host.startsWith("ppd")){

				apikey = oResourceBundle.getText("apiKey_PPD");

			} else{

				apikey = oResourceBundle.getText("apiKey_PRD");

			}
			var alias = sSelectedZone === "AOA" ? oResourceBundle.getText("zoneAOA_Alias") :
				sSelectedZone === "EUR" ? oResourceBundle.getText("zoneEUR_Alias") :
					sSelectedZone === "AMS" ? oResourceBundle.getText("zoneAMS_Alias"):
						"";            



					var that = this;
					var url = "/ETY_MR_AUTH_DETERMINATIONSet";
					BusyIndicator.show(0);
					var oFilterZone = new Filter({
						filters: [
							new Filter("Zone", FilterOperator.EQ, sSelectedZone)
							]
					});

					if (oODataModel) {
						oODataModel.read(url, {
							headers: {
								"apikey": apikey,
								"username": nbId,
								"sysali": alias
							},
							filters: [oFilterZone],
							success: function(data,textStatus,xhr) {
								var zoneUserModel = new sap.ui.model.json.JSONModel();
								zoneUserModel.setData(data);
								BusyIndicator.hide();
								this.getView().byId("idSatandardSelection").setEditable(true);
								sap.ui.getCore().setModel(zoneUserModel, "loginUserModel");
								this.getOwnerComponent().setModel(zoneUserModel, "loginUserModel");
								for (var i = 0; i< sap.ui.getCore().getModel("loginUserModel").getData().results.length; i++){
									var authType = sap.ui.getCore().getModel("loginUserModel").getData().results[i].AuthType;
									if (authType === "C"){
										break;
									}
								}
								
								this.getView().byId("idconfiguration").setVisible(authType === "C");
							}.bind(this),
							error: function(xhr, status, error) {
								BusyIndicator.hide();
								let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
										xhr.responseJSON.error.message :
											this.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
								that.onShowError(errorMessage);
								that.getView().byId("idSatandardSelection").setEditable(false);
							}.bind(this),
						});
					} else {
						MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
					}
					if(evt.oSource.mProperties.value == " ")
					{
						var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						oRouter.navTo("RouteHomeView");
					}
		},
		onMenuAction: function (oEvent) {
			var sMenuSelected = oEvent.getParameter("item").mProperties.text;
			if (sMenuSelected == 'Approval and Archiving configuration') {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("ConFigView");
			}else
			{
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("LossConFigView");
			}


		}
	});
});