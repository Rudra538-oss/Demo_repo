sap.ui.define(
    [
        "l8gttpmgllpstdui/controller/BaseController",
        "sap/ui/core/mvc/Controller",
        "l8gttpmgllpstdui/model/formatter",
        'sap/m/MessageToast',
        "sap/ui/core/routing/History",
        'sap/ui/core/BusyIndicator',
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
		"sap/m/MessageBox"
						  

        ],
        function (BaseController, Controller, formatter, MessageToast, History, BusyIndicator, Filter, FilterOperator,MessageBox) {
        "use strict";
        var tableIndex, plantsParam, role, apikey,variant, matUom, approverLevel,
        oODataModel, formattedDateVal, zone, nbId, plannedDtLossVal, currentBottleneckRes, currentCostCenter,semicreatedFlagEnbaled,secResFlag=0,operationNo,phaseNo,totalPeople,tempPhaseNo=100,editFlag =0,
        selectedTableIndex, configNo, prodId, userRole, selectedPlant, globalRoleVal, iMatSelectedIndex, ecn, selectedVariant,
        toggle = 1,
        defaultDate, sProductComment, totcrewSize = 0,
        speedValue, copiedSpeedValue, bottleneckResource, prdStandardNo, controlKeyPreviousVal, bottleneckSpeedUom;
        var plant, ID, plantDesc, destinationKey, costCenter, validFrom, validTo, lotSize, mrNo, mrCounter, chargeQty, opQty;
        var deleteProdStdMaterialData = [];
        var deleteProdStdVarDtData = [];
        var deleteProdStdSecResData = [];
        var deleteProdStdBottleneckData = [];
        var prodBttlnckControlKeyData = [];
        var mHeaders = [];
        return BaseController.extend("l8gttpmgllpstdui.controller.ProductStandardView", {
            formatter: formatter,
            onInit: function () {
                const oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                const oHistory = sap.ui.core.routing.History.getInstance();
                const sPreviousHash = oHistory.getPreviousHash();
                oRouter.getRoute("ProductStandardView").attachPatternMatched(this.onObjectMatched, this);
                // If there is no previous hash, navigate to HomeView
                if (sPreviousHash === undefined) {
                    oRouter.navTo("RouteHomeView", true);
                } else {
                    oRouter.getRoute("ProductStandardView").attachPatternMatched(this.onObjectMatched, this);
                } // Attach pattern matched event for the ProductStandardView route
                this.oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            },
            getProductStdHeaderData: function (initialCallFlag) {
                var that = this;
                var newData = sap.ui.getCore().getModel("loginUserModel").getData().results;
                nbId = newData[0].Username;							   
                zone = newData[0].Zone;
                if (role === undefined){
                    role = "V";
                } 
                var url2 = "/ETY_PLANT_SHSet";
                var oFilterRole = new Filter({
                    filters: [
                        new Filter("User_Type", FilterOperator.EQ, role)
                        ]
                });
                if (oODataModel) {
                    oODataModel.read(url2, {
                        headers: mHeaders,
                        filters: [oFilterRole],
											
						  
                        success: function (oData) {
												 
                            var oModelPlant = new sap.ui.model.json.JSONModel();
                            oModelPlant.setData(oData);
                            oModelPlant.setSizeLimit(3000);
                            this.getView().setModel(oModelPlant, "plantModel1");
                            var aPlantData = this.getView().getModel("plantModel1").getData().results;
                            var plantIds = [];																				
                            for (var i = 0; i < aPlantData.length; i++) {
                                var plant = aPlantData[i].Werks;
                                plantIds.push(plant);
								 
                            }
                            plantsParam = plantIds.join(',');

                            if(initialCallFlag === 1){
                                if (newData.length>1){
                                that.fnProdViewRecords();
                                }else{
                                role = "V";
                                var url = "odata/v4/data-services/ProductRelStandardHeadersDB";
                                $.ajax({
                                    url: url,
                                    method: 'GET',
                                    headers: {
                                        'x-username': nbId,
                                        'x-zone': zone,
                                        'x-plants': plantsParam,
                                        'x-role': "Executor/Viewer"
                                    },
                                    success: function (data, textStatus, xhr) {
            
                                        userRole = xhr.getResponseHeader('x-userrole');
            
                                        if (userRole === "Viewer"){
                                            that.getView().byId("viewerId").setVisible(true);
                                            that.getView().byId("executorId").setVisible(false);
                                        } else{
                                            that.getView().byId("viewerId").setVisible(true);
                                            that.getView().byId("executorId").setVisible(true);
                                        }
                                        that.fnProdViewRecords();    
                                    },
                                    error: function (xhr, status, error) {
                                        BusyIndicator.hide();
                                        let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                                xhr.responseJSON.error.message :
                                                    that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                        MessageToast.show(that.oResourceBundle.getText("PROD_EXE_VIEWER_LOAD_FAIL") + " " + errorMessage);
                                        // alert("Error fetching OData: " + error);
                                    }
                                });
                            }
                        }else{
                            if (role === "A") {
                                var url = "odata/v4/data-services/ProductRelStandardHeadersDB";
                                $.ajax({
                                    url: url,
                                    method: 'GET',
                                    headers: {
                                        'x-username': nbId,
                                        'x-zone': zone,
                                        'x-plants': plantsParam,
                                        'x-role': "Approver"
                                    },
                                    success: function (data) {
                                        BusyIndicator.hide();
                                        var oTableModel = new sap.ui.model.json.JSONModel(data);
                                        that.getView().byId("idProductTable").setModel(oTableModel, "productModel");
                                        that.getOwnerComponent().setModel(oTableModel, "productModel");
                                        that.getView().byId("idProdCreate").setVisible(false);
                                        that.getView().byId("idProdCopyCreate").setVisible(false);
                                        that.getView().byId("idProdArchive").setVisible(false);
                                        that.getView().byId("idMenu4").setVisible(false);
                                        that.getView().byId("idCreateProdMenu").setVisible(false);
                                        that.getView().byId("idMenu5").setVisible(true);
                                        that.getView().byId("idMenu6").setVisible(false);
                                        that.getView().byId("idSendToSAP").setVisible(false);	
                                        that.getView().byId("idSendToSAP").setEnabled(false);
                                        that.getView().byId("idPopoverSubmit").setVisible(false);
                                        that.getView().byId("idPopoverSubmit").setEnabled(false);
                                        MessageToast.show(that.oResourceBundle.getText("PROD_APPROVER_LOAD_SUCCESS"));
                                        var aHeaderData = that.getView().getModel("productModel").getProperty("/value");
                                        for (var i = 0; i < aHeaderData.length; i++) {
                                            if (that.getView().getModel("productModel").getProperty("/value/" + i + "/status") == "Archived - SAP Del") {
                                                that.getView().getModel("productModel").setProperty("/value/" + i + "/enable", false);
                                            }
                                        }
                                        var parts = sap.ui.core.routing.History.getInstance().getPreviousHash().split('/');    
                                        var firstPart = parts[0];
                                        if(firstPart === "onProductViewStandard"){
                                            that.onProdFilterSearch();
                                        }
                                    },
                                    error: function (xhr, _status, _error) {
                                        BusyIndicator.hide();
                                        let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                                xhr.responseJSON.error.message :
                                                    that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                        MessageToast.show(that.oResourceBundle.getText("PROD_APPROVER_LOAD_FAIL") + " " + errorMessage);
                                    }
                                });
                            } else if (role === "V") {
                                var url = "odata/v4/data-services/ProductRelStandardHeadersDB";
                                $.ajax({
                                    url: url,
                                    method: 'GET',
                                    headers: {
                                        'x-username': nbId,
                                        'x-zone': zone,
                                        'x-plants': plantsParam,
                                        'x-role': "Executor/Viewer"
                                    },
                                    success: function (data, textStatus, xhr) {
                                        userRole = xhr.getResponseHeader('x-userrole');
                                        if (userRole === "Viewer"){
                                            that.getView().byId("viewerId").setVisible(true);
                                            that.getView().byId("executorId").setVisible(false);
                                        } else{
                                            that.getView().byId("viewerId").setVisible(true);
                                            that.getView().byId("executorId").setVisible(true);
                                        }
                                        that.fnProdViewRecords();               
                                    },
                                    error: function (xhr, status, error) {
                                        BusyIndicator.hide();
                                        let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                                xhr.responseJSON.error.message :
                                                    that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                        MessageToast.show(that.oResourceBundle.getText("PROD_EXE_VIEWER_LOAD_FAIL") + " " + errorMessage);
                                    }
                                });
                            } else {
                                var url = "odata/v4/data-services/ProductRelStandardHeadersDB";
                                $.ajax({
                                    url: url,
                                    method: 'GET',
                                    headers: {
                                        'x-username': nbId,
                                        'x-zone': zone,
                                        'x-plants': plantsParam,
                                        'x-role': "Creator/Editor"
                                    },
                                    success: function (data) {
                                        BusyIndicator.hide();
                                        var oTableModel = new sap.ui.model.json.JSONModel(data);
                                        that.getView().byId("idProductTable").setModel(oTableModel, "productModel");
                                        //Setting model at component level
                                        userRole =  "Creator/Editor";
                                        that.getView().byId("idProdCreate").setVisible(true);
                                        that.getView().byId("idProdCopyCreate").setVisible(true);
                                        that.getView().byId("idProdArchive").setVisible(true);
                                        that.getView().byId("idProdArchive").setEnabled(false);
                                        that.getView().byId("idSendToSAP").setVisible(true);
                                        that.getView().byId("idSendToSAP").setEnabled(false);
                                        that.getView().byId("idCreateProdMenu").setVisible(true);
                                        that.getView().byId("idMenu4").setVisible(false);
                                        that.getView().byId("idMenu5").setVisible(false);
                                        that.getView().byId("idMenu6").setVisible(false);
                                       
                                        that.getView().byId("idPopoverSubmit").setVisible(true);
                                        that.getView().byId("idPopoverSubmit").setEnabled(false);
                                        that.getOwnerComponent().setModel(oTableModel, "productModel");
                                        MessageToast.show(that.oResourceBundle.getText("PROD_CREATE_EDITOR_SUCCESS"));
                                        var aHeaderData = that.getView().getModel("productModel").getProperty("/value");
                                        for (var i = 0; i < aHeaderData.length; i++) {
                                            if (that.getView().getModel("productModel").getProperty("/value/" + i + "/status") == "Archived - SAP Del") {
                                                that.getView().getModel("productModel").setProperty("/value/" + i + "/enable", false);
                                            }
                                        }
                                        var parts = sap.ui.core.routing.History.getInstance().getPreviousHash().split('/');    
                                        var firstPart = parts[0];
                                        if(firstPart === "onProductViewStandard"){
                                            that.onProdFilterSearch();
                                        }
                                    },
                                    error: function (xhr, status, error) {
                                        BusyIndicator.hide();
                                        let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                                xhr.responseJSON.error.message :
                                                    that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                        MessageToast.show(that.oResourceBundle.getText("PROD_CREATE_EDITOR_FAIL") + " " + errorMessage);
                                    }
                                })
                            }
                        }
                        }.bind(this),
                        error: function (jqXHR) {
												 
                            let errorMessage = jqXHR.responseText ?
																
                                    JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                    // Handle errors
                                    MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
																	   
                        }
                    });
                } else {																   
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));	 
					  
                }
        },
            onNavBack: function () {
                var oHistory = History.getInstance();
                var sPreviousHash = oHistory.getPreviousHash();
                if (sPreviousHash !== undefined) {
                    window.history.go(-1);
                } else {
                    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                    oRouter.navTo("RouteHomeView", true);
                }
            },
            onObjectMatched: function () {
                // initital setting for Line Standard filters
                var oView = this.getView();
                // Fetch controls by their IDs
                var parts = sap.ui.core.routing.History.getInstance().getPreviousHash().split('/');    
                var firstPart = parts[0];
                if(firstPart !== "onProductViewStandard"){
                oView.byId("mcb_status_PPD_Z1").setSelectedItem(null);
                oView.byId("mcb_status_PPD_Z1").setValue("");
                oView.byId("mcb_ordTyp_PPD_Z1").setValue("");
                oView.byId("mcb_ordTyp_PPD_Z1").setSelectedItem(null);
                oView.byId("idprodCostCenterFilter").setValue("");
                oView.byId("DPprodValidFrom").setValue("");
                oView.byId("DPprodValidTo").setValue("");
                oView.byId("DPprodCreatedOn").setValue("");
                oView.byId("DPprodLastChangedon").setValue("");
                oView.byId("mcb_status_PPD_Z214").setSelectedItems([]);
                oView.byId("idprodFilterMRGroup").setValue("");
                oView.byId("idprodFilterMRCounter").setValue("");
                oView.byId("idprodFilterNominalSpeed").setValue("");
                oView.byId("idprodFilterAI").setValue("");
                oView.byId("idprodFilterNSUoM").setValue("");
                oView.byId("idprodFilterProcessorderSize").setValue("");
                oView.byId("idprodFilterCapacityNumber").setValue("");
                oView.byId("idprodFilterVariant").setValue("");
                oView.byId("idprodFilterLineEfficiency").setValue("");
                oView.byId("idprodFilterChargeQuantity").setValue("");
                oView.byId("idprodFilterOperationQuantity").setValue("");
                oView.byId("idprodFilterECM").setValue("");
                oView.byId("idprodFilterCrewSize").setValue("");

                if (this.getView().getModel("statusFilterModel") !== undefined) {
                    this.getView().getModel("statusFilterModel").setProperty("/value", []);
                }
                if (this.getView().getModel("resourceModel") !== undefined) {
                    this.getView().getModel("resourceModel").setProperty("/results", []);
                }
            }
                var statusFilterModel = new sap.ui.model.json.JSONModel();
                var url = 'odata/v4/data-services/LineAndProductRelStandardStatusDb?$filter=prodFlag eq 1&$select=status'
                    statusFilterModel.loadData(url);
                statusFilterModel.setSizeLimit(100);
                this.getView().setModel(statusFilterModel, "statusFilterModel");
                if (sap.ui.getCore().getModel("loginUserModel") !== undefined) {
                    this.getRequiredMasterData();
                }

            },
            getRequiredMasterData: function () {
                var that = this;
                oODataModel = this.getOwnerComponent().getModel();
                BusyIndicator.show(0);
                var newData = sap.ui.getCore().getModel("loginUserModel").getData().results;
                nbId = newData[0].Username;
                zone = newData[0].Zone;
                var currentURL = window.location.href;
                var url = new URL(currentURL);
                var host = url.host;
                console.log(host);
                var oResourceBundle = this.getView().getModel("util").getResourceBundle();
                if (host.startsWith("dev") || host.startsWith("poc")) {
                    apikey = oResourceBundle.getText("apiKey_Dev");
                } else if (host.startsWith("ppd")) {
                    apikey = oResourceBundle.getText("apiKey_PPD");
                } else {
                    apikey = oResourceBundle.getText("apiKey_PRD");
                }
                var alias = zone === "AOA" ? oResourceBundle.getText("zoneAOA_Alias") :
                    zone === "EUR" ? oResourceBundle.getText("zoneEUR_Alias") :
                        zone === "AMS" ? oResourceBundle.getText("zoneAMS_Alias") :
                            "";
                        mHeaders = {
                                "apikey": apikey,
                                "username": nbId,
                                "sysali": alias
                        };								  
                        var statusFilterModel = new sap.ui.model.json.JSONModel();
                        var url1 = 'odata/v4/data-services/LineAndProductRelStandardStatusDb?$filter=prodFlag eq 1&$select=status'
                            statusFilterModel.loadData(url1);								   
                        statusFilterModel.setSizeLimit(100);
                        this.getView().setModel(statusFilterModel, "statusFilterModel");
                        //Select standard 
                        var jsonModel = new sap.ui.model.json.JSONModel();
                        jsonModel.setData({
                            "data": [{
                                standard: " "
                            }, {
                                standard: "Line Standard"
                            }, {
                                standard: "Product Standard"
                            }]
                        });
                        this.getView().setModel(jsonModel, "standardModel");
                        sap.ui.getCore().setModel(jsonModel, "standardModel");
                        var secondaryresourceDBModel = new sap.ui.model.json.JSONModel();
                        secondaryresourceDBModel.setData({
                            "SecondaryResData": []
                        });
                        this.getView().setModel(secondaryresourceDBModel, "secondaryresourceDBModel");
                       
                        var url3 = "/ETY_SPEED_UOMSet";

                        if (oODataModel) {
                            oODataModel.read(url3, {
                                headers: mHeaders,
                                success: function (oData) {
                                    var oUomModel = new sap.ui.model.json.JSONModel();
                                    oUomModel.setData(oData);
                                    oUomModel.setSizeLimit(3000);
                                    this.getView().setModel(oUomModel, "uomModel");
                                    var parts = sap.ui.core.routing.History.getInstance().getPreviousHash().split('/');    
                                    var firstPart = parts[0];
                                    var initialCallFlag = firstPart === "onProductViewStandard"? 0:1;
                                    this.getProductStdHeaderData(initialCallFlag);
                                }.bind(this),
                                error: function (jqXHR) {
                                    let errorMessage = jqXHR.responseText ?
                                            JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                            // Handle errors
                                            MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                                }
                            });
                        } else {
                            MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                        }
                        var url4 = "/ETY_CONTROL_KEYSet";
                        if (oODataModel) {
                            oODataModel.read(url4, {
                                headers: mHeaders,
                                success: function (oData) {
                                    var oModelControlKey = new sap.ui.model.json.JSONModel();
                                    oModelControlKey.setData(oData);
                                    this.getView().setModel(oModelControlKey, "controlKeyModel");
                                }.bind(this),
                                error: function (jqXHR) {
                                    let errorMessage = jqXHR.responseText ?
                                            JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                            // Handle errors
                                            MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                                }
                            });
                        } else {
                            MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                        }
                        var secondaryResourceModel = new sap.ui.model.json.JSONModel();
                        secondaryResourceModel.setData({
                            "secondaryresourceData": []
                        });
                        this.getView().setModel(secondaryResourceModel, "secondaryResourceModel");
                        var variableDtDBModel = new sap.ui.model.json.JSONModel();
                        variableDtDBModel.setData({
                            "variableDtData": []
                        });
                        this.getView().setModel(variableDtDBModel, "variableDtDBModel");
                        var materialDBCreateModel = new sap.ui.model.json.JSONModel();
                        materialDBCreateModel.setData({
                            "materialData": []
                        });
                        this.getView().setModel(materialDBCreateModel, "materialDBCreateModel");
                        this.oglobalResponseModel = this.getOwnerComponent().getModel("globalResponseModel");
                        var standardCycleModel = new sap.ui.model.json.JSONModel();
                        standardCycleModel.setData({
                            "standardCycleData": []
                        });
                        this.getView().setModel(standardCycleModel, "standardCycleModel");

                        var intStandardCycleModel = new sap.ui.model.json.JSONModel();
                        intStandardCycleModel.setData({
                            "standardCycleDataInt": []
                        });
                        this.getView().setModel(intStandardCycleModel, "intStandardCycleModel");	 
            },
            // fnProdApprovalRecords: function(){
            //     var isApprovalEnable = this.getView().byId("idApproveBtn").getState();
            //     if(isApprovalEnable){
            //         var url = "odata/v4/data-services/ProductRelStandardHeadersDB";
            //         BusyIndicator.show(0);
            //         var that = this;
            //         $.ajax({
            //             url: url,
            //             method: 'GET',
            //             headers: {
            //                 'x-username': nbId,
            //                 'x-zone': zone,
            //                 'x-plants': plantsParam,
            //                 'x-role': "Approver"
            //             },
            //             success: function (data) {
            //                 BusyIndicator.hide();
            //                 var oTableModel = new sap.ui.model.json.JSONModel(data);
            //                 that.getView().byId("idProductTable").setModel(oTableModel, "productModel");
            //                 //Setting model at component level
            //                 that.getOwnerComponent().setModel(oTableModel, "productModel");
            //                 that.getView().byId("idProdCreate").setVisible(false);
            //                 that.getView().byId("idProdCopyCreate").setVisible(false);
            //                 that.getView().byId("idProdArchive").setVisible(false);
            //                 that.getView().byId("idMenu4").setVisible(false);
            //                 that.getView().byId("idCreateProdMenu").setVisible(false);
            //                 that.getView().byId("idMenu5").setVisible(true);
            //                 that.getView().byId("idMenu6").setVisible(false);
            //                 that.getView().byId("idSendToSAP").setVisible(false);
            //                 that.getView().byId("idApproveBtn").setVisible(true);
            //                 that.getView().byId("idApproveBtn").setState(true);
            //                 that.getView().byId("idExecuteBtn").setVisible(false);
            //                 that.getView().byId("idApproveLabel").setVisible(true);
            //                 that.getView().byId("idExecuteLabel").setVisible(false);
            //                 MessageToast.show(that.oResourceBundle.getText("PROD_APPROVER_LOAD_SUCCESS"));
            //             },
            //             error: function (xhr, _status, _error) {
            //                 BusyIndicator.hide();
            //                 let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
            //                         xhr.responseJSON.error.message :
            //                             that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
            //                 MessageToast.show(that.oResourceBundle.getText("PROD_APPROVER_LOAD_FAIL") + " " + errorMessage);
            //             }
            //         });
            //     }
            //     else{
            //         BusyIndicator.show(0);
            //         this.getProductStdHeaderData();  
            //     }
            // },
            fnProdExecutionRecords:function(){
                    BusyIndicator.show(0);
                    var that = this;
                    var url = "odata/v4/data-services/ProductRelStandardHeadersDB";
                    $.ajax({
                        url: url,
                        method: 'GET',
                        headers: {
                            'x-username': nbId,
                            'x-zone': zone,
                            'x-plants': plantsParam,
                            'x-role': "Executor/Viewer"
                        },
                        success: function (data, _textStatus, _xhr) {
                            BusyIndicator.hide();
                            var oTableModel = new sap.ui.model.json.JSONModel(data);
                            that.getView().byId("idProductTable").setModel(oTableModel, "productModel");
                            //Setting model at component level
                            that.getOwnerComponent().setModel(oTableModel, "productModel");
                            that.getView().byId("idProdCreate").setVisible(false);
                            that.getView().byId("idProdCopyCreate").setVisible(false);
                            that.getView().byId("idProdArchive").setVisible(false);
                            that.getView().byId("idMenu4").setVisible(false);
                            that.getView().byId("idCreateProdMenu").setVisible(false);
                            that.getView().byId("idMenu5").setVisible(false);
                            that.getView().byId("idMenu6").setVisible(true);
                            that.getView().byId("idSendToSAP").setVisible(false);																					
                            MessageToast.show(that.oResourceBundle.getText("PROD_EXE_LOAD_SUCCESS"));
                            var aHeaderData = that.getView().getModel("productModel").getProperty("/value");
                            for (var i = 0; i < aHeaderData.length; i++) {
                                if (that.getView().getModel("productModel").getProperty("/value/" + i + "/status") == "Archived - SAP Del") {
                                    that.getView().getModel("productModel").setProperty("/value/" + i + "/enable", false);
                                }
                            }
                            var parts = sap.ui.core.routing.History.getInstance().getPreviousHash().split('/');    
                            var firstPart = parts[0];
                            if(firstPart === "onProductViewStandard"){
                                that.onProdFilterSearch();
                            }
                        },
                        error: function (xhr, _status, _error) {
                            BusyIndicator.hide();
                            let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                    xhr.responseJSON.error.message :
                                        that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                            MessageToast.show(that.oResourceBundle.getText("PROD_EXE_LOAD_FAIL") + " " + errorMessage);
                            // alert("Error fetching OData: " + error);
                        }
                    });																 
            },
            fnProdViewRecords:function(){
                var that = this;
                var url = "odata/v4/data-services/ProductRelStandardHeadersDB";
                $.ajax({
                    url: url,
                    method: 'GET',
                    headers: {
                        'x-username': nbId,
                        'x-zone': zone,
                        'x-plants': plantsParam,
                        'x-role': "View"
                    },
                    success: function (data, _textStatus, _xhr) {
                        BusyIndicator.hide();
                        var oTableModel = new sap.ui.model.json.JSONModel(data);
                        that.getView().byId("idProductTable").setModel(oTableModel, "productModel");
                        //Setting model at component level
                        that.getOwnerComponent().setModel(oTableModel, "productModel");
                        userRole =  "View";
                        that.getView().byId("idProdCreate").setVisible(false);
                        that.getView().byId("idProdCopyCreate").setVisible(false);
                        that.getView().byId("idProdArchive").setVisible(false);
                        that.getView().byId("idMenu4").setVisible(true);
                        that.getView().byId("idCreateProdMenu").setVisible(false);
                        that.getView().byId("idMenu5").setVisible(false);
                        that.getView().byId("idMenu6").setVisible(false);
                        that.getView().byId("idSendToSAP").setVisible(false);	
                        that.getView().byId("idSendToSAP").setEnabled(false);
                        that.getView().byId("idPopoverSubmit").setVisible(false);
                        that.getView().byId("idPopoverSubmit").setEnabled(false);													
                        MessageToast.show(that.oResourceBundle.getText("PROD_VIEWER_LOAD_SUCCESS"));

                        var aHeaderData = that.getView().getModel("productModel").getProperty("/value");
                            for (var i = 0; i < aHeaderData.length; i++) {
                                if (that.getView().getModel("productModel").getProperty("/value/" + i + "/status") == "Archived - SAP Del") {
                                    that.getView().getModel("productModel").setProperty("/value/" + i + "/enable", false);
                                }
                            }
                            var parts = sap.ui.core.routing.History.getInstance().getPreviousHash().split('/');    
                            var firstPart = parts[0];
                            if(firstPart === "onProductViewStandard"){
                                that.onProdFilterSearch();
                            }
                    },
                    error: function (xhr, _status, _error) {
                        BusyIndicator.hide();
                        let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                xhr.responseJSON.error.message :
                                    that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                        MessageToast.show(that.oResourceBundle.getText("PROD_VIEWER_LOAD_FAIL") + " " + errorMessage);
                        // alert("Error fetching OData: " + error);
                    }
                });
            },
            fnProductTableRowSelected: function () {
                //role = sap.ui.getCore().getModel("loginUserModel").getData().results[0].AuthType;
                var oTable = this.getView().byId("idProductTable");
                var aSelectedPaths = oTable._aSelectedPaths;
                var oModel = this.getView().getModel("productModel");
											
                var sSelectedPath = aSelectedPaths[0];
                if (sSelectedPath !== undefined) {
                    for (var i = 0; i < aSelectedPaths.length; i++) {
                        var sSelectedPath = aSelectedPaths[i];
                        var iSelectedIndex = parseFloat(sSelectedPath.split("/")[2], 10);
                        var status = oModel.getData().value[iSelectedIndex].status;
                        if (aSelectedPaths.length > 0 && (status === "Created" || status === "Modified")) {
                            this.getView().byId("idPopoverSubmit").setVisible(true);
                            this.getView().byId("idPopoverSubmit").setEnabled(true);
                            this.getView().byId("idProdArchive").setEnabled(true);
																				  
                        }
                        //Appr -In Exec
                        else if (aSelectedPaths.length > 0 && status === "Appr -In Exec" && role !== "S") {
                            this.getView().byId("idSendToSAP").setEnabled(true);
                        } else {
                            this.getView().byId("idSendToSAP").setEnabled(false);
                        }
                    }
                } else {
                    this.getView().byId("idSendToSAP").setEnabled(false);
                    this.getView().byId("idPopoverSubmit").setVisible(true);
                    this.getView().byId("idPopoverSubmit").setEnabled(false);
                    this.getView().byId("idProdArchive").setEnabled(false);
																		   
                }
            },
            onSaveSecRes: function() {
                var iRowCount = this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData.length;
                var aDialogData = [];
                for (var i = 0; i < iRowCount; i++) {
                    var secondaryResData = this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i];
                    var secondaryResourceData = {};

if (secondaryResData.ID !== undefined && secondaryResData.ID !== "") {
    secondaryResourceData.ID = secondaryResData.ID;
}
secondaryResourceData.resource = this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].resource,
secondaryResourceData.machine= this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].machine,
secondaryResourceData.secResource= this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].secResource,
secondaryResourceData.energy1Type= this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].energy1Type,
secondaryResourceData.energy1Uom= this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].energy1Uom,
secondaryResourceData.energy1QtyPerHr= this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].energy1QtyPerHr,
secondaryResourceData.energy2Type= this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].energy2Type,
secondaryResourceData.energy2Uom= this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].energy2Uom,
secondaryResourceData.energy2QtyPerHr= this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].energy2QtyPerHr,
secondaryResourceData.energy3Type= this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].energy3Type,
secondaryResourceData.energy3Uom= this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].energy3Uom,
secondaryResourceData.energy3QtyPerHr= this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].energy3QtyPerHr,
secondaryResourceData.energy4Type= this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].energy4Type,
secondaryResourceData.energy4Uom= this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].energy4Uom,
secondaryResourceData.energy4QtyPerHr= this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].energy4QtyPerHr,
secondaryResourceData.energy5Type= this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].energy5Type,
secondaryResourceData.energy5Uom= this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].energy5Uom,
secondaryResourceData.energy5QtyPerHr= this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].energy5QtyPerHr,
secondaryResourceData.energy6Type= this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].energy6Type,
secondaryResourceData.energy6Uom= this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].energy6Uom,
secondaryResourceData.energy6QtyPerHr= this.getView().getModel("secondaryresourceDBModel").getData().SecondaryResData[i].energy6QtyPerHr,
                    aDialogData.push(secondaryResourceData);
                }
											 
                var secondaryresourceDBModel = new sap.ui.model.json.JSONModel();
                this.getView().getModel("secondaryresourceDBModel").setProperty("/SecondaryResData", aDialogData);
                var oDialogData = {
                        SecondaryResData: aDialogData
                };
                secondaryresourceDBModel = new sap.ui.model.json.JSONModel(oDialogData);
                if (sap.ui.getCore().byId("idSecondaryResourceDB2") != undefined) {
                    sap.ui.getCore().byId("idSecondaryResourceDB2").setModel(secondaryresourceDBModel, "secondaryresourceDBModel");
                    this.getView().getModel("secondaryresourceDBModel").setProperty("/SecondaryResData", aDialogData);
                } else if (sap.ui.getCore().byId("idSecondaryResourceDB3") != undefined) {
                    sap.ui.getCore().byId("idSecondaryResourceDB3").setModel(secondaryresourceDBModel, "globalResponseModel");
                    this.getView().getModel("globalResponseModel").setProperty("/SecondaryResData", aDialogData);
                } else {
                    sap.ui.getCore().byId("idSecondaryResourceDB6").setModel(secondaryresourceDBModel, "globalResponseModel");
                    this.getView().getModel("globalResponseModel").setProperty("/SecondaryResData", aDialogData);
                }
                MessageToast.show("Activity data has been saved successfully");
                this._oPopover32.close();
            },
            handleCloseSecResButton: function () {
                this._oPopover32.close();
            },
            backToSecResWizardContent: function () {
                this._oPopover32.close();
            },
            AddSecResource: function(secResFlag) {
                //role = sap.ui.getCore().getModel("loginUserModel").getData().results[0].AuthType;
                var iRowCount = this.getView().getModel("standardCycleModel").getData().standardCycleData.length;
                var aDialogData = [];
                for (var i = 0; i < iRowCount; i++) {
                    aDialogData.push({
                        resource: this.getView().getModel("standardCycleModel").getData().standardCycleData[i].resource,
                        machine: this.getView().getModel("standardCycleModel").getData().standardCycleData[i].machine,
                        secResource: this.getView().getModel("standardCycleModel").getData().standardCycleData[i].secResource,
                        energy1Type: "",
                        energy1Uom: "",
                        energy1QtyPerHr: "",
                        edit: false,
                        enable: true,
                        energy2Type: "",
                        energy2Uom: "",
                        energy2QtyPerHr: "",
                        energy3Type: "",
                        energy3Uom: "",
                        energy3QtyPerHr: "",
                        energy4Type: "",
                        energy4Uom: "",
                        energy4QtyPerHr: "",
                        energy5Type: "",
                        energy5Uom: "",
                        energy5QtyPerHr: "",
                        energy6Type: "",
                        energy6Uom: "",
                        energy6QtyPerHr: "",
                    });
                }
                if (secResFlag !==1){
                if (!this._oPopover32) {
                    this._oPopover32 = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.SecondaryResourceProdStd", this);
                    this.getView().addDependent(this._oPopover32);
                }
                this._oPopover32.open();
            
                var secondaryresourceDBModel = new sap.ui.model.json.JSONModel();
                this.getView().getModel("secondaryresourceDBModel").setProperty("/SecondaryResData", aDialogData);
                var oDialogData = {
                        SecondaryResData: aDialogData
                };
                var secondaryresourceDBModel = new sap.ui.model.json.JSONModel(oDialogData);
                sap.ui.getCore().byId("idSecondaryResourceDB1").setModel(secondaryresourceDBModel, "secondaryresourceDBModel");
                //sap.ui.getCore().byId("idSecondaryResourceDB1").setVisibleRowCount(secondaryresourceDBModel.getData().SecondaryResData.length);
                }else{
                    var secondaryresourceDBModel = new sap.ui.model.json.JSONModel();
                this.getView().getModel("secondaryresourceDBModel").setProperty("/SecondaryResData", aDialogData);
                }
            },
            // Product standard
            AddBottleneckDB: function (oEvent) {
                //role = sap.ui.getCore().getModel("loginUserModel").getData().results[0].AuthType;
                if (role === "S"){
                var mandatoryFields = [
                    "idGetResource",
                    "idSpeed",
                    "idNsUoM",
									   
								   
                    "idLineEff",
                    "idcapacityNo",
                    "idGetMachine"
                    ];
                } else{
                    var mandatoryFields = [
                        "idGetResource",
                        "idSpeed",
                        "idNsUoM",
                        "idDestinationKey",
                        "idControlKey",
                        "idLineEff",
                        "idcapacityNo",
                        "idGetMachine"
                        ];
                }
                var isValid = true;
                var emptyFields = [];
                mandatoryFields.forEach(function (fieldId) {
                    var fieldValue = sap.ui.getCore().byId(fieldId).getValue();
                    if (!fieldValue) {
                        isValid = false;
                        emptyFields.push(fieldId);
                    }
                });
                if (!isValid) {
                    var message = this.oResourceBundle.getText("MAND_FIELDS_ERROR");
                    this.onShowError(message);
                } else {
                    var oSource = oEvent.getSource() || null;
                    var resource = sap.ui.getCore().byId("idGetResource").getValue();
                    var machine = sap.ui.getCore().byId("idGetMachine").getValue();
                    var speed = sap.ui.getCore().byId("idSpeed").getValue();
                    var nsUoM = sap.ui.getCore().byId("idNsUoM").getValue();
                    matUom = nsUoM;
                    destinationKey = sap.ui.getCore().byId("idDestinationKey").getValue();
                    var controlKey = sap.ui.getCore().byId("idControlKey").getValue();
                    var lineEff = sap.ui.getCore().byId("idLineEff").getValue();
                    var capacityNo = sap.ui.getCore().byId("idcapacityNo").getValue();
                    var peopleNo = sap.ui.getCore().byId("idPeopleNo").getValue();
                    totcrewSize = parseFloat(peopleNo) + totcrewSize;
                    var obj = {};
                    obj.resource = resource;
                    obj.machine = machine;
                    obj.speed = speed;
                    obj.nsUoM = nsUoM;
                    obj.destinationKey = destinationKey;
                    obj.controlKey = controlKey;
                    obj.lineEff = lineEff;
                    obj.capacityNo = capacityNo;
                    obj.peopleNo = peopleNo;
                    obj.edit = false;
                    obj.enable = true;
                    obj.selected = false
                    var objPrev = {};
                    objPrev.controlKey = controlKey;
                    var aCurrentData = this.getView().getModel("standardCycleModel").getProperty("/standardCycleData");
                    if (aCurrentData.length > 0) {
                        var existingNsUoM = aCurrentData[0].nsUoM;
                        if (existingNsUoM !== nsUoM) {
                            sap.m.MessageBox.warning(this.oResourceBundle.getText("ADD_NS_U0M_ERROR") + " " + existingNsUoM);
                            return;
                        }
                    }
                    var aCurrentDataOld = this.getView().getModel("intStandardCycleModel").getProperty("/standardCycleDataInt");
                    aCurrentData.push(obj);
                    aCurrentDataOld.push(objPrev);
                    this.getView().getModel("standardCycleModel").setProperty("/standardCycleData", aCurrentData);
                    this.getView().getModel("intStandardCycleModel").setProperty("/standardCycleDataInt", aCurrentDataOld);
                    var index = 0;
                    speedValue = parseFloat(aCurrentData[0].speed);
                    for (var i = 0; i < aCurrentData.length; i++) {
                        if (parseFloat(aCurrentData[i].speed) < speedValue) {
                            speedValue = parseFloat(aCurrentData[i].speed);
                            index = i;
                        }
                    }

                    this.getView().getModel("standardCycleModel").setProperty("/standardCycleData/" + index + "/selected", true);
                    this.getView().getModel("standardCycleModel").setProperty("/standardCycleData/" + index + "/controlKey", "YBN1");
                    this.getView().getModel("standardCycleModel").setProperty("/standardCycleData/" + index + "/editKey", true);
                    this.getView().getModel("standardCycleModel").setProperty("/standardCycleData/" + index + "/enableKey", true);
                    for (var i = 0; i < aCurrentData.length; i++) {
                        if (i != index) {
                            this.getView().getModel("standardCycleModel").setProperty("/standardCycleData/" + i + "/selected", false);
                            this.getView().getModel("standardCycleModel").setProperty("/standardCycleData/" + i + "/controlKey", aCurrentDataOld[i].controlKey);
                            this.getView().getModel("standardCycleModel").setProperty("/standardCycleData/" + i + "/editKey", false);
                            this.getView().getModel("standardCycleModel").setProperty("/standardCycleData/" + i + "/enableKey", true);
                        }
                    }
                    if (oSource) {
                        oSource.setEnabled(true);
                        oSource.setBusy(false); //to re-enable the control and hide the busy indicator once the operation is complete
                    }
                }
            },
            MandatoryFieldsCopyBottleneckDB: function () {
                //role = sap.ui.getCore().getModel("loginUserModel").getData().results[0].AuthType;
                if (role === "S"){
                var mandatoryFields = [
                    "idProdCopyGetResource",
                    "idProdCopySpeed",
                    "idProdCopyNsUoM",				   
                    "idProdCopyLineEff",
                    "idProdCopycapacityNo",
                    "idProdCopyPeopleNo"
                    ];
                } else{
                    var mandatoryFields = [
                        "idProdCopyGetResource",
                        "idProdCopySpeed",
                        "idProdCopyNsUoM",
                        "idProdCopyLineEff",
                        "idProdCopycapacityNo",
                        "idProdCopyPeopleNo",
                        "idProdCopyDestinationKey",
                        "idProdCopyControlKey"
                        ];
                }

                var isValid = true;
                var emptyFields = [];

                mandatoryFields.forEach(function (fieldId) {
                    var fieldValue = sap.ui.getCore().byId(fieldId).getValue();
                    if (!fieldValue) {
                        isValid = false;
                        emptyFields.push(fieldId);
                    }
                });

                if (!isValid) {
                    var message = this.oResourceBundle.getText("MAND_FIELDS_ERROR");
                    this.onShowError(message);
                    return false;
                }
                return true;

            },
            MandatoryFieldsUpdateBottleneckDB: function () {
                //role = sap.ui.getCore().getModel("loginUserModel").getData().results[0].AuthType;
                if (role === "S"){
                var mandatoryFields = [
                    "idProdUpdateGetResource",
                    "idProdUpdateSpeed",
                    "idProdUpdateNsUoM",
                    "idProdUpdateLineEff",
                    "idProdUpdatecapacityNo",
                    "idProdUpdatePeopleNo",
                    "idProdUpdateGetMachine"
                    ];
                }
                    else{
                        var mandatoryFields = [
                            "idProdUpdateGetResource",
                            "idProdUpdateSpeed",
                            "idProdUpdateNsUoM",
                            "idProdUpdateDestinationKey",
                            "idProdUpdateControlKey",
                            "idProdUpdateLineEff",
                            "idProdUpdatecapacityNo",
                            "idProdUpdatePeopleNo",
                            "idProdUpdateGetMachine",
                            "idProdUpdateControlKey",
                            "idProdUpdateDestinationKey"
                            ];
        
                    }

                var isValid = true;
                var emptyFields = [];

                mandatoryFields.forEach(function (fieldId) {
                    var fieldValue = sap.ui.getCore().byId(fieldId).getValue();
                    if (!fieldValue) {
                        isValid = false;
                        emptyFields.push(fieldId);
                    }
                });

                if (!isValid) {
                    var message = this.oResourceBundle.getText("MAND_FIELDS_ERROR");
                    this.onShowError(message);
                    return false;
                }
                return true;

            },
            MachineFetchAddProdCopyBottleneckDB: function(resource){
                var url = "/ETY_Machine_DetailsSet";
                 var plant = sap.ui.getCore().byId("idProdCopyCreateReviewPlant").getSelectedKey();
                var validDate = sap.ui.getCore().byId("idProdCopyCreateReviewModifiedFrom").getValue();																			   
                var oFilterPlant = new Filter({
                    filters: [
                        new Filter("Plant", FilterOperator.EQ, plant)
                        ]
                });
                var oFilterResource = new Filter({
                    filters: [
                        new Filter("ResourceName", FilterOperator.EQ, resource)
                        ]
                });
				 var oFilterValidDate = new Filter({
                    filters: [
                        new Filter("ValidDate", FilterOperator.EQ, validDate)
						 ]
                });
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        filters: [oFilterPlant, oFilterResource, oFilterValidDate],
                        success: function (oData) {
                            var standardCycleData = this.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
                            var machineData = oData.results;
                            var index = standardCycleData.length - 1;
                            standardCycleData[index].machineModel = [];
                            for (var j = 0; j < machineData.length; j++) {
                                var machinename = machineData[j].FunctionalLoc;
                                standardCycleData[index].machineModel.push({
                                    FunctionalLoc: machinename
                                });
                            }

                            this.getView().getModel("globalResponseModel").setProperty("/standardCycleData", standardCycleData);

                        }.bind(this),
                        error: function (jqXHR) {
                            let errorMessage = jqXHR.responseText ?
                                    JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                    // Handle errors
                                    MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }

            },
            //Started
            MachineFetchAddProdUpdateBottleneckDB: function(resource){
                var url = "/ETY_Machine_DetailsSet";
                var plant = sap.ui.getCore().byId("idProdUpdatePlant").getSelectedKey();
				var validDate = sap.ui.getCore().byId("idUpdateModifiedFrom").getValue();															
                var oFilterPlant = new Filter({
                    filters: [
                        new Filter("Plant", FilterOperator.EQ, plant)
                        ]
                });
                var oFilterResource = new Filter({
                    filters: [
                        new Filter("ResourceName", FilterOperator.EQ, resource)
                        ]
                });
				var oFilterValidDate = new Filter({
                    filters: [
                        new Filter("ValidDate", FilterOperator.EQ, validDate)
					 ]
                });
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        filters: [oFilterPlant, oFilterResource, oFilterValidDate],
                        success: function (oData) {
                            var standardCycleData = this.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
                            var machineData = oData.results;
                            var index = standardCycleData.length - 1;
                            standardCycleData[index].machineModel = [];
                            for (var j = 0; j < machineData.length; j++) {
                                var machinename = machineData[j].FunctionalLoc;
                                standardCycleData[index].machineModel.push({
                                    FunctionalLoc: machinename
                                });
                            }

                            this.getView().getModel("globalResponseModel").setProperty("/standardCycleData", standardCycleData);

                        }.bind(this),
                        error: function (jqXHR) {
                            let errorMessage = jqXHR.responseText ?
                                    JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                    // Handle errors
                                    MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }

            },
            //Ended
            AddProdCopyBottleneckDB: function (oEvent) {
                if (!this.MandatoryFieldsCopyBottleneckDB()) {
                    return;
                }
                var oSource = oEvent.getSource() || null;
                var resource = sap.ui.getCore().byId("idProdCopyGetResource").getValue();
                var machine = sap.ui.getCore().byId("idProdCopyGetMachine").getValue();
                var nominalSpeed = sap.ui.getCore().byId("idProdCopySpeed").getValue();
                var nsUom = sap.ui.getCore().byId("idProdCopyNsUoM").getSelectedKey();
                var destinationKey = sap.ui.getCore().byId("idProdCopyDestinationKey").getValue();
                var controlKey = sap.ui.getCore().byId("idProdCopyControlKey").getValue();
                var pctlineEfficiency = sap.ui.getCore().byId("idProdCopyLineEff").getValue();
                var capacityNo = sap.ui.getCore().byId("idProdCopycapacityNo").getValue();
                var numOfPeople = sap.ui.getCore().byId("idProdCopyPeopleNo").getValue();
                totcrewSize = parseFloat(numOfPeople) + totcrewSize;
                var obj = {};
                obj.resource = resource;
                obj.machine = machine;
                obj.nominalSpeed = nominalSpeed;
                obj.nsUom = nsUom;
                obj.destinationKey = destinationKey;
                obj.controlKey = controlKey;
                obj.pctlineEfficiency = pctlineEfficiency;
                obj.capacityNo = capacityNo;
                obj.numOfPeople = numOfPeople;
                obj.edit = false;
                obj.enable = true;
                obj.selected = false
                var objUpdatePrev = {};
                objUpdatePrev.controlKey = controlKey;
                var aCurrentData = this.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
                if (aCurrentData.length > 0) {
                    var existingNsUoM = aCurrentData[0].nsUom;
                    if (existingNsUoM !== nsUom) {
                        // Show warning message if a different nsUoM value is attempted to be added
                        sap.m.MessageBox.warning("You can only add the same NS UoM value: " + existingNsUoM);
                        return;
                    }
                }
                var aCurrentDataOld = this.getView().getModel("intStandardCycleModel").getProperty("/standardCycleDataInt");
                aCurrentData.push(obj);
                aCurrentDataOld.push(objUpdatePrev);
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData", aCurrentData);
                this.getView().getModel("intStandardCycleModel").setProperty("/standardCycleDataInt", aCurrentDataOld);
                this.MachineFetchAddProdCopyBottleneckDB(resource);
                var index = 0;
                speedValue = parseFloat(aCurrentData[0].nominalSpeed);
                for (var i = 0; i < aCurrentData.length; i++) {
                    if (parseFloat(aCurrentData[i].nominalSpeed) < speedValue) {
                        speedValue = parseFloat(aCurrentData[i].nominalSpeed);
                        index = i;
                    }
                }
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/selected", true);
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/controlKey", "YBN1");
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/editKey", true);
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/enableKey", true);
                role === "S" ? this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/editable", false):this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/editable", true);
                role === "S" ? this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/enabled", false):this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/enabled", true);

                for (var i = 0; i < aCurrentData.length; i++) {
                    if (i != index) {
                        this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/selected", false);
                        this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/controlKey", aCurrentDataOld[i].controlKey);
                        this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/editKey", false);
                        this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/enableKey", true);
                        role === "S" ? this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/editable", false):this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/editable", true);
                        role === "S" ? this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/enabled", false):this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/enabled", true);

                    }
                }
                if (oSource) {
                    oSource.setEnabled(true);
                    oSource.setBusy(false);
                }

            },
            AddProdUpdateBottleneckDB: function (oEvent) {
                //role = sap.ui.getCore().getModel("loginUserModel").getData().results[0].AuthType;
                var aCurrentData = this.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
                if (!this.MandatoryFieldsUpdateBottleneckDB()) {
                    return;
                }
               
                var oSource = oEvent.getSource() || null;
                var resource = sap.ui.getCore().byId("idProdUpdateGetResource").getValue();
                var machine = sap.ui.getCore().byId("idProdUpdateGetMachine").getValue();
                var nominalSpeed = sap.ui.getCore().byId("idProdUpdateSpeed").getValue();
                var nsUom = sap.ui.getCore().byId("idProdUpdateNsUoM").getValue();
                var destinationKey = sap.ui.getCore().byId("idProdUpdateDestinationKey").getValue();
                var controlKey = sap.ui.getCore().byId("idProdUpdateControlKey").getValue();
                var pctlineEfficiency = sap.ui.getCore().byId("idProdUpdateLineEff").getValue();
                var capacityNo = sap.ui.getCore().byId("idProdUpdatecapacityNo").getValue();
                var numOfPeople = sap.ui.getCore().byId("idProdUpdatePeopleNo").getValue();
                totcrewSize = parseFloat(numOfPeople) + totcrewSize;
                var obj = {};
                obj.resource = resource;
                obj.machine = machine;
                obj.nominalSpeed = nominalSpeed;
                obj.nsUom = nsUom;
                obj.destinationKey = destinationKey;
                obj.controlKey = controlKey;
                obj.pctlineEfficiency = pctlineEfficiency;
                obj.capacityNo = capacityNo;
                obj.numOfPeople = numOfPeople;
                obj.edit = false;
                obj.enable = true;
                obj.selected = false
                var objPrev = {};
                objPrev.controlKey = controlKey;
																													
                if (aCurrentData.length > 0) {
                    var existingNsUoM = aCurrentData[0].nsUom;
                    if (existingNsUoM !== nsUom) {
                        // Show warning message if a different nsUoM value is attempted to be added
                        sap.m.MessageBox.warning("You can only add the same NS UoM value: " + existingNsUoM);
                        return;
                    }
                }
               
                var aCurrentDataOld = this.getView().getModel("intStandardCycleModel").getProperty("/standardCycleDataInt");
                aCurrentData.push(obj);
                aCurrentDataOld.push(objPrev);
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData", aCurrentData);
                this.getView().getModel("intStandardCycleModel").setProperty("/standardCycleDataInt", aCurrentDataOld);
                this.MachineFetchAddProdUpdateBottleneckDB(resource);
                var index = 0;
                speedValue = parseFloat(aCurrentData[0].nominalSpeed);
                for (var i = 0; i < aCurrentData.length; i++) {
                    if (parseFloat(aCurrentData[i].nominalSpeed) < speedValue) {
                        speedValue = parseFloat(aCurrentData[i].nominalSpeed);
                        index = i;
                       
                    }
                }
                
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/selected", true);
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/controlKey", "YBN1");
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/editKey", true);
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/enableKey", true);
                role === "S" ? this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/editable", false):this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/editable", true);
                role === "S" ? this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/enabled", false):this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/enabled", true);
                for (var j = 0; j < aCurrentData.length; j++) {
                    if (j !== index) {
                        this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + j + "/selected", false);
                        this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + j + "/controlKey", aCurrentDataOld[j].controlKey);
                        this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + j + "/editKey", false);
                        this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + j + "/enableKey", true);
                        role === "S" ? this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + j + "/editable", false):this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + j + "/editable", true);
                        role === "S" ? this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + j + "/enabled", false):this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + j + "/enabled", true);
                    }
                }
                if (oSource) {
                    oSource.setEnabled(true);
                    oSource.setBusy(false);
                }
            

            },
            getCurrentDateFormatted: function () {
                var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
                    ];
                var today = new Date();
                var month = months[today.getMonth()];
                var day = today.getDate();
                var year = today.getFullYear();
                defaultDate = month + ' ' + day + ', ' + year;
                return defaultDate;
            },
            // Product standard   
            AddvariableDtDB: function (oEvent) {
                var oSource = oEvent.getSource() || null;
                var lossCat = sap.ui.getCore().byId("idProdLossCat").getValue();
                var subCat = sap.ui.getCore().byId("idProdSubCat").getValue();
                var duration = sap.ui.getCore().byId("idDuration").getValue();
                var frequency = sap.ui.getCore().byId("idFrequency").getValue();
                var processOrderLotSize = sap.ui.getCore().byId("idCostingLotSize").getValue();
				// Validation for Loss Category and Subcategory
                if (lossCat && !subCat) {
                    var message = this.oResourceBundle.getText("SUB_CATEGORY_MISSING_ERROR");
                    this.onShowWarning(message);
                    return; // Stop execution if validation fails
                }
                if (processOrderLotSize === "") {
                    var message = this.oResourceBundle.getText("COSTING_LOT_SIZE_ERROR");
                    this.onShowWarning(message);
                } else {
                    var totVariableDt = (processOrderLotSize / frequency * duration / 60);
                    var obj = {};
                    obj.lossCat = lossCat;
                    obj.subCat = subCat;
                    obj.duration = duration;
                    obj.frequency = frequency;
                    obj.processOrderLotSize = processOrderLotSize;
                    obj.totVariableDt = totVariableDt.toFixed(3);
                    obj.edit = false;
                    obj.enable = true;
                    var aCurrentData = this.getView().getModel("variableDtDBModel").getProperty("/variableDtData");
                    aCurrentData.push(obj);
                    this.getView().getModel("variableDtDBModel").setProperty("/variableDtData", aCurrentData);
                    if (oSource) {
                        oSource.setEnabled(true);
                        oSource.setBusy(false);
                    }
                }

            },
            AddProdCopyvariableDtDB: function (oEvent) {
                                var oSource = oEvent.getSource() || null;
                // var varDtDesc = sap.ui.getCore().byId("idProdCopyVarDtDesc").getValue();
                var lossCat = sap.ui.getCore().byId("idProdcopyLossCat").getValue();
                var subCat = sap.ui.getCore().byId("idProdcopySubCat").getValue();
                var durationInMin = sap.ui.getCore().byId("idProdCopyDuration").getValue();
                var freqInProdUom = sap.ui.getCore().byId("idProdCopyFrequency").getValue();
                var procOrdrSizeOrCostingLotSize = sap.ui.getCore().byId("idProdCopyCreateReviewLotSize").getValue();
                if (lossCat && !subCat) {
                    var message = this.oResourceBundle.getText("SUB_CATEGORY_MISSING_ERROR");
                    this.onShowWarning(message);
                    return;
				}
                if (procOrdrSizeOrCostingLotSize === "") {
                    var message = this.oResourceBundle.getText("COSTING_LOT_SIZE_ERROR");
                    this.onShowWarning(message);
                } else {
                    var totalVarDT = (procOrdrSizeOrCostingLotSize / freqInProdUom * durationInMin / 60);
                    var obj = {};
                    obj.lossCat = lossCat;
                    obj.subCat = subCat;
                    obj.durationInMin = durationInMin;
                    obj.freqInProdUom = freqInProdUom;
                    obj.procOrdrSizeOrCostingLotSize = procOrdrSizeOrCostingLotSize;
                    obj.totalVarDT = totalVarDT.toFixed(3);
                    obj.edit = false;
                    obj.enable = true;
                    var aCurrentData = this.getView().getModel("globalResponseModel").getProperty("/variableDtData");
                    aCurrentData.push(obj);
                    this.getView().getModel("globalResponseModel").setProperty("/variableDtData", aCurrentData);
                     // Load sub-category list for the new loss category
                    var sPlant = sap.ui.getCore().byId("idProdCopyCreateReviewPlant").getSelectedKey();
                    var oRowIndex = aCurrentData.length - 1; // Index of the newly added row
                    this.fnAddVariableCopySubCat(this, sPlant, lossCat, false, oRowIndex);
					if (oSource) {
                        oSource.setEnabled(true);
                        oSource.setBusy(false);
                    }
                }
            },
            AddProdUpdatevariableDtDB: function (oEvent) {
                var oSource = oEvent.getSource() || null;
                var lossCat = sap.ui.getCore().byId("idProdUpdateLossCat").getValue();
                var subCat = sap.ui.getCore().byId("idProdUpdateSubCat").getValue();
                var durationInMin = sap.ui.getCore().byId("idProdUpdateDuration").getValue();
                var freqInProdUom = sap.ui.getCore().byId("idProdUpdateFrequency").getValue();
                var procOrdrSizeOrCostingLotSize = sap.ui.getCore().byId("idProdUpdateLotSize").getValue();
                if (procOrdrSizeOrCostingLotSize === "") {
                    var message = this.oResourceBundle.getText("COSTING_LOT_SIZE_ERROR");
                    this.onShowWarning(message);
                } else {
                    var totalVarDT = (procOrdrSizeOrCostingLotSize / freqInProdUom * durationInMin / 60);
                    var obj = {};
												 
                    obj.lossCat = lossCat;
                    obj.subCat = subCat;                  
                    obj.durationInMin = durationInMin;
                    obj.freqInProdUom = freqInProdUom;
                    obj.procOrdrSizeOrCostingLotSize = procOrdrSizeOrCostingLotSize;
                    obj.totalVarDT = totalVarDT.toFixed(3);
                    obj.edit = false;
                    obj.enable = true;
                    var aCurrentData = this.getView().getModel("globalResponseModel").getProperty("/variableDtData");
                    aCurrentData.push(obj);
                    this.getView().getModel("globalResponseModel").setProperty("/variableDtData", aCurrentData);
																	   
																									   
																							
																						  
                    if (oSource) {
                        oSource.setEnabled(true);
                        oSource.setBusy(false);
                    }
                }
            },
	fnAddVariableCopySubCat: function (that, sPlant, lossCat, oSelected, oRowindex) {
                var oModelProdsubCat = new sap.ui.model.json.JSONModel();
                var sUrl = "odata/v4/data-services/LineRelatedLossCatDB?$filter=plant eq '" + sPlant + "' and lossCat eq '" + lossCat + "'&$select=subCat";
                jQuery.ajax({
                    url: sUrl,
                    method: "GET",
                    success: function (data) {
                        oModelProdsubCat.setData(data);
                        oModelProdsubCat.setSizeLimit(100);

                        var aVariableDtData = that.getView().getModel("globalResponseModel").getProperty("/variableDtData");
                        for (var x = 0; x < aVariableDtData.length; x++) {
                            if (aVariableDtData[x].lossCat === lossCat) {
                                aVariableDtData[x].subCatList = data.value;
                                if (oSelected && oRowindex == x) {
                                    aVariableDtData[x].subCat = "";
                                }
                            }
                        }
                        that.getView().getModel("globalResponseModel").setProperty("/variableDtData", aVariableDtData);
                    }.bind(this),
                    error: function (oError) {
                        console.log("Error loading SubCategory data: ", oError);
                    }
                });
            },

            getMaterialDB: function () {
                var plant = sap.ui.getCore().byId("idProductCreatePlant").getSelectedKey();
                var that = this;
                if (!this._oMaterialDialog) {
                    this._oMaterialDialog = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.ProductStandardMaterialDialog", this);
                    this.getView().addDependent(this._oMaterialDialog);
                }

                this.getAssignedMaterialList(plant,matUom);

                // if (sap.ui.getCore().byId("idMaterialDB5") !== undefined) {
                // var oInput = oEvent.getSource();
                // var oContext = oInput.getBindingContext("globalResponseModel");

                // iMatSelectedIndex = oContext.getPath().split("/").pop();
                sap.ui.getCore().byId("addMRcomponentMat").setVisible(true);
                sap.ui.getCore().byId("updateMRcomponentMat").setVisible(false);
                sap.ui.getCore().byId("addCopyMRcomponentMat").setVisible(false)
                // } else {

                // }
                sap.ui.getCore().byId("idMaterialDialogDB").clearSelection();
                if (sap.ui.getCore().byId("searchField").getValue() !== "") {
                    sap.ui.getCore().byId("searchField").setValue();
                    var url = "/ETY_MATERIAL_LISTSet";
                    var oFilterPlant = new Filter({
                        filters: [
                            new Filter("WERKS", FilterOperator.EQ, plant)
                            ]
                    });
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            filters: [oFilterPlant],
                            success: function (oData) {

                                var results = oData.results;

                                var filteredResults = results.filter(function(item) {
                                    return item.MEINH === matUom;
                                });

                                // Create and set the JSONModel with the data received
                                var oModelMaterial = new sap.ui.model.json.JSONModel();
                                oModelMaterial.setData({ results: filteredResults });
                                oModelMaterial.setSizeLimit(10000);
                                this.getView().setModel(oModelMaterial, "materialModel");
                                BusyIndicator.hide();
                            }.bind(this),
                            error: function (xhr, _status, _error) {
                                // Handle errors
                                BusyIndicator.hide();
                                let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                        xhr.responseJSON.error.message :
                                            "Unknown error occurred.";
                                MessageToast.show(this.oResourceBundle.getText("MATERIAL_DB_FAIL") + " " + errorMessage);
                            }.bind(this),
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                }
            },
            getAssignedMaterialList: function(plant,matUom){
                var url = "/ETY_MATERIAL_LISTSet";
                BusyIndicator.show(0);
                var oFilterPlant = new Filter({
                    filters: [
                        new Filter("WERKS", FilterOperator.EQ, plant)
                        ]
                });
                var oFilterUom = new Filter({
                    filters: [
                        new Filter("MEINH", FilterOperator.EQ, matUom)
                        ]
                });
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        filters: [oFilterPlant,oFilterUom],
                        success: function (oData) {

                            // var results = oData.results;

                            // var filteredResults = results.filter(function(item) {
                            //     return item.MEINH === matUom;
                            // });

                            // // Create and set the JSONModel with the data received
                            var oModelMaterial = new sap.ui.model.json.JSONModel();
                            // oModelMaterial.setData({ results: filteredResults });
                            oModelMaterial.setData(oData);
                            oModelMaterial.setSizeLimit(10000);
                            this.getView().setModel(oModelMaterial, "materialModel");
                            BusyIndicator.hide();

                            this._oMaterialDialog.open();
                        }.bind(this),
                        error: function (jqXHR) {
                            BusyIndicator.hide();
                            let errorMessage = jqXHR.responseText ?
                                    JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                    // Handle errors
                                    MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);

                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    BusyIndicator.hide();
                }
            },

            getProdCopyMaterialDB: function () {
                var plant = sap.ui.getCore().byId("idProdCopyCreateReviewPlant").getSelectedKey();
                var that = this;
                if (!this._oMaterialDialog) {
                    this._oMaterialDialog = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.ProductStandardMaterialDialog", this);
                    this.getView().addDependent(this._oMaterialDialog);
                }
                this.getAssignedMaterialList(plant,matUom);


                // if (sap.ui.getCore().byId("idMaterialDB5") !== undefined) {
                // var oInput = oEvent.getSource();
                // var oContext = oInput.getBindingContext("globalResponseModel");

                // iMatSelectedIndex = oContext.getPath().split("/").pop();
                sap.ui.getCore().byId("addMRcomponentMat").setVisible(false);
                sap.ui.getCore().byId("updateMRcomponentMat").setVisible(false);
                sap.ui.getCore().byId("addCopyMRcomponentMat").setVisible(true);
                // } else {
                sap.ui.getCore().byId("updateMRcomponentMat").setVisible(false);
                // }
                sap.ui.getCore().byId("idMaterialDialogDB").clearSelection();
                if (sap.ui.getCore().byId("searchField").getValue() !== "") {
                    sap.ui.getCore().byId("searchField").setValue();
                    var url = "/ETY_MATERIAL_LISTSet";
                    var oFilterPlant = new Filter({
                        filters: [
                            new Filter("WERKS", FilterOperator.EQ, plant)
                            ]
                    });
                    var oFilterUom = new Filter({
                        filters: [
                            new Filter("MEINH", FilterOperator.EQ, matUom)
                            ]
                    });
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            filters: [oFilterPlant,oFilterUom],
                            success: function (oData) {



                                // Create and set the JSONModel with the data received
                                var oModelMaterial = new sap.ui.model.json.JSONModel();
                                oModelMaterial.setData(oData);
                                oModelMaterial.setSizeLimit(10000);
                                this.getView().setModel(oModelMaterial, "materialModel");
                                BusyIndicator.hide();
                            }.bind(this),
                            error: function (xhr, status, error) {
                                // Handle errors
                                BusyIndicator.hide();
                                let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                        xhr.responseJSON.error.message :
                                            "Unknown error occurred.";
                                MessageToast.show(this.oResourceBundle.getText("MATERIAL_DB_FAIL") + " " + errorMessage);
                            }.bind(this),
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                }
            },

            
            getAssignedMaterialDB: function () {
                var plant = sap.ui.getCore().byId("idProdUpdatePlant").getSelectedKey();
                var that = this;
                if (!this._oMaterialDialog) {
                    this._oMaterialDialog = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.ProductStandardMaterialDialog", this);
                    this.getView().addDependent(this._oMaterialDialog);
                }
                this.getAssignedMaterialList(plant,matUom);


                // if (sap.ui.getCore().byId("idMaterialDB5") !== undefined) {
                // var oInput = oEvent.getSource();
                // var oContext = oInput.getBindingContext("globalResponseModel");

                // iMatSelectedIndex = oContext.getPath().split("/").pop();
                sap.ui.getCore().byId("addMRcomponentMat").setVisible(false);
                sap.ui.getCore().byId("updateMRcomponentMat").setVisible(false);
                sap.ui.getCore().byId("addCopyMRcomponentMat").setVisible(true);
                sap.ui.getCore().byId("modifyCopyMRcomponentMat").setVisible(false);
                // } else {
                sap.ui.getCore().byId("updateMRcomponentMat").setVisible(false);
                // }
                sap.ui.getCore().byId("idMaterialDialogDB").clearSelection();
                if (sap.ui.getCore().byId("searchField").getValue() !== "") {
                    sap.ui.getCore().byId("searchField").setValue();
                    var url = "/ETY_MATERIAL_LISTSet";
                    var oFilterPlant = new Filter({
                        filters: [
                            new Filter("WERKS", FilterOperator.EQ, plant)
                            ]
                    });
                    var oFilterUom = new Filter({
                        filters: [
                            new Filter("MEINH", FilterOperator.EQ, matUom)
                            ]
                    });
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            filters: [oFilterPlant,oFilterUom],
                            success: function (oData) {



                                // Create and set the JSONModel with the data received
                                var oModelMaterial = new sap.ui.model.json.JSONModel();
                                oModelMaterial.setData(oData);
                                oModelMaterial.setSizeLimit(10000);
                                this.getView().setModel(oModelMaterial, "materialModel");
                                BusyIndicator.hide();
                            }.bind(this),
                            error: function (xhr, status, error) {
                                // Handle errors
                                BusyIndicator.hide();
                                let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                        xhr.responseJSON.error.message :
                                            "Unknown error occurred.";
                                MessageToast.show(this.oResourceBundle.getText("MATERIAL_DB_FAIL") + " " + errorMessage);
                            }.bind(this),
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                }
            },

            getProdUpdateMaterialDB: function (oEvent) {

                var plant = sap.ui.getCore().byId("idProdUpdatePlant").getSelectedKey();
                var that = this;
                if (!this._oMaterialDialog) {
                    this._oMaterialDialog = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.ProductStandardMaterialDialog", this);
                    this.getView().addDependent(this._oMaterialDialog);
                }
                this.getAssignedMaterialList(plant,matUom);

                sap.ui.getCore().byId("addMRcomponentMat").setVisible(false);
                sap.ui.getCore().byId("updateMRcomponentMat").setVisible(true);
                sap.ui.getCore().byId("addCopyMRcomponentMat").setVisible(false);
                sap.ui.getCore().byId("modifyCopyMRcomponentMat").setVisible(false);

                var oInput = oEvent.getSource();
                var oContext = oInput.getBindingContext("globalResponseModel");

                iMatSelectedIndex = oContext.getPath().split("/").pop();

                sap.ui.getCore().byId("idMaterialDialogDB").clearSelection();
                if (sap.ui.getCore().byId("searchField").getValue() !== "") {
                    sap.ui.getCore().byId("searchField").setValue();
                    var url = "/ETY_MATERIAL_LISTSet";
                    var oFilterPlant = new Filter({
                        filters: [
                            new Filter("WERKS", FilterOperator.EQ, plant)
                            ]
                    });
                    var oFilterUom = new Filter({
                        filters: [
                            new Filter("MEINH", FilterOperator.EQ, matUom)
                            ]
                    });
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            filters: [oFilterPlant,oFilterUom],
                            success: function (oData) {



                                // Create and set the JSONModel with the data received
                                var oModelMaterial = new sap.ui.model.json.JSONModel();
                                oModelMaterial.setData(oData);
                                oModelMaterial.setSizeLimit(10000);
                                this.getView().setModel(oModelMaterial, "materialModel");
                                BusyIndicator.hide();
                            }.bind(this),
                            error: function (xhr, _status, _error) {
                                // Handle errors
                                BusyIndicator.hide();
                                let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                        xhr.responseJSON.error.message :
                                            "Unknown error occurred.";
                                MessageToast.show(this.oResourceBundle.getText("MATERIAL_DB_FAIL") + " " + errorMessage);
                            }.bind(this),
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                }
            },
            addProdUpdateMaterialDB: function (oEvent) {

                var plant = sap.ui.getCore().byId("idProdUpdatePlant").getSelectedKey();
                var that = this;
                if (!this._oMaterialDialog) {
                    this._oMaterialDialog = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.ProductStandardMaterialDialog", this);
                    this.getView().addDependent(this._oMaterialDialog);
                }
                this.getAssignedMaterialList(plant,matUom);

                sap.ui.getCore().byId("addMRcomponentMat").setVisible(false);
                sap.ui.getCore().byId("updateMRcomponentMat").setVisible(false);
                sap.ui.getCore().byId("addCopyMRcomponentMat").setVisible(false);
                sap.ui.getCore().byId("modifyCopyMRcomponentMat").setVisible(true);


                // var oInput = oEvent.getSource();
                // var oContext = oInput.getBindingContext("globalResponseModel");

                // iMatSelectedIndex = oContext.getPath().split("/").pop();

                sap.ui.getCore().byId("idMaterialDialogDB").clearSelection();
                if (sap.ui.getCore().byId("searchField").getValue() !== "") {
                    sap.ui.getCore().byId("searchField").setValue();
                    var url = "/ETY_MATERIAL_LISTSet";
                    var oFilterPlant = new Filter({
                        filters: [
                            new Filter("WERKS", FilterOperator.EQ, plant)
                            ]
                    });
                    var oFilterUom = new Filter({
                        filters: [
                            new Filter("MEINH", FilterOperator.EQ, matUom)
                            ]
                    });
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            filters: [oFilterPlant,oFilterUom],
                            success: function (oData) {



                                // Create and set the JSONModel with the data received
                                var oModelMaterial = new sap.ui.model.json.JSONModel();
                                oModelMaterial.setData(oData);
                                oModelMaterial.setSizeLimit(10000);
                                this.getView().setModel(oModelMaterial, "materialModel");
                                BusyIndicator.hide();
                            }.bind(this),
                            error: function (xhr, _status, _error) {
                                // Handle errors
                                BusyIndicator.hide();
                                let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                        xhr.responseJSON.error.message :
                                            "Unknown error occurred.";
                                MessageToast.show(this.oResourceBundle.getText("MATERIAL_DB_FAIL") + " " + errorMessage);
                            }.bind(this),
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                }
            },
            // Product standard
            AddMaterialDB: function () {

                var materialDBCreateModel = new sap.ui.model.json.JSONModel();
                var aCurrentData = this.getView().getModel("materialDBCreateModel").getProperty("/materialData");
                var oMatTable = sap.ui.getCore().byId("idMaterialDialogDB");
                var matIndex = oMatTable.getSelectedIndices();
                if (matIndex.length === 0) {
                    var matMessage = this.oResourceBundle.getText("ADD_MATERIAL_DB_ERROR")
                    this.onShowWarning(matMessage);
                } else {
                    for (var i = 0; i < matIndex.length; i++) {
                        aCurrentData.push({
                            edit: false,
                            enable: true,
                            material: oMatTable.getContextByIndex(matIndex[i]).getProperty("MATNR"),
                            materialDesc: oMatTable.getContextByIndex(matIndex[i]).getProperty("MAKTX"),
                        })
                    }
                    sap.ui.getCore().byId("idMaterialDB1").setModel(materialDBCreateModel, "materialDBCreateModel");
                    sap.ui.getCore().byId("idMaterialDB").setModel(materialDBCreateModel, "materialDBCreateModel");
                    materialDBCreateModel.setProperty("/materialData", aCurrentData);
                }

                this._oMaterialDialog.close();
                this._oMaterialDialog.destroy();  
                this._oMaterialDialog = null;
            },
            ModifyMaterialDB: function () {

                var materialDBCreateModel = new sap.ui.model.json.JSONModel();
                var oModel = this.getView().getModel("globalResponseModel");
                var aCurrentData = this.getView().getModel("globalResponseModel").getProperty("/materialData");
                var oMatTable = sap.ui.getCore().byId("idMaterialDialogDB");
                var matIndex = oMatTable.getSelectedIndices();
                if (matIndex.length === 0) {
                    var matMessage = this.oResourceBundle.getText("ADD_MATERIAL_DB_ERROR")
                    this.onShowWarning(matMessage);
                } else {
                    for (var i = 0; i < matIndex.length; i++) {
                        aCurrentData.push({
                            edit: false,
                            enable: true,
                            material: oMatTable.getContextByIndex(matIndex[i]).getProperty("MATNR"),
                            materialDesc: oMatTable.getContextByIndex(matIndex[i]).getProperty("MAKTX"),
                        })
                    }
                    oModel.setProperty("/materialData", aCurrentData);
                    sap.ui.getCore().byId("idMaterialDB7").setModel(oModel, "globalResponseModel");
                    //sap.ui.getCore().byId("idMaterialDB6").setModel(materialDBCreateModel, "globalResponseModel");
                    //this.getView().getModel("globalResponseModel").setProperty("/materialData", aCurrentData);
                }

                this._oMaterialDialog.close();
                this._oMaterialDialog.destroy();  
                this._oMaterialDialog = null;
            },

            AddCopyMaterialDB: function () {

                var oModel = this.getView().getModel("globalResponseModel");
                var oMatTable = sap.ui.getCore().byId("idMaterialDialogDB");
                var matIndex = oMatTable.getSelectedIndices();
                var aCurrentData = oModel.getProperty("/materialData");
                if (matIndex.length === 0) {
                    var message = this.oResourceBundle.getText("ADD_MATERIAL_DB_ERROR")
                    this.onShowWarning(message);
                } else  {
                    for (var i = 0; i < matIndex.length; i++) {
                        aCurrentData.push({
                            edit: false,
                            enable: true,
                            material: oMatTable.getContextByIndex(matIndex[i]).getProperty("MATNR"),
                            materialDesc: oMatTable.getContextByIndex(matIndex[i]).getProperty("MAKTX"),
                        })
                    }

                    oModel.setProperty("/materialData", aCurrentData);
                    sap.ui.getCore().byId("idMaterialDB2").setModel(oModel, "globalResponseModel");
                } 

                this._oMaterialDialog.close();
                this._oMaterialDialog.destroy();  
                this._oMaterialDialog = null;
            },
            UpdateMaterialDB: function () {
                var oModel = this.getView().getModel("globalResponseModel");
                var oMatTable = sap.ui.getCore().byId("idMaterialDialogDB");
                var matIndex = oMatTable.getSelectedIndices();
                if (matIndex.length === 0) {
                    var message = this.oResourceBundle.getText("ADD_MATERIAL_DB_ERROR")
                    this.onShowWarning(message);
                } else {
                    var matIndex = oMatTable.getSelectedIndices();
                    var material = oMatTable.getContextByIndex(matIndex).getProperty("MATNR");
                    var materialDesc = oMatTable.getContextByIndex(matIndex).getProperty("MAKTX");
                    oModel.setProperty("/materialData/" + iMatSelectedIndex + "/material", material);
                    oModel.setProperty("/materialData/" + iMatSelectedIndex + "/materialDesc", materialDesc);
                    sap.ui.getCore().byId("idMaterialDB7").setModel(oModel, "globalResponseModel");
                }
                this._oMaterialDialog.close();
                this._oMaterialDialog.destroy();  
                this._oMaterialDialog = null;
            },
            handleCloseMatDialogButton: function () {
                this._oMaterialDialog.close();
                this._oMaterialDialog.destroy();  
                this._oMaterialDialog = null;
                sap.ui.getCore().byId("searchField").setValue();

            },
            backToMatWizardContent: function () {
                this._oMaterialDialog.close();
                this._oMaterialDialog.destroy();  
                this._oMaterialDialog = null;
                sap.ui.getCore().byId("searchField").setValue();
            },
            onMatSearch: function (oEvent) {
                var sQuery = oEvent.getParameter("query") || oEvent.getParameter("newValue");
                var oTable = sap.ui.getCore().byId("idMaterialDialogDB");
                var oBinding = oTable.getBinding("rows");
                var aFilters = [];
                if (sQuery && sQuery.length > 0) {
                    // Create a filter for each column
                    var oFilter = new Filter({
                        filters: [
                            new Filter("MATNR", FilterOperator.Contains, sQuery),
                            new Filter("MAKTX", FilterOperator.Contains, sQuery)
                            ],
                            and: false
                    });
                    aFilters.push(oFilter);
                }
                // Apply filters to the table binding
                oBinding.filter(aFilters);
            },
            // Product standard
            fnBottleNeckDBDeleteItem: function (oEvent) {
			sap.m.MessageBox.confirm(
                    this.oResourceBundle.getText("DELETE_CONFIRMATION"), // Message
                    {
                        actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                        onClose: function (sAction) { // Callback when the dialog is closed
                            if (sAction === MessageBox.Action.YES) {												
                var iItem = oEvent.getSource().getParent().getBindingContext("standardCycleModel").sPath.slice(19);
												   
                var aCurrentData = this.getView().getModel("standardCycleModel").getProperty("/standardCycleData");
                var aCurrentDataOld = this.getView().getModel("intStandardCycleModel").getProperty("/standardCycleDataInt");
                var aNewData = aCurrentData.splice(iItem, 1);
                var aNewDataPrev = aCurrentDataOld.splice(iItem, 1);
                this.getView().getModel("standardCycleModel").setProperty("/standardCycleData", aCurrentData);
                this.getView().getModel("intStandardCycleModel").setProperty("/standardCycleDataInt", aCurrentDataOld);
																							
                var aStandardCycleData = this.getView().getModel("standardCycleModel").getProperty("/standardCycleData");
                var index = 0;
                var speedValue = parseFloat(aStandardCycleData[0].speed);
                for (var i = 0; i < aStandardCycleData.length; i++) {
                    if (parseFloat(aStandardCycleData[i].speed) < speedValue) {
                        speedValue = parseFloat(aCurrentData[i].speed);
                        bottleneckResource = aCurrentData[i].secRes;
                        bottleneckSpeedUom = aCurrentData[i].nsUoM;
                        index = i;	 
                    }
                }
                this.getView().getModel("standardCycleModel").setProperty("/standardCycleData/" + index + "/selected", true);
                this.getView().getModel("standardCycleModel").setProperty("/standardCycleData/" + index + "/controlKey", "YBN1");
                for (var j = 0; j < aStandardCycleData.length; j++) {
                                    if (j !== index) {
                                        this.getView().getModel("standardCycleModel").setProperty("/standardCycleData/" + j + "/selected", false);
                                    }
                                    // else{
                                    //     this.getView().getModel("standardCycleModel").setProperty("/standardCycleData",[]);
                                    //     this.getView().getModel("intStandardCycleModel").setProperty("/standardCycleDataInt",[]);
                                    //     }
                                }

                            }
                        }.bind(this)
                    }
                
            );
        },
            // Product standard
            fnDeleteMaterialDBItem: function (oEvent) {
                sap.m.MessageBox.confirm(
                    this.oResourceBundle.getText("DELETE_CONFIRMATION"), // Message
                    {
                        actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                        onClose: function (sAction) { // Callback when the dialog is closed
                            if (sAction === MessageBox.Action.YES) {
                                var materialDBCreateModel = new sap.ui.model.json.JSONModel();
                                var iItem = oEvent.getSource().getParent().getBindingContext("materialDBCreateModel").sPath.slice(14);
                                var aCurrentData = this.getView().getModel("materialDBCreateModel").getProperty("/materialData");
                                aCurrentData.splice(iItem, 1);
                                sap.ui.getCore().byId("idMaterialDB").setModel(materialDBCreateModel, "materialDBCreateModel");
                                materialDBCreateModel.setProperty("/materialData", aCurrentData);
                            }
                        }.bind(this)
                    }
                );

            },
            // Product standard
            fnVaraibleDTDeleteItem: function (oEvent) {
                sap.m.MessageBox.confirm(
                    this.oResourceBundle.getText("DELETE_CONFIRMATION"), // Message
                    {
                        actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                        onClose: function (sAction) { // Callback when the dialog is closed
                            if (sAction === MessageBox.Action.YES) {
                                var iItem = oEvent.getSource().getParent().getBindingContext("variableDtDBModel").sPath.slice(16);
                                var aCurrentData = this.getView().getModel("variableDtDBModel").getProperty("/variableDtData");
                                aCurrentData.splice(iItem, 1);
                                this.getView().getModel("variableDtDBModel").setProperty("/variableDtData", aCurrentData);
                            }
                        }.bind(this)
                    }
                );
            },
            onProdMenuApprove: function (oEvent) {
                var that = this;
                if (!this._oApproverReviewProd) {
                    this._oApproverReviewProd = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.ApproverReviewProdStd", this);
                    this.getView().addDependent(this._oApproverReviewProd);
                }
                sProductComment = 1;
                this._oApproverReviewProd.open();
                var TableIndex = this.getView().byId("idProductTable").getItems().indexOf(oEvent.getSource().getParent());
                var oModel = this.getView().getModel("productModel");
                prdStandardNo = oModel.getData().value[TableIndex].prodStdNo;
                approverLevel = oModel.getData().value[TableIndex].stdApprLvl;
                var oModel = this.getView().getModel("productModel");
                var ID = oModel.getData().value[TableIndex].ID;
                var url = `odata/v4/data-services/ProductRelStandardHeadersDB(ID=${ID},prodStdNo='${prdStandardNo}')?$expand=ProdStdToProdBttlnckDataNav($filter=modificationType ne 'D'),ProdStdToProdSecResDataNav,ProdStdToProdVarDtDataNav,ProdStdToProdMatrAllDataNav`;
                BusyIndicator.show(0);
                $.ajax({
                    url: url,
                    method: 'GET',
                    headers: {
                        'x-username': nbId,
                        'x-zone': zone,
                        'x-plants': plantsParam,
                        'x-role': "Approver"
                    },
                    success: function (response) {
                        BusyIndicator.hide();
                        MessageToast.show(that.oResourceBundle.getText("PROD_STD_DB_SUCCESS"));
                        var prodBttlnckData = response.ProdStdToProdBttlnckDataNav;
                        var prodSecResData = response.ProdStdToProdSecResDataNav;
                        var prodVarDtData = response.ProdStdToProdVarDtDataNav;
                        var prodMatrData = response.ProdStdToProdMatrAllDataNav;
                        that.oglobalResponseModel.setData({
                            standardCycleData: prodBttlnckData,
                            variableDtData: prodVarDtData,
                            materialData: prodMatrData,
                            SecondaryResData: prodSecResData
                        });
                        configNo = response.configNo;
                        prodId = response.ID;
                        sap.ui.getCore().byId("idProdApprovePlant").setText(response.plant);
                        sap.ui.getCore().byId("idProdApproveValidFrom").setText(that.getDateFormat(response.validFrom));
                        sap.ui.getCore().byId("idProdApproveValidTo").setText(that.getDateFormat(response.validTo));
                        sap.ui.getCore().byId("idProdApproveLotSize").setText(response.procOrdrSizeOrCostingLotSize);
                        sap.ui.getCore().byId("idProdApproveMrNo").setText(response.mrGroup);
                        sap.ui.getCore().byId("idProdApproveCostCenter").setText(response.costCenter);
                        sap.ui.getCore().byId("idProdApproveMrCounter").setText(response.mrCounter);
                        sap.ui.getCore().byId("idProdApproveAiPercent").setText(response.pctAI);
                        sap.ui.getCore().byId("idProdApproveEff").setText(response.lineEfficiency);
                        sap.ui.getCore().byId("idProdApproveNS").setText(response.nominalSpeed);
                        sap.ui.getCore().byId("idProdApproveOperationQty").setText(response.operationQty);
                        sap.ui.getCore().byId("idProdApproveChrgQty").setText(response.chargeQty);
                        var bottleneckCorrect = (response.bottleneckCorrect === "Y") ? "True" : "False";
                        sap.ui.getCore().byId("idProdApproveBottleneckCorrect").setText(bottleneckCorrect);
                        sap.ui.getCore().byId("idProdApproveDescription").setText(response.masterRecipeDesc);
                        sap.ui.getCore().byId("idProdApproveCrewSize").setText(response.crewSize);
                        sap.ui.getCore().byId("idProdApproveCostCenter").setText(response.costCenter);
                        sap.ui.getCore().byId("idProdApproveBottleneckCorrect")
                        .addStyleClass((bottleneckCorrect === "True") ? "greenText" : "redText")
                        .removeStyleClass((bottleneckCorrect === "True") ? "redText" : "greenText")
                    },
                    error: function (xhr, status, error) {
                        // Hide BusyIndicator and show error message
                        BusyIndicator.hide();
                        let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                xhr.responseJSON.error.message :
                                    that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                        MessageToast.show(that.oResourceBundle.getText("PROD_STD_DB_FAIL") + " " + errorMessage);
                    }
                });
            },
            onApprove: function (oEvent) {
                var that = this;
                var payload = {
                        "stdNo": prdStandardNo,
                        "configNo": configNo,
                        "currentApprStdLevel": approverLevel
                }
                // Create the payload
                var sUrl = "odata/v4/data-services/onApproveProductStd";
                BusyIndicator.show(0);
                $.ajax({
                    url: sUrl,
                    type: "POST",
                    data: JSON.stringify(payload),
                    contentType: "application/json",
                    headers: {
                        'x-username': nbId

                    }
                })
                .done(function (response) {
                    BusyIndicator.hide();
                    var message = that.oResourceBundle.getText("PROD_APPROVE_SUCCESS");
                    that.onShowSuccess(message);
                    var initialCallFlag = 0;
                    that.getProductStdHeaderData(initialCallFlag);
                })
                .fail(function (xhr, _status, _error) {
                    BusyIndicator.hide();
                    let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                            xhr.responseJSON.error.message :
                                that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                    var message = that.oResourceBundle.getText("PROD_APPROVE_FAIL") + " " + errorMessage;
                    that.onShowError(message);
                    var initialCallFlag = 0;
                    that.getProductStdHeaderData(initialCallFlag);
                });
                this._oApproverReviewProd.close();
            },
            backToApproverWizardContent: function () {
                this._oApproverReviewProd.close();
            },
            onProdMenuExecute: function (oEvent) {
                var that = this;
                if (!this._oExecutorReviewProd) {
                    this._oExecutorReviewProd = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.ExecutorReviewProdStd", this);
                    this.getView().addDependent(this._oExecutorReviewProd);
                }
                this._oExecutorReviewProd.open();
                var TableIndex = this.getView().byId("idProductTable").getItems().indexOf(oEvent.getSource().getParent());
                var oModel = this.getView().getModel("productModel");
                prdStandardNo = oModel.getData().value[TableIndex].prodStdNo;
                var oModel = this.getView().getModel("productModel");
                var ID = oModel.getData().value[TableIndex].ID;
                var url = `odata/v4/data-services/ProductRelStandardHeadersDB(ID=${ID},prodStdNo='${prdStandardNo}')?$expand=ProdStdToProdBttlnckDataNav($filter=modificationType ne 'D'),ProdStdToProdSecResDataNav,ProdStdToProdVarDtDataNav,ProdStdToProdMatrAllDataNav`;
                BusyIndicator.show(0);
                $.ajax({
                    url: url,
                    method: 'GET',
                    headers: {
                        'x-username': nbId,
                        'x-zone': zone,
                        'x-plants': plantsParam,
                        'x-role': "Executor/Viewer"
                    },
                    success: function (response) {
                        // Hide BusyIndicator and show success message
                        BusyIndicator.hide();
                        MessageToast.show(that.oResourceBundle.getText("PROD_STD_DB_SUCCESS"));
                        var prodBttlnckData = response.ProdStdToProdBttlnckDataNav;
                        var prodSecResData = response.ProdStdToProdSecResDataNav;
                        var prodVarDtData = response.ProdStdToProdVarDtDataNav;
                        var prodMatrData = response.ProdStdToProdMatrAllDataNav;
                        that.oglobalResponseModel.setData({
                            standardCycleData: prodBttlnckData,
                            variableDtData: prodVarDtData,
                            materialData: prodMatrData,
                            SecondaryResData: prodSecResData
                        });
                        configNo = response.configNo;
                        prodId = response.ID;
                        sap.ui.getCore().byId("idProdExecutePlant").setText(response.plant);
                        sap.ui.getCore().byId("idProdExecuteValidFrom").setText(that.getDateFormat(response.validFrom));
                        sap.ui.getCore().byId("idProdExecuteValidTo").setText(that.getDateFormat(response.validTo));
                        sap.ui.getCore().byId("idProdExecuteLotSize").setText(response.procOrdrSizeOrCostingLotSize);
                        sap.ui.getCore().byId("idProdExecuteMrNo").setText(response.mrGroup);
                        sap.ui.getCore().byId("idProdExecuteCostCenter").setText(response.costCenter);
                        sap.ui.getCore().byId("idProdExecuteMrCounter").setText(response.mrCounter);
                        sap.ui.getCore().byId("idProdExecuteAiPercent").setText(response.pctAI);
                        sap.ui.getCore().byId("idProdExecuteEff").setText(response.lineEfficiency);
                        sap.ui.getCore().byId("idProdExecuteNS").setText(response.nominalSpeed);
                        sap.ui.getCore().byId("idProdExecuteOperationQty").setText(response.operationQty);
                        sap.ui.getCore().byId("idProdExecuteChrgQty").setText(response.chargeQty);
                        var bottleneckCorrect = (response.bottleneckCorrect === "Y") ? "True" : "False";
                        sap.ui.getCore().byId("idProdExecuteBottleneckCorrect").setText(bottleneckCorrect);
                        sap.ui.getCore().byId("idProdExecuteDescription").setText(response.masterRecipeDesc);
                        sap.ui.getCore().byId("idProdExecuteCrewSize").setText(response.crewSize);
                        sap.ui.getCore().byId("idProdExecuteCostCenter").setText(response.costCenter);
                        sap.ui.getCore().byId("idProdExecuteBottleneckCorrect")
                        .addStyleClass((bottleneckCorrect === "True") ? "greenText" : "redText")
                        .removeStyleClass((bottleneckCorrect === "True") ? "redText" : "greenText")
                    },
                    error: function (xhr, _status, _error) {
                        // Hide BusyIndicator and show error message
                        BusyIndicator.hide();
                        let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                xhr.responseJSON.error.message :
                                    that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                        MessageToast.show(that.oResourceBundle.getText("PROD_STD_DB_FAIL") + " " + errorMessage);
                    }
                });
            },
            onExecute: function () {
                var that = this;
                var nbId = sap.ui.getCore().getModel("loginUserModel").getData().results[0].Username;
                var payload = {

                        "stdNo": prdStandardNo,
                        "configNo": configNo,
                        "executor": nbId
                }
                // Create the payload

                var sUrl = "odata/v4/data-services/onExecuteNAProductStd";
                BusyIndicator.show(0);
                $.ajax({
                    url: sUrl,
                    type: "POST",
                    data: JSON.stringify(payload),
                    contentType: "application/json"
                })
                .done(function (_response) {
                    BusyIndicator.hide();
                    var message = that.oResourceBundle.getText("PROD_EXECUTION_SUCCESS");
                    that.onShowSuccess(message);
                    var viewerFlag =0;
                    that.fnProdExecutionRecords(viewerFlag);
                })
                .fail(function (xhr, _status, _error) {
                    BusyIndicator.hide();
                    let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                            xhr.responseJSON.error.message :
                                that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                    var message = that.oResourceBundle.getText("PROD_EXECUTION_FAIL") + " " + errorMessage;
                    that.onShowError(message);
                    var viewerFlag =0;
                    that.fnProdExecutionRecords(viewerFlag);
                });
                this._oExecutorReviewProd.close();
            },
            backToExecutorWizardContent: function () {
                this._oExecutorReviewProd.close();
            },
            onRework: function () {
                if (!this._reworkComment) {
                    this._reworkComment = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.PopoverProdApproverComment", this);
                    this.getView().addDependent(this._reworkComment);
                }
                this._reworkComment.open();
            },
            onRadioPress: function (oEvent) {
                var that = this;
                var oModel = this.getView().getModel("standardCycleModel");
                var aData = oModel.getProperty("/standardCycleData");
                var iRowCount = aData.length;
                var source = oEvent.getSource();
                var context = source.getBindingContext("standardCycleModel");
                var index = context.getPath().split("/").pop();
                var changedSpeed = oModel.getProperty("/standardCycleData/" + index + "/speed");
                var changedEfficiency = oModel.getProperty("/standardCycleData/" + index + "/lineEff");
                var changedResource = oModel.getProperty("/standardCycleData/" + index + "/resource");
                var plant = sap.ui.getCore().byId("idProductCreatePlant").getSelectedKey();
                var avariableDtData = this.getView().getModel("variableDtDBModel").getProperty("/variableDtData");
                var totalVariableDt = 0;
                for (var i = 0; i < avariableDtData.length; i++) {
                    var variableDtInt = Number(avariableDtData[i].totVariableDt);
                    totalVariableDt = variableDtInt + totalVariableDt;
                }
                var costingLotSize = sap.ui.getCore().byId("idProdCreateReviewLotSize").getText();
                var url = `/ETY_CostCentre_ValueHelpSet(Werks='${plant}',Arbpl='${changedResource}')`;
                var oModelCostcenter = new sap.ui.model.json.JSONModel();
                BusyIndicator.show(0);
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        success: function (oData) {
                            oModelCostcenter.setData(oData);
                            // Get the new data from the temporary model
                            var newData = oModelCostcenter.getData();
                            var updatedCostCenter = newData.Kostl;
                            var costCenterControl = sap.ui.getCore().byId("idHeaderProdCreateCostCenter");
                            if (costCenterControl) {
                                // Use attachEvent to set the text after rendering
                                costCenterControl.attachEvent("afterRendering", function () {
                                    this.setText(updatedCostCenter);
                                });
                            }
                            sap.ui.getCore().byId("idHeaderProdCreateCostCenter").setText(updatedCostCenter);
                            BusyIndicator.hide();
                        }.bind(this),
                        error: function (xhr, status, error) {
                            BusyIndicator.hide();
                            let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                    xhr.responseJSON.error.message :
                                        this.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                            var message = this.oResourceBundle.getText("COST_LOT_FETCH_ECC_FAIL") + " " + errorMessage;
                            this.onShowError(message);
                        }.bind(this),
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
                sap.ui.getCore().byId("idExpectedEfficiency").setText(changedEfficiency);
                sap.ui.getCore().byId("idprodcreateNominalSpeed").setText(changedSpeed);
                var prodStdValidFrom = sap.ui.getCore().byId("idProdCreateReviewValidFrom").getText();
                var tempLineStdNo = "LR" + "_" + plant + "_" + changedResource + "_";
                var formattedProdStdValidFrom = this.fnFormattedDate2(prodStdValidFrom);
                var url = `odata/v4/data-services/getProductionLoss(stdPrefix='${tempLineStdNo}',validFromDate=${formattedProdStdValidFrom})`;
                $.get(url)
                .done(function (response) {
                    plannedDtLossVal = (response.value) / 100;
                    var percentageAI = ((costingLotSize / changedSpeed) / ((costingLotSize / changedSpeed / changedEfficiency / 100) + totalVariableDt / (1 - plannedDtLossVal))).toFixed(3);
                    sap.ui.getCore().byId("idAIPercent").setText(percentageAI);
                }).fail(function (xhr, status, error) {
                    let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                            xhr.responseJSON.error.message :
                                this.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                    MessageToast.show(this.oResourceBundle.getText("PLANNED_DT_RETRIEVE_FAIL") + " " + errorMessage);
                }.bind(this));
                var aCurrentDataOld = this.getView().getModel("intStandardCycleModel").getProperty("/standardCycleDataInt");
                for (var i = 0; i < iRowCount; i++) {
                    if (i != index) {
                        oModel.setProperty("/standardCycleData/" + i + "/controlKey", aCurrentDataOld[i].controlKey);
                        oModel.setProperty("/standardCycleData/" + i + "/selected", false);
                        oModel.setProperty("/standardCycleData/" + i + "/editKey", false);
                        oModel.setProperty("/standardCycleData/" + i + "/enableKey", true);
                        oModel.setProperty("/standardCycleData/" + i + "/style", "coloredActualBottleneckSpeed");
                    } else {
                        oModel.setProperty("/standardCycleData/" + index + "/selected", true);
                        controlKeyPreviousVal = aCurrentDataOld[i].controlKey;
                        oModel.setProperty("/standardCycleData/" + index + "/controlKey", "YBN1");
                        oModel.setProperty("/standardCycleData/" + index + "/editKey", true);
                        oModel.setProperty("/standardCycleData/" + index + "/enableKey", true);
                        if (speedValue == aData[index].speed) {
                            sap.ui.getCore().byId("idProdCreateBottleneckCorrect").setText("True");
                            sap.ui.getCore().byId("idProdCreateBottleneckCorrect").addStyleClass("greenText");
                            sap.ui.getCore().byId("idProdCreateBottleneckCorrect").removeStyleClass("redText");
                            oModel.setProperty("/standardCycleData/" + index + "/style", "coloredActualBottleneckSpeed");
                        } else {
                            sap.ui.getCore().byId("idProdCreateBottleneckCorrect").setText("False");
                            sap.ui.getCore().byId("idProdCreateBottleneckCorrect").removeStyleClass("greenText");
                            sap.ui.getCore().byId("idProdCreateBottleneckCorrect").addStyleClass("redText");
                            oModel.setProperty("/standardCycleData/" + index + "/style", "coloredFalseBottleneckSpeed");
                        }
                    }
                }
            },
            onNominalSpeedChange: function (oEvent) {
                
                var aCurrentData = this.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
                var index = 0;
                var speedValue = isNaN(parseFloat(oEvent.getParameter("value"))) ? "" : parseFloat(oEvent.getParameter("value"));
                var sPath = oEvent.getSource().getBindingContext("globalResponseModel").getPath();
                var oModel = this.getView().getModel("globalResponseModel");
                oModel.setProperty(sPath + "/nominalSpeed", speedValue);
               // var oModel = that.getView().getModel("globalResponseModel");
               
                var aCurrentDataOld = this.getView().getModel("intStandardCycleModel").getProperty("/standardCycleDataInt");
                for (var i = 0; i < aCurrentData.length; i++) {
                    if (parseFloat(aCurrentData[i].nominalSpeed) < parseFloat(speedValue)) {
                        speedValue = parseFloat(aCurrentData[i].nominalSpeed);
                        index = i;
                        var flag = i;
                    }

                }
                if (flag === undefined) {
                    for (var i = 0; i < aCurrentData.length; i++) {
                        if (parseFloat(aCurrentData[i].nominalSpeed) == parseFloat(speedValue)) {
                            speedValue = parseFloat(aCurrentData[i].nominalSpeed);
                            index = i;
                            break;
                        }

                    }
                }
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/selected", true);
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/controlKey", "YBN1");
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/editKey", true);
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/enableKey", true);
                for (var i = 0; i < aCurrentData.length; i++) {
                    if (i != index) {
                        this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/selected", false);
                        role === "S" ? this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/controlKey", ""):this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/controlKey", aCurrentDataOld[i].controlKey);
                        this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/editKey", false);
                        this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/enableKey", true);
                    }
                }
                oModel.refresh(true);
            },

            onProdUpdateNominalSpeedChange: function (oEvent) {
                
                var aCurrentData = this.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
                var index = 0;
                var speedValue = isNaN(parseFloat(oEvent.getParameter("value"))) ? "" : parseFloat(oEvent.getParameter("value"));
                var sPath = oEvent.getSource().getBindingContext("globalResponseModel").getPath();
                var changeSpeedIndex = sPath.split("/").pop();
                var oModel = this.getView().getModel("globalResponseModel");
                oModel.setProperty(sPath + "/nominalSpeed", speedValue);           
                var aCurrentDataOld = this.getView().getModel("intStandardCycleModel").getProperty("/standardCycleDataInt");
                for (var i = 0; i < aCurrentData.length; i++) {
                    if (parseFloat(aCurrentData[i].nominalSpeed) < parseFloat(speedValue)) {
                        speedValue = parseFloat(aCurrentData[i].nominalSpeed);
                        index = i;
                        var flag = i;
                        
                    }

                }
                
                if (flag === undefined) {
                    for (var i = 0; i < aCurrentData.length; i++) {
                        if (parseFloat(aCurrentData[i].nominalSpeed) == parseFloat(speedValue)) {
                            speedValue = parseFloat(aCurrentData[i].nominalSpeed);
                            index = i;
                           
                            break;
                        }

                    }
                }
                
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/selected", true);
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/controlKey", "YBN1");
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/editKey", true);
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/enableKey", true);
                for (var i = 0; i < aCurrentData.length; i++) {
                    if (i != index) {
                        this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/selected", false);
                        role === "S" ? this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/controlKey", ""): this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/controlKey", aCurrentDataOld[i].controlKey);
                        this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/editKey", false);
                        this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/enableKey", true);
                    }
                }
                oModel.refresh(true);
            
            },
               
            onCopyRadioPress: function (oEvent) {
                var that = this;
                var oModel = this.getView().getModel("globalResponseModel");
                var aData = oModel.getProperty("/standardCycleData");
                var iRowCount = aData.length;
                var source = oEvent.getSource();
                var context = source.getBindingContext("globalResponseModel");
                var index = context.getPath().split("/").pop();
                var changedSpeed = oModel.getProperty("/standardCycleData/" + index + "/nominalSpeed");
                var changedEfficiency = oModel.getProperty("/standardCycleData/" + index + "/pctlineEfficiency");
                var changedResource = oModel.getProperty("/standardCycleData/" + index + "/resource");
                var plant = sap.ui.getCore().byId("idProdCreateCopyPlant").getText();
                var avariableDtData = this.getView().getModel("globalResponseModel").getProperty("/variableDtData");
                var totalVariableDt = 0;
                for (var i = 0; i < avariableDtData.length; i++) {
                    var variableDtInt = Number(avariableDtData[i].totalVarDT);
                    totalVariableDt = variableDtInt + totalVariableDt;
                }
                var costingLotSize = sap.ui.getCore().byId("idProdCreateCopyLotSize").getText();
                sap.ui.getCore().byId("idProdCreateCopyEff").setText(changedEfficiency);
                sap.ui.getCore().byId("idProdCreateCopyNS").setText(changedSpeed);
                var aCurrentDataOld = this.getView().getModel("intStandardCycleModel").getProperty("/standardCycleDataInt");
                for (var i = 0; i < iRowCount; i++) {
                    if (i != index) {
                        oModel.setProperty("/standardCycleData/" + i + "/controlKey", aCurrentDataOld[i].controlKey);
                        oModel.setProperty("/standardCycleData/" + i + "/selected", false);
                        oModel.setProperty("/standardCycleData/" + i + "/editKey", false);
                        oModel.setProperty("/standardCycleData/" + i + "/enableKey", true);
                        oModel.setProperty("/standardCycleData/" + i + "/style", "coloredActualBottleneckSpeed");
                    } else {
                        oModel.setProperty("/standardCycleData/" + index + "/selected", true);
                        oModel.setProperty("/standardCycleData/" + index + "/controlKey", "YBN1");
                        oModel.setProperty("/standardCycleData/" + index + "/editKey", true);
                        oModel.setProperty("/standardCycleData/" + index + "/enableKey", true);
                        if (copiedSpeedValue == aData[index].nominalSpeed) {
                            sap.ui.getCore().byId("idProdCreateCopyBottleneckCorrect").setText("True");
                            sap.ui.getCore().byId("idProdCreateCopyBottleneckCorrect").addStyleClass("greenText");
                            sap.ui.getCore().byId("idProdCreateCopyBottleneckCorrect").removeStyleClass("redText");
                            oModel.setProperty("/standardCycleData/" + index + "/style", "coloredActualBottleneckSpeed");
                        } else {
                            sap.ui.getCore().byId("idProdCreateCopyBottleneckCorrect").setText("False");
                            sap.ui.getCore().byId("idProdCreateCopyBottleneckCorrect").removeStyleClass("greenText");
                            sap.ui.getCore().byId("idProdCreateCopyBottleneckCorrect").addStyleClass("redText");
                            oModel.setProperty("/standardCycleData/" + index + "/style", "coloredFalseBottleneckSpeed");
                        }
                    }
                }

                var url = `/ETY_CostCentre_ValueHelpSet(Werks='${plant}',Arbpl='${changedResource}')`;
                var oModelCostcenter = new sap.ui.model.json.JSONModel();
                BusyIndicator.show(0);
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        success: function (oData) {
                            oModelCostcenter.setData(oData);
                            var newData = oModelCostcenter.getData();
                            var updatedCostCenter = newData.Kostl;
                            sap.ui.getCore().byId("idProdCreateCopyCostCenter").setText(updatedCostCenter);
                            var prodStdValidFrom = sap.ui.getCore().byId("idProdCreateCopyValidFrom").getText();
                            var tempLineStdNo = "LR" + "_" + plant + "_" + changedResource + "_";
                            var formattedProdStdValidFrom = this.fnFormattedDate2(prodStdValidFrom);
                            var url = `odata/v4/data-services/getProductionLoss(stdPrefix='${tempLineStdNo}',validFromDate=${formattedProdStdValidFrom})`;
                            $.get(url)
                            .done(function (response) {
                                plannedDtLossVal = (response.value) / 100;
                                var percentageAI = ((costingLotSize / changedSpeed) / ((costingLotSize / changedSpeed / changedEfficiency / 100) + totalVariableDt / (1 - plannedDtLossVal))).toFixed(3);
                                sap.ui.getCore().byId("idProdCreateCopyAiPercent").setText(percentageAI);
                            }).fail(function (xhr, status, error) {
                                let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                        xhr.responseJSON.error.message :
                                            this.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                var message = this.oResourceBundle.getText("COST_LOT_FETCH_ECC_FAIL") + " " + errorMessage;
                                this.onShowError(message);
                            });
                            BusyIndicator.hide();
                        }.bind(this),
                        error: (function (xhr, status, error) {
                            // Hide the busy indicator in case of error
                            BusyIndicator.hide();
                            let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                    xhr.responseJSON.error.message :
                                        this.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                            var message = this.oResourceBundle.getText("COST_LOT_FETCH_ECC_FAIL") + " " + errorMessage;
                            this.onShowError(message);
                        }.bind(this))
                    })
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
            },
            onProdUpdateRadioPress: function (oEvent) {
                var that = this;
                var oModel = this.getView().getModel("globalResponseModel");
                var aData = oModel.getProperty("/standardCycleData");
                var iRowCount = aData.length;
                var source = oEvent.getSource();
                var context = source.getBindingContext("globalResponseModel");
                var index = context.getPath().split("/").pop();
                var changedSpeed = oModel.getProperty("/standardCycleData/" + index + "/nominalSpeed");
                var changedEfficiency = oModel.getProperty("/standardCycleData/" + index + "/pctlineEfficiency");
                var changedResource = oModel.getProperty("/standardCycleData/" + index + "/resource");
                var plant = sap.ui.getCore().byId("idProdUpdateReviewPlant").getText();
                var avariableDtData = this.getView().getModel("globalResponseModel").getProperty("/variableDtData");
                var totalVariableDt = 0;
                for (var i = 0; i < avariableDtData.length; i++) {
                    var variableDtInt = Number(avariableDtData[i].totalVarDT);
                    totalVariableDt = variableDtInt + totalVariableDt;
                }
                var costingLotSize = sap.ui.getCore().byId("idProdUpdateReviewLotSize").getText();
                sap.ui.getCore().byId("idProdUpdateReviewEff").setText(changedEfficiency);
                sap.ui.getCore().byId("idProdUpdateReviewNS").setText(changedSpeed);
                var aCurrentDataOld = this.getView().getModel("intStandardCycleModel").getProperty("/standardCycleDataInt");
                for (var i = 0; i < iRowCount; i++) {
                    if (i != index) {
                        oModel.setProperty("/standardCycleData/" + i + "/controlKey", aCurrentDataOld[i].controlKey);
                        oModel.setProperty("/standardCycleData/" + i + "/selected", false);
                        oModel.setProperty("/standardCycleData/" + i + "/editKey", false);
                        oModel.setProperty("/standardCycleData/" + i + "/enableKey", true);
                        oModel.setProperty("/standardCycleData/" + i + "/style", "coloredActualBottleneckSpeed");
                    } else {
                        oModel.setProperty("/standardCycleData/" + index + "/selected", true);
                        oModel.setProperty("/standardCycleData/" + index + "/controlKey", "YBN1");
                        oModel.setProperty("/standardCycleData/" + index + "/editKey", true);
                        oModel.setProperty("/standardCycleData/" + index + "/enableKey", true);
                        if (copiedSpeedValue == aData[index].nominalSpeed) {
                            sap.ui.getCore().byId("idProdUpdateReviewBottleneckCorrect").setText("True");
                            sap.ui.getCore().byId("idProdUpdateReviewBottleneckCorrect").addStyleClass("greenText");
                            sap.ui.getCore().byId("idProdUpdateReviewBottleneckCorrect").removeStyleClass("redText");
                            oModel.setProperty("/standardCycleData/" + index + "/style", "coloredActualBottleneckSpeed");
                        } else {
                            sap.ui.getCore().byId("idProdUpdateReviewBottleneckCorrect").setText("False");
                            sap.ui.getCore().byId("idProdUpdateReviewBottleneckCorrect").removeStyleClass("greenText");
                            sap.ui.getCore().byId("idProdUpdateReviewBottleneckCorrect").addStyleClass("redText");
                            oModel.setProperty("/standardCycleData/" + index + "/style", "coloredFalseBottleneckSpeed");
                        }
                    }
                }

                var url = `/ETY_CostCentre_ValueHelpSet(Werks='${plant}',Arbpl='${changedResource}')`;
                var oModelCostcenter = new sap.ui.model.json.JSONModel();
                BusyIndicator.show(0);
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        success: function (oData) {
                            oModelCostcenter.setData(oData);
                            var newData = oModelCostcenter.getData();
                            var updatedCostCenter = newData.Kostl;
                            sap.ui.getCore().byId("idProdUpdateReviewCostCenter").setText(updatedCostCenter);
                            var prodStdValidFrom = sap.ui.getCore().byId("idProdUpdateReviewValidFrom").getText();
                            var tempLineStdNo = "LR" + "_" + plant + "_" + changedResource + "_";
                            var formattedProdStdValidFrom = this.fnFormattedDate2(prodStdValidFrom);
                            var url = `odata/v4/data-services/getProductionLoss(stdPrefix='${tempLineStdNo}',validFromDate=${formattedProdStdValidFrom})`;
                            $.get(url)
                            .done(function (response) {
                                plannedDtLossVal = (response.value) / 100;
                                var percentageAI = ((costingLotSize / changedSpeed) / ((costingLotSize / changedSpeed / changedEfficiency / 100) + totalVariableDt / (1 - plannedDtLossVal))).toFixed(3);
                                sap.ui.getCore().byId("idProdUpdateReviewAiPercent").setText(percentageAI);
                            }).fail(function (xhr, status, error) {
                                let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                        xhr.responseJSON.error.message :
                                            this.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                var message = this.oResourceBundle.getText("COST_LOT_FETCH_ECC_FAIL") + " " + errorMessage;
                                this.onShowError(message);
                            });
                            BusyIndicator.hide();
                        }.bind(this),
                        error: (function (xhr, status, error) {
                            // Hide the busy indicator in case of error
                            BusyIndicator.hide();
                            let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                    xhr.responseJSON.error.message :
                                        this.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                            var message = this.oResourceBundle.getText("COST_LOT_FETCH_ECC_FAIL") + " " + errorMessage;
                            this.onShowError(message);
                        }.bind(this))
                    })
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
            },
            onControlKeySelectionChange: function (oEvent) {
                var oComboBox = oEvent.getSource();
                var sSelectedKey = oComboBox.getSelectedKey();
                var oModel = this.getView().getModel("standardCycleModel");
                var oContext = oComboBox.getBindingContext("standardCycleModel");
                var sPath = oContext.getPath();
                if (sSelectedKey === "YBN2") {
                    oModel.setProperty(sPath + "/controlKey", ""); // Clear the controlKey value for custom input
                } else {
                    oModel.setProperty(sPath + "/controlKey", sSelectedKey);
                }
            },
            onUpdateControlKeySelectionChange: function (oEvent) {
                var oComboBox = oEvent.getSource();
                var sSelectedKey = oComboBox.getSelectedKey();
                var oModel = this.getView().getModel("globalResponseModel");
                var oContext = oComboBox.getBindingContext("globalResponseModel");
                var index = oContext.getPath().split("/").pop();
                var previousControlKey = prodBttlnckControlKeyData[index].steus;
                var sPath = oContext.getPath();
                if (sSelectedKey === "YBN1" || sSelectedKey === "YBN2" || sSelectedKey === "YBN3") {
                    oComboBox.setSelectedKey(previousControlKey);
                    var message = this.oResourceBundle.getText("SELECT_CONTROL_KEY_ERROR"); // Clear the controlKey value for custom input
                    this.onShowWarning(message);
                }
            },
            onMoreButtonPress: function () {
                this.getView().byId('lbl_capacityNumber').setVisible(true);
                this.getView().byId('lbl_variant').setVisible(true);
                this.getView().byId('lbl_lineEfficiency').setVisible(true);
                this.getView().byId('additionalFilters').setVisible(true);
                this.getView().byId('moreButton1').setVisible(false);
                this.getView().byId('lessButton1').setVisible(true);
                this.getView().byId('ResetButton').setVisible(true);
                this.getView().byId('searchButton').setVisible(true);
            },
            // Product standard panel less button
            onlessButtonPress: function () {
                this.getView().byId('lbl_capacityNumber').setVisible(false)
                this.getView().byId('lbl_variant').setVisible(false)
                this.getView().byId('lbl_lineEfficiency').setVisible(false)
                this.getView().byId('additionalFilters').setVisible(false)
                this.getView().byId('moreButton1').setVisible(true)
                this.getView().byId('lessButton1').setVisible(false)
                this.getView().byId('ResetButton').setVisible(true)
                this.getView().byId('searchButton').setVisible(true)
            },
			   onTrueSelect: function (_oEvent) {
                var chkTrue = this.getView().byId("chkTrue2");
                var chkFalse = this.getView().byId("chkFalse2");
                if (chkTrue.getSelected()) {
                    chkFalse.setSelected(false);
                }
            },

            onFalseSelect: function (_oEvent) {
                var chkTrue = this.getView().byId("chkTrue2");
                var chkFalse = this.getView().byId("chkFalse2");
                if (chkFalse.getSelected()) {
                    chkTrue.setSelected(false);
                }
            },
            // Product standard view rework function
            fnRework: function () {
                var that = this;
                var payload = {
                        "prodStdNo": prdStandardNo,
                        "status": "Re-Work",
                        "stdApprLvl": 0,
                        "currentApprStdLevel": approverLevel,
                        "reworkComment": sap.ui.getCore().byId("idProdReworkComment").getValue()

                }

                var sUrl = "odata/v4/data-services/onReWorkProductStd";
                BusyIndicator.show(0);
                $.ajax({
                    url: sUrl,
                    headers: {
                        'x-username': nbId,
                        'x-zone': zone,
                        'x-plants': plantsParam,
                        'x-role': "Approver"
                    },
                    type: "POST",
                    data: JSON.stringify(payload),
                    contentType: "application/json"
                })
                .done(function (_response) {
                    BusyIndicator.hide();
                    var message = that.oResourceBundle.getText("SELECT_PROD_STD_REJECT_SUCCESS");
                    that.onShowSuccess(message);
                    var initialCallFlag = 0;
                    that.getProductStdHeaderData(initialCallFlag);
                })
                .fail(function (xhr, status, error) {
                    BusyIndicator.hide();
                    let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                            xhr.responseJSON.error.message :
                                that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                    var message = that.oResourceBundle.getText("SELECT_PROD_STD_REJECT_FAIL") + " " + errorMessage;
                    that.onShowError(message);
                    var initialCallFlag = 0;
                    that.getProductStdHeaderData(initialCallFlag);
                });
                this._reworkComment.close();
                sap.ui.getCore().byId("idProdReworkComment").setValue();
                this._oApproverReviewProd.close();
            },
            // Product standard view rework display function
            fnShowReworkComment(oEvent) {
                if (oEvent.getSource().getBindingContext("lineModel") !== undefined) {
                    var iSelectedIndex = oEvent.getSource().getBindingContext("lineModel").sPath.slice(10);
                    var comment = this.getView().getModel("lineModel").getProperty("/lineData/" + iSelectedIndex + "/reworkComment");
                    if (comment) {
                        if (!this._oPopoverCommentDisplay) {
                            this._oPopoverCommentDisplay = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.ApproverCommentDisplay", this);
                            this.getView().addDependent(this._oPopoverCommentDisplay);
                        }
                        //oEvent.getSource()
                        this._oPopoverCommentDisplay.openBy(oEvent.getSource());
                        sap.ui.getCore().byId("idLineApprCommentDisplay").setVisible(true);
                        sap.ui.getCore().byId("idProdApprCommentDisplay").setVisible(false);
                        sap.ui.getCore().byId("idLineApprCommentDisplay").setText(comment);
                        MessageToast.show(comment);
                    }
                }
                if (oEvent.getSource().getBindingContext("productModel") !== undefined) {
                    var iSelectedIndex1 = oEvent.getSource().getBindingContext("productModel").sPath.slice(7);
                    var comment1 = this.getView().getModel("productModel").getProperty("/value/" + iSelectedIndex1 + "/reworkComment");
                    if (comment1) {
                        if (!this._oPopoverCommentDisplay) {
                            this._oPopoverCommentDisplay = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.ApproverCommentDisplay", this);

                            this.getView().addDependent(this._oPopoverCommentDisplay);
                        }
                        this._oPopoverCommentDisplay.openBy(oEvent.getSource());
                        sap.ui.getCore().byId("idProdApprCommentDisplay").setVisible(true);
                        sap.ui.getCore().byId("idLineApprCommentDisplay").setVisible(false);
                        sap.ui.getCore().byId("idProdApprCommentDisplay").setText(comment1);
                        MessageToast.show(comment1);
                    }
                }
            },
            getDateFormat: function (val) {
                var dateParts = val.split("-");
                var date = new Date(dateParts[0], dateParts[1] - 1, dateParts[2]);
                var day = String(date.getDate()).padStart(2, '0');
                var month = String(date.getMonth() + 1).padStart(2, '0');
                var year = date.getFullYear();
                return `${day}-${month}-${year}`;
            },
            onProdStandardCopyCreate: function () {
                this._isConfirming = false;
                // Reset the wizard and dialog before opening (call the handleClose function here)
                //this.handleCloseButtonProdCopyCreate();

                var oTable = this.getView().byId("idProductTable")
                var selectedPath = this.getView().byId("idProductTable")._aSelectedPaths;
                if (selectedPath.length === 1) {
                    var that = this;
                    if (!this._oProdCopyCreateDialog) {
                        that._oProdCopyCreateDialog = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.StandardProdCopyCreate", this);
                        this.getView().addDependent(this._oProdCopyCreateDialog);
                    }
                    this._oProdCopyCreateDialog.open();
                    BusyIndicator.show(0);
                    var oTable = this.getView().byId("idProductTable");
                    var aSelectedPaths = oTable._aSelectedPaths;
                    if (aSelectedPaths.length > 0) {
                        var sSelectedPath = aSelectedPaths[0];
                        var iSelectedIndex = parseFloat(sSelectedPath.split("/")[2], 10);
                        var oModel = this.getView().getModel("productModel");
                        var prdStdNo = oModel.getData().value[iSelectedIndex].prodStdNo;
                        var ID = oModel.getData().value[iSelectedIndex].ID;
                    }
                    // Construct the URL with dynamic values using template literals
                    var url = `odata/v4/data-services/ProductRelStandardHeadersDB(ID=${ID},prodStdNo='${prdStdNo}')?$expand=ProdStdToProdBttlnckDataNav($filter=modificationType ne 'D'),ProdStdToProdSecResDataNav,ProdStdToProdVarDtDataNav,ProdStdToProdMatrAllDataNav`;
                    $.ajax({
                        url: url,
                        method: 'GET',
                        headers: {
                            'x-username': nbId,
                            'x-zone': zone,
                            'x-plants': plantsParam,
                            'x-role': "Creator/Editor"
                        },
                        success: function (response) {
                            BusyIndicator.hide();
                            MessageToast.show(that.oResourceBundle.getText("PROD_STD_DB_SUCCESS"));
							that.fnProdCopyVariableDTLossCat(response.plant);												 
                            var prodBttlnckData = response.ProdStdToProdBttlnckDataNav;
                            var prodSecResData = response.ProdStdToProdSecResDataNav;
                            var prodVarDtData = response.ProdStdToProdVarDtDataNav;
                            var prodMatrData = response.ProdStdToProdMatrAllDataNav;
                            that.oglobalResponseModel.setData({
                                standardCycleData: prodBttlnckData,
                                variableDtData: prodVarDtData,
                                materialData: prodMatrData,
                                SecondaryResData: prodSecResData
                            });
                            ecn = response.ecm;
                            sap.ui.getCore().byId("idProdCreateCopyPlant").setText(response.plant);
                            sap.ui.getCore().byId("idProdCreateCopyValidFrom").setText(that.getDateFormat(response.validFrom));
							 sap.ui.getCore().byId("idProdCreateCopyModifiedFrom").setText(that.getDateFormat(response.validFrom));																									  
                            sap.ui.getCore().byId("idProdCreateCopyValidTo").setText(that.getDateFormat(response.validTo));
                            sap.ui.getCore().byId("idProdCreateCopyLotSize").setText(response.procOrdrSizeOrCostingLotSize);
                            sap.ui.getCore().byId("idProdCreateCopyMrNo").setText(response.mrGroup);
                            sap.ui.getCore().byId("idProdCreateCopyCostCenter").setText(response.costCenter);
                            sap.ui.getCore().byId("idProdCreateCopyMrCounter").setText(response.mrCounter);
                            sap.ui.getCore().byId("idProdCreateCopyAiPercent").setText(response.pctAI);
                            sap.ui.getCore().byId("idProdCreateCopyEff").setText(response.lineEfficiency);
                            sap.ui.getCore().byId("idProdCreateCopyNS").setText(response.nominalSpeed);
                            sap.ui.getCore().byId("idProdCreateCopyOperationQty").setText(response.operationQty);
                            sap.ui.getCore().byId("idProdCreateCopyChrgQty").setText(response.chargeQty);
                            matUom = response.nsUom;
                            var bottleneckCorrect = (response.bottleneckCorrect === "Y") ? "True" : "False";
                            sap.ui.getCore().byId("idProdCreateCopyBottleneckCorrect").setText(bottleneckCorrect);
                            sap.ui.getCore().byId("idProdCreateCopyDescription").setText(response.masterRecipeDesc);
                            sap.ui.getCore().byId("idProdCreateCopyCrewSize").setText(response.crewSize);
                            sap.ui.getCore().byId("idProdCreateCopyCostCenter").setText(response.costCenter);
                            sap.ui.getCore().byId("idProdCreateCopyBottleneckCorrect")
                            .addStyleClass((bottleneckCorrect === "True") ? "greenText" : "redText")
                            .removeStyleClass((bottleneckCorrect === "True") ? "redText" : "greenText")


                            copiedSpeedValue = response.nominalSpeed;
                            prdStandardNo = response.prodStdNo;
                            that._oNavContainer = that.byId("wizardNavContainerProd");
                            var oModel = that.getView().getModel("globalResponseModel");
                            var aCurrentData = that.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
                            var aData = oModel.getProperty("/standardCycleData");
                            that.getView().getModel("intStandardCycleModel").setProperty("/standardCycleDataInt", aData);
                            var aCurrentDataOld = that.getView().getModel("intStandardCycleModel").getProperty("/standardCycleDataInt");
                            if(role === "S"){
                    
                                sap.ui.getCore().byId("idProdCopyControlKey_Vbox").setVisible(false);
                                sap.ui.getCore().byId("idProdCopyDestinationKey_VBox").setVisible(false);
                                sap.ui.getCore().byId("secProdCopyResBttn").setVisible(true);
                                   
                                for (var i = 0; i < aCurrentData.length; i++) {
                                    that.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/editable", false);
                                    that.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/enabled", false);
                                }
                            } else{
            
                                sap.ui.getCore().byId("idProdCopyControlKey_Vbox").setVisible(true);
                                sap.ui.getCore().byId("idProdCopyDestinationKey_VBox").setVisible(true);
                                sap.ui.getCore().byId("secProdCopyResBttn").setVisible(true);
                            
                                for (var i = 0; i < aCurrentData.length; i++) {
                                    that.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/editable", true);
                                    that.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/enabled", true);
                                }
                            }
                            
                            
                            
                            var aCurrentDataOld1 = aCurrentDataOld.map(item => ({
                                ...item,
                                controlKey: item.controlKey === 'YBN1' ? "PI01" : item.controlKey
                            }));
                            that.getView().getModel("intStandardCycleModel").setProperty("/standardCycleDataInt", aCurrentDataOld1);
                        },
                        error: function (xhr, _status, _error) {
                            // Hide BusyIndicator and show error message
                            BusyIndicator.hide();
                            let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                    xhr.responseJSON.error.message :
                                        that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                            MessageToast.show(that.oResourceBundle.getText("PROD_STD_DB_FAIL") + " " + errorMessage);
                        }
                    })
                } else if (selectedPath.length > 1) {
                    var prodCreatemessage = this.oResourceBundle.getText("SELECT_PROD_ROW_COPY_CREATE");
                    this.onShowWarning(prodCreatemessage);
                } else {
                    var message = this.oResourceBundle.getText("SELECT_PROD_NOROW_COPY_CREATE");
                    this.onShowWarning(message);
                }
            },
			fnLoadCopySubCatforLossCat: function (that, sPlant, lossCat, oSelected, oRowindex) { // Load sub category for loss category
                var oModelProdsubCat = new sap.ui.model.json.JSONModel();
                var sUrl = "odata/v4/data-services/LineRelatedLossCatDB?$filter=plant eq '" + sPlant + "' and lossCat eq '" + lossCat + "'&$select=subCat";
                jQuery.ajax({
                    url: sUrl,
                    method: "GET",
                    success: function (data) {
                        oModelProdsubCat.setData(data);
                        oModelProdsubCat.setSizeLimit(100);

                        var aVariableDtData = that.getView().getModel("globalResponseModel").getProperty("/variableDtData");
                        for (var x = 0; x < aVariableDtData.length; x++) {
                            if (aVariableDtData[x].lossCat === lossCat) {
                                aVariableDtData[x].subCatList = data.value;
                                if (oSelected && oRowindex == x)
                                    aVariableDtData[x].subCat = "";
                            }
                        }
                        that.getView().getModel("globalResponseModel").setProperty("/variableDtData", aVariableDtData);

                    }.bind(this),
                    error: function (oError) {
                        console.log("Error loading LossCat data: ", oError);
                    }
                });
            },
            fnProdCopyVariableDTLossCat: function (sPlant) {
                var oModelProdLossCat = new sap.ui.model.json.JSONModel();
                var sUrl = "odata/v4/data-services/LineRelatedLossCatDB?$apply=groupby((lossCat,plant))&$filter=plant eq '" + sPlant + "'&$select=lossCat";
                jQuery.ajax({
                    url: sUrl,
                    method: "GET",
                    success: function (data) {
                        oModelProdLossCat.setData(data);
                        oModelProdLossCat.setSizeLimit(100);
                        this.getView().setModel(oModelProdLossCat, "ProdLossCatModel");

                        // Loading Subcategory for Each loss category
                        for (var i = 0; i < data.value.length; i++)
                            this.fnLoadCopySubCatforLossCat(this, sPlant, data.value[i].lossCat, false);

                    }.bind(this),
                    error: function (oError) {
                        console.log("Error loading LossCat data: ", oError);
                    }
                });

            },

            fnProdCopyOnChangeLossCat: function (oEvent) {
                var oSelectedLossCat = oEvent.getSource().getSelectedKey();
                var oPlant = sap.ui.getCore().byId("idProdCopyCreateReviewPlant").getSelectedKey();
                if (oPlant) {
                    var oPath = oEvent.getSource().getParent().oBindingContexts.globalResponseModel.sPath;
                    var aPathParts = oPath.split('/');
                    var oRowindex = aPathParts[aPathParts.length - 1];

                    this.fnLoadCopySubCatforLossCat(this, oPlant, oSelectedLossCat, true, oRowindex);
                }
            },


            //////////////////////////Product copycreate delete row item function////////////////////////////////////////////////////////////////////
            fnDeleteCopyCreateMaterialDBItem: function (oEvent) {
                sap.m.MessageBox.confirm(
                    this.oResourceBundle.getText("DELETE_CONFIRMATION"), // Message
                    {
                        actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                        onClose: function (sAction) { // Callback when the dialog is closed
                            if (sAction === MessageBox.Action.YES) {
                                var iItem = oEvent.getSource().getParent().getBindingContext("globalResponseModel").sPath.slice(14);
                                var aCurrentData = this.getView().getModel("globalResponseModel").getProperty("/materialData");
                                aCurrentData.splice(iItem, 1);
                                this.getView().getModel("globalResponseModel").setProperty("/materialData", aCurrentData);
                            }
                        }.bind(this)
                    }
                );
            },
            fnCopyCreateVaraibleDTDeleteItem: function (oEvent) {
			 sap.m.MessageBox.confirm(
                    this.oResourceBundle.getText("DELETE_CONFIRMATION"), // Message
                    {
                        actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                        onClose: function (sAction) { // Callback when the dialog is closed
                            if (sAction === MessageBox.Action.YES) {												
                var iItem = oEvent.getSource().getParent().getBindingContext("globalResponseModel").sPath.slice(16);
                var aCurrentData = this.getView().getModel("globalResponseModel").getProperty("/variableDtData");
                aCurrentData.splice(iItem, 1);
                this.getView().getModel("globalResponseModel").setProperty("/variableDtData", aCurrentData);
				}
                        }.bind(this)
                    }
                );
            },
            fnCopyCreateBottleneckDBDeleteItem: function (oEvent) {
			 sap.m.MessageBox.confirm(
                    this.oResourceBundle.getText("DELETE_CONFIRMATION"), // Message
                    {
                        actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                        onClose: function (sAction) { // Callback when the dialog is closed
                            if (sAction === MessageBox.Action.YES) {										
                var iItem = oEvent.getSource().getParent().getBindingContext("globalResponseModel").sPath.slice(19);
                var aCurrentData = this.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
                var aCurrentDataOld = this.getView().getModel("intStandardCycleModel").getProperty("/standardCycleDataInt");
                aCurrentData.splice(iItem, 1);
                aCurrentDataOld.splice(iItem, 1);
                this.getView().getModel("intStandardCycleModel").setProperty("/standardCycleDataInt", aCurrentDataOld);
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData", aCurrentData);
                var aStandardCycleData = this.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
                var index = 0;
                var speedValue = parseFloat(aStandardCycleData[0].nominalSpeed);
                for (var i = 0; i < aStandardCycleData.length; i++) {
                    if (parseFloat(aStandardCycleData[i].nominalSpeed) < speedValue) {
                        speedValue = parseFloat(aCurrentData[i].nominalSpeed);
                        index = i;		
                    }
                }
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/selected", true);
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/controlKey", "YBN1");
                for (var j = 0; j < aStandardCycleData.length; j++) {
                    if (j != index) {
                        this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + j + "/selected", false);
                      }
                                }
                            }
                        }.bind(this)
                    }
				 
                );
            },
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////
            //////////////////////////Product update delete row item function////////////////////////////////////////////////////////////////////
            fnDeleteUpdateMaterialDBItem: function (oEvent) {
										 
																				   
					 
																							   
																						   
																	
                var iItem = oEvent.getSource().getParent().getBindingContext("globalResponseModel").sPath.slice(14);
                var aCurrentData = this.getView().getModel("globalResponseModel").getProperty("/materialData");
                var aNewData = aCurrentData.splice(iItem, 1);
                this.getView().getModel("globalResponseModel").setProperty("/materialData", aCurrentData);
               
                deleteProdStdMaterialData.push({
                    "ID": aNewData[0].ID != undefined? aNewData[0].ID: ""
                });
							 
									
					 
				  

            },
            fnUpdateVaraibleDTDeleteItem: function (oEvent) {
										 
																				   
					 
																							   
																						   
																	
                var iItem = oEvent.getSource().getParent().getBindingContext("globalResponseModel").sPath.slice(16);
                var aCurrentData = this.getView().getModel("globalResponseModel").getProperty("/variableDtData");
                var aNewData = aCurrentData.splice(iItem, 1);
                this.getView().getModel("globalResponseModel").setProperty("/variableDtData", aCurrentData);
                deleteProdStdVarDtData.push({
                    "ID": aNewData[0].ID != undefined? aNewData[0].ID: ""
                });
							 
									
					 
				  
            },
            fnDeleteUpdateBottlecNeckDBItem: function (oEvent) {
                var iItem = oEvent.getSource().getParent().getBindingContext("globalResponseModel").sPath.slice(19);
                var aCurrentData = this.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
                var aCurrentDataOld = this.getView().getModel("intStandardCycleModel").getProperty("/standardCycleDataInt");
                var aNewData = aCurrentData.splice(iItem, 1);
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData", aCurrentData);
                deleteProdStdBottleneckData.push({
                    "ID": aNewData[0].ID != undefined? aNewData[0].ID: ""
                });
                this.getView().getModel("intStandardCycleModel").setProperty("/standardCycleDataInt", aCurrentDataOld);
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData", aCurrentData);
                var aStandardCycleData = this.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
                var index = 0;
                var speedValue = parseFloat(aStandardCycleData[0].nominalSpeed);
                for (var i = 0; i < aStandardCycleData.length; i++) {
                    if (parseFloat(aStandardCycleData[i].nominalSpeed) < speedValue) {
                        speedValue = parseFloat(aCurrentData[i].nominalSpeed);
                        index = i;
                    }
                }
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/selected", true);
                this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + index + "/controlKey", "YBN1");
                for (var i = 0; i < aStandardCycleData.length; i++) {
                    if (i != index) {
                        this.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/selected", false);
                    }
                }
            },

            onProdFilterSearch: function () {
                //role = sap.ui.getCore().getModel("loginUserModel").getData().results[0].AuthType;

                var oView = this.getView();
                var sUrl = "odata/v4/data-services/ProductRelStandardHeadersDB?$filter=(";

                // Fetch controls by their IDs
                var oPlantComboBox = oView.byId("mcb_status_PPD_Z1").getSelectedKey();
                var count = 0;
                if (oPlantComboBox !== "") {
                    sUrl = sUrl + "contains(plant,'" + oPlantComboBox + "')";
                    count++;
                }
                var oBottleneckResourceComboBox = oView.byId("mcb_ordTyp_PPD_Z1").getValue();
                if (oBottleneckResourceComboBox !== "") {
                    if (count !== 0) {
                        sUrl = sUrl + " and contains(bottleneckResource,'" + oBottleneckResourceComboBox + "')"
                    }
                    else {
                        sUrl = sUrl + " contains(bottleneckResource,'" + oBottleneckResourceComboBox + "')";
                        count++;
                    }
                }

                var oCostCenterMultiComboBox = oView.byId("idprodCostCenterFilter").getValue();
                if (oCostCenterMultiComboBox !== "") {
                    if (count !== 0) {
                        sUrl = sUrl + " and contains(costCenter,'" + oCostCenterMultiComboBox + "')";
                    }
                    else {
                        sUrl = sUrl + " contains(costCenter,'" + oCostCenterMultiComboBox + "')";
                        count++;
                    }

                }
                var oData = this.getView().getModel("productModel").getData();
                if (oData.validFrom !== undefined) {
                    var dTo = oData.validFrom.to;
                    var dFrom = oData.validFrom.from;
                    if (oData.validFrom.to != "undefined-undefined-undefined" && oData.validFrom.from !== "undefined-undefined-undefined") {
                        if (count !== 0) {
                            sUrl = sUrl + " and validFrom ge " + dFrom + " and validFrom le " + dTo;
                        }
                        else {
                            sUrl = sUrl + " validFrom ge " + dFrom + " and validFrom le " + dTo;
                            count++;
                        }
                    }
                }
                var oData = this.getView().getModel("productModel").getData();
                if (oData.modifiedFrom !== undefined) {
                    var dTo = oData.modifiedFrom.to;
                    var dFrom = oData.modifiedFrom.from;
                    if (oData.modifiedFrom.to != "undefined-undefined-undefined" && oData.modifiedFrom.from !== "undefined-undefined-undefined") {
                        if (count !== 0) {
                            sUrl = sUrl + " and modifiedFrom ge " + dFrom + " and modifiedFrom le " + dTo;
                        }
                        else {
                            sUrl = sUrl + " modifiedFrom ge " + dFrom + " and modifiedFrom le " + dTo;
                            count++;
                        }
                    }
                }
                if (oData.validTo !== undefined) {

                    var dValidTo = oData.validTo.to;
                    var dValidFrom = oData.validTo.from;

                    if (oData.validTo.to !== "undefined-undefined-undefined" && oData.validTo.from !== "undefined-undefined-undefined") {

                        if (count !== 0) {
                            sUrl = sUrl + " and validTo ge " + dValidFrom + " and validTo le " + dValidTo;
                        }
                        else {
                            sUrl = sUrl + " validTo ge " + dValidFrom + " and validTo le " + dValidTo;
                            count++;
                        }

                    }
                }
                if (oData.createdOn !== undefined) {
                    var dCreatedTo = oData.createdOn.to;
                    var dCreatedFrom = oData.createdOn.from;
                    if (oData.createdOn.to !== "undefined-undefined-undefined" && oData.createdOn.from !== "undefined-undefined-undefined") {

                        if (count !== 0) {
                            sUrl = sUrl + " and createdOn ge " + dCreatedFrom + "T00:00:00.000Z" + " and createdOn le " + dCreatedTo + "T23:59:59.000Z";
                        }
                        else {
                            sUrl = sUrl + " createdOn ge " + dCreatedFrom + "T00:00:00.000Z" + " and createdOn le " + dCreatedTo + "T23:59:59.000Z";
                            count++;
                        }
                    }
                }
                if (oData.lastChangedOn !== undefined) {
                    var dLastTo = oData.lastChangedOn.to;
                    var dLastFrom = oData.lastChangedOn.from;
                    if (oData.lastChangedOn.to !== "undefined-undefined-undefined" && oData.lastChangedOn.from !== "undefined-undefined-undefined") {

                        if (count !== 0) {
                            sUrl = sUrl + " and lastChangedOn ge " + dLastFrom + "T00:00:00.000Z" + " and lastChangedOn le " + dLastTo + "T23:59:59.000Z";
                        }
                        else {
                            sUrl = sUrl + " lastChangedOn ge " + dLastFrom + "T00:00:00.000Z" + " and lastChangedOn le " + dLastTo + "T23:59:59.000Z";
                            count++;
                        }
                    }
                }

                var aMRGroup = oView.byId("idprodFilterMRGroup").getValue();
                if (aMRGroup !== "") {
                    if (count !== 0) {
                        sUrl = sUrl + " and contains(mrGroup,'" + aMRGroup + "')";
                        count++;
                    }
                    else {
                        sUrl = sUrl + " contains(mrGroup,'" + aMRGroup + "')";
                        count++;
                    }
                }
                var iValid = 0;
                if (this.getView().byId("idprodFilterMRCounter").getValue() !== "") {

                    var aMRCounter = this.getView().byId("idprodFilterMRCounter").getValue();
                    var patternRange = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                    var patternComma = /^[0-9]*(\.\d{1,3})?(,[0-9]*(\.\d{1,3})?)*$/;

                    if (patternRange.test(aMRCounter)) {
                        this.getView().byId("idprodFilterMRCounter").setValueState("None");

                        var aMRCounterList = aMRCounter.split('-');
                        if (aMRCounterList.length === 2) {
                            var aMrCounter = aMRCounterList[0];
                            var bMrCounter = aMRCounterList[1];
                        }
                        if (count != 0) {
                            sUrl = sUrl + " and mrCounter ge " + aMrCounter + " and mrCounter le " + bMrCounter;
                        } else {
                            sUrl = sUrl + " mrCounter ge " + aMrCounter + " and mrCounter le " + bMrCounter;
                            count++;
                        }
                    } else if (patternComma.test(aMRCounter)) {
                        this.getView().byId("idprodFilterMRCounter").setValueState("None");

                        var aValues = aMRCounter.split(',');
                        var sOrConditions = aValues.map(function (value) {
                            return "mrCounter eq " + value.trim();
                        }).join(" or ");

                        if (count != 0) {
                            sUrl = sUrl + " and (" + sOrConditions + ")";
                        } else {
                            sUrl = sUrl + " (" + sOrConditions + ")";
                            count++;
                        }
                    } else {
                        this.getView().byId("idprodFilterMRCounter").setValueState("Error");
                        this.getView().byId("idprodFilterMRCounter").setValueStateText("Enter Range or Comma-, sepreated Counter");
                        iValid = 1;
                    }
                }
                if (this.getView().byId("idprodFilterNominalSpeed").getValue() !== "") {
                    var aNominalSpeed = this.getView().byId("idprodFilterNominalSpeed").getValue();
                    var patternRange = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                    var patternComma = /^[0-9]*(\.\d{1,3})?(,[0-9]*(\.\d{1,3})?)*$/;
                    if (patternRange.test(aNominalSpeed)) {
                        this.getView().byId("idprodFilterNominalSpeed").setValueState("None");
                        var aNominalSpeedList = aNominalSpeed.split('-');
                        if (aNominalSpeedList.length === 2) {
                        var nominalSpeedMin = aNominalSpeedList[0];
                        var nominalSpeedMax = aNominalSpeedList[1];
                    }

                    if (count !== 0) {
                        sUrl = sUrl + " and nominalSpeed ge " + nominalSpeedMin + " and nominalSpeed le " + nominalSpeedMax;
                    }
                    else {
                        sUrl = sUrl + " nominalSpeed ge " + nominalSpeedMin + " and nominalSpeed le " + nominalSpeedMax;
                        count++;
                    }
                } else if (patternComma.test(aNominalSpeed)) {
                    this.getView().byId("idprodFilterNominalSpeed").setValueState("None");

                    var aValues = aNominalSpeed.split(',');
                    var sOrConditions = aValues.map(function (value) {
                        return "nominalSpeed eq " + value.trim();
                    }).join(" or ");

                    if (count != 0) {
                        sUrl = sUrl + " and (" + sOrConditions + ")";
                    } else {
                        sUrl = sUrl + " (" + sOrConditions + ")";
                        count++;
                    }
                } else {
                    this.getView().byId("idprodFilterNominalSpeed").setValueState("Error");
                    this.getView().byId("idprodFilterNominalSpeed").setValueStateText("Enter Range or Comma-, sepreated Nominal Speed");
                    iValid = 1;
                }
                }
                if (this.getView().byId("idprodFilterAI").getValue() !== "") {
                    var aPctAI = this.getView().byId("idprodFilterAI").getValue();
                    var patternRange = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                    var patternComma = /^[0-9]*(\.\d{1,3})?(,[0-9]*(\.\d{1,3})?)*$/;
                    if (patternRange.test(aPctAI)) {
                        this.getView().byId("idprodFilterAI").setValueState("None");
                        var aPctAIList = aPctAI.split('-');
                    if (aPctAIList.length === 2) {
                        var pctAIMin = aPctAIList[0];
                        var pctAIMax = aPctAIList[1];
                    }
                    if (count !== 0) {
                        sUrl = sUrl + " and pctAI ge " + pctAIMin + " and pctAI le " + pctAIMax;
                    }
                    else {
                        sUrl = sUrl + " pctAI ge " + pctAIMin + " and pctAI le " + pctAIMax;
                        count++;
                    }
                } else if (patternComma.test(aPctAI)) {
                    this.getView().byId("idprodFilterAI").setValueState("None");

                    var aValues = aPctAI.split(',');
                    var sOrConditions = aValues.map(function (value) {
                        return "pctAI eq " + value.trim();
                    }).join(" or ");

                    if (count != 0) {
                        sUrl = sUrl + " and (" + sOrConditions + ")";
                    } else {
                        sUrl = sUrl + " (" + sOrConditions + ")";
                        count++;
                    }
                } else {
                    this.getView().byId("idprodFilterAI").setValueState("Error");
                    this.getView().byId("idprodFilterAI").setValueStateText("Enter Range or Comma-, sepreated %AI");
                    iValid = 1;
                }

                }
                
                var oSpeedComboBox = oView.byId("idprodFilterNSUoM").getSelectedKey();
                if (oSpeedComboBox !== "") {
                    if (count !== 0) {
                        sUrl = sUrl + " and contains(nsUom,'" + oSpeedComboBox + "')";
                        count++;
                    }
                    else {
                        sUrl = sUrl + " contains(nsUom,'" + oSpeedComboBox + "')";
                        count++;
                    }
                }

                if (this.getView().byId("idprodFilterCrewSize").getValue() !== "") {
                    var aCrewSize = this.getView().byId("idprodFilterCrewSize").getValue();
                    var patternRange = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                    var patternComma = /^[0-9]*(\.\d{1,3})?(,[0-9]*(\.\d{1,3})?)*$/;
                    if (patternRange.test(aCrewSize)) {
                        this.getView().byId("idprodFilterCrewSize").setValueState("None");
                        var aCrewSizeList = aCrewSize.split('-');
                    if (aCrewSizeList.length === 2) {
                        var crewSizeMin = aCrewSizeList[0];
                        var crewSizeMax = aCrewSizeList[1];
                    }
                    if (count !== 0) {
                        sUrl = sUrl + " and crewSize ge " + crewSizeMin + " and crewSize le " + crewSizeMax;
                    }
                    else {
                        sUrl = sUrl + " crewSize ge " + crewSizeMin + " and crewSize le " + crewSizeMax;
                        count++;
                    }
                } else if (patternComma.test(aCrewSize)) {
                    this.getView().byId("idprodFilterCrewSize").setValueState("None");

                    var aValues = aCrewSize.split(',');
                    var sOrConditions = aValues.map(function (value) {
                        return "crewSize eq " + value.trim();
                    }).join(" or ");

                    if (count != 0) {
                        sUrl = sUrl + " and (" + sOrConditions + ")";
                    } else {
                        sUrl = sUrl + " (" + sOrConditions + ")";
                        count++;
                    }
                } else {
                    this.getView().byId("idprodFilterCrewSize").setValueState("Error");
                    this.getView().byId("idprodFilterCrewSize").setValueStateText("Enter Range or Comma-, sepreated CrewSize");
                    iValid = 1;
                }

                }

                if (this.getView().byId("idprodFilterProcessorderSize").getValue() !== "") {
                    var aProcOrdrSizeOrCostingLotSize = this.getView().byId("idprodFilterProcessorderSize").getValue();
                    var patternRange = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                    var patternComma = /^[0-9]*(\.\d{1,3})?(,[0-9]*(\.\d{1,3})?)*$/;
                    if (patternRange.test(aProcOrdrSizeOrCostingLotSize)) {
                        this.getView().byId("idprodFilterProcessorderSize").setValueState("None");
                        var aProcOrdrSizeOrCostingLotSizeList = aProcOrdrSizeOrCostingLotSize.split('-');
                    if (aProcOrdrSizeOrCostingLotSizeList.length === 2) {
                        var procOrdrSizeOrCostingLotSizeMin = aProcOrdrSizeOrCostingLotSizeList[0];
                        var procOrdrSizeOrCostingLotSizeMax = aProcOrdrSizeOrCostingLotSizeList[1];
                    }
                    if (count !== 0) {
                        sUrl = sUrl + " and procOrdrSizeOrCostingLotSize ge " + procOrdrSizeOrCostingLotSizeMin + " and procOrdrSizeOrCostingLotSize le " + procOrdrSizeOrCostingLotSizeMax;
                    }
                    else {
                        sUrl = sUrl + " procOrdrSizeOrCostingLotSize ge " + procOrdrSizeOrCostingLotSizeMin + " and procOrdrSizeOrCostingLotSize le " + procOrdrSizeOrCostingLotSizeMax;
                        count++;
                    }
                } else if (patternComma.test(aProcOrdrSizeOrCostingLotSize)) {
                    this.getView().byId("idprodFilterProcessorderSize").setValueState("None");

                    var aValues = aProcOrdrSizeOrCostingLotSize.split(',');
                    var sOrConditions = aValues.map(function (value) {
                        return "procOrdrSizeOrCostingLotSize eq " + value.trim();
                    }).join(" or ");

                    if (count != 0) {
                        sUrl = sUrl + " and (" + sOrConditions + ")";
                    } else {
                        sUrl = sUrl + " (" + sOrConditions + ")";
                        count++;
                    }
                } else {
                    this.getView().byId("idprodFilterProcessorderSize").setValueState("Error");
                    this.getView().byId("idprodFilterProcessorderSize").setValueStateText("Enter Range or Comma-, sepreated Processorder size");
                    iValid = 1;
                }

                }

                if (this.getView().byId("idprodFilterCapacityNumber").getValue() !== "") {
                    var aCapacityNumber = this.getView().byId("idprodFilterCapacityNumber").getValue();
                    var patternRange = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                    var patternComma = /^[0-9]*(\.\d{1,3})?(,[0-9]*(\.\d{1,3})?)*$/;
                    if (patternRange.test(aCapacityNumber)) {
                        this.getView().byId("idprodFilterCapacityNumber").setValueState("None");
                        var aCapacityNumberList = aCapacityNumber.split('-');
                    if (aCapacityNumberList.length === 2) {
                        var capacityNumberMin = aCapacityNumberList[0];
                        var capacityNumberMax = aCapacityNumberList[1];
                    }
                    if (count !== 0) {
                        sUrl = sUrl + " and capacityNumber ge " + capacityNumberMin + " and capacityNumber le " + capacityNumberMax;
                    }
                    else {
                        sUrl = sUrl + " capacityNumber ge " + capacityNumberMin + " and capacityNumber le " + capacityNumberMax;
                        count++;
                    }
                } else if (patternComma.test(aCapacityNumber)) {
                    this.getView().byId("idprodFilterCapacityNumber").setValueState("None");

                    var aValues = aCapacityNumber.split(',');
                    var sOrConditions = aValues.map(function (value) {
                        return "capacityNumber eq " + value.trim();
                    }).join(" or ");

                    if (count != 0) {
                        sUrl = sUrl + " and (" + sOrConditions + ")";
                    } else {
                        sUrl = sUrl + " (" + sOrConditions + ")";
                        count++;
                    }
                } else {
                    this.getView().byId("idprodFilterCapacityNumber").setValueState("Error");
                    this.getView().byId("idprodFilterCapacityNumber").setValueStateText("Enter Range or Comma-, sepreated Capacity Number");
                    iValid = 1;
                }

                }


                if (this.getView().byId("idprodFilterVariant").getValue() !== "") {
                    var aVariant = this.getView().byId("idprodFilterVariant").getValue();
                    var patternRange = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                    var patternComma = /^[0-9]*(\.\d{1,3})?(,[0-9]*(\.\d{1,3})?)*$/;
                    if (patternRange.test(aVariant)) {
                        this.getView().byId("idprodFilterVariant").setValueState("None");
                        var aVariantList = aVariant.split('-');
                    if (aVariantList.length === 2) {
                        var variantMin = aVariantList[0];
                        var variantMax = aVariantList[1];
                    }
                    if (count !== 0) {
                        sUrl = sUrl + " and variant ge " + variantMin + " and variant le " + variantMax;
                    }
                    else {
                        sUrl = sUrl + " variant ge " + variantMin + " and variant le " + variantMax;
                        count++;
                    }
                } else if (patternComma.test(aVariant)) {
                    this.getView().byId("idprodFilterVariant").setValueState("None");

                    var aValues = aVariant.split(',');
                    var sOrConditions = aValues.map(function (value) {
                        return "variant eq " + value.trim();
                    }).join(" or ");

                    if (count != 0) {
                        sUrl = sUrl + " and (" + sOrConditions + ")";
                    } else {
                        sUrl = sUrl + " (" + sOrConditions + ")";
                        count++;
                    }
                } else {
                    this.getView().byId("idprodFilterVariant").setValueState("Error");
                    this.getView().byId("idprodFilterVariant").setValueStateText("Enter Range or Comma-, sepreated Variant");
                    iValid = 1;
                } 
                }

                if (this.getView().byId("idprodFilterLineEfficiency").getValue() !== "") {
                    var aLineEfficiency = this.getView().byId("idprodFilterLineEfficiency").getValue();
                    var patternRange = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                    var patternComma = /^[0-9]*(\.\d{1,3})?(,[0-9]*(\.\d{1,3})?)*$/;
                    if (patternRange.test(aLineEfficiency)) {
                        this.getView().byId("idprodFilterLineEfficiency").setValueState("None");
                        var aLineEfficiencyList = aLineEfficiency.split('-');
                    if (aLineEfficiencyList.length === 2) {
                        var lineEfficiencyMin = aLineEfficiencyList[0];
                        var lineEfficiencyMax = aLineEfficiencyList[1];
                    }
                    if (count !== 0) {
                        sUrl = sUrl + " and lineEfficiency ge " + lineEfficiencyMin + " and lineEfficiency le " + lineEfficiencyMax;
                    }
                    else {
                        sUrl = sUrl + " lineEfficiency ge " + lineEfficiencyMin + " and lineEfficiency le " + lineEfficiencyMax;
                        count++;
                    }
                } else if (patternComma.test(aLineEfficiency)) {
                    this.getView().byId("idprodFilterLineEfficiency").setValueState("None");

                    var aValues = aLineEfficiency.split(',');
                    var sOrConditions = aValues.map(function (value) {
                        return "lineEfficiency eq " + value.trim();
                    }).join(" or ");

                    if (count != 0) {
                        sUrl = sUrl + " and (" + sOrConditions + ")";
                    } else {
                        sUrl = sUrl + " (" + sOrConditions + ")";
                        count++;
                    }
                } else {
                    this.getView().byId("idprodFilterLineEfficiency").setValueState("Error");
                    this.getView().byId("idprodFilterLineEfficiency").setValueStateText("Enter Range or Comma-, sepreated Line Efiiciency");
                    iValid = 1;
                } 

                }
                if (this.getView().byId("idprodFilterChargeQuantity").getValue() !== "") {
                    var aChargeQty = this.getView().byId("idprodFilterChargeQuantity").getValue();
                    var patternRange = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                    var patternComma = /^[0-9]*(\.\d{1,3})?(,[0-9]*(\.\d{1,3})?)*$/;
                    if (patternRange.test(aChargeQty)) {
                        this.getView().byId("idprodFilterChargeQuantity").setValueState("None");
                        var aChargeQtyList = aChargeQty.split('-');
                    if (aChargeQtyList.length === 2) {
                        var chargeQtyMin = aChargeQtyList[0];
                        var chargeQtyMax = aChargeQtyList[1];
                    }
                    if (count !== 0) {
                        sUrl = sUrl + " and chargeQty ge " + chargeQtyMin + " and chargeQty le " + chargeQtyMax;
                    }
                    else {
                        sUrl = sUrl + " chargeQty ge " + chargeQtyMin + " and chargeQty le " + chargeQtyMax;
                        count++;
                    }
                } else if (patternComma.test(aChargeQty)) {
                    this.getView().byId("idprodFilterChargeQuantity").setValueState("None");

                    var aValues = aChargeQty.split(',');
                    var sOrConditions = aValues.map(function (value) {
                        return "chargeQty eq " + value.trim();
                    }).join(" or ");

                    if (count != 0) {
                        sUrl = sUrl + " and (" + sOrConditions + ")";
                    } else {
                        sUrl = sUrl + " (" + sOrConditions + ")";
                        count++;
                    }
                } else {
                    this.getView().byId("idprodFilterChargeQuantity").setValueState("Error");
                    this.getView().byId("idprodFilterChargeQuantity").setValueStateText("Enter Range or Comma-, sepreated Charge Quantity");
                    iValid = 1;
                } 
                }
                if (this.getView().byId("idprodFilterOperationQuantity").getValue() !== "") {
                    var aOperationQty = this.getView().byId("idprodFilterOperationQuantity").getValue();
                    var patternRange = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                    var patternComma = /^[0-9]*(\.\d{1,3})?(,[0-9]*(\.\d{1,3})?)*$/;
                    if (patternRange.test(aOperationQty)) {
                        this.getView().byId("idprodFilterOperationQuantity").setValueState("None");
                        var aOperationQtyList = aOperationQty.split('-');
                    if (aOperationQtyList.length === 2) {
                        var operationQtyMin = aOperationQtyList[0];
                        var operationQtyMax = aOperationQtyList[1];
                    }
                    if (count !== 0) {
                        sUrl = sUrl + " and operationQty ge " + operationQtyMin + " and operationQty le " + operationQtyMax;
                    }
                    else {
                        sUrl = sUrl + " operationQty ge " + operationQtyMin + " and operationQty le " + operationQtyMax;
                        count++;
                    }
                } else if (patternComma.test(aOperationQty)) {
                    this.getView().byId("idprodFilterOperationQuantity").setValueState("None");

                    var aValues = aOperationQty.split(',');
                    var sOrConditions = aValues.map(function (value) {
                        return "operationQty eq " + value.trim();
                    }).join(" or ");

                    if (count != 0) {
                        sUrl = sUrl + " and (" + sOrConditions + ")";
                    } else {
                        sUrl = sUrl + " (" + sOrConditions + ")";
                        count++;
                    }
                } else {
                    this.getView().byId("idprodFilterOperationQuantity").setValueState("Error");
                    this.getView().byId("idprodFilterOperationQuantity").setValueStateText("Enter Range or Comma-, sepreated Operation Quantity");
                    iValid = 1;
                } 
                }
                var aECM = oView.byId("idprodFilterECM").getValue();
                if (aECM !== "") {
                    if (count !== 0) {
                        sUrl = sUrl + " and contains(ecm,'" + aECM + "')";
                        count++;
                    }
                    else {
                        sUrl = sUrl + " contains(ecm,'" + aECM + "')";
                        count++;
                    }
                }
				var oCheckboxTrue = oView.byId("chkTrue2");
                var oCheckboxFalse = oView.byId("chkFalse2");
                if (oCheckboxTrue.getSelected()) {
                    if (count !== 0) {
                        sUrl = sUrl + " and createdBySemiCreator eq true";
                    } else {
                        sUrl = sUrl + "createdBySemiCreator eq true";
                        count++;
                    }
                } else if (oCheckboxFalse.getSelected()) {
                    if (count !== 0) {
                        sUrl = sUrl + " and createdBySemiCreator eq false";
                    } else {
                        sUrl = sUrl + "createdBySemiCreator eq false";
                        count++;
                    }
                }
                var oStatusComboBox = oView.byId("mcb_status_PPD_Z214").getSelectedItems();
                if (oStatusComboBox.length > 0) {
                    for (var i = 0; i < oStatusComboBox.length; i++) {
                        if (count !== 0) {
                            if (i === 0) {
                                sUrl = sUrl + " and (status eq '" + oStatusComboBox[i].mProperties.text + "'";
                            }
                            else {
                                sUrl = sUrl + " or status eq '" + oStatusComboBox[i].mProperties.text + "'";
                            }

                        }
                        else {
                            sUrl = sUrl + "(status eq '" + oStatusComboBox[i].mProperties.text + "'";
                            count++;
                        }
                        if (i == oStatusComboBox.length - 1) {
                            sUrl = sUrl + ")";
                        }

                    }
                }

                sUrl = sUrl + ")";
                if(count !== 0){
                    // this.getProductStdHeaderData();  
                   // sap.m.MessageBox.warning(this.oResourceBundle.getText("BLANK_PRODSTD_SEARCH"));								 
                    var that = this;
                    if (role === "A") {			   
                        userRole = "Approver";								 
                    } else if (role === "E") {
                        userRole = "Executor/Viewer";
                    } else if ((role ==="V") || (role === undefined)){
                        userRole = "View"; 
                    }
                    else  {
  
                        userRole = "Creator/Editor";
                    }

                    BusyIndicator.show(0);
                    $.ajax({
                        url: sUrl,
                        method: 'GET',
                        headers: {
                            'x-username': nbId,
                            'x-zone': zone,
                            'x-plants': plantsParam,
                            'x-role': userRole
                        },
                        success: function (data) {
                            BusyIndicator.hide();
                            var oTableModel = new sap.ui.model.json.JSONModel(data);
                            that.getView().byId("idProductTable").setModel(oTableModel, "productModel");
                            that.getOwnerComponent().setModel(oTableModel, "productModel");
                            MessageToast.show(that.oResourceBundle.getText("PROD_FILTER_LOAD_SUCCESS"));
                        },
                        error: function (xhr, _status, _error) {
                            BusyIndicator.hide();
                            let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                    xhr.responseJSON.error.message :
                                        that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                            MessageToast.show(that.oResourceBundle.getText("PROD_FILTER_LOAD_FAIL") + " " + errorMessage);
                        }
                    });
                }
            },
             onProdFilterReset: function () {
                role = sap.ui.getCore().getModel("loginUserModel").getData().results[0].AuthType;
                var oView = this.getView();

                // Array of elements to reset with setValue('')
                var aFieldsToReset = [
                    "mcb_status_PPD_Z1", "mcb_ordTyp_PPD_Z1", "idprodCostCenterFilter",
                    "DPprodValidFrom", "DPprodValidTo", "DPprodCreatedOn", "DPprodmodifiedFrom",
                    "DPprodLastChangedon", "idprodFilterMRGroup", "idprodFilterMRCounter",
                    "idprodFilterNominalSpeed", "idprodFilterAI", "idprodFilterNSUoM",
                    "idprodFilterProcessorderSize", "idprodFilterCapacityNumber",
                    "idprodFilterVariant", "idprodFilterLineEfficiency", "idprodFilterChargeQuantity",
                    "idprodFilterOperationQuantity", "idprodFilterECM", "idprodFilterCrewSize"
                ];

                // Loop through the fields and reset their values
                aFieldsToReset.forEach(function (sId) {
                    var oField = oView.byId(sId);
                    if (oField) {
                        oField.setValue('');
                    }
                });

                // Reset ComboBoxes with selected items
                var oStatusComboBox = oView.byId("mcb_status_PPD_Z214");
                if (oStatusComboBox) {
                    oStatusComboBox.setSelectedItems([]);
                }
				 var oChkTrue = oView.byId("chkTrue2");
                var oChkFalse = oView.byId("chkFalse2");

                if (oChkTrue) {
                    oChkTrue.setSelected(false);
                }
                if (oChkFalse) {
                    oChkFalse.setSelected(false);
                }									  

                var oResourceModel = this.getView().getModel("resourceModel");
                if (oResourceModel) {
                    var aResults = oResourceModel.getProperty("/results");

                    if (aResults) {
                        oResourceModel.setProperty("/results", []);
                    } else {
                        oResourceModel.setData({ results: [] });
                    }
                }      
               if(role === "E"){
                this.fnProdExecutionRecords();
																									 
				 
               }else if ((role === "V") || (role === undefined)){
                this.fnProdViewRecords();
               }else{
                var initialCallFlag = 0;
                this.getProductStdHeaderData(initialCallFlag);
               }
                
				 
         },
            onProdFilterPressed: function (evt) {
                // if (this.getView().byId("idLineStandard").getVisible() == false && this.getView().byId("idSatandardSelection").getSelectedKey() == "Line Standard") {
                if (this.getOwnerComponent().getModel("sStandardSelectedModel").getProperty("/standardtype") == "Product Standard" && toggle == 1) {
                    this.getView().byId("idPane2").setVisible(true);
                    //this.getView().byId("idPane2").setExpandAnimation(true);
                    this.getView().byId("idPane2").setExpanded(true); //render content
                    //this.getView().byId("idPane2").setExpandable(true); // while closing gettting animation
                    this.getView().byId("idProductStandard").setVisible(true);
                    this.getView().byId("idProdStandard22").setVisible(true);
                    this.getView().byId("idProductStandard213").setVisible(true);
                    this.getView().byId("idProductPanelOverflowtoolbar").setVisible(true);
                    toggle = 2;
                } else if (this.getOwnerComponent().getModel("sStandardSelectedModel").getProperty("/standardtype") == "Product Standard" && toggle == 2) {
                    this.getView().byId("idPane2").setVisible(true);
                    // this.getView().byId("idPane2").setExpandAnimation(true);
                    this.getView().byId("idPane2").setExpanded(false);
                    toggle = 1;
                    //this.getView().byId("idPane2").setExpandable(true);
                    this.getView().byId("idProductStandard").setVisible(false);
                    this.getView().byId("idProdStandard22").setVisible(false);
                    this.getView().byId("idProductStandard213").setVisible(false);
                    this.getView().byId("idProductPanelOverflowtoolbar").setVisible(false);
                }
            },
            onProdStandardCreate: function () {
                if (!this._oPopover13) {
                    this._oPopover13 = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.StandardProdCreate", this);
                    this.getView().addDependent(this._oPopover13);
                }
                this._oPopover13.open();
                this._oNavContainer = this.byId("wizardNavContainerProd");
            },
            onShowPress: function () {
                this.getView().byId("idHideDetails").setVisible(true);
                this.getView().byId("idShowDetails").setVisible(false);
            },
            onHidePress: function () {
                this.getView().byId("idShowDetails").setVisible(true);
                this.getView().byId("idHideDetails").setVisible(false);
            },
            onSubmitProdStdData: function () {
                var oTable = this.getView().byId("idProductTable");
                var aSelectedPaths = oTable._aSelectedPaths;
                var sSelectedPath = aSelectedPaths[0];
                var iSelectedIndex = parseFloat(sSelectedPath.split("/")[2], 10);
                var oModel = this.getView().getModel("productModel");
                var ecmNumber = oModel.getData().value[iSelectedIndex].ecm;
                var flag = oModel.getData().value[iSelectedIndex].createdBySemiCreator;
                var prdStdNo = oModel.getData().value[iSelectedIndex].prodStdNo;
                var ID = oModel.getData().value[iSelectedIndex].ID;
                if (aSelectedPaths.length > 1) {
                    var message = this.oResourceBundle.getText("SELECT_MASTER_RECP_PROD_STD");
                    this.onShowWarning(message);
                } else {
                    if (flag === true){
                        var semiFlag = 1;
                        var message = this.oResourceBundle.getText("SEMICREATED_PRD_STD_DATA_CONFIRMATION");
                        this.onShowConfirmation(message,ID,prdStdNo,semiFlag);
                    }else{
                        var semiFlag = 0;
                        var message = this.oResourceBundle.getText("MR_SIMULATION_PREVIEW");
                        this.onShowConfirmation(message,ID,prdStdNo,semiFlag);
                    

										 
                    //this.getView().byId("valECN").setValue(ecmNumber);
                }
            }
        },
            onCloseECNDialog: function () {
                if (this._oDialog) {
                    this._oDialog.close();
                }
            },
            onSubmitECNDialog: function () {
                    var that = this;
                    var oTable = this.getView().byId("idProductTable");
                    var sSelectedPath = oTable._aSelectedPaths[0];
                    var iSelectedIndex = parseFloat(sSelectedPath.split("/")[2], 10);
                    var oModel = this.getView().getModel("productModel");
                    var { prodStdNo, ID } = oModel.getData().value[iSelectedIndex];
                    var url = `odata/v4/data-services/ProductRelStandardHeadersDB(ID=${ID},prodStdNo='${prodStdNo}')?$expand=ProdStdToProdBttlnckDataNav,ProdStdToProdSecResDataNav,ProdStdToProdVarDtDataNav,ProdStdToProdMatrAllDataNav`;                  
            
                    BusyIndicator.show(0); // Show BusyIndicator before the AJAX call
                    $.ajax({
                        url: url,
                        method: 'GET',
                        headers: {
                            'x-username': nbId, 'x-zone': zone, 'x-plants': plantsParam, 'x-role': "Approver"
                        },
                        success: function (response) {
                            var { ProdStdToProdBttlnckDataNav, ProdStdToProdSecResDataNav, ProdStdToProdVarDtDataNav, ProdStdToProdMatrAllDataNav } = response;
                            that.oglobalResponseModel.setData({
                                standardCycleData: ProdStdToProdBttlnckDataNav,
                                variableDtData: ProdStdToProdVarDtDataNav,
                                materialData: ProdStdToProdMatrAllDataNav,
                                SecondaryResData: ProdStdToProdSecResDataNav
                            });
            
                            var totalVariableMRDtVal = ProdStdToProdVarDtDataNav.reduce((acc, item) => acc + +item.totalVarDT, 0);
                            var uniqueResources = new Set();
                            var uomMR, controlKeyMR, bottleneckResMR;           
                            ProdStdToProdBttlnckDataNav.forEach(item => {
                                if (["YBN1", "YBN2", "YBN3"].includes(item.controlKey)) {
                                    uomMR = item.nsUom;
                                    controlKeyMR = item.controlKey;
                                    bottleneckResMR = item.resource;
                                }
                                uniqueResources.add(JSON.stringify({
                                    resource: item.resource,
                                    destinationKey: item.destinationKey,
                                    controlKey: item.controlKey,
                                    noOfPeople: item.numOfPeople,
                                    mrLineEff: item.pctlineEfficiency,
                                    mrCapacity: item.capacityNo,
                                    mrSpeed: item.nominalSpeed,
                                    machine: item.machine,
                                    deletionInd: item.modificationType,
                                    id:item.ID,
                                    phaseNo:item.phaseNo,
                                    modifiedOn:item.auditInfoCreatedOn
                                }));
                            });
            
                            var uniqueResourcesArray = Array.from(uniqueResources).map(JSON.parse);
                            uniqueResourcesArray.sort((a, b) => new Date(a.modifiedOn) - new Date(b.modifiedOn));
                            const groupedByResource = uniqueResourcesArray.reduce((acc, resource) => {
                                const resourceKey = resource.resource;
                                if (!acc[resourceKey]) {
                                  acc[resourceKey] = [];
                                }
                                acc[resourceKey].push(resource);
                                return acc;
                              }, {});
                              
                              // Step 2: Sort the keys (resource types) alphabetically
                              const sortedResourceKeys = Object.keys(groupedByResource).sort();
                              
                              // Step 3: Rebuild the uniqueResourcesArray in the sorted order
                              uniqueResourcesArray = sortedResourceKeys.reduce((acc, resourceKey) => {
                                acc.push(...groupedByResource[resourceKey]);
                                return acc;
                              }, []);
                            that.getSelectedResFromDuplicateRes(uniqueResourcesArray, response, uomMR, controlKeyMR, bottleneckResMR,totalVariableMRDtVal);
                        }.bind(this), // Important to bind 'this' to ensure it refers to the correct context
                        error: function (xhr) {
                            BusyIndicator.hide(); // Hide BusyIndicator in case of error
                            var errorMessage = xhr.responseJSON?.error?.message || this.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                            MessageToast.show(this.oResourceBundle.getText("PROD_STD_DB_FAIL") + " " + errorMessage);
                        }
                    }); // Close the AJAX call properly
				 
            },
            getPhaseType: function(uniqueResourcesArray, selectedResources, response, uomMR, controlKeyMR, bottleneckResMR, oData,totalVariableMRDtVal){
                var that = this;
                var sConfigNo = response.configNo;
                $.get("odata/v4/data-services/PhaseDB?$filter=configNo eq '" + sConfigNo + "'&$orderby=auditInfoModifiedOn desc").done(function (data) {
                    var oTableModel = new sap.ui.model.json.JSONModel(data)
                    that.getView().setModel(oTableModel, "phaseConfigModel");
                    that.getOwnerComponent().setModel(oTableModel, "phaseConfigModel");
                    that.getMROriginalPhaseNo(uniqueResourcesArray, selectedResources, response, uomMR, controlKeyMR, bottleneckResMR, oData,totalVariableMRDtVal);
                }).fail(function (_xhr, _status, error) {
                    MessageToast.show(that.oResourceBundle.getText("CONFIG_LOADING_FAIL"));
                });   
        },  
        getMROriginalPhaseNo:function(uniqueResourcesArray, selectedResources, response, uomMR, controlKeyMR, bottleneckResMR, oData, totalVariableMRDtVal){
            var that = this;
            var mrNumber = response.mrGroup;
            var mrCounter = response.mrCounter;
            if(mrNumber!=="" && mrCounter!==null){
            var mrCounter = parseInt(mrCounter) < 10 ? '0' + mrCounter : mrCounter.toString();
            var url = "/ETY_MR_HEADER_CRSet";
            var oFilterMRNo = new Filter({
                filters: [
                    new Filter("PLNNR", FilterOperator.EQ, mrNumber)
                    ]
            });
            var oFilterMRCounter = new Filter({
                filters: [
                    new Filter("Plnal", FilterOperator.EQ, mrCounter)
                    ]
            });
            
            if (oODataModel) {
                oODataModel.read(url, {
                    urlParameters: {
                        "$expand": "HeaderToOperation"
                      },
                    headers: mHeaders,
                    filters: [oFilterMRNo,oFilterMRCounter],
                    success: function (data) {
                        // Create and set the JSONModel with the data received
                        var oOriginalPhaseModel = new sap.ui.model.json.JSONModel();
                        oOriginalPhaseModel.setData(data);
                        this.getView().setModel(oOriginalPhaseModel, "oOriginalPhaseModel");
                        this.getOwnerComponent().setModel(oOriginalPhaseModel, "oOriginalPhaseModel");
                        this.getMrOperationData(uniqueResourcesArray, selectedResources, response, uomMR, controlKeyMR, bottleneckResMR, oData, totalVariableMRDtVal); 
                    }.bind(this),
                    error: function (jqXHR) {
                        let errorMessage = jqXHR.responseText ?
                                JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                // Handle errors
                                MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                    }
                });
            } else {
                MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
            }  
        } else{
            this.getMrOperationData(uniqueResourcesArray, selectedResources, response, uomMR, controlKeyMR, bottleneckResMR, oData, totalVariableMRDtVal); 
        }
    },
            getSelectedResFromDuplicateRes: function(uniqueResourcesArray, response, uomMR, controlKeyMR, bottleneckResMR,totalVariableMRDtVal) {
                const resourceCount = uniqueResourcesArray
  .filter(item => {
    if (item.deletionInd !== null && item.phaseNo !== null) {
      return item.deletionInd !== 'D';
    }
    return true; // If either is null, no filtering is applied
  })
  .reduce((acc, item) => {
    acc[item.resource] = (acc[item.resource] || 0) + 1;
    return acc;
  }, {});

                // Step 2: Filter the array to get all duplicates
                const duplicateResourcesArray = uniqueResourcesArray.filter(item => resourceCount[item.resource] > 1 );
            
                const resourceMap = {}; // Group resources by resource name
                duplicateResourcesArray.forEach(item => {
                    if (!resourceMap[item.resource]) {
                        resourceMap[item.resource] = [];
                    }
                    resourceMap[item.resource].push(item);
                });
            
                const selectedResources = [];  // Process each group of resources
                for (const resource in resourceMap) {
                    if (resourceMap.hasOwnProperty(resource)) {
                        const group = resourceMap[resource];
            
                        if (Array.isArray(group)) {
                            const ybnResources = group.filter(item => 
                                item.controlKey === 'YBN1' || item.controlKey === 'YBN2' || item.controlKey === 'YBN3'
                            );
            
                            const selectedResource = ybnResources.length > 0 
                            ? ybnResources[0] 
                            : group.reduce((prev, curr) => (prev.mrSpeed < curr.mrSpeed) ? prev : curr);
                        
                        selectedResources.push(selectedResource);
                        }
                    }
                }
                var plantMR = response.plant;
                var descMR = response.masterRecipeDesc;
                var speedMR = response.nominalSpeed;
                var mrNumber = response.mrGroup;
                var mrCounter = response.mrCounter;
                var aMaterialMRData = this.getView().getModel("globalResponseModel").getProperty("/materialData");
                var oData = {
                    "PLNNR": mrNumber ? String(mrNumber) : "X",
                    "Werks": plantMR,
                    "Plnal": mrCounter ? String(mrCounter) : "X",
                    "Ktext": descMR,
                    "Profidnetz": "PI01",
                    "Verwe": "1",
                    "Statu": "4",
                    "Bmsch": speedMR.toFixed(3),
                    "Losbs": "99999999.000",
                    "Plnme": uomMR,
                    "Aennr": "",
                    "HeaderToItem": [],
                    "HeaderToOperation": []
                };
            
                // Add material data to HeaderToItem
                for (var i = 0; i < aMaterialMRData.length; i++) {
                    var materialNumber = String(aMaterialMRData[i].material);
    
                if (materialNumber.length < 18) {
                         materialNumber = materialNumber.padStart(18, '0'); 
                }
                    oData.HeaderToItem.push({
                        "Matnr": materialNumber,
                        "Werks": plantMR,
                        "Plnal": mrCounter ? String(mrCounter) : "01",
                    });
                }
            
                // Call the function to process the operation data
                this.getPhaseType(uniqueResourcesArray, selectedResources, response, uomMR, controlKeyMR, bottleneckResMR, oData,totalVariableMRDtVal);
                
            },            
            getMrOperationData: function(uniqueResourcesArray, selectedResources, response, uomMR, _controlKeyMR, bottleneckResMR, oData, totalVariableMRDtVal) {
                var plantMR = response.plant;
                var mrNumber = response.mrGroup;
													   
                var aSecResMRData = this.getView().getModel("globalResponseModel").getProperty("/SecondaryResData");
                var oPhaseModel = this.getView().getModel("phaseConfigModel").getData();
                var phaseConfigCount = oPhaseModel.value.length;          
                var operation1 = {}, operation2 = {};
                var phaseNoCreationProceedFlag = 0;
                for (var i = 0; i < uniqueResourcesArray.length; i++) {
                    var resource = uniqueResourcesArray[i].resource;
                    const resourceExists = selectedResources.find(item => item.resource === resource);
                    if (!resourceExists || (resource === resourceExists.resource && uniqueResourcesArray[i].mrSpeed === resourceExists.mrSpeed)) {
                        console.log("test");
                        var phaseNoCreationProceedFlag = phaseNoCreationProceedFlag+1;
                        totalPeople = uniqueResourcesArray.filter(i => i.resource === resource).reduce((sum, i) => sum + i.noOfPeople, 0);
                        operationNo = phaseNoCreationProceedFlag === 1 ? "100" : String(parseInt(operationNo) + 100);
                        phaseNo = phaseNoCreationProceedFlag === 1 ? "110" : String(parseInt(phaseNo) + 100);
                        tempPhaseNo = parseInt(operationNo);
                        var deletionIndFlag = (uniqueResourcesArray[i].deletionInd === null || uniqueResourcesArray[i].phaseNo === null) ? "" : "D"; 
                        const firstDigit = parseInt(phaseNo[0],10);
                        for (let i = 0; i < uniqueResourcesArray.length; i++) {
                            if(uniqueResourcesArray[i].phaseNo!== null){
                            if (parseInt(uniqueResourcesArray[i].phaseNo.toString()[0],10) === firstDigit ) {
                              var deletionIndFlag = uniqueResourcesArray[i].deletionInd === "D" ? "D" : "";
                              break; // Exit the loop when condition is satisfied
                            }else{
                                var deletionIndFlag = ""; 
                            }
                        }
                    }
                       
                        
                        
                        operation1 = {
                            "Vplal": "1", "Werks": plantMR, "Vornr": operationNo.toString().padStart(4, '0'), "Arbpl": resource, "Steus": uniqueResourcesArray[i].controlKey,
                            "Bmsch": (uniqueResourcesArray[i].mrSpeed).toFixed(3), "Meinh": uomMR, "Ltxa1": "",  "Origin_Act_Num": operationNo.toString().padStart(4, '0'),"Loekz" :deletionIndFlag,  "Umrez": String(response.chargeQty), "Umren": String(response.operationQty),"Phase_Config_Type": ""
                        };
                        operation2 = {
                            "ID": uniqueResourcesArray[i].id, "Vplal": "1", "Werks": plantMR, "Vornr": phaseNo.toString().padStart(4, '0'), "Arbpl": resource, "Steus": uniqueResourcesArray[i].controlKey,
                            "Bmsch": (uniqueResourcesArray[i].mrSpeed).toFixed(3), "Meinh": uomMR, "Ltxa1": "", "Origin_Act_Num": phaseNo.toString().padStart(4, '0'),"Loekz" : deletionIndFlag, "Umrez": String(response.chargeQty), "Umren": String(response.operationQty),
                            "Pvznr": operationNo.toString().padStart(4, '0'), "Phseq": uniqueResourcesArray[i].destinationKey, "Phflg": "X", "PhaseType": "R","Anzma": String(totalPeople), "Usr04": String(uniqueResourcesArray[i].mrLineEff),
                            "Usr05": String(uniqueResourcesArray[i].mrCapacity), "Flag": resource === bottleneckResMR ? "X" : "", "Vge01": "H", "Vgw01": "0",
                            "Vge02": "H", "Vgw02": "1", "Vge03": "H", "Vgw03": "0", "Vge04": "H", "Vgw04": String(totalPeople),
                            "Vge05": "H", "Vgw05": String(totalVariableMRDtVal), "Vge06": "H", "Vgw06": String(totalVariableMRDtVal * totalPeople), "Phase_Config_Type": "R"
                        };
            
                        if (Object.entries(operation1).length !== 0 && Object.entries(operation2).length !== 0) {
                            oData.HeaderToOperation.push(operation1);
                            
                            for (var a = 0; a < phaseConfigCount; a++) {     
                            if (oPhaseModel.value[a].beforeRunTimePhase === true && phaseNoCreationProceedFlag === 1) {
                                editFlag = deletionIndFlag === "D" ? 1:0;
                                tempPhaseNo = tempPhaseNo + 10;
                                let phaseOperation = {
                                    "Vplal": "1", 
                                    "Werks": plantMR, 
                                    "Vornr": tempPhaseNo.toString().padStart(4, '0'), // New phase number
                                    "Arbpl": resource, 
                                    "Steus": oPhaseModel.value[a].phaseControlKey,
                                    "Bmsch": (uniqueResourcesArray[i].mrSpeed).toFixed(3),
                                    "Ltxa1": oPhaseModel.value[a].phaseName +"-"+ oPhaseModel.value[a].phaseType,
                                    "Origin_Act_Num": tempPhaseNo.toString().padStart(4, '0'),
                                    "Loekz" : deletionIndFlag, 
                                    "Meinh": uomMR, 
                                    "Umrez": String(response.chargeQty), 
                                    "Umren": String(response.operationQty),
                                    "Pvznr": operationNo.toString().padStart(4, '0'), 
                                    "Phseq": oPhaseModel.value[a].destinationKey, 
                                    "Phflg": "X", 
                                    "PhaseType": oPhaseModel.value[a].phaseType,
                                    "Anzma": String(totalPeople), 
                                    "Usr04": String(uniqueResourcesArray[i].mrLineEff),
                                    "Usr05": String(uniqueResourcesArray[i].mrCapacity), 
                                    "Flag": resource === bottleneckResMR ? "X" : "", 
                                    "Vge01": "H", 
                                    "Vgw01": "0",
                                    "Vge02": "H", 
                                    "Vgw02": "1", 
                                    "Vge03": "H", 
                                    "Vgw03": "0", 
                                    "Vge04": "H", 
                                    "Vgw04": String(totalPeople),
                                    "Vge05": "H", 
                                    "Vgw05": String(totalVariableMRDtVal), 
                                    "Vge06": "H", 
                                    "Vgw06": String(totalVariableMRDtVal * totalPeople),
                                    "Phase_Config_Type": oPhaseModel.value[a].phaseType,
                                    "BeforeFlag": "X"
                                };
                                oData.HeaderToOperation.push(phaseOperation);
                            }
                            }
                            if (phaseNoCreationProceedFlag===2 && editFlag === 1 && i !== uniqueResourcesArray.length - 1){
                            for (var a = 0; a < phaseConfigCount; a++) {     
                                if (oPhaseModel.value[a].beforeRunTimePhase === true) {
                                    tempPhaseNo = tempPhaseNo + 10;
                                    let phaseOperation = {
                                        "Vplal": "1", 
                                        "Werks": plantMR, 
                                        "Vornr": tempPhaseNo.toString().padStart(4, '0'), // New phase number
                                        "Arbpl": resource, 
                                        "Steus": oPhaseModel.value[a].phaseControlKey,
                                        "Bmsch": (uniqueResourcesArray[i].mrSpeed).toFixed(3),
                                        "Ltxa1": oPhaseModel.value[a].phaseName +"-"+ oPhaseModel.value[a].phaseType,
                                        "Origin_Act_Num": tempPhaseNo.toString().padStart(4, '0'),
                                        "Loekz" : deletionIndFlag,
                                        "Meinh": uomMR, 
                                        "Umrez": String(response.chargeQty), 
                                        "Umren": String(response.operationQty),
                                        "Pvznr": operationNo.toString().padStart(4, '0'), 
                                        "Phseq": oPhaseModel.value[a].destinationKey, 
                                        "Phflg": "X", 
                                        "PhaseType": oPhaseModel.value[a].phaseType,
                                        "Anzma": String(totalPeople), 
                                        "Usr04": String(uniqueResourcesArray[i].mrLineEff),
                                        "Usr05": String(uniqueResourcesArray[i].mrCapacity), 
                                        "Flag": resource === bottleneckResMR ? "X" : "", 
                                        "Vge01": "H", 
                                        "Vgw01": "0",
                                        "Vge02": "H", 
                                        "Vgw02": "1", 
                                        "Vge03": "H", 
                                        "Vgw03": "0", 
                                        "Vge04": "H", 
                                        "Vgw04": String(totalPeople),
                                        "Vge05": "H", 
                                        "Vgw05": String(totalVariableMRDtVal), 
                                        "Vge06": "H", 
                                        "Vgw06": String(totalVariableMRDtVal * totalPeople),
                                        "Phase_Config_Type": oPhaseModel.value[a].phaseType,
                                        "BeforeFlag": "X"
                                    };
                                    oData.HeaderToOperation.push(phaseOperation);
                                }
                                }

                        }
                            operation2.Vornr = (phaseNoCreationProceedFlag=== 1 || phaseNoCreationProceedFlag=== 2) ? (tempPhaseNo+10).toString().padStart(4, '0'): phaseNo.toString().padStart(4, '0');
                            operation2.Origin_Act_Num = (phaseNoCreationProceedFlag=== 1 || phaseNoCreationProceedFlag=== 2) ? (tempPhaseNo+10).toString().padStart(4, '0'): phaseNo.toString().padStart(4, '0');
                            oData.HeaderToOperation.push(operation2);    
                            var additionalPhaseNo =  parseInt(operation2.Vornr);                 
                    
                        }
                    } else {
                        operation2 = {};
                        operation1 = {};
                    }          
                    // Secondary resources loop
                    operation2.OperationToSecondary = [];
                    for (var j = 0; j < aSecResMRData.length; j++) {
                        if (aSecResMRData[j].secResource !== "" && aSecResMRData[j].resource === resource && aSecResMRData[j].secResource !== null) {
                            operation2.OperationToSecondary.push({
                                "Plnnr": mrNumber ? String(mrNumber) : "X",
                                "Plnty": "2",
                                "Vornr": operationNo === undefined? "100".toString().padStart(4, '0'): operationNo.toString().padStart(4, '0'),
                                "Uvorn": operationNo === undefined? "100".toString().padStart(4, '0'): operationNo.toString().padStart(4, '0'),
                                "Arbpl": aSecResMRData[j].secResource,
                                "Werks": plantMR,
                                "Steus": uniqueResourcesArray[i].controlKey,
                                "Vge01": aSecResMRData[j].energy1Uom !== null ? aSecResMRData[j].energy1Uom : "",
                                "Vgw01": aSecResMRData[j].energy1QtyPerHr !== null ? String(aSecResMRData[j].energy1QtyPerHr) : "0",
                                "Vge02": aSecResMRData[j].energy2Uom !== null ? aSecResMRData[j].energy2Uom : "",
                                "Vgw02": aSecResMRData[j].energy2QtyPerHr !== null ? String(aSecResMRData[j].energy2QtyPerHr) : "0",
                                "Vge03": aSecResMRData[j].energy3Uom !== null ? aSecResMRData[j].energy3Uom : "",
                                "Vgw03": aSecResMRData[j].energy3QtyPerHr !== null ? String(aSecResMRData[j].energy3QtyPerHr) : "0",
                                "Vge04": aSecResMRData[j].energy4Uom !== null ? aSecResMRData[j].energy4Uom : "",
                                "Vgw04": aSecResMRData[j].energy4QtyPerHr !== null ? String(aSecResMRData[j].energy4QtyPerHr) : "0",
                                "Vge05": aSecResMRData[j].energy5Uom !== null ? aSecResMRData[j].energy5Uom : "",
                                "Vgw05": aSecResMRData[j].energy5QtyPerHr !== null ? String(aSecResMRData[j].energy5QtyPerHr) : "0",
                                "Vge06": aSecResMRData[j].energy6Uom !== null ? aSecResMRData[j].energy6Uom : "",
                                "Vgw06": aSecResMRData[j].energy6QtyPerHr !== null ? String(aSecResMRData[j].energy6QtyPerHr) : "0"
                            });
                        }
                    }
                    for (var a = 0; a < phaseConfigCount; a++) {
                    if (oPhaseModel.value[a].afterRunTimePhase === true && i === uniqueResourcesArray.length - 1) {
                        
                        phaseNoCreationProceedFlag === 1? phaseNo = additionalPhaseNo : phaseNo;
                        phaseNo = parseInt(phaseNo)+10;
                        let phaseOperation = {
                            "Vplal": "1", 
                            "Werks": plantMR, 
                            "Vornr": phaseNo.toString().padStart(4, '0'), // New phase number
                            "Arbpl": resource, 
                            "Steus": oPhaseModel.value[a].phaseControlKey,  
                            "Bmsch": (uniqueResourcesArray[i].mrSpeed).toFixed(3), 
                            "Ltxa1": oPhaseModel.value[a].phaseName +"-"+ oPhaseModel.value[a].phaseType,
                            "Origin_Act_Num": phaseNo.toString().padStart(4, '0'),
                            "Loekz" : "",   
                            "Meinh": uomMR, 
                            "Umrez": String(response.chargeQty), 
                            "Umren": String(response.operationQty),
                            "Pvznr": operationNo.toString().padStart(4, '0'), 
                            "Phseq": oPhaseModel.value[a].destinationKey,  
                            "Phflg": "X", 
                            "PhaseType": oPhaseModel.value[a].phaseType,
                            "Anzma": String(totalPeople), 
                            "Usr04": String(uniqueResourcesArray[i].mrLineEff),
                            "Usr05": String(uniqueResourcesArray[i].mrCapacity), 
                            "Flag": resource === bottleneckResMR ? "X" : "", 
                            "Vge01": "H", 
                            "Vgw01": "0",
                            "Vge02": "H", 
                            "Vgw02": "1", 
                            "Vge03": "H", 
                            "Vgw03": "0", 
                            "Vge04": "H", 
                            "Vgw04": String(totalPeople),
                            "Vge05": "H", 
                            "Vgw05": String(totalVariableMRDtVal), 
                            "Vge06": "H", 
                            "Vgw06": String(totalVariableMRDtVal * totalPeople),
                            "Phase_Config_Type": oPhaseModel.value[a].phaseType,
                            "BeforeFlag": ""
                        };
                        oData.HeaderToOperation.push(phaseOperation);
                        var additionalPhaseNo =  additionalPhaseNo + 10;
                    }
                }
            }     
                var phaseSimulationModel = new sap.ui.model.json.JSONModel(oData);
                this.getView().setModel(phaseSimulationModel, "phaseSimulationModel");
               
                if (response.mrGroup !== "" && response.mrCounter !== null) {
                    var oOriginalPhaseData = this.getView().getModel("oOriginalPhaseModel").getData();
                    var phaseSimulationResults = phaseSimulationModel.getData().HeaderToOperation;
                 
                    for (var n = 0; n < phaseSimulationResults.length; n++) {
                        var currentOperation = phaseSimulationResults[n]; // Current operation in simulation model
                        var originalOperations = oOriginalPhaseData.results[0].HeaderToOperation.results; // Original operations
                 
                        if (currentOperation.Phase_Config_Type === "") {                           
                                currentOperation.Origin_Act_Num = currentOperation.Vornr;                          
                        } else {
                            var matchedOperation = originalOperations.find(function (op) {
                                return op.Phase_Config_Type === currentOperation.Phase_Config_Type &&
                                       op.Pvznr === currentOperation.Pvznr
                            });
                 
                            if (matchedOperation) {
                                // If a match is found, take the value from the matched operation
                                currentOperation.Origin_Act_Num = matchedOperation.Vornr;
                            } else {
                                if(currentOperation.BeforeFlag==="X"){
                                    for(var l = 1; l<phaseSimulationResults.length; l++){
                                        if(phaseSimulationResults[l].Phase_Config_Type!==""){
                                            currentOperation.Origin_Act_Num = phaseSimulationResults[l].Vornr;
                                        }else{
                                            break;
                                        }

                                    }
                                }else{
                                // Handle the case where no match is found
                                currentOperation.Origin_Act_Num = currentOperation.Vornr;
                                }
                            }
                        }
                    }
                }
                this._oSimulationDialog.open();
                BusyIndicator.hide();
            },
            onFinalSaveMR: function(){
                var that = this;
                BusyIndicator.show(0);
                var eccData = this.getView().getModel("phaseSimulationModel").getData();
                var updateData = [];
                for(var i = 0; i<eccData.HeaderToOperation.length; i++){
                    if(editFlag === 1){
                    if(eccData.HeaderToOperation[i].PhaseType === "R"){
                        updateData.push({
                            "ID": eccData.HeaderToOperation[i].ID,
                            "phaseNo": parseInt(eccData.HeaderToOperation[i].Vornr)
                        });
                    }
                }else{
                    if(eccData.HeaderToOperation[i].PhaseType === "R"){
                        updateData.push({
                            "ID": eccData.HeaderToOperation[i].ID,
                            "phaseNo": parseInt(eccData.HeaderToOperation[i].Vornr)
                        });
                    } 
                }
                }
                var payload = {
                "updateData": updateData
                };

                var sUrl = "odata/v4/data-services/updateBttlnckPhaseNos";
                $.ajax({
                    url: sUrl,
                    type: "POST",
                    data: JSON.stringify(payload),
                    contentType: "application/json"
                })
                    .done(function (response) {
                        BusyIndicator.hide();
                        that._oSimulationDialog.close();
                        if (!that._oDialog) {
                            var oView = that.getView();
                            that._oDialog = sap.ui.xmlfragment(oView.getId(), "l8gttpmgllpstdui.view.fragment.PopoverSendDataToSAP", that); // Load the fragment             
                            oView.addDependent(that._oDialog); 
                        }
                        that._oDialog.open();
                    })
                    .fail(function (xhr, _status, _error) {
                        BusyIndicator.hide();
                        let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                            xhr.responseJSON.error.message :
                            that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                        var message = that.oResourceBundle.getText("PROD_STD_UPDATE_FAIL") + " " + errorMessage;
                        that.onShowError(message);
                    });
            },          
            postMrDataToECC: function(){ 
                var eccData = this.getView().getModel("phaseSimulationModel").getData();
                var deleteProperties = ["ID","BeforeFlag"];
                eccData.HeaderToOperation.forEach(operation => {
                    deleteProperties.forEach(property =>{
                        delete operation[property];
                    })
                    
                  });
                var oTable = this.getView().byId("idProductTable");
                var aSelectedPaths = oTable._aSelectedPaths;
                var sSelectedPath = aSelectedPaths[0];
                var iSelectedIndex = parseFloat(sSelectedPath.split("/")[2], 10);
                var oModel = this.getView().getModel("productModel");
                var ecmNumber = oModel.getData().value[iSelectedIndex].ecm;
                var ECN = (ecmNumber === "" ? this.getView().byId("valECN").getValue(): ecmNumber);
                var prdStdNo = oModel.getData().value[iSelectedIndex].prodStdNo;
                var prdStandardNo = prdStdNo;
                var that = this;        
                eccData.Aennr = String(ECN);    
                var url = "/ETY_MR_HEADER_CRSet";
                BusyIndicator.show(0);
                if (oODataModel) {
                    oODataModel.create(url, eccData, {
                        headers: {
                            ...mHeaders
                        },
                        success: function (res, status, xhr) {
                           
                            var mrNumber = res.PLNNR;
                            var mrCounter = res.Plnal;
                            var status = mrNumber === "" ?
                                    "Appr - Failed in SAP" :
                                        "Appr - SAP";
                            var message = mrNumber === "" ?
                                    that.oResourceBundle.getText("MASTER_RECIPE_CREATION_FAILED") :
                                        that.oResourceBundle.getText("MASTER_RECIPE_SUCCESS") + " " + mrNumber + ", Counter :" + mrCounter + ", ECN :" + ECN + ".";
                                    mrNumber === "" ? that.onShowError(message) : that.onShowSuccess(message);
                                    that.updateMasterRecipeToHeaderDB(mrNumber, mrCounter, prdStandardNo, ECN, status);
                                    BusyIndicator.hide();
                                    that._oDialog.close();
                                    that.getView().byId("idSendToSAP").setEnabled(false);
                                  
                        },
                        error: function (jqXHR, textStatus, error) {
                            BusyIndicator.hide();
                            let errorMessage = jqXHR.responseText ?
                                    JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                    var message = that.oResourceBundle.getText("ERROR_SUBMIT_PROD") + " " + errorMessage;
                                    that.onShowError(message);
                                    that._oDialog.close();
                                    that.getView().byId("idSendToSAP").setEnabled(false);
                                    that.getView().byId("idProductTable").removeSelections();
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
            },
            updateMasterRecipeToHeaderDB: function (mrNumber, mrCounter, prdStandardNo, ECN, status) {
                var that = this;
                var updateProdStdHdrDBMRNumber = [];
                updateProdStdHdrDBMRNumber.push({
                    "prodStdNo": prdStandardNo,
                    "mrGroup": mrNumber,
                    "mrCounter": mrCounter,
                    "ecm": ECN,
                    "status": status
                });
                // Create the payload
                var payload = {
                        "updateProdStdHdrDBMRNumber": updateProdStdHdrDBMRNumber,

                };
                var sUrl = "odata/v4/data-services/updateMRNumber";
                $.ajax({
                    url: sUrl,
                    headers: {
                        'x-username': nbId,
                        'x-zone': zone,
                        'x-plants': plantsParam,
                        'x-role': "Approver"
                    },
                    type: "POST",
                    data: JSON.stringify(payload),
                    contentType: "application/json"

                })
                .done(function (response) {
                    var message = that.oResourceBundle.getText("PROD_STD_MASTER_RECP_UPDATE_SUCCESS");
                    MessageToast.show(message);
                    var oTable = that.getView().byId("idProductTable");
                    var aSelectedPaths = oTable._aSelectedPaths;
                    var sSelectedPath = aSelectedPaths[0];
                    var iSelectedIndex = parseFloat(sSelectedPath.split("/")[2], 10);
                    var oModel = that.getView().getModel("productModel");
                    oModel.setProperty("/value/" + iSelectedIndex + "/mrGroup", mrNumber);
                    oModel.setProperty("/value/" + iSelectedIndex + "/mrCounter", mrCounter);
                    oModel.setProperty("/value/" + iSelectedIndex + "/ecm", ECN);
                    oModel.setProperty("/value/" + iSelectedIndex + "/status", status);
                    that.getView().byId("idProductTable").removeSelections();
                })
                .fail(function (xhr, status, error) {
                    let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                            xhr.responseJSON.error.message :
                                that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                    var message = that.oResourceBundle.getText("PROD_STD_MASTER_RECP_UPDATE_FAIL") + " " + errorMessage;
                    MessageToast.show(message);
                    that.getView().byId("idProductTable").removeSelections();
                });
            },
            onApprovalView: function (evt) {
                if (!this._oApproverReviewProd) {
                    this._oApproverReviewProd = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.ApproverReviewProdStd", this);
                    this.getView().addDependent(this._oApproverReviewProd);
                }
                this._oApproverReviewProd.open();
            },
			  onSelectionChange: function (oEvent) {
                var oComboBox = oEvent.getSource();
                var oSelectedItem = oComboBox.getSelectedItem();

                if (oSelectedItem) {
                    var sSelectedKey = oSelectedItem.getText().split(" - ")[0];
                    oComboBox.setValue(sSelectedKey);
                    console.log("Selected Item Text:", oSelectedItem.getText());
                    console.log("Selected Item Key:", oSelectedItem.getKey());
                }
            },
             onMenuProd: function (oEvent) {
                if (!this._oPopover) {
                    this._oPopover = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.Popover", this);
                    this.getView().addDependent(this._oPopover);
                }
                tableIndex = this.getView().byId("idProductTable")._aSelectedPaths[0];
                selectedTableIndex = this.getView().byId("idProductTable").getItems().indexOf(oEvent.getSource().getParent());
																																						 
                this._oPopover.openBy(oEvent.getSource());
                var oProductTableData = this.getView().getModel("productModel").getData().value[selectedTableIndex];
                this._plant = oProductTableData.plant;
                this._mrCounter = oProductTableData.mrCounter;
                this._mrNumber = oProductTableData.mrGroup;
                var status = oProductTableData.status;
                this._prdStdNo = oProductTableData.prodStdNo;
                this._selectedProdRowStatus = oProductTableData.status;
                this._ID = oProductTableData.ID;
                if (status === "Under Review" || status === "Archived - SAP Del") {
                    sap.ui.getCore().byId("idpopoverprodview").setVisible(false);
                    sap.ui.getCore().byId("idpopoverprodedit").setVisible(false);
                    sap.ui.getCore().byId("idpopoverprodreview").setVisible(true);
                } else {
                    sap.ui.getCore().byId("idpopoverprodview").setVisible(true);
                    sap.ui.getCore().byId("idpopoverprodedit").setVisible(true);
                    sap.ui.getCore().byId("idpopoverprodreview").setVisible(false);
                }
            },
            onProdReviewpress: function () {
                var that = this;
                var prdStandardNo = this._prdStdNo;
                var ID = this._ID;
                if (!this._oAutomaticArchivingProd) {
                    this._oAutomaticArchivingProd = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.AutomaticArchievingProdstd", this);
                    this.getView().addDependent(this._oAutomaticArchivingProd);
                }
                // Access elements inside the fragment and set properties based on status
                if (this._selectedProdRowStatus === "Archived - SAP Del") {
                    // Only "Re-work" and "Cancel" buttons should be visible
                    sap.ui.getCore().byId("idProdStdActualButton").setVisible(false);
                    sap.ui.getCore().byId("idProdStdArchiveButton").setVisible(false);
                    sap.ui.getCore().byId("idProdStdRevertButton").setVisible(true);
                    sap.ui.getCore().byId("idProdStdCancelButton").setVisible(true);
                    sap.ui.getCore().byId("idProdStdReworkButton").setVisible(false);
                } else if (this._selectedProdRowStatus === "Under Review") {
                    // All four buttons should be visible
                    sap.ui.getCore().byId("idProdStdActualButton").setVisible(true);
                    sap.ui.getCore().byId("idProdStdArchiveButton").setVisible(true);
                    sap.ui.getCore().byId("idProdStdRevertButton").setVisible(false);
                    sap.ui.getCore().byId("idProdStdCancelButton").setVisible(true);
                    sap.ui.getCore().byId("idProdStdReworkButton").setVisible(true);
                } else {
                    // Default case: all buttons hidden except "Cancel"
                    sap.ui.getCore().byId("idProdStdActualButton").setVisible(false);
                    sap.ui.getCore().byId("idProdStdArchiveButton").setVisible(false);
                    sap.ui.getCore().byId("idProdStdReworkButton").setVisible(false);
                    sap.ui.getCore().byId("idProdStdRevertButton").setVisible(false);
                    sap.ui.getCore().byId("idProdStdCancelButton").setVisible(true);
                }
                this._oAutomaticArchivingProd.open();
                var url = `odata/v4/data-services/ProductRelStandardHeadersDB(ID=${ID},prodStdNo='${prdStandardNo}')?$expand=ProdStdToProdBttlnckDataNav,ProdStdToProdSecResDataNav,ProdStdToProdVarDtDataNav,ProdStdToProdMatrAllDataNav`;
                BusyIndicator.show(0);
                $.ajax({
                    url: url,
                    method: 'GET',
                    headers: {
                        'x-username': nbId,
                        'x-zone': zone,
                        'x-plants': plantsParam,
                        'x-role': "Creator/Editor"
                    },
                    success: function (response) {
                        BusyIndicator.hide();
                        MessageToast.show(that.oResourceBundle.getText("PROD_STD_DB_SUCCESS"));
                        var prodBttlnckData = response.ProdStdToProdBttlnckDataNav;
                        var prodSecResData = response.ProdStdToProdSecResDataNav;
                        var prodVarDtData = response.ProdStdToProdVarDtDataNav;
                        var prodMatrData = response.ProdStdToProdMatrAllDataNav;
                        that.oglobalResponseModel.setData({
                            standardCycleData: prodBttlnckData,
                            variableDtData: prodVarDtData,
                            materialData: prodMatrData,
                            SecondaryResData: prodSecResData
                        });
                        configNo = response.configNo;
                        prodId = response.ID;
                        sap.ui.getCore().byId("idProdReviewPlant").setText(response.plant);
                        sap.ui.getCore().byId("idProdReviewValidFrom").setText(that.getDateFormat(response.validFrom));
                        sap.ui.getCore().byId("idProdReviewModifiedFrom").setText(that.getDateFormat(response.modifiedFrom));
                        sap.ui.getCore().byId("idProdReviewValidTo").setText(that.getDateFormat(response.validTo));
                        sap.ui.getCore().byId("idProdReviewLotSize").setText(response.procOrdrSizeOrCostingLotSize);
                        sap.ui.getCore().byId("idProdReviewMrNo").setText(response.mrGroup);
                        sap.ui.getCore().byId("idProdReviewMrCounter").setText(response.mrCounter);
                        sap.ui.getCore().byId("idProdReviewAiPercent").setText(response.pctAI);
                        sap.ui.getCore().byId("idProdReviewEff").setText(response.lineEfficiency);
                        sap.ui.getCore().byId("idProdReviewNS").setText(response.nominalSpeed);
                        sap.ui.getCore().byId("idProdReviewOperationQty").setText(response.operationQty);
                        sap.ui.getCore().byId("idProdReviewChrgQty").setText(response.chargeQty);
                        var bottleneckCorrect = (response.bottleneckCorrect === "Y") ? "True" : "False";
                        sap.ui.getCore().byId("idProdReviewBottleneckCorrect").setText(bottleneckCorrect);
                        sap.ui.getCore().byId("idProdReviewDescription").setText(response.masterRecipeDesc);
                        sap.ui.getCore().byId("idProdReviewCrewSize").setText(response.crewSize);
                        sap.ui.getCore().byId("idProdReviewCostCenter").setText(response.costCenter);
                        sap.ui.getCore().byId("idProdReviewBottleneckCorrect")
                            .addStyleClass((bottleneckCorrect === "True") ? "greenText" : "redText")
                            .removeStyleClass((bottleneckCorrect === "True") ? "redText" : "greenText")
                    },
                    error: function (xhr, _status, _error) {
                        // Hide BusyIndicator and show error message
                        BusyIndicator.hide();
                        let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                            xhr.responseJSON.error.message :
                            that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                        MessageToast.show(that.oResourceBundle.getText("PROD_STD_DB_FAIL") + " " + errorMessage);
                    }
                });

            },
            onProdstdActualpress: function () {
                var that = this;
                var newData = sap.ui.getCore().getModel("loginUserModel").getData().results;
                nbId = newData[0].Username;
                role = newData[0].AuthType;
                // Role assignment logic
                if (role === 'C') {
                    role = "Creator/Editor";
                } else if (role === 'A') {
                    role = "Approver";
                } else if (role === 'V' || role === 'E') {
                    role = "Executor/Viewer";
                }
                var payload = {
                    "prodStdNo": this._prdStdNo
                };
                BusyIndicator.show();
                $.ajax({
                    url: "odata/v4/data-services/actualProdStdByCreator",
                    type: "POST",
                    data: JSON.stringify(payload),
                    contentType: "application/json",
                    dataType: "json",
                    headers: {
                        "x-username": nbId,
                        "x-role": role
                    }
                }).done(function (response) {
                    BusyIndicator.hide();
                    MessageToast.show(response.value || "Successfully sent Product standard.");
                    that.getProductStdHeaderData();
                    that.onProdStdReviewclose();
                }).fail(function (xhr) {
                    BusyIndicator.hide();
                    var errorMessage = xhr.responseJSON?.error?.message || "Failed to send line standard.";
                    MessageToast.show(errorMessage);
                    that.getProductStdHeaderData();
                    that.onProdStdReviewclose();
                });

            },
            onProdStandardReviewArchive: function () {
                var that = this;
                var newData = sap.ui.getCore().getModel("loginUserModel").getData().results;
                nbId = newData[0].Username;
                role = newData[0].AuthType;
                // Role assignment logic
                if (role === 'C') {
                    role = "Creator/Editor";
                } else if (role === 'A') {
                    role = "Approver";
                } else if (role === 'V' || role === 'E') {
                    role = "Executor/Viewer";
                }
                var prodStdNos = Array.isArray(this._prdStdNo) ? this._prdStdNo : [this._prdStdNo];
                var payload = {
                    "prodStdNos": prodStdNos
                };
                var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                var nbId = newData[0].Username;
                var role = newData[0].AuthType;
                if (role === 'C') {
                    role = "Creator/Editor";
                } else if (role === 'A') {
                    role = "Approver";
                } else if (role === 'V' || role === 'E') {
                    role = "Executor/Viewer";
                }
                var sUrl = "odata/v4/data-services/archiveProdStdItems";
                $.ajax({
                    url: sUrl,
                    type: "POST",
                    data: JSON.stringify(payload),
                    contentType: "application/json",
                    headers: {
                        "x-username": nbId,
                        "x-role": role
                    }
                })
                    .done(function (_response) {
                        BusyIndicator.hide();
                        var message = that.oResourceBundle.getText("PROD_STD_ARCHIVE_SUCCESS");
                        MessageToast.show(message);
                        that.getProductStdHeaderData();
                        that.onProdStdReviewclose();
                    })
                    .fail(function (xhr, _status, _error) {
                        BusyIndicator.hide();
                        let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                            xhr.responseJSON.error.message :
                            that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                        var message = that.oResourceBundle.getText("PROD_STD_ARCHIVE_FAIL") + " " + errorMessage;
                        MessageToast.show(message);
                        that.getProductStdHeaderData();
                        that.onProdStdReviewclose();
                    });
            },
            fnProdStandardReviewArchive: function () {
                var that = this;
                BusyIndicator.show(0);
                var url = `/ETY_MR_HEADER_CRSet(PLNNR='${this._mrNumber}',Werks='${this._plant}',Plnal='${this._mrCounter}')`;
                if (oODataModel) {
                    oODataModel.remove(url, {
                        headers: mHeaders,
                        success: function (_res, _status, _xhr) {
                            BusyIndicator.hide();
                            var message = that.oResourceBundle.getText("MASTER_RECP_DELETE_ECC") + " " + this._mrNumber
                            that.onShowSuccess(message);
                            that.onProdStandardReviewArchive();
                            that.onProdStdReviewclose();
                        }.bind(this),
                        error: function (jqXHR, _textStatus, _error) {
                            BusyIndicator.hide();
                            let errorMessage = jqXHR.responseText ?
                                JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                            var message = that.oResourceBundle.getText("ERROR_SUBMIT_PROD") + " " + errorMessage;
                            that.onShowError(message);
                            that.onProdStdReviewclose();
                        }.bind(this)
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
            },
            onProdStandardReviewRework: function () {
                var that = this;
                var newData = sap.ui.getCore().getModel("loginUserModel").getData().results;
                nbId = newData[0].Username;
                role = newData[0].AuthType;
                // Role assignment logic
                if (role === 'C') {
                    role = "Creator/Editor";
                } else if (role === 'A') {
                    role = "Approver";
                } else if (role === 'V' || role === 'E') {
                    role = "Executor/Viewer";
                }
                var payload = {
                    "prodStdNo": this._prdStdNo
                };
                var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                var nbId = newData[0].Username;
                var role = newData[0].AuthType;
                if (role === 'C') {
                    role = "Creator/Editor";
                } else if (role === 'A') {
                    role = "Approver";
                } else if (role === 'V' || role === 'E') {
                    role = "Executor/Viewer";
                }
                var sUrl = "odata/v4/data-services/reworkProdStdByCreator";
                $.ajax({
                    url: sUrl,
                    type: "POST",
                    data: JSON.stringify(payload),
                    contentType: "application/json",
                    headers: {
                        "x-username": nbId,
                        "x-role": role
                    }
                })
                    .done(function (_response) {
                        BusyIndicator.hide();
                        var message = "Product standard has been updated to rework"
                        MessageToast.show(message);
                        that.getProductStdHeaderData();
                        that.onProdStdReviewclose();
                    })
                    .fail(function (xhr, _status, _error) {
                        BusyIndicator.hide();
                        let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                            xhr.responseJSON.error.message :
                            that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                        var message = that.oResourceBundle.getText("PROD_STD_ARCHIVE_FAIL") + " " + errorMessage;
                        MessageToast.show(message);
                        that.getProductStdHeaderData();
                        that.onProdStdReviewclose();
                    });
            },
            onProdstdReworkpress: function () {
                var that = this;
                BusyIndicator.show(0);
                var url = `/ETY_DELETE_MRSet(Plnnr='${this._mrNumber}',Werks='${this._plant}',Plnal='${this._mrCounter}',Delkz='X')`;
                if (oODataModel) {
                    oODataModel.remove(url, {
                        headers: mHeaders,
                        success: function (_res, _status, _xhr) {
                            BusyIndicator.hide();
                            var message = "Master Recipe has been Reverted" + " " + this._mrNumber
                            that.onShowSuccess(message);
                            that.onProdStandardReviewRevert();
                            that.onProdStdReviewclose();
                        }.bind(this),
                        error: function (jqXHR, _textStatus, _error) {
                            BusyIndicator.hide();
                            let errorMessage = jqXHR.responseText ?
                                JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                            var message = that.oResourceBundle.getText("ERROR_SUBMIT_PROD") + " " + errorMessage;
                            that.onShowError(message);
                            that.onProdStdReviewclose();
                        }.bind(this)
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }


            },
            onProdStandardReviewRevert: function () {
                var that = this;
                var newData = sap.ui.getCore().getModel("loginUserModel").getData().results;
                nbId = newData[0].Username;
                role = newData[0].AuthType;
                // Role assignment logic
                if (role === 'C') {
                    role = "Creator/Editor";
                } else if (role === 'A') {
                    role = "Approver";
                } else if (role === 'V' || role === 'E') {
                    role = "Executor/Viewer";
                }
                var payload = {
                    "prodStdNo": this._prdStdNo
                };
                var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                var nbId = newData[0].Username;
                var role = newData[0].AuthType;
                if (role === 'C') {
                    role = "Creator/Editor";
                } else if (role === 'A') {
                    role = "Approver";
                } else if (role === 'V' || role === 'E') {
                    role = "Executor/Viewer";
                }
                var sUrl = "odata/v4/data-services/reworkProdStdByCreator";
                $.ajax({
                    url: sUrl,
                    type: "POST",
                    data: JSON.stringify(payload),
                    contentType: "application/json",
                    headers: {
                        "x-username": nbId,
                        "x-role": role
                    }
                })
                    .done(function (_response) {
                        BusyIndicator.hide();
                        var message = that.oResourceBundle.getText("PROD_STD_ARCHIVE_SUCCESS");
                        MessageToast.show(message);
                        that.getProductStdHeaderData();
                        that.onProdStdReviewclose();
                    })
                    .fail(function (xhr, _status, _error) {
                        BusyIndicator.hide();
                        let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                            xhr.responseJSON.error.message :
                            that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                        var message = that.oResourceBundle.getText("PROD_STD_ARCHIVE_FAIL") + " " + errorMessage;
                        MessageToast.show(message);
                        that.getProductStdHeaderData();
                        that.onProdStdReviewclose();
                    });
            },
            onProdStdReviewclose: function () {
                if (this._oAutomaticArchivingProd) {
                    this._oAutomaticArchivingProd.close();
                }

            },
             onSubmitForApproval: function () {
                var oTable = this.getView().byId("idProductTable");
                var aSelectedPaths = oTable._aSelectedPaths;
                var oModel = this.getView().getModel("productModel");
                if (aSelectedPaths.length >= 1) {
                    for (var i = 0; i < aSelectedPaths.length; i++) {
                        var sSelectedPath = aSelectedPaths[i];
                        var iSelectedIndex = parseFloat(sSelectedPath.split("/")[2], 10);
                        var status = oModel.getData().value[iSelectedIndex].status;
                        var flag;
                        if ((status === "Created") || (status === "Modified")) {
                            flag = 1;  
                        } else {
                            flag = 0;
                            var message = this.oResourceBundle.getText("PROD_STD_STATUS_FAIL");
                            this.onShowWarning(message);
                            break;
                        }
                    }
                }
                if (flag === 1) {
                    this.onProdStdStatusChange("Under Appr");
                }
            },

            onProdStdStatusChange: function (status) {
                var oTable = this.getView().byId("idProductTable");
                var aSelectedPaths = oTable._aSelectedPaths;
                var that = this;
                var oModel = this.getView().getModel("productModel");
                var updateProdStdHdrStatusData = [];
                var updateProdStdMaterialStatusData = [];
                var updateProdStdVarDtStatusData = [];
                var updateProdStdSecResStatusData = [];
                var updateProdStdBottleneckStatusData = [];
                if (aSelectedPaths.length >= 1) {
                    for (var i = 0; i < aSelectedPaths.length; i++) {
                        var sSelectedPath = aSelectedPaths[i];
                        var iSelectedIndex = parseFloat(sSelectedPath.split("/")[2], 10);
                        updateProdStdHdrStatusData.push({
                            "prodStdNo": oModel.getData().value[iSelectedIndex].prodStdNo,
                            "status": status,
                            "stdApprLvl": 1,
                            "executionState": 0

                        });
                        updateProdStdMaterialStatusData.push({
                            "prodStdNo": oModel.getData().value[iSelectedIndex].prodStdNo,
                            "status": status
                        });
                        updateProdStdVarDtStatusData.push({
                            "prodStdNo": oModel.getData().value[iSelectedIndex].prodStdNo,
                            "status": status
                        });
                        updateProdStdSecResStatusData.push({
                            "prodStdNo": oModel.getData().value[iSelectedIndex].prodStdNo,
                            "status": status
                        });
                        updateProdStdBottleneckStatusData.push({
                            "prodStdNo": oModel.getData().value[iSelectedIndex].prodStdNo,
                            "status": status
                        });
                    }
                }
                // Create the payload
                var payload = {
                        "updateProdStdHdrStatusData": updateProdStdHdrStatusData,
                        "updateProdStdMaterialStatusData": updateProdStdMaterialStatusData,
                        "updateProdStdVarDtStatusData": updateProdStdVarDtStatusData,
                        "updateProdStdSecResStatusData": updateProdStdSecResStatusData,
                        "updateProdStdBottleneckStatusData": updateProdStdBottleneckStatusData,
                };
                var sUrl = "odata/v4/data-services/upsertProductStdStatusItems";
                $.ajax({
                    url: sUrl,
                    headers: {
                        'x-username': nbId,
                        'x-zone': zone,
                        'x-plants': plantsParam,
                        'x-role': "Approver"
                    },
                    type: "POST",
                    data: JSON.stringify(payload),
                    contentType: "application/json"
                })
                .done(function (response) {
                    BusyIndicator.hide();
                    var message = that.oResourceBundle.getText("PROD_STD_APPR_SUBMIT_SUCCESS");
                    for (var i = 0; i < aSelectedPaths.length; i++) {
                        var sSelectedPath = aSelectedPaths[i];
                        var iSelectedIndex = parseFloat(sSelectedPath.split("/")[2], 10);
                        oModel.setProperty("/value/" + iSelectedIndex + "/status", status);
                    }
                    that.onShowSuccess(message);
                    that.getView().byId("idPopoverSubmit").setEnabled(false);
                    that.getView().byId("idProductTable").removeSelections();
                })
                .fail(function (xhr, status, error) {
                    BusyIndicator.hide();
                    let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                            xhr.responseJSON.error.message :
                                that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                    var message = that.oResourceBundle.getText("PROD_STD_UPDATE_STATUS_FAIL") + " " + errorMessage;
                    that.onShowError(message);
                   that.getView().byId("idPopoverSubmit").setEnabled(false);
                    that.getView().byId("idProductTable").removeSelections();
                });
            },
            onConfiguration: function () {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("ConFigView");
            },
            onStandardCreate: function () {
				this._isConfirming = false;						   
                if (!this._ProdCreate) {
                    this._ProdCreate = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.StandardProdCreate", this);
                    this.getView().addDependent(this._ProdCreate);
                }
                this._ProdCreate.open();
                //role = sap.ui.getCore().getModel("loginUserModel").getData().results[0].AuthType;
                var oWizard = sap.ui.getCore().byId("CreateProductWizard");
                var oFirstStep = oWizard.getSteps()[0];
                oWizard.discardProgress(oFirstStep);
								
                oWizard.goToStep(oFirstStep);
										
                oFirstStep.setValidated(true);
                this._oNavContainer = this.byId("wizardNavContainer");
                this.getCurrentDateFormatted();
                sap.ui.getCore().byId("idProductCreateValidFrom").setValue(defaultDate);
				 sap.ui.getCore().byId("idProductCreateModifiedFrom").setValue(defaultDate);															  
                sap.ui.getCore().byId("idChargeQtyVal").setValue("1");
                sap.ui.getCore().byId("idOpQty").setValue("1");
                if(role === "S"){
                    sap.ui.getCore().byId("idProdCreateControlKey_Vbox").setVisible(false);
                    sap.ui.getCore().byId("idProdCreateDestinationKey").setVisible(false);
                    sap.ui.getCore().byId("idDestinationKey").setVisible(false);
                    sap.ui.getCore().byId("secResBttn").setVisible(true);
                   
                } else{
                    sap.ui.getCore().byId("idProdCreateControlKey_Vbox").setVisible(true);
                    sap.ui.getCore().byId("idProdCreateDestinationKey").setVisible(true);
                    sap.ui.getCore().byId("idDestinationKey").setVisible(true);
                    sap.ui.getCore().byId("secResBttn").setVisible(true);
                    
                }


            },
	        handleValidfromChange: function () {
                var oValidFrom = sap.ui.getCore().byId("idProductCreateValidFrom");
                var oModifiedFrom = sap.ui.getCore().byId("idProductCreateModifiedFrom");
                if (oValidFrom && oModifiedFrom) {
                    var sValidFromDate = oValidFrom.getDateValue();
                    oModifiedFrom.setDateValue(sValidFromDate);
                }
            },
            handleCopyValidfromChange: function () {
                var oCopyValidFrom = sap.ui.getCore().byId("idProdCopyCreateReviewValidFrom");
                var oCopyModifiedFrom = sap.ui.getCore().byId("idProdCopyCreateReviewModifiedFrom");
                if (oCopyValidFrom && oCopyModifiedFrom) {
                    var sValidFromDate = oCopyValidFrom.getDateValue();
                    oCopyModifiedFrom.setDateValue(sValidFromDate);
                }
            },
            onDescChange: function () {
                var recipeDesc;
                if (sap.ui.getCore().byId("idDesc") !== undefined) {
                    recipeDesc = sap.ui.getCore().byId("idDesc").getValue();
                } else {
                    recipeDesc = sap.ui.getCore().byId("idProdCopyCreateReviewDesc").getValue();
                }
                if (recipeDesc.length > 40) {
                    var message = this.oResourceBundle.getText("MASTER_RECP_DESC_ERROR");
                    this.onShowWarning(message);
                }
            },
            onResourceSelection: function () {
                var that = this;
                if (sap.ui.getCore().byId("idProductCreatePlant") !== undefined && sap.ui.getCore().byId("idGetResource") !== undefined) {
                    var plant = sap.ui.getCore().byId("idProductCreatePlant").getSelectedKey();
                    var resource = sap.ui.getCore().byId("idGetResource").getValue();
                    var validDate = sap.ui.getCore().byId("idProductCreateModifiedFrom").getValue();
                    sap.ui.getCore().byId("idGetMachine").setEditable(true);
                    sap.ui.getCore().byId("idGetMachineDesc").setEditable(true);
                    sap.ui.getCore().byId("idcapacityNo").setEditable(true);
                    sap.ui.getCore().byId("idGetMachine").setValue();
                    sap.ui.getCore().byId("idGetMachineDesc").setValue();
                    var url = "/ETY_Machine_DetailsSet";
                    BusyIndicator.show(0);
                    var oFilterPlant = new Filter({
                        filters: [
                            new Filter("Plant", FilterOperator.EQ, plant)
                        ]
                    });
                    var oFilterResource = new Filter({
                        filters: [
                            new Filter("ResourceName", FilterOperator.EQ, resource)
                        ]
                    });
                    var oFilterValidDate = new Filter({
                        filters: [
                            new Filter("ValidDate", FilterOperator.EQ, validDate)
                        ]
                    });
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            filters: [oFilterPlant, oFilterResource, oFilterValidDate],
                            success: function (oData) {
                                // Create and set the JSONModel with the data received
                                var oModelMachine = new sap.ui.model.json.JSONModel();
                                oModelMachine.setData(oData);
                                this.getView().setModel(oModelMachine, "machineModel");
                                BusyIndicator.hide();
                            }.bind(this),
                            error: function (jqXHR) {
                                let errorMessage = jqXHR.responseText ?
                                        JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                        // Handle errors
                                        MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                                        BusyIndicator.hide();
                            }
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
  this.fnCapacityNumber(plant, resource);
                }
            },
            onMachineSelection: function (oEvent) {
                var sId = oEvent.getSource().getId();
                var oMachineComboBox = sap.ui.getCore().byId("idGetMachine");
                var oMachineDescComboBox = sap.ui.getCore().byId("idGetMachineDesc");
                var aMachines = this.getView().getModel("machineModel").getProperty("/results");

                if (sId === "idGetMachine") {
                    var selectedMachineKey = oMachineComboBox.getSelectedKey();
                    var selectedMachineValue = oMachineComboBox.getValue();

                    if (selectedMachineKey || selectedMachineValue) {
                        var matchingMachines = aMachines.filter(machine =>
                            machine.FunctionalLoc === selectedMachineKey || machine.FunctionalLoc === selectedMachineValue
                        );

                        if (matchingMachines.length > 0) {
                            var matchingMachine = matchingMachines[0];

                            if (matchingMachine) {
                                oMachineDescComboBox.setValue(matchingMachine.FunctionalLocDes);
                            }
                        } else {
                            oMachineDescComboBox.setValue("");
                        }
                    }
                } else if (sId === "idGetMachineDesc") {
                    var selectedMachineDescValue = oMachineDescComboBox.getValue();

                    if (selectedMachineDescValue) {
                        var matchingDescriptions = aMachines.filter(machine =>
                            machine.FunctionalLocDes === selectedMachineDescValue
                        );

                        if (matchingDescriptions.length > 0) {
                            var matchingMachine = matchingDescriptions[0];

                            if (matchingMachine) {
                                oMachineComboBox.setSelectedKey(matchingMachine.FunctionalLoc);
                            }
                        } else {
                            oMachineComboBox.setSelectedKey("");
                        }
                    }
														  
                }
            },
            fnCapacityNumber: function (plant,resource){

                var url = "/ETY_CAPACITY_NUMBERSet";
                var oFilterPlant = new Filter({
                    filters: [
                        new Filter("Werks", FilterOperator.EQ, plant)
                        ]
                });
                var oFilterResource = new Filter({
                    filters: [
                        new Filter("Arbpl", FilterOperator.EQ, resource)
                        ]
                });
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        filters: [oFilterPlant, oFilterResource],
                        success: function (oData) {
                            // Create and set the JSONModel with the data received
                            var oModelCapacity = new sap.ui.model.json.JSONModel();
                            oModelCapacity.setData(oData);
                            this.getView().setModel(oModelCapacity, "capacityModel");
                            BusyIndicator.hide();
                        }.bind(this),
                        error: function (jqXHR) {
                            let errorMessage = jqXHR.responseText ?
                                    JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                    // Handle errors
                                    MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                                    BusyIndicator.hide();
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }

            },
            onProdCopyTableResourceSelection: function (oEvent) {
                var that = this;
                var oInput = oEvent.getSource();
                var oModel = this.getView().getModel("globalResponseModel");
                var sPath = oEvent.getSource().getBindingContext("globalResponseModel").getPath();
                var index = sPath.split("/").pop();
                 var plant = sap.ui.getCore().byId("idProdCopyCreateReviewPlant").getSelectedKey();
                var validDate = sap.ui.getCore().byId("idProdCopyCreateReviewModifiedFrom").getValue();
                var resource = oModel.getData().standardCycleData[index].resource;
                var url = "/ETY_CAPACITY_NUMBERSet";
                var oFilterPlant = new Filter({
                    filters: [
                        new Filter("Werks", FilterOperator.EQ, plant)
                        ]
                });
                var oFilterResource = new Filter({
                    filters: [
                        new Filter("Arbpl", FilterOperator.EQ, resource)
                        ]
                });
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        filters: [oFilterPlant, oFilterResource],
                        success: function (oData) {
                            // Create and set the JSONModel with the data received
                            var oModelCapacity = new sap.ui.model.json.JSONModel();
                            oModelCapacity.setData(oData);
                            var data = oModelCapacity.getData();
                            if (data && data.results && data.results.length > 0) {
                                var capacityValue = data.results[0].Aznor;
                                oModel.setProperty(`/standardCycleData/${index}/capacityNo`, capacityValue);
                                oInput.getParent().getCells()[7].setValueState("None");
                            }
                        }.bind(this),
                        error: function (jqXHR) {
                            let errorMessage = jqXHR.responseText ?
                                    JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                    // Handle errors
                                    MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
                 var surl = "/ETY_Machine_DetailsSet";
                var oFilterPlant1 = new Filter({
                    filters: [
                        new Filter("Plant", FilterOperator.EQ, plant)
                    ]
                });
                var oFilterResource1 = new Filter({
                    filters: [
                        new Filter("ResourceName", FilterOperator.EQ, resource)
                    ]
                });
				 var oFilterValidDate = new Filter({
					  filters: [
                        new Filter("ValidDate", FilterOperator.EQ, validDate)
                    ]
                });
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        filters: [oFilterPlant1, oFilterResource1, oFilterValidDate],
                        success: function (oData) {
                            var oModelMachine = new sap.ui.model.json.JSONModel();
                            oModelMachine.setData(oData);
                            this.getView().setModel(oModelMachine,"machineModel");
                            oModelMachine.setProperty(sPath + index+ "/machine","");
                            this.SetMachineDataComboBox(oData,this);

                        }.bind(this),
                        error: function (jqXHR) {
                            let errorMessage = jqXHR.responseText ?
                                    JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                    // Handle errors
                                    MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
            },
            //Started
            onProdUpdateTableResourceSelection: function (oEvent) {
                var that = this;
                var oInput = oEvent.getSource();
                var oModel = this.getView().getModel("globalResponseModel");
                var sPath = oEvent.getSource().getBindingContext("globalResponseModel").getPath();
                var index = sPath.split("/").pop();
                var plant = sap.ui.getCore().byId("idProdUpdatePlant").getSelectedKey();
                var resource = oModel.getData().standardCycleData[index].resource;
                var url = "/ETY_CAPACITY_NUMBERSet";
                var oFilterPlant = new Filter({
                    filters: [
                        new Filter("Werks", FilterOperator.EQ, plant)
                        ]
                });
                var oFilterResource = new Filter({
                    filters: [
                        new Filter("Arbpl", FilterOperator.EQ, resource)
                        ]
                });
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        filters: [oFilterPlant, oFilterResource],
                        success: function (oData) {
                            // Create and set the JSONModel with the data received
                            var oModelCapacity = new sap.ui.model.json.JSONModel();
                            oModelCapacity.setData(oData);
                            var data = oModelCapacity.getData();
                            if (data && data.results && data.results.length > 0) {
                                var capacityValue = data.results[0].Aznor;
                                oModel.setProperty(`/standardCycleData/${index}/capacityNo`, capacityValue);
                                oInput.getParent().getCells()[7].setValueState("None");
                            }
                        }.bind(this),
                        error: function (jqXHR) {
                            let errorMessage = jqXHR.responseText ?
                                    JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                    // Handle errors
                                    MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
                var url = "/ETY_Machine_DetailsSet";
                var oFilterPlant = new Filter({
                    filters: [
                        new Filter("Plant", FilterOperator.EQ, plant)
                        ]
                });
                var oFilterResource = new Filter({
                    filters: [
                        new Filter("ResourceName", FilterOperator.EQ, resource)
                        ]
                });
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        filters: [oFilterPlant, oFilterResource],
                        success: function (oData) {
                            var oModelMachine = new sap.ui.model.json.JSONModel();
                            oModelMachine.setData(oData);
                            this.getView().setModel(oModelMachine,"machineModel");
                            oModelMachine.setProperty(sPath + index+ "/machine","");
                            this.SetMachineDataComboBox(oData,this);

                        }.bind(this),
                        error: function (jqXHR) {
                            let errorMessage = jqXHR.responseText ?
                                    JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                    // Handle errors
                                    MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
            },
            SetMachineDataComboBox: function (oData,that){
                var standardCycleData = that.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
                var machineData = oData.results;
                var ResourceName = machineData[0].ResourceName
                for (var x = 0; x < standardCycleData.length; x++) {
                    if (ResourceName === standardCycleData[x].resource) {
                        var loopindex = x;
                        console.log(ResourceName + "-" + loopindex);
                        standardCycleData[loopindex].machineModel = [];
                        for (var j = 0; j < machineData.length; j++) {
                            var machinename = machineData[j].FunctionalLoc;
                            standardCycleData[loopindex].machineModel.push({
                                FunctionalLoc: machinename
                            });
                        }
                    }
                }
                that.getView().getModel("globalResponseModel").setProperty("/standardCycleData", standardCycleData);
            },
            onProdCopyResourceSelection: function () {
                var that = this;
                if (sap.ui.getCore().byId("idProdCopyCreateReviewPlant") !== undefined && sap.ui.getCore().byId("idProdCopyGetResource") != undefined) {
                     var plant = sap.ui.getCore().byId("idProdCopyCreateReviewPlant").getSelectedKey();
                    var resource = sap.ui.getCore().byId("idProdCopyGetResource").getValue();
					var validDate = sap.ui.getCore().byId("idProdCopyCreateReviewModifiedFrom").getValue();
                    sap.ui.getCore().byId("idProdCopyGetMachine").setEditable(true);
                    sap.ui.getCore().byId("idProdCopyMachineDesc").setEditable(true);
                    sap.ui.getCore().byId("idProdCopycapacityNo").setEditable(true);
                    sap.ui.getCore().byId("idProdCopyGetMachine").setValue();
                    sap.ui.getCore().byId("idProdCopyMachineDesc").setValue();								  
                    var url = "/ETY_Machine_DetailsSet";
                    var oFilterPlant = new Filter({
                        filters: [
                            new Filter("Plant", FilterOperator.EQ, plant)
                            ]
                    });
                    var oFilterResource = new Filter({
                        filters: [
                            new Filter("ResourceName", FilterOperator.EQ, resource)
                        ]
                    });
                    var oFilterValidDate = new Filter({
                        filters: [
                            new Filter("ValidDate", FilterOperator.EQ, validDate)
                        ]
                    });
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                              filters: [oFilterPlant, oFilterResource, oFilterValidDate],
                            success: function (oData) {
                                var oModelMachine = new sap.ui.model.json.JSONModel();
                                oModelMachine.setData(oData);
                                this.getView().setModel(oModelMachine, "machineModel");
                            }.bind(this),
                            error: function (jqXHR) {
                                let errorMessage = jqXHR.responseText ?
                                        JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                        // Handle errors
                                        MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                            }
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                   var surl = "/ETY_CAPACITY_NUMBERSet";
                    var oFilterPlant1 = new Filter({
                        filters: [
                            new Filter("Werks", FilterOperator.EQ, plant)
                        ]
                    });
                    var oFilterResource1 = new Filter({
                        filters: [
                            new Filter("Arbpl", FilterOperator.EQ, resource)
                        ]
                    });
                    if (oODataModel) {
                        oODataModel.read(surl, {
                            headers: mHeaders,
                            filters: [oFilterPlant1, oFilterResource1],
                            success: function (oData) {
                                var oModelCapacity = new sap.ui.model.json.JSONModel();
                                oModelCapacity.setData(oData);
                                this.getView().setModel(oModelCapacity, "capacityModel");
                            }.bind(this),
                            error: function (jqXHR) {
                                let errorMessage = jqXHR.responseText ?
                                        JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                        // Handle errors
                                        MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                            }
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                }
            },
			onMachineCopySelection: function (oEvent) {
                var sId = oEvent.getSource().getId();
								
                var oMachineComboBox = sap.ui.getCore().byId("idProdCopyGetMachine");
                var oMachineDescComboBox = sap.ui.getCore().byId("idProdCopyMachineDesc");
                var aMachines = this.getView().getModel("machineModel").getProperty("/results");

                if (sId === "idProdCopyGetMachine") {
                    var selectedMachineKey = oMachineComboBox.getSelectedKey();
                    var selectedMachineValue = oMachineComboBox.getValue();

                    if (selectedMachineKey || selectedMachineValue) {
                        var matchingMachines = aMachines.filter(machine =>
                            machine.FunctionalLoc === selectedMachineKey || machine.FunctionalLoc === selectedMachineValue
                        );

                        if (matchingMachines.length > 0) {
                            var matchingMachine = matchingMachines[0];

                            if (matchingMachine) {
                                oMachineDescComboBox.setValue(matchingMachine.FunctionalLocDes);
											   
											  
																	 
													   
																					  
															 
																					   
										 
													 
																	   
																																					
														
																																
                            }
						   
                        } else {
                            oMachineDescComboBox.setValue("");
                        }
                    }
                } else if (sId === "idProdCopyMachineDesc") {
                    var selectedMachineDescValue = oMachineDescComboBox.getValue();

                    if (selectedMachineDescValue) {
                        var matchingDescriptions = aMachines.filter(machine =>
                            machine.FunctionalLocDes === selectedMachineDescValue
                        );

                        if (matchingDescriptions.length > 0) {
                            var matchingMachine = matchingDescriptions[0];

                            if (matchingMachine) {
                                oMachineComboBox.setSelectedKey(matchingMachine.FunctionalLoc);
											  
																	 
													   
																					   
															  
																						 
										 
													 
																	   
																																					
														
																																
                            }
						   
                        } else {
                            oMachineComboBox.setSelectedKey("");
                        }
                    }
                }
            },
            onMachineUpdateSelection: function (oEvent) {
                var sId = oEvent.getSource().getId();
								
                var oMachineComboBox = sap.ui.getCore().byId("idProdUpdateGetMachine");
                var oMachineDescComboBox = sap.ui.getCore().byId("idProdUpdateMachineDesc");
                var aMachines = this.getView().getModel("machineModel").getProperty("/results");

                if (sId === "idProdUpdateGetMachine") {
                    var selectedMachineKey = oMachineComboBox.getSelectedKey();
                    var selectedMachineValue = oMachineComboBox.getValue();

                    if (selectedMachineKey || selectedMachineValue) {
                        var matchingMachines = aMachines.filter(machine =>
                            machine.FunctionalLoc === selectedMachineKey || machine.FunctionalLoc === selectedMachineValue
                        );

                        if (matchingMachines.length > 0) {
                            var matchingMachine = matchingMachines[0];

                            if (matchingMachine) {
                                oMachineDescComboBox.setValue(matchingMachine.FunctionalLocDes);
																									
                            }
						   
                        } else {
                            oMachineDescComboBox.setValue("");
                        }
                    }
                } else if (sId === "idProdUpdateMachineDesc") {
                    var selectedMachineDescValue = oMachineDescComboBox.getValue();

                    if (selectedMachineDescValue) {
                        var matchingDescriptions = aMachines.filter(machine =>
                            machine.FunctionalLocDes === selectedMachineDescValue
                        );

                        if (matchingDescriptions.length > 0) {
                            var matchingMachine = matchingDescriptions[0];

                            if (matchingMachine) {
                                oMachineComboBox.setSelectedKey(matchingMachine.FunctionalLoc);																							
                            }
						   
                        } else {
                            oMachineComboBox.setSelectedKey("");
                        }
                    }
                }
            },
            //Started
            onProdUpdateResourceSelection: function () {
                var that = this;
                if (sap.ui.getCore().byId("idProdUpdatePlant") != undefined && sap.ui.getCore().byId("idProdUpdateGetResource") != undefined) {
                    var plant = sap.ui.getCore().byId("idProdUpdatePlant").getSelectedKey();
                    var resource = sap.ui.getCore().byId("idProdUpdateGetResource").getValue();
                    var validDate = sap.ui.getCore().byId("idUpdateModifiedFrom").getValue();
                    sap.ui.getCore().byId("idProdUpdateGetMachine").setEditable(true);
                    sap.ui.getCore().byId("idProdUpdatecapacityNo").setEditable(true);
                    
                    sap.ui.getCore().byId("idProdUpdateMachineDesc").setEditable(true);
                  
                    sap.ui.getCore().byId("idProdUpdateGetMachine").setValue();
                    var url = "/ETY_Machine_DetailsSet";
                    var oFilterPlant = new Filter({
                        filters: [
                            new Filter("Plant", FilterOperator.EQ, plant)
                            ]
                    });
                    var oFilterResource = new Filter({
                        filters: [
                            new Filter("ResourceName", FilterOperator.EQ, resource)
                            ]
                    });
                    var oFilterValidDate = new Filter({
                        filters: [
                            new Filter("ValidDate", FilterOperator.EQ, validDate)
                        ]
                    });
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            filters: [oFilterPlant, oFilterResource, oFilterValidDate],
                            success: function (oData) {
                                var oModelMachine = new sap.ui.model.json.JSONModel();
                                oModelMachine.setData(oData);
                                this.getView().setModel(oModelMachine, "machineModel");
                            }.bind(this),
                            error: function (jqXHR) {
                                let errorMessage = jqXHR.responseText ?
                                        JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                        // Handle errors
                                        MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                            }
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
						 
                    }
                    var url = "/ETY_CAPACITY_NUMBERSet";
                    var oFilterPlant = new Filter({
                        filters: [
                            new Filter("Werks", FilterOperator.EQ, plant)
                            ]
                    });
                    var oFilterResource = new Filter({
                        filters: [
                            new Filter("Arbpl", FilterOperator.EQ, resource)
                            ]
                    });
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            filters: [oFilterPlant, oFilterResource],
                            success: function (oData) {
                                var oModelCapacity = new sap.ui.model.json.JSONModel();
                                oModelCapacity.setData(oData);
                                this.getView().setModel(oModelCapacity, "capacityModel");
                            }.bind(this),
                            error: function (jqXHR) {
                                let errorMessage = jqXHR.responseText ?
                                        JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                        // Handle errors
                                        MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                            }
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
						 
                    }
                }
            },
            //Ended
            onCapacityValueChange: function (oEvent) {
                var oInput = oEvent.getSource();
                var sValue = oInput.getValue();
                var maxCapacityValue = this.getView().getModel("capacityModel").getProperty("/results/0/Aznor");
                if (parseFloat(sValue) > parseFloat(maxCapacityValue)) {
                    oInput.setValueState(sap.ui.core.ValueState.Error);
                    oInput.setValueStateText(this.oResourceBundle.getText("CAPACITY_VALUE_ERROR") + " " + maxCapacityValue);
                } else {
                    oInput.setValueState(sap.ui.core.ValueState.None);
                    oInput.setValueStateText("");
                }
            },
            onCopyCapacityValueChange: function (oEvent) {
                var that = this;
                var oModel = this.getView().getModel("globalResponseModel");
                var sPath = oEvent.getSource().getBindingContext("globalResponseModel").getPath();
                var index = sPath.split("/").pop();
                var resource = oModel.getData().standardCycleData[index].resource;
                var sValue = oEvent.getParameter("value");
                var oInput = oEvent.getSource();
                if (sap.ui.getCore().byId("idProdCopyCreateReviewPlant") !== undefined) {
                    var plant = sap.ui.getCore().byId("idProdCopyCreateReviewPlant").getSelectedKey();
                }
                var url = "/ETY_CAPACITY_NUMBERSet";
                var oFilterPlant = new Filter({
                    filters: [
                        new Filter("Werks", FilterOperator.EQ, plant)
                        ]
                });
                var oFilterResource = new Filter({
                    filters: [
                        new Filter("Arbpl", FilterOperator.EQ, resource)
                        ]
                });
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        filters: [oFilterPlant, oFilterResource],
                        success: function (oData) {
                            // Create and set the JSONModel with the data received
                            var oModelCapacity = new sap.ui.model.json.JSONModel();
                            oModelCapacity.setData(oData);
                            var data = oModelCapacity.getData();
                            if (data && data.results && data.results.length > 0) {
                                var maxCapacityValue = data.results[0].Aznor;
                            }
                            if (parseFloat(sValue) > parseFloat(maxCapacityValue)) {
                                oInput.setValueState(sap.ui.core.ValueState.Error);
                                oInput.setValueStateText(this.oResourceBundle.getText("CAPACITY_VALUE_ERROR") + " " + maxCapacityValue);
                            } else {
                                oInput.setValueState(sap.ui.core.ValueState.None);
                                oInput.setValueStateText("");
                            }
                        }.bind(this),
                        error: function (jqXHR) {
                            let errorMessage = jqXHR.responseText ?
                                    JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                    // Handle errors
                                    MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
            },
            onUpdateCapacityValueChange: function (oEvent) {
                var that = this;
                var oModel = this.getView().getModel("globalResponseModel");
                var sPath = oEvent.getSource().getBindingContext("globalResponseModel").getPath();
                var index = sPath.split("/").pop();
                var resource = oModel.getData().standardCycleData[index].resource;
                var sValue = oEvent.getParameter("value");
                var oInput = oEvent.getSource();
                var plant = sap.ui.getCore().byId("idProdUpdatePlant").getSelectedKey();
                var url = "/ETY_CAPACITY_NUMBERSet";
                var oFilterPlant = new Filter({
                    filters: [
                        new Filter("Werks", FilterOperator.EQ, plant)
                        ]
                });
                var oFilterResource = new Filter({
                    filters: [
                        new Filter("Arbpl", FilterOperator.EQ, resource)
                        ]
                });
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        filters: [oFilterPlant, oFilterResource],
                        success: function (oData) {
                            // Create and set the JSONModel with the data received
                            var oModelCapacity = new sap.ui.model.json.JSONModel();
                            oModelCapacity.setData(oData);
                            var data = oModelCapacity.getData();
                            if (data && data.results && data.results.length > 0) {
                                var maxCapacityValue = data.results[0].Aznor;
                            }
                            if (parseFloat(sValue) > parseFloat(maxCapacityValue)) {
                                oInput.setValueState(sap.ui.core.ValueState.Error);
                                oInput.setValueStateText(this.oResourceBundle.getText("CAPACITY_VALUE_ERROR") + " " + maxCapacityValue);
                            } else {
                                oInput.setValueState(sap.ui.core.ValueState.None);
                                oInput.setValueStateText("");
                            }
                        }.bind(this),
                        error: function (jqXHR) {
                            let errorMessage = jqXHR.responseText ?
                                    JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                    // Handle errors
                                    MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
            },
            onFilterPlantSelection: function () {
                var that = this;
                var plant = this.getView().byId("mcb_status_PPD_Z1").getSelectedKey();
                if (plant === ""){
                    this.getView().byId("mcb_ordTyp_PPD_Z1").setValue();
                    this.getView().byId("idprodCostCenterFilter").setValue();
                } else{
                    this.getView().byId("mcb_ordTyp_PPD_Z1").setEnabled(true);
                    var url = "/ETY_RESOURCE_SHSet";
                    BusyIndicator.show(0);
                    var oFilterPlant = new Filter({
                        filters: [
                            new Filter("Werks", FilterOperator.EQ, plant)
                            ]
                    });
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            filters: [oFilterPlant],
                            success: function (oData) {
                                // Create and set the JSONModel with the data received
                                var oModelResource = new sap.ui.model.json.JSONModel();
                                oModelResource.setData(oData);
                                this.getView().setModel(oModelResource, "resourceModel");
                                BusyIndicator.hide();
                            }.bind(this),
                            error: function (jqXHR) {
                                let errorMessage = jqXHR.responseText ?
                                        JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                        // Handle errors
                                        MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                                        BusyIndicator.hide();
                            }
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                }
            },
            onPlantSelectionCreate: function () {

                sap.ui.getCore().byId("idGetResource").setEditable(false);
                sap.ui.getCore().byId("idGetMachine").setEditable(false);
                sap.ui.getCore().byId("idcapacityNo").setEditable(false);
                sap.ui.getCore().byId("idGetResource").setValue("");
                sap.ui.getCore().byId("idGetMachine").setValue("");
                sap.ui.getCore().byId("idcapacityNo").setValue("");
				sap.ui.getCore().byId("idProdLossCat").setEditable(true);
                sap.ui.getCore().byId("idProdLossCat").setValue("");
                sap.ui.getCore().byId("idProdSubCat").setEditable(false);
                sap.ui.getCore().byId("idProdSubCat").setValue("");											   
                 var plant = sap.ui.getCore().byId("idProductCreatePlant").getSelectedKey();
																				
                if (plant == null || plant === "") {
                    sap.ui.getCore().byId("idGetResource").setEditable(false);
																			  
                }
                else {
                    sap.ui.getCore().byId("idGetResource").setEditable(true);
																			 
                }
                //this.onPlantSelection(plant);
                this.getResourceModel(plant);
                //this.getMaterialModel(plant);
                this.getDestinationModel(plant);
                this.fnProdCreateLossCat(plant);
            },
            onPlantSelectionCopy: function () {
                sap.ui.getCore().byId("idProdCopyGetResource").setEditable(false);
                sap.ui.getCore().byId("idProdCopyGetMachine").setEditable(false);
                sap.ui.getCore().byId("idProdCopycapacityNo").setEditable(false);
                sap.ui.getCore().byId("idProdCopyGetResource").setValue("");
                sap.ui.getCore().byId("idProdCopycapacityNo").setValue("");
                sap.ui.getCore().byId("idProdCopyGetMachine").setValue("");
				sap.ui.getCore().byId("idProdcopyLossCat").setValue("");
                sap.ui.getCore().byId("idProdcopySubCat").setValue("");
                sap.ui.getCore().byId("idProdcopySubCat").setEditable(false);														 
                  var plant = sap.ui.getCore().byId("idProdCopyCreateReviewPlant").getSelectedKey();
                if (plant == null || plant ==="") {
                    sap.ui.getCore().byId("idProdCopyGetResource").setEditable(false);
					sap.ui.getCore().byId("idProdcopySubCat").setEditable(false);
                }
                else {
                    sap.ui.getCore().byId("idProdCopyGetResource").setEditable(true);
                }
                //this.onPlantSelection(plant);
                this.getResourceModel(plant);
                this.getDestinationModel(plant);
												
            },
            getResourceModel: function (plant) {
                var that = this;
                var url = "/ETY_RESOURCE_SHSet";
                var oFilterPlant = new Filter({
                    filters: [
                        new Filter("Werks", FilterOperator.EQ, plant)
                        ]
                });
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        filters: [oFilterPlant],
                        success: function (oData) {
                            // Create and set the JSONModel with the data received
                            var oModelResource = new sap.ui.model.json.JSONModel();
                            oModelResource.setData(oData);
                            this.getView().setModel(oModelResource, "resourceModel");
                        }.bind(this),
                        error: function (jqXHR) {
                            let errorMessage = jqXHR.responseText ?
                                    JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                    // Handle errors
                                    MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
            },
            getDestinationModel: function(plant){
                var url = "/ETY_CONTROL_DESTSet";
                var oFilterPlant = new Filter({
                    filters: [
                        new Filter("WERKS", FilterOperator.EQ, plant)
                        ]
                });
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        filters: [oFilterPlant],
                        success: function (oData) {
                            // Create and set the JSONModel with the data received
                            var oModelDestination = new sap.ui.model.json.JSONModel();
                            oModelDestination.setData(oData);
                            this.getView().setModel(oModelDestination, "destinationModel");
                        }.bind(this),
                        error: function (jqXHR) {
                            let errorMessage = jqXHR.responseText ?
                                    JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                    // Handle errors
                                    MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }

            },
            onResourceSelectionCostCenter: function () {
                var that = this;
                 var plant = this.getView().byId("mcb_status_PPD_Z1").getSelectedKey();
                var resource = this.getView().byId("mcb_ordTyp_PPD_Z1").getValue();
                if (resource === ""){
                    this.getView().byId("idprodCostCenterFilter").setValue();
                } else{
                    var url = `/ETY_CostCentre_ValueHelpSet(Werks='${plant}',Arbpl='${resource}')`;
                    BusyIndicator.show(0);
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            success: function (oData) {
                                // Create and set the JSONModel with the data received
                                var oModelCostcenter = new sap.ui.model.json.JSONModel();
                                oModelCostcenter.setData(oData);
                                this.getView().setModel(oModelCostcenter, "costcenterFilterModel");
                                BusyIndicator.hide();
                            }.bind(this),
                            error: function (jqXHR) {
                                let errorMessage = jqXHR.responseText ?
                                        JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                        // Handle errors
                                        MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                                        BusyIndicator.hide();
                            }
                        });

                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                }
            },
            _fnDateFormat: function (val) {

                if (val != null) {
                    var iDay = ('0' + val.getDate()).slice(-2);
                    var iMonth = ('0' + (val.getMonth() + 1)).slice(-2);
                    var iYear = (val + "").substring(11, 15);
                }
                return iYear + "-" + iMonth + "-" + iDay;
            },
            handleProdChangeValidFrom: function (oEvent) {
                var sFrom = this._fnDateFormat(oEvent.getParameter("from")),
                    sTo = this._fnDateFormat(oEvent.getParameter("to"));
                this.getView().getModel("productModel").setProperty("/validFrom", { from: sFrom, to: sTo });
            },
            handleProdChangeModifiedFrom: function (oEvent) {
                var sFrom = this._fnDateFormat(oEvent.getParameter("from")),
                    sTo = this._fnDateFormat(oEvent.getParameter("to"));
                this.getView().getModel("productModel").setProperty("/validFrom", { from: sFrom, to: sTo });
            },
            handleProdChangeValidTo: function (oEvent) {
                var sFrom = this._fnDateFormat(oEvent.getParameter("from")),
                sTo = this._fnDateFormat(oEvent.getParameter("to"));
                this.getView().getModel("productModel").setProperty("/validTo", { from: sFrom, to: sTo });
            },
            handleProdChangeCreatedOn: function (oEvent) {
                var sFrom = this._fnDateFormat(oEvent.getParameter("from")),
                sTo = this._fnDateFormat(oEvent.getParameter("to"));
                this.getView().getModel("productModel").setProperty("/createdOn", { from: sFrom, to: sTo });
            },
            handleProdChangeLastChangedOn: function (oEvent) {
                var sFrom = this._fnDateFormat(oEvent.getParameter("from")),
                sTo = this._fnDateFormat(oEvent.getParameter("to"));
                this.getView().getModel("productModel").setProperty("/lastChangedOn", { from: sFrom, to: sTo });
            },

            onEdit: function () {
                this._isConfirming = false;
                //this.handleCloseProdEditButton();
                //role = sap.ui.getCore().getModel("loginUserModel").getData().results[0].AuthType;
                var that = this;
                if (!this._ProductUpdate) {
                    this._ProductUpdate = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.StandardProdUpdate", this);
                    this.getView().addDependent(this._ProductUpdate);
                }
                ////////// navigate to content screen in the update dialog/////
                sap.ui.getCore().byId("wizardProdUpdateNavContainer").to(sap.ui.getCore().byId("wizardProdUpdateContentPage"));
                var oWizard = sap.ui.getCore().byId("updateProductWizard");
                var oFirstStep = oWizard.getSteps()[0];
                oWizard.discardProgress(oFirstStep);
                oFirstStep.setValidated(true);
                var oTable = this.getView().byId("idProductTable");
                var aSelectedPaths = oTable._aSelectedPaths;
                var sSelectedPath = aSelectedPaths[0];
                var oModel = this.getView().getModel("productModel");
                var prdStdNo = oModel.getData().value[selectedTableIndex].prodStdNo;
                prdStandardNo = prdStdNo;
                ID = oModel.getData().value[selectedTableIndex].ID;
                var plant = oModel.getData().value[selectedTableIndex].plant;
                variant = oModel.getData().value[selectedTableIndex].variant;
                this.getResourceModel(plant);
                this.getDestinationModel(plant);
                this.fnProdCreateLossCat(plant);
                // Construct the URL with dynamic values using template literals
                var url = `odata/v4/data-services/ProductRelStandardHeadersDB(ID=${ID},prodStdNo='${prdStdNo}')?$expand=ProdStdToProdBttlnckDataNav($filter=modificationType ne 'D'),ProdStdToProdSecResDataNav,ProdStdToProdVarDtDataNav,ProdStdToProdMatrAllDataNav`;
                BusyIndicator.show(0); //added
                $.ajax({
                    url: url,
                    method: 'GET',
                    headers: {
                        'x-username': nbId,
                        'x-zone': zone,
                        'x-plants': plantsParam,
                        'x-role': "Creator/Editor"
                    },
                    success: function (response) {
                        BusyIndicator.hide();
                        var message = that.oResourceBundle.getText("PROD_STD_DB_SUCCESS");
                        MessageToast.show(message);
                       
                        that.onEditSuccessCall(response,that);
                        that.fnProdUpdateVariableDTLossCat(plant);
                    },
                    error: function (xhr, _status, _error) {
                        BusyIndicator.hide();
                        let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                xhr.responseJSON.error.message :
                                    that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                        var message = that.oResourceBundle.getText("PROD_STD_DB_FAIL") + " " + errorMessage;
                        MessageToast.show(message);
                    }
                })

            },  
            fnProdUpdateVariableDTLossCat: function (plant) {
                var oModelProdLossCat = new sap.ui.model.json.JSONModel();
                var sUrl = "odata/v4/data-services/LineRelatedLossCatDB?$apply=groupby((lossCat,plant))&$filter=plant eq '" + plant + "'&$select=lossCat";
                jQuery.ajax({
                    url: sUrl,
                    method: "GET",
                    success: function (data) {
                        oModelProdLossCat.setData(data);
                        oModelProdLossCat.setSizeLimit(100);
                        this.getView().setModel(oModelProdLossCat, "ProdLossCatModel");
 
                        // Loading Subcategory for Each loss category
                        for (var i = 0; i < data.value.length; i++)
                            this.fnLoadUpdateSubCatforLossCat(this, plant, data.value[i].lossCat, false);
 
                    }.bind(this),
                    error: function (oError) {
                        console.log("Error loading LossCat data: ", oError);
                    }
                });
 
            }, 
            fnLoadUpdateSubCatforLossCat: function (that, plant, lossCat, oSelected, oRowindex) { // Load sub category for loss category
                var oModelProdsubCat = new sap.ui.model.json.JSONModel();
                var sUrl = "odata/v4/data-services/LineRelatedLossCatDB?$filter=plant eq '" + plant + "' and lossCat eq '" + lossCat + "'&$select=subCat";
                jQuery.ajax({
                    url: sUrl,
                    method: "GET",
                    success: function (data) {
                        oModelProdsubCat.setData(data);
                        oModelProdsubCat.setSizeLimit(100);
 
                        var aVariableDtData = that.getView().getModel("globalResponseModel").getProperty("/variableDtData");
                        for (var x = 0; x < aVariableDtData.length; x++) {
                            if (aVariableDtData[x].lossCat === lossCat) {
                                aVariableDtData[x].subCatList = data.value;
                                if (oSelected && oRowindex == x)
                                    aVariableDtData[x].subCat = "";
                            }
                        }
                        that.getView().getModel("globalResponseModel").setProperty("/variableDtData", aVariableDtData);
 
                    }.bind(this),
                    error: function (oError) {
                        console.log("Error loading LossCat data: ", oError);
                    }
                });
            },
            fnProdUpdateOnChangeLossCat: function (oEvent) {
                var oSelectedLossCat = oEvent.getSource().getSelectedKey();
                var oPlant = sap.ui.getCore().byId("idProdUpdatePlant").getSelectedKey();
                if (oPlant) {
                    var oPath = oEvent.getSource().getParent().oBindingContexts.globalResponseModel.sPath;
                    var aPathParts = oPath.split('/');
                    var oRowindex = aPathParts[aPathParts.length - 1];
 
                    this.fnLoadUpdateSubCatforLossCat(this, oPlant, oSelectedLossCat, true, oRowindex);
                }
            },
            fnProdCreateLossCat: function (plant) {
                var oModelProdLossCat = new sap.ui.model.json.JSONModel();
                var sUrl = "odata/v4/data-services/LineRelatedLossCatDB?$apply=groupby((lossCat,plant))&$filter=plant eq '" + plant + "'&$select=lossCat";
                jQuery.ajax({
                    url: sUrl,
                    method: "GET",
                    success: function (data) {
                        oModelProdLossCat.setData(data);
                        this.getView().setModel(oModelProdLossCat, "ProdLossCatModel");
                    }.bind(this),
                    error: function (oError) {
                        console.log("Error loading LossCat data: ", oError);
                    }
                });
            },
            fnProdCreateSubCat: function () {
                if (sap.ui.getCore().byId("idProductCreatePlant") !== undefined) {
                    var sPlant = sap.ui.getCore().byId("idProductCreatePlant").getSelectedKey();
                    var sLossCat = sap.ui.getCore().byId("idProdLossCat").getValue();
                    if (sLossCat === "") {
                        sap.ui.getCore().byId("idProdSubCat").setValue("");
                        sap.ui.getCore().byId("idProdSubCat").setEditable(false);
                    } else {
                        sap.ui.getCore().byId("idProdSubCat").setValue("");
                        sap.ui.getCore().byId("idProdSubCat").setEditable(true);
                    }
                    var oModelProdSubCat = new sap.ui.model.json.JSONModel();
                    var sUrl = "odata/v4/data-services/LineRelatedLossCatDB?$filter=plant eq '" + sPlant + "' and lossCat eq '" + sLossCat + "'&$select=subCat";
                    jQuery.ajax({
                        url: sUrl,
                        method: "GET",
                        success: function (data) {
                            oModelProdSubCat.setData(data);
                            oModelProdSubCat.setSizeLimit(100);
                            this.getView().setModel(oModelProdSubCat, "ProdSubCatModel");
                        }.bind(this),
                        error: function (oError) {
                            console.log("Error loading SubCat data: ", oError);
                        }
                    });
                }
            },
            fnProdUpdateSubCat: function () {
                if (sap.ui.getCore().byId("idProdUpdatePlant") !== undefined) {
                    var sPlant = sap.ui.getCore().byId("idProdUpdatePlant").getSelectedKey();
                    var sLossCat = sap.ui.getCore().byId("idProdUpdateLossCat").getValue();
                    if (sLossCat === "") {
                        sap.ui.getCore().byId("idProdUpdateSubCat").setValue("");
                        sap.ui.getCore().byId("idProdUpdateSubCat").setEditable(false);
                    } else {
                        sap.ui.getCore().byId("idProdUpdateSubCat").setValue("");
                        sap.ui.getCore().byId("idProdUpdateSubCat").setEditable(true);
                    }
                    var oModelProdSubCat = new sap.ui.model.json.JSONModel();
                    var sUrl = "odata/v4/data-services/LineRelatedLossCatDB?$filter=plant eq '" + sPlant + "' and lossCat eq '" + sLossCat + "'&$select=subCat";
                    jQuery.ajax({
                        url: sUrl,
                        method: "GET",
                        success: function (data) {
                            oModelProdSubCat.setData(data);
                            oModelProdSubCat.setSizeLimit(100);
                            this.getView().setModel(oModelProdSubCat, "ProdSubCatModel");
                        }.bind(this),
                        error: function (oError) {
                            console.log("Error loading SubCat data: ", oError);
                        }
                    });
                }
            },        
            onEditSuccessCall: function(response,that){
                var prodBttlnckData = response.ProdStdToProdBttlnckDataNav;
                var prodSecResData = response.ProdStdToProdSecResDataNav;
                var prodVarDtData = response.ProdStdToProdVarDtDataNav;
                var prodMatrData = response.ProdStdToProdMatrAllDataNav;
                that.oglobalResponseModel.setData({
                    standardCycleData: prodBttlnckData,
                    variableDtData: prodVarDtData,
                    materialData: prodMatrData,
                    SecondaryResData: prodSecResData
                });
                for (var i = 0; i < prodBttlnckData.length; i++) {
                    prodBttlnckControlKeyData.push({
                        "steus": prodBttlnckData[i].controlKey
                    })
                }
                
                that._ProductUpdate.open();
                
                ecn = response.ecm;
                var plant = response.plant;
                matUom = response.nsUom;
                semicreatedFlagEnbaled = response.createdBySemiCreator;
                currentBottleneckRes = response.bottleneckResource;
                currentCostCenter = response.costCenter;
                sap.ui.getCore().byId("idProdUpdatePlant").setSelectedKey(plant);
                var desc = response.masterRecipeDesc;
                sap.ui.getCore().byId("idProdUpdateDesc").setValue(desc);
                sap.ui.getCore().byId("idProdUpdateValidFrom").setValue(that.fnFormattedDate1(response.validFrom));
				 sap.ui.getCore().byId("idUpdateModifiedFrom").setValue(that.fnFormattedDate1(response.modifiedFrom));																									 
                sap.ui.getCore().byId("idProdUpdateValidTo").setValue(that.fnFormattedDate1(response.validTo));
                var mrNo = response.mrGroup, mrCounter = response.mrCounter;
                sap.ui.getCore().byId("idProdUpdateMrNo").setValue(mrNo);
                sap.ui.getCore().byId("idProdUpdateMrCounter").setValue(mrCounter === null ? '' : mrCounter);
                var chargeQty = response.chargeQty;
                sap.ui.getCore().byId("idProdUpdateChrgQty").setValue(chargeQty);
                var opQty = response.operationQty;
                sap.ui.getCore().byId("idProdUpdateOperationQty").setValue(opQty);
                var lotSize = response.procOrdrSizeOrCostingLotSize;
                sap.ui.getCore().byId("idProdUpdateLotSize").setValue(lotSize);
                var aCurrentData = that.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
                var aData = that.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
                that.getView().getModel("intStandardCycleModel").setProperty("/standardCycleDataInt", aData);
                var aCurrentDataOld = that.getView().getModel("intStandardCycleModel").getProperty("/standardCycleDataInt");
                if(role === "S"){
                    
                    sap.ui.getCore().byId("idProdUpdateControlKey_Vbox").setVisible(false);
                    sap.ui.getCore().byId("idProdUpdateDestinationKey_VBox").setVisible(false);
                    sap.ui.getCore().byId("secProdUpdateResBttn").setVisible(true);
                       
                    for (var i = 0; i < aCurrentData.length; i++) {
                        that.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/editable", false);
                        that.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/enabled", false);
                    }
                } else{

                    sap.ui.getCore().byId("idProdUpdateControlKey_Vbox").setVisible(true);
                    sap.ui.getCore().byId("idProdUpdateDestinationKey_VBox").setVisible(true);
                    sap.ui.getCore().byId("secProdUpdateResBttn").setVisible(true);
                
                    for (var i = 0; i < aCurrentData.length; i++) {
                        that.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/editable", true);
                        that.getView().getModel("globalResponseModel").setProperty("/standardCycleData/" + i + "/enabled", true);
                    }
                }
                
                var aCurrentDataOld1 = aCurrentDataOld.map(item => ({
                    ...item,
                    controlKey: item.controlKey === 'YBN1' ? "PI01" : item.controlKey
                }));
                that.getView().getModel("intStandardCycleModel").setProperty("/standardCycleDataInt", aCurrentDataOld1);
                for(var k = 0; k<aCurrentData.length; k++){
                    var resource = aCurrentData[k].resource;
																							 
                    var surl = "/ETY_Machine_DetailsSet";
                    var oFilterPlantNew = new Filter({
                        filters: [
                            new Filter("Plant", FilterOperator.EQ, plant)
                            ]
                    }); 
                    var oFilterResource = new Filter({
                        filters: [
                            new Filter("ResourceName", FilterOperator.EQ, resource)
						 
					   
													   
								  
																				 
                            ]
                    });
                    if (oODataModel) {
                        oODataModel.read(surl, {
                            headers: mHeaders,
                            filters: [oFilterPlantNew, oFilterResource],
                            success: function (oData) {
                                // Create and set the JSONModel with the data received
                                var oModelMachine = new sap.ui.model.json.JSONModel();
                                oModelMachine.setData(oData);
                                that.getView().setModel(oModelMachine, "machineModel");
                                that.SetMachineDataComboBox(oData,that);
                            }.bind(this),
                            error: function (jqXHR) {
                                let errorMessage = jqXHR.responseText ?
                                        JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                        // Handle errors
                                        MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                            }
                        });
                    }
                    else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                }
            },
																																		 
																		 
																																						   
							 
							  
								  
											  
													   
														   

																															
																		  
																		 
																		   
																
																   
							 
						 
																													   

								 
											  
																			
					 
				   
			  
															  
																		  
																																						   
							 
							  
								  
											  
														
															
																					   

																	 
																   
																										  

								 
											  
																			
					 
				   

			  

															
																		   
																				   
							 
																										  
													  
																	  

																									   
				 
			  
            onView: function (evt) {
                var oModel = this.getView().getModel("productModel");
                if (selectedTableIndex === undefined) {
                    selectedTableIndex = this.getView().byId("idProductTable").getItems().indexOf(evt.getSource().getParent())
                }
                var prdStdNo = oModel.getData().value[selectedTableIndex].prodStdNo;
                ID = oModel.getData().value[selectedTableIndex].ID;
                selectedPlant = oModel.getData().value[selectedTableIndex].plant;
                selectedVariant =  oModel.getData().value[selectedTableIndex].variant;
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
													
											 
						
                globalRoleVal = userRole;
				 
                var selectedZone = zone;
                var userId = nbId;
                ecn = oModel.getData().value[selectedTableIndex].ecm;
                if (userRole === "View") {
                    oRouter.navTo("onProductViewStandard", {
                        prdStdNo: prdStdNo,
                        ID: ID,
                        selectedPlant: selectedPlant,
                        globalRoleVal: globalRoleVal,
                        selectedZone: selectedZone,
                        userId: userId,
                        selectedVariant: selectedVariant
                    });
                } else {
                    oRouter.navTo("onProductViewStandard", {
                        prdStdNo: prdStdNo,
                        ID: ID,
                        selectedPlant: selectedPlant,
                        globalRoleVal: "Editor",
                        selectedZone: selectedZone,
                        userId: userId,
                        selectedVariant: selectedVariant
                    });
                }
            },
            backToWizardContent: function () {
                if (sap.ui.getCore().byId("wizardNavContainer") !== undefined) {
                    sap.ui.getCore().byId("wizardNavContainer").backToPage(sap.ui.getCore().byId("wizardContentPage"));
                }
                if (sap.ui.getCore().byId("wizardProdUpdateNavContainer") !== undefined) {
                    sap.ui.getCore().byId("wizardProdUpdateNavContainer").backToPage(sap.ui.getCore().byId("wizardProdUpdateContentPage"));
                }
                if (sap.ui.getCore().byId("wizardNavContainerProdApprover") !== undefined) {
                    this._oPopover25.close();
                }
                if (sap.ui.getCore().byId("wizardNavContainerProdExecutor") !== undefined) {
                    this._oPopover26.close();
                }

            },
            editStepOneProdCreate: function () {
                sap.ui.getCore().byId("wizardNavContainer").backToPage(sap.ui.getCore().byId("wizardContentPage"));
                sap.ui.getCore().byId("CreateProductWizard").goToStep(sap.ui.getCore().byId("ProductTypeStep"));
            },
            editStepTwoProdCreate: function () {
                sap.ui.getCore().byId("wizardNavContainer").backToPage(sap.ui.getCore().byId("wizardContentPage"));
                sap.ui.getCore().byId("CreateProductWizard").goToStep(sap.ui.getCore().byId("ProductInfoStep"));
                var oBottleneckTable = sap.ui.getCore().byId("idBottleneckDB2");
                oBottleneckTable.setModel(oResponseModel, "standardCycleModel");
                var oMaterialTable = sap.ui.getCore().byId("idMaterialDB1");
                oMaterialTable.setModel(oResponseModel, "materialDBCreateModel");
                var oVariableDtTable = sap.ui.getCore().byId("idVariableDtDB1");
                oVariableDtTable.setModel(oResponseModel, "variableDtDBModel");
                var oSecResTable = sap.ui.getCore().byId("idSecondaryResourceDB2");
                oSecResTable.setModel("secondaryresourceDBModel");
            },
            editStepThreeProdCreate: function () {
                sap.ui.getCore().byId("wizardNavContainer").backToPage(sap.ui.getCore().byId("wizardContentPage"));
                sap.ui.getCore().byId("CreateProductWizard").goToStep(sap.ui.getCore().byId("PricingStep"));
            },
            editStepFourProdCreate: function () {
                sap.ui.getCore().byId("wizardNavContainer").backToPage(sap.ui.getCore().byId("wizardContentPage"));
                sap.ui.getCore().byId("CreateProductWizard").goToStep(sap.ui.getCore().byId("variableDt"));
            },
            //////////////////////////////////////////Product Copy Create//////////////////////////////////////////////
            editStepOneProdCopyCreate: function () {
                sap.ui.getCore().byId("wizardCopyNavContainer").to(sap.ui.getCore().byId("copyWizardContentPage"));
                sap.ui.getCore().byId("copyCreateProductWizard").goToStep(sap.ui.getCore().byId("copyProductTypeStep"));
                this.getProdHeaderData();
            },
            editStepTwoProdCopyCreate: function () {
                sap.ui.getCore().byId("wizardCopyNavContainer").to(sap.ui.getCore().byId("copyWizardContentPage"));
                sap.ui.getCore().byId("copyCreateProductWizard").goToStep(sap.ui.getCore().byId("copyProductInfoStep"));
                this.getProdHeaderData();
            },
            editStepThreeProdCopyCreate: function () {
                sap.ui.getCore().byId("wizardCopyNavContainer").to(sap.ui.getCore().byId("copyWizardContentPage"));
                sap.ui.getCore().byId("copyCreateProductWizard").goToStep(sap.ui.getCore().byId("copyPricingStep"));
                this.getProdHeaderData();
            },
            editStepFourProdCopyCreate: function () {
                sap.ui.getCore().byId("wizardCopyNavContainer").to(sap.ui.getCore().byId("copyWizardContentPage"));
                sap.ui.getCore().byId("copyCreateProductWizard").goToStep(sap.ui.getCore().byId("copyVariableDt"));
                this.getProdHeaderData();
            },
            getProdHeaderData: function () {
                //role = sap.ui.getCore().getModel("loginUserModel").getData().results[0].AuthType;
                var that = this;
                

                var plant = sap.ui.getCore().byId("idProdCreateCopyPlant").getText();
                sap.ui.getCore().byId("idProdCopyCreateReviewPlant").setSelectedKey(plant);
                var desc = sap.ui.getCore().byId("idProdCreateCopyDescription").getText();
                sap.ui.getCore().byId("idProdCopyCreateReviewDesc").setValue(desc);
                var validFromDate = sap.ui.getCore().byId("idProdCreateCopyValidFrom").getText();
                var validToDate = sap.ui.getCore().byId("idProdCreateCopyValidTo").getText();
				 var modifiedFromDate = sap.ui.getCore().byId("idProdCreateCopyModifiedFrom").getText();
                sap.ui.getCore().byId("idProdCopyCreateReviewValidTo").setValue(this.fnDateFormatted(validToDate));
                sap.ui.getCore().byId("idProdCopyCreateReviewValidFrom").setValue(this.fnDateFormatted(validFromDate));
                sap.ui.getCore().byId("idProdCopyCreateReviewModifiedFrom").setValue(this.fnDateFormatted(modifiedFromDate));																									 
                var aCurrentData = this.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
                this.getView().getModel("intStandardCycleModel").setProperty("/standardCycleDataInt", aCurrentData);
                var aCurrentDataOld = this.getView().getModel("intStandardCycleModel").getProperty("/standardCycleDataInt");
                var aCurrentDataOld1 = aCurrentDataOld.map(item => ({
                    ...item,
                    controlKey: item.controlKey === 'YBN1' ? "PI01" : item.controlKey
                }));
                this.getView().getModel("intStandardCycleModel").setProperty("/standardCycleDataInt", aCurrentDataOld1);
                var mrNo = sap.ui.getCore().byId("idProdCreateCopyMrNo").getText();
                sap.ui.getCore().byId("idProdCopyCreateReviewMrNo").setValue(mrNo);
                var mrCounter = sap.ui.getCore().byId("idProdCreateCopyMrCounter").getText();
                sap.ui.getCore().byId("idProdCopyCreateReviewMrCounter").setValue(mrCounter);
                var lotSize = sap.ui.getCore().byId("idProdCreateCopyLotSize").getText();
                sap.ui.getCore().byId("idProdCopyCreateReviewLotSize").setValue(lotSize);
                var url = "/ETY_RESOURCE_SHSet";
                BusyIndicator.show(0);
                var oFilterPlant = new Filter({
                    filters: [
                        new Filter("Werks", FilterOperator.EQ, plant)
                        ]
                });
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        filters: [oFilterPlant],
                        success: function (oData) {
                            // Create and set the JSONModel with the data received
                            var oModelResource = new sap.ui.model.json.JSONModel();
                            oModelResource.setData(oData);
                            this.getView().setModel(oModelResource, "resourceModel");
                        }.bind(this),
                        error: function (jqXHR) {
                            let errorMessage = jqXHR.responseText ?
                                    JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                    // Handle errors
                                    MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }

                var url1 = "/ETY_CONTROL_DESTSet";
                var oFilterPlant = new Filter({
                    filters: [
                        new Filter("WERKS", FilterOperator.EQ, plant)
                        ]
                });
                if (oODataModel) {
                    oODataModel.read(url1, {
                        headers: mHeaders,
                        filters: [oFilterPlant],
                        success: function (oData) {
                            // Create and set the JSONModel with the data received
                            var oModelDestination = new sap.ui.model.json.JSONModel();
                            oModelDestination.setData(oData);
                            this.getView().setModel(oModelDestination, "destinationModel");
                        }.bind(this),
                        error: function (jqXHR) {
                            let errorMessage = jqXHR.responseText ?
                                    JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                    // Handle errors
                                    MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
                for(var i = 0; i<aCurrentData.length; i++){
                    var resource = aCurrentData[i].resource;
					 var validDate = sap.ui.getCore().byId("idProdCopyCreateReviewModifiedFrom").getValue();
                    var surl = "/ETY_Machine_DetailsSet";
                    var oFilterPlantNew = new Filter({
                        filters: [
                            new Filter("Plant", FilterOperator.EQ, plant)
                            ]
                    });
                     var oFilterResource = new Filter({
                        filters: [
                            new Filter("ResourceName", FilterOperator.EQ, resource)
                        ]
                    });
                    var oFilterValidDate = new Filter({
                        filters: [
                            new Filter("ValidDate", FilterOperator.EQ, validDate)
                        ]
                    });
                    if (oODataModel) {
                        oODataModel.read(surl, {
                            headers: mHeaders,
                            filters: [oFilterPlantNew, oFilterResource, oFilterValidDate],
                            success: function (oData) {
                                var oModelMachine = new sap.ui.model.json.JSONModel(); 
                                oModelMachine.setData(oData); 
                                var machineData = oData.results;
                                for (var j = 0; j < machineData.length; j++) {
                                    oModelMachine.setProperty("/results/" + j + "/FunctionalLoc", machineData[j].FunctionalLoc);
                                    oModelMachine.setProperty("/results/" + j + "/FunctionalLocDes", machineData[j].FunctionalLocDes);
                                }
                                this.getView().setModel(oModelMachine, "machineModel");

                                this.SetMachineDataComboBox(oData,this);

                            }.bind(this),
                            error: function (jqXHR) {
                                let errorMessage = jqXHR.responseText ?
                                        JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                        // Handle errors
                                        MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                            }
                        });
                    }
                    else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                }
                BusyIndicator.hide();
            },
            ////////////////////////////////////////// Prod Update//////////////////////////////////////////////
            editStepOneProdUpdate: function () {
                sap.ui.getCore().byId("wizardProdUpdateNavContainer").backToPage(sap.ui.getCore().byId("wizardProdUpdateContentPage"));
                sap.ui.getCore().byId("updateProductWizard").goToStep(sap.ui.getCore().byId("updateProductTypeStep"));
                this.getProdUpdatedHeaderData();
            },
            editStepTwoProdUpdate: function () {
                sap.ui.getCore().byId("wizardProdUpdateNavContainer").backToPage(sap.ui.getCore().byId("wizardProdUpdateContentPage"));
                sap.ui.getCore().byId("updateProductWizard").goToStep(sap.ui.getCore().byId("updateProductInfoStep"));
                this.getProdUpdatedHeaderData();
            },
            editStepThreeProdUpdate: function () {
                sap.ui.getCore().byId("wizardProdUpdateNavContainer").backToPage(sap.ui.getCore().byId("wizardProdUpdateContentPage"));
                sap.ui.getCore().byId("updateProductWizard").goToStep(sap.ui.getCore().byId("updatePricingStep"));
                this.getProdUpdatedHeaderData();
            },
            editStepFourProdUpdate: function () {
                sap.ui.getCore().byId("wizardProdUpdateNavContainer").backToPage(sap.ui.getCore().byId("wizardProdUpdateContentPage"));
                sap.ui.getCore().byId("updateProductWizard").goToStep(sap.ui.getCore().byId("variableUpdateDt"));
                this.getProdUpdatedHeaderData();
            },
            getProdUpdatedHeaderData: function () {
                var that = this;
				var date;		 
                var plant = sap.ui.getCore().byId("idProdUpdateReviewPlant").getText();
                sap.ui.getCore().byId("idProdUpdatePlant").setSelectedKey(plant);
                var desc = sap.ui.getCore().byId("idProdUpdateReviewDescription").getText();
                sap.ui.getCore().byId("idProdUpdateDesc").setValue(desc);
                date = sap.ui.getCore().byId("idProdUpdateReviewValidFrom").getText();
				var Modifiedfromdateupdate = sap.ui.getCore().byId("idProdUpdateReviewModifiedFrom").getText();																							   
                var dateParts = date.split("-");
                date = new Date(dateParts[2], dateParts[1] - 1, dateParts[0]);
                var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                var day = date.getDate();
                var month = monthNames[date.getMonth()];
                var year = date.getFullYear();
                var formattedValidFrom = `${month} ${day}, ${year}`;
                sap.ui.getCore().byId("idProdUpdateValidFrom").setValue(formattedValidFrom);
                sap.ui.getCore().byId("idUpdateModifiedFrom").setValue(this.fnDateFormatted(Modifiedfromdateupdate));																								 
                var mrNo = sap.ui.getCore().byId("idProdUpdateReviewMrNo").getText();
                sap.ui.getCore().byId("idProdUpdateMrNo").setValue(mrNo);
                var mrCounter = sap.ui.getCore().byId("idProdUpdateReviewMrCounter").getText();
                sap.ui.getCore().byId("idProdUpdateMrCounter").setValue(mrCounter);
                var lotSize = sap.ui.getCore().byId("idProdUpdateReviewLotSize").getText();
                sap.ui.getCore().byId("idProdUpdateLotSize").setValue(lotSize);
                var url = "/ETY_RESOURCE_SHSet";
                var oFilterPlant = new Filter({
                    filters: [
                        new Filter("Werks", FilterOperator.EQ, plant)
                        ]
                });
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        filters: [oFilterPlant],
                        success: function (oData) {
                            // Create and set the JSONModel with the data received
                            var oModelResource = new sap.ui.model.json.JSONModel();
                            oModelResource.setData(oData);
                            this.getView().setModel(oModelResource, "resourceModel");
                        }.bind(this),
                        error: function (jqXHR) {
                            let errorMessage = jqXHR.responseText ?
                                    JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                    // Handle errors
                                    MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
            },
            editStepOne: function () {
                if (sap.ui.getCore().byId("wizardProdUpdateNavContainer") !== undefined) {
                    sap.ui.getCore().byId("wizardProdUpdateNavContainer").backToPage(sap.ui.getCore().byId("wizardProdUpdateContentPage"));
                    sap.ui.getCore().byId("updateProductWizard").goToStep(sap.ui.getCore().byId("updateProductTypeStep"));
                }
                if (sap.ui.getCore().byId("wizardCopyNavContainer") !== undefined) {
                    sap.ui.getCore().byId("wizardCopyNavContainer").to(sap.ui.getCore().byId("copyWizardContentPage"));
                    sap.ui.getCore().byId("copyCreateProductWizard").goToStep(sap.ui.getCore().byId("copyProductTypeStep"));
                }
            },
            editStepOneProd: function () {
                sap.ui.getCore().byId("wizardNavContainer").backToPage(sap.ui.getCore().byId("wizardContentPage"));
                sap.ui.getCore().byId("CreateProductWizard").goToStep(sap.ui.getCore().byId("ProductTypeStep"));
            },
            editStepTwo: function () {
                if (sap.ui.getCore().byId("wizardProdUpdateNavContainer") !== undefined) {
                    sap.ui.getCore().byId("wizardProdUpdateNavContainer").backToPage(sap.ui.getCore().byId("wizardProdUpdateContentPage"));
                    sap.ui.getCore().byId("updateProductWizard").goToStep(sap.ui.getCore().byId("updateProductInfoStep"));
                }
                // Wizard navigation from review page to step2 on click of edit
                if (sap.ui.getCore().byId("wizardCopyNavContainer") !== undefined) {
                    sap.ui.getCore().byId("wizardCopyNavContainer").to(sap.ui.getCore().byId("copyWizardContentPage"));
                    sap.ui.getCore().byId("copyCreateProductWizard").goToStep(sap.ui.getCore().byId("copyProductInfoStep"));
                }
            },
            editStepTwoProd: function () {
                sap.ui.getCore().byId("wizardNavContainer").backToPage(sap.ui.getCore().byId("wizardContentPage"));
                sap.ui.getCore().byId("CreateProductWizard").goToStep(sap.ui.getCore().byId("ProductInfoStep"));
            },
            editStepThree: function () {
                if (sap.ui.getCore().byId("wizardNavContainer") !== undefined) {
                    sap.ui.getCore().byId("wizardNavContainer").backToPage(sap.ui.getCore().byId("wizardContentPage"));
                    sap.ui.getCore().byId("CreateProductWizard").goToStep(sap.ui.getCore().byId("PricingStep"));
                }
                if (sap.ui.getCore().byId("wizardProdUpdateNavContainer") !== undefined) {
                    sap.ui.getCore().byId("wizardProdUpdateNavContainer").backToPage(sap.ui.getCore().byId("wizardProdUpdateContentPage"));
                    sap.ui.getCore().byId("updateProductWizard").goToStep(sap.ui.getCore().byId("updatePricingStep"));
                }
                //Wizard navigation from review page to step 3 on click of edit
                if (sap.ui.getCore().byId("wizardCopyNavContainer") !== undefined) {
                    sap.ui.getCore().byId("wizardCopyNavContainer").to(sap.ui.getCore().byId("copyWizardContentPage"));
                    sap.ui.getCore().byId("copyCreateProductWizard").goToStep(sap.ui.getCore().byId("copyPricingStep"));
                }
            },
            editStepThreeProd: function () {
                sap.ui.getCore().byId("wizardNavContainer").backToPage(sap.ui.getCore().byId("wizardContentPage"));
                sap.ui.getCore().byId("CreateProductWizard").goToStep(sap.ui.getCore().byId("OptionalInfoStep"));
            },
            editStepFour: function () {
                if (sap.ui.getCore().byId("wizardNavContainer") !== undefined) {
                    sap.ui.getCore().byId("wizardNavContainer").backToPage(sap.ui.getCore().byId("wizardContentPage"));
                    sap.ui.getCore().byId("CreateProductWizard").goToStep(sap.ui.getCore().byId("variableDt"));
                }
                if (sap.ui.getCore().byId("wizardProdUpdateNavContainer") !== undefined) {
                    sap.ui.getCore().byId("wizardProdUpdateNavContainer").backToPage(sap.ui.getCore().byId("wizardProdUpdateContentPage"));
                    sap.ui.getCore().byId("updateProductWizard").goToStep(sap.ui.getCore().byId("variableUpdateDt"));
                }
                // Wizard navigation from review page to step4 on click of edit
                if (sap.ui.getCore().byId("wizardCopyNavContainer") !== undefined) {
                    sap.ui.getCore().byId("wizardCopyNavContainer").to(sap.ui.getCore().byId("copyWizardContentPage"));
                    sap.ui.getCore().byId("copyCreateProductWizard").goToStep(sap.ui.getCore().byId("copyVariableDt"));
                }
            },
            editStepFourProd: function () {
                sap.ui.getCore().byId("wizardNavContainer").backToPage(sap.ui.getCore().byId("wizardContentPage"));
                sap.ui.getCore().byId("CreateProductWizard").goToStep(sap.ui.getCore().byId("PricingStep"));
            },
            wizardCompletedHandler: function () {
                //role = sap.ui.getCore().getModel("loginUserModel").getData().results[0].AuthType;
                var that = this;
                secResFlag = 1;
                ((role === "S")|| (this.getView().getModel("secondaryresourceDBModel").getProperty("/SecondaryResData").length == 0))?
                    this.AddSecResource(secResFlag): null;
                
                if (sap.ui.getCore().byId("wizardNavContainer") != undefined) {
                    sap.ui.getCore().byId("wizardNavContainer").to(sap.ui.getCore().byId("wizardReviewPage"));
                    var aCurrentData = this.getView().getModel("standardCycleModel").getProperty("/standardCycleData");
                    var aStandardCycleData = this.getView().getModel("standardCycleModel").getProperty("/standardCycleData");
                    var aCurrentDataOld = this.getView().getModel("intStandardCycleModel").getProperty("/standardCycleDataInt");
                    var nominalSpeed = "";
                    var expectedEfficiency = "";
                    for (var i = 0; i < aStandardCycleData.length; i++) {
                        if (aStandardCycleData[i].controlKey === ("YBN1" || "YBN2" || "YBN3")) {
                            nominalSpeed = aStandardCycleData[i].speed;
                            controlKeyPreviousVal = aCurrentDataOld[i].controlKey;
                            expectedEfficiency = aStandardCycleData[i].lineEff;
                            var updatedRes = aStandardCycleData[i].resource;
                            break;
                        }
                    }
                    var oNominalSpeedField = sap.ui.getCore().byId("idprodcreateNominalSpeed");
                    if (oNominalSpeedField) {
                        oNominalSpeedField.setText(nominalSpeed);
                    }
                    var oExpectedEfficiencyField = sap.ui.getCore().byId("idExpectedEfficiency");
                    if (oExpectedEfficiencyField) {
                        oExpectedEfficiencyField.setText(expectedEfficiency);
                    }
                    var avariableDtData = this.getView().getModel("variableDtDBModel").getProperty("/variableDtData");
                     plant = sap.ui.getCore().byId("idProductCreatePlant").getSelectedKey();
                    var url = `/ETY_CostCentre_ValueHelpSet(Werks='${plant}',Arbpl='${updatedRes}')`;
                    BusyIndicator.show(0);
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            success: function (oData) {
                                // Create and set the JSONModel with the data received
                                var oModelCostcenter = new sap.ui.model.json.JSONModel();
                                oModelCostcenter.setData(oData);
                                sap.ui.getCore().byId("wizardReviewPage").setModel(oModelCostcenter, "costcenterModel");
                                BusyIndicator.hide();
                            }.bind(this),
                            error: function (jqXHR) {
                                let errorMessage = jqXHR.responseText ?
                                        JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                        // Handle errors
                                        MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                                        BusyIndicator.hide();
                            }
                        });

                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                    var totalVariableDt = 0;
                    for (var i = 0; i < avariableDtData.length; i++) {
                        var variableDtInt = Number(avariableDtData[i].totVariableDt);
                        totalVariableDt = variableDtInt + totalVariableDt;
                    }
                    plant = sap.ui.getCore().byId("idProdCreateReviewPlant").setText(sap.ui.getCore().byId("idProductCreatePlant").getSelectedKey());
										 
                    var validdate = sap.ui.getCore().byId("idProductCreateValidFrom").getValue();
                    if (validdate.indexOf('/') == 1) {
                        var validFromDate = sap.ui.getCore().byId("idProductCreateValidFrom").getValue();
                        var prodStdValidFrom = this.fnFormattedDate(validFromDate);
                        sap.ui.getCore().byId("idProdCreateReviewValidFrom").setText(prodStdValidFrom);
                    } else {

                        let dateObj = new Date(validdate);
                        validFrom = `${dateObj.getDate().toString().padStart(2, '0')}-${(dateObj.getMonth() + 1).toString().padStart(2, '0')}-${dateObj.getFullYear()}`;
                        sap.ui.getCore().byId("idProdCreateReviewValidFrom").setText(validFrom);
						  prodStdValidFrom = validFrom;
                    }
                    var prodModifiedfrom;
                    var Modifieddate = sap.ui.getCore().byId("idProductCreateModifiedFrom").getValue();
                    if (Modifieddate.indexOf('/') === 1) {
                        var Modifieddate = sap.ui.getCore().byId("idProductCreateModifiedFrom").getValue();
                        prodModifiedfrom = this.fnFormattedDate(validFromDate);
                        sap.ui.getCore().byId("idProdCreateReviewModifiedFrom").setText(prodModifiedfrom);
                    } else {

                        let dateObj = new Date(validdate);
                        validFrom = `${dateObj.getDate().toString().padStart(2, '0')}-${(dateObj.getMonth() + 1).toString().padStart(2, '0')}-${dateObj.getFullYear()}`;
                        sap.ui.getCore().byId("idProdCreateReviewModifiedFrom").setText(validFrom);
                        prodStdValidFrom = validFrom;
                    }
                    lotSize = sap.ui.getCore().byId("idProdCreateReviewLotSize").setText(sap.ui.getCore().byId("idCostingLotSize").getValue());
                    mrNo = sap.ui.getCore().byId("idProdCreateReviewMrNo").setText(sap.ui.getCore().byId("idMrNo").getValue());
                    mrCounter = sap.ui.getCore().byId("idProdCreateReviewMrCounter").setText(sap.ui.getCore().byId("idMrCounter").getValue());
                    chargeQty = sap.ui.getCore().byId("idProdCreateReviewChrgQty").setText(sap.ui.getCore().byId("idChargeQtyVal").getValue());
                    opQty = sap.ui.getCore().byId("idProdCreateReviewOperationQty").setText(sap.ui.getCore().byId("idOpQty").getValue());
                    if (role === "S"){
                    var mandatoryFields = [
                        "idProductCreatePlant",
                        "idDesc",
                        "idProductCreateValidFrom",
                        "idCostingLotSize",
                        "idChargeQtyVal",
                        "idOpQty",
                        "idGetResource",
                        "idSpeed",
                        "idNsUoM",				   
                        "idLineEff",
                        "idcapacityNo",
                        "idPeopleNo",
                        "idProdLossCat",
                        "idProdSubCat",
                        "idDuration",
                        "idFrequency"
                        ];
                    } else{
                        var mandatoryFields = [
                            "idProductCreatePlant",
                            "idDesc",
                            "idProductCreateValidFrom",
                            "idCostingLotSize",
                            "idChargeQtyVal",
                            "idOpQty",
                            "idGetResource",
                            "idSpeed",
                            "idNsUoM",
                            "idDestinationKey",
                            "idControlKey",
                            "idLineEff",
                            "idcapacityNo",
                            "idPeopleNo",
                            "idProdLossCat",
                            "idProdSubCat",
                            "idDuration",
                            "idFrequency"
                            ];
                    }
                    var isValid = true;
                    var emptyFields = [];
                    mandatoryFields.forEach(function (fieldId) {
                        var fieldValue = sap.ui.getCore().byId(fieldId).getValue();
                        if (!fieldValue) {
                            isValid = false;
                            emptyFields.push(fieldId);
                        }
                    });
                    if (!isValid) {
                        var message = this.oResourceBundle.getText("MAND_FIELDS_ERROR");
                        this.onShowError(message);
                        sap.ui.getCore().byId("wizardNavContainer").to(sap.ui.getCore().byId("wizardContentPage"));
                    } else{
                        sap.ui.getCore().byId("wizardNavContainer").to(sap.ui.getCore().byId("wizardReviewPage"));
                    }



                    sap.ui.getCore().byId("idProdCreateReviewPlant").setText(sap.ui.getCore().byId("idProductCreatePlant").getSelectedKey());
                    sap.ui.getCore().byId("idProdCreateReviewDescription").setText(sap.ui.getCore().byId("idDesc").getValue());
                    if (sap.ui.getCore().byId("idProductCreateValidTo").getValue() === "") {
                        sap.ui.getCore().byId("idProdCreateReviewValidTo").setText("31-12-9999");
                    } else {
                        var validToDate = sap.ui.getCore().byId("idProductCreateValidTo").getDateValue();
                        sap.ui.getCore().byId("idProdCreateReviewValidTo").setText(this.fnFormattedDate(validToDate));
                    }

                    sap.ui.getCore().byId("idProdCreateReviewMrNo").setText(sap.ui.getCore().byId("idMrNo").getValue());
                    sap.ui.getCore().byId("idProdCreateReviewMrCounter").setText(sap.ui.getCore().byId("idMrCounter").getValue());
                    sap.ui.getCore().byId("idProdCreateReviewChrgQty").setText(sap.ui.getCore().byId("idChargeQtyVal").getValue());
                    sap.ui.getCore().byId("idProdCreateReviewOperationQty").setText(sap.ui.getCore().byId("idOpQty").getValue());
                    sap.ui.getCore().byId("idProdCreateReviewLotSize").setText(sap.ui.getCore().byId("idCostingLotSize").getValue());
                    lotSize = sap.ui.getCore().byId("idCostingLotSize").getValue();
                    sap.ui.getCore().byId("idProdCreateReviewLotSize").setText(lotSize);
                    sap.ui.getCore().byId("idProdCreateReviewCrewSize").setText(totcrewSize);
                    sap.ui.getCore().byId("idExpectedEfficiency").setText(expectedEfficiency);
                    sap.ui.getCore().byId("idprodcreateNominalSpeed").setText(speedValue);
                    speedValue = parseFloat(speedValue);
                    var plantVal = sap.ui.getCore().byId("idProdCreateReviewPlant").getText();
                    var tempLineStdNo = "LR" + "_" + plantVal + "_" + updatedRes + "_";
                    var formattedProdStdValidFrom = this.fnFormattedDate2(prodStdValidFrom);
                    var surl = `odata/v4/data-services/getProductionLoss(stdPrefix='${tempLineStdNo}',validFromDate=${formattedProdStdValidFrom})`;
                    $.get(surl)
                    .done(function (response) {
                        plannedDtLossVal = (response.value) / 100;
                        var percentageAI = ((lotSize / speedValue) / ((lotSize / speedValue / expectedEfficiency / 100) + totalVariableDt / (1 - plannedDtLossVal))).toFixed(3);
                        sap.ui.getCore().byId("idAIPercent").setText(percentageAI);
                    }).fail(function (xhr, status, error) {
                        let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                xhr.responseJSON.error.message :
                                    this.oResourceBundle().getText("UNKNOWN_ERROR_OCCURRED");
                        MessageToast.show(this.oResourceBundle.getText("PLANNED_DT_RETRIEVE_FAIL") + " " + errorMessage);
                    }.bind(this));
                    sap.ui.getCore().byId("idProdCreateBottleneckCorrect").addStyleClass("greenText");
                }
        },
            wizardProdUpdateCompletedHandler: function () {
                //role = sap.ui.getCore().getModel("loginUserModel").getData().results[0].AuthType;
                var that = this;
                secResFlag = 1;
                ((role === "S")|| (this.getView().getModel("globalResponseModel").getProperty("/SecondaryResData").length !== this.getView().getModel("globalResponseModel").getProperty("/standardCycleData").length))?
                    this.onPressSecResource(secResFlag): null;
                if (sap.ui.getCore().byId("wizardProdUpdateNavContainer") != undefined) {
                   
                    var mandatoryFields = [
                        "idProdUpdatePlant",
                        "idProdUpdateDesc",
                        "idProdUpdateValidFrom",
                        "idProdUpdateLotSize",
                        "idProdUpdateChrgQty",
                        "idProdUpdateOperationQty"
                        ];
                    var isValid = true;
                    var emptyFields = [];

                    mandatoryFields.forEach(function (fieldId) {
                        var fieldValue = sap.ui.getCore().byId(fieldId).getValue();
                        if (!fieldValue) {
                            isValid = false;
                            emptyFields.push(fieldId);
                        }
                    });

                    if (!isValid) {
                        var message = this.oResourceBundle.getText("MAND_FIELDS_ERROR");
                        this.onShowError(message);
                        return; // Ensure that we exit if the validation fails
                    }
                    var avariableDtData = this.getView().getModel("globalResponseModel").getProperty("/variableDtData");
					for (var i = 0; i < avariableDtData.length; i++) {
                        var lossCat = avariableDtData[i].lossCat;
                        var subCat = avariableDtData[i].subCat;
                        if (!lossCat && !subCat) {
                            isValid = false;
                            var message = this.oResourceBundle.getText("LOSS_CATEGORY_REQUIRED");
                            this.onShowError(message);
                            return;
                        }
                        if (!lossCat && subCat) {
                            isValid = false;
                            var message = this.oResourceBundle.getText("LOSS_CATEGORY_REQUIRED");
                            this.onShowError(message);
                            return;
                        }
                        if (!subCat && lossCat) {
                            isValid = false;
                            var message = this.oResourceBundle.getText("SUB_CATEGORY_REQUIRED");
                            this.onShowError(message);
                            return;
                        }
                    }
                    var aStandardCycleData = this.getView().getModel("globalResponseModel").getProperty("/standardCycleData");
                    var nominalSpeed = "";
                    var expectedEfficiency = "";
                    var prodCopySpeedVal = [];
                    for (var i = 0; i < aStandardCycleData.length; i++) {
                        prodCopySpeedVal.push(
                                aStandardCycleData[i].nominalSpeed);
                        if (aStandardCycleData[i].controlKey === ("YBN1" || "YBN2" || "YBN3")) {
                            nominalSpeed = aStandardCycleData[i].nominalSpeed;
                            copiedSpeedValue = nominalSpeed;
                            expectedEfficiency = aStandardCycleData[i].pctlineEfficiency;
                            var updatedRes = aStandardCycleData[i].resource;
                        }
                    }
                    const minimumSpeed = Math.min(...prodCopySpeedVal.map(Number));
                    if (String(minimumSpeed) === String(nominalSpeed)) {
                        sap.ui.getCore().byId("idProdUpdateReviewBottleneckCorrect").setText("True");
                        sap.ui.getCore().byId("idProdUpdateReviewBottleneckCorrect").addStyleClass("greenText").removeStyleClass("redText");
                    } else {
                        sap.ui.getCore().byId("idProdUpdateReviewBottleneckCorrect").setText("False");
                        sap.ui.getCore().byId("idProdUpdateReviewBottleneckCorrect").addStyleClass("redText").removeStyleClass("greenText");
                    }
                    var totCrewSize = 0;
                    for (var i = 0; i < aStandardCycleData.length; i++) {
                        var updatedCrewTotSize = parseInt((aStandardCycleData[i].numOfPeople),10);
                        var initCreSize = updatedCrewTotSize;
                        totCrewSize = initCreSize + totCrewSize;
                    }
                    plant = sap.ui.getCore().byId("idProdUpdatePlant").getSelectedKey();
                    var url = `/ETY_CostCentre_ValueHelpSet(Werks='${plant}',Arbpl='${updatedRes}')`;
                    BusyIndicator.show(0);
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            success: function (oData) {
                                // Create and set the JSONModel with the data received
                                var oModelCostcenter = new sap.ui.model.json.JSONModel();
                                oModelCostcenter.setData(oData);
                                sap.ui.getCore().byId("wizardUpdateReviewPage").setModel(oModelCostcenter, "costcenterModel");
                                BusyIndicator.hide();
                            }.bind(this),
                            error: function (jqXHR) {
                                let errorMessage = jqXHR.responseText ?
                                        JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                        // Handle errors
                                        MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                                        BusyIndicator.hide();
                            }
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                    var curlotSize = sap.ui.getCore().byId("idProdUpdateLotSize").getValue();
                    var totalVariableDt = 0;
                    for (var i = 0; i < avariableDtData.length; i++) {
                        var frequency = avariableDtData[i].freqInProdUom;
                        var duration = avariableDtData[i].durationInMin;
                        var calcVariableDt = parseFloat((curlotSize / frequency * duration / 60).toFixed(3));
                        avariableDtData[i].totalVarDT = calcVariableDt;
                        avariableDtData[i].procOrdSize = curlotSize;
                        var totalVariableDt = (totalVariableDt + calcVariableDt);
                    }
                    this.getView().getModel("globalResponseModel").setProperty("/variableDtData", avariableDtData);
                    //this.getView().getModel("standardCycleModel").setProperty("/standardCycleData/" + index + "/selected", true);.getSelectedItem().getKey()
                    plantDesc = sap.ui.getCore().byId("idProdUpdateDesc").getValue();
                    sap.ui.getCore().byId("idProdUpdateReviewDescription").setText(plantDesc);
                    var validFromDate = sap.ui.getCore().byId("idProdUpdateValidFrom").getValue();
					var ModifiedFromDate = sap.ui.getCore().byId("idUpdateModifiedFrom").getValue();
                    var prodStdValidFrom1 = this.fnFormattedDate2(validFromDate);
                    var prodStdModifiedFrom2 = this.fnFormattedDate2(ModifiedFromDate);
                    if (new Date(prodStdModifiedFrom2) < new Date(prodStdValidFrom1)) {
                        sap.m.MessageBox.error("'Modified From' date cannot be older than 'Valid From' date.");
                        return;
                    }
                    var prodStdValidFrom = this.fnFormattedDate(validFromDate);
                    var prodStdModifiedFrom = this.fnFormattedDate(ModifiedFromDate);
                    sap.ui.getCore().byId("idProdUpdateReviewValidFrom").setText(prodStdValidFrom);
                    sap.ui.getCore().byId("idProdUpdateReviewModifiedFrom").setText(prodStdModifiedFrom);															 
                    var validToDate = sap.ui.getCore().byId("idProdUpdateValidTo").getDateValue();
                    sap.ui.getCore().byId("idProdUpdateReviewValidTo").setText(this.fnFormattedDate(validToDate));
                    lotSize = sap.ui.getCore().byId("idProdUpdateReviewLotSize").setText(curlotSize);
                    mrNo = sap.ui.getCore().byId("idProdUpdateMrNo").getValue();
                    sap.ui.getCore().byId("idProdUpdateReviewMrNo").setText(mrNo);
                    mrCounter = sap.ui.getCore().byId("idProdUpdateMrCounter").getValue();
                    sap.ui.getCore().byId("idProdUpdateReviewMrCounter").setText(mrCounter);
                    chargeQty = sap.ui.getCore().byId("idProdUpdateChrgQty").getValue();
                    sap.ui.getCore().byId("idProdUpdateReviewChrgQty").setText(chargeQty);
                    opQty = sap.ui.getCore().byId("idProdUpdateOperationQty").getValue();
                    sap.ui.getCore().byId("idProdUpdateReviewOperationQty").setText(opQty);
                    sap.ui.getCore().byId("idProdUpdateReviewPlant").setText(plant);
                    sap.ui.getCore().byId("idProdUpdateReviewEff").setText(expectedEfficiency);
                    sap.ui.getCore().byId("idProdUpdateReviewCrewSize").setText(totCrewSize);
                    sap.ui.getCore().byId("idProdUpdateReviewNS").setText(nominalSpeed);
                    var tempLineStdNo = "LR" + "_" + plant + "_" + updatedRes + "_";
                    var formattedProdStdValidFrom = this.fnFormattedDate2(prodStdValidFrom);
                    var url = `odata/v4/data-services/getProductionLoss(stdPrefix='${tempLineStdNo}',validFromDate=${formattedProdStdValidFrom})`;
                    $.get(url).done(function (response) {
                        plannedDtLossVal = (response.value) / 100;
                        var percentageAI = ((curlotSize / nominalSpeed) / ((curlotSize / nominalSpeed / expectedEfficiency / 100) + totalVariableDt / (1 - plannedDtLossVal))).toFixed(3);
                        sap.ui.getCore().byId("idProdUpdateReviewAiPercent").setText(percentageAI);
                    }).fail(function (xhr, status, error) {
                        let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                xhr.responseJSON.error.message :
                                    this.oResourceBundle().getText("UNKNOWN_ERROR_OCCURRED");
                        MessageToast.show(this.oResourceBundle.getText("PLANNED_DT_RETRIEVE_FAIL") + " " + errorMessage);
                    }.bind(this));
                    sap.ui.getCore().byId("wizardProdUpdateNavContainer").to(sap.ui.getCore().byId("wizardUpdateReviewPage"));
                }
            },
            wizardProdCopyCompletedHandler: function () {
                var that = this;
                //role = sap.ui.getCore().getModel("loginUserModel").getData().results[0].AuthType;
                var that = this;
                secResFlag = 1;
                ((role === "S")|| (this.getView().getModel("globalResponseModel").getProperty("/SecondaryResData").length !== this.getView().getModel("globalResponseModel").getProperty("/standardCycleData").length))?
                    this.onPressSecResource(secResFlag): null;
                if (sap.ui.getCore().byId("wizardCopyNavContainer") != undefined) {
                  
                    var mandatoryFields = [
                        "idProdCopyCreateReviewPlant",
                        "idProdCopyCreateReviewDesc",
                        "idProdCopyCreateReviewValidFrom",
                        "idProdCopyCreateReviewLotSize",
                        "idProdCopyCreateReviewChrgQty",
                        "idProdCopyCreateReviewOperationQty",
                        ];
                    var isValid = true;
                    var emptyFields = [];

                    mandatoryFields.forEach(function (fieldId) {
                        var fieldValue = sap.ui.getCore().byId(fieldId).getValue();
                        if (!fieldValue) {
                            isValid = false;
                            emptyFields.push(fieldId);
                        }
                    });

                    if (!isValid) {
                        var message = this.oResourceBundle.getText("MAND_FIELDS_ERROR");
                        this.onShowError(message);
                        return; // Ensure that we exit if the validation fails
                    }

                    var avariableDtData = this.getView().getModel("globalResponseModel").getProperty("/variableDtData");
					 for (var i = 0; i < avariableDtData.length; i++) {
                        var lossCat = avariableDtData[i].lossCat;
                        var subCat = avariableDtData[i].subCat;
                        if (!lossCat && !subCat) {
                            isValid = false;
                            var message = this.oResourceBundle.getText("LOSS_CATEGORY_REQUIRED");
                            this.onShowError(message);
                            return;
                        }
                        if (!lossCat && subCat) {
                            isValid = false;
                            var message = this.oResourceBundle.getText("LOSS_CATEGORY_REQUIRED");
                            this.onShowError(message);
                            return;
                        }
                        if (!subCat && lossCat) {
                            isValid = false;
                            var message = this.oResourceBundle.getText("SUB_CATEGORY_REQUIRED");
                            this.onShowError(message);
                            return;
                        }
                    }
                    var aStandardCycleData = this.getView().getModel("globalResponseModel").getProperty("/standardCycleData");

                    var nominalSpeed = "";
                    var expectedEfficiency = "";
                    var prodCopySpeedVal = [];
                    for (var i = 0; i < aStandardCycleData.length; i++) {
                        prodCopySpeedVal.push(
                                aStandardCycleData[i].nominalSpeed);
                        if (aStandardCycleData[i].controlKey === ("YBN1" || "YBN2" || "YBN3")) {
                            nominalSpeed = aStandardCycleData[i].nominalSpeed;
                            copiedSpeedValue = nominalSpeed;
                            var changedRes = aStandardCycleData[i].resource;
                            expectedEfficiency = aStandardCycleData[i].pctlineEfficiency;

                        }
                    }
                    const minimumSpeed = Math.min(...prodCopySpeedVal.map(Number));
                    if (String(minimumSpeed) === String(copiedSpeedValue)) {
                        sap.ui.getCore().byId("idProdCreateCopyBottleneckCorrect").setText("True");
                        sap.ui.getCore().byId("idProdCreateCopyBottleneckCorrect").addStyleClass("greenText").removeStyleClass("redText");
                    } else {
                        sap.ui.getCore().byId("idProdCreateCopyBottleneckCorrect").setText("False");
                        sap.ui.getCore().byId("idProdCreateCopyBottleneckCorrect").addStyleClass("redText").removeStyleClass("greenText");
                    }
                    var totCrewSize = 0;
                    for (var i = 0; i < aStandardCycleData.length; i++) {
                        var updatedCrewTotSize = parseInt((aStandardCycleData[i].numOfPeople),10);
                        var initCreSize = updatedCrewTotSize;
                        totCrewSize = initCreSize + totCrewSize;
                    }
                    plant = sap.ui.getCore().byId("idProdCopyCreateReviewPlant").getSelectedKey();
                    var url = `/ETY_CostCentre_ValueHelpSet(Werks='${plant}',Arbpl='${changedRes}')`;
                    BusyIndicator.show(0);
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            success: function (oData) {
                                // Create and set the JSONModel with the data received
                                var oModelCostcenter = new sap.ui.model.json.JSONModel();
                                oModelCostcenter.setData(oData);
                                sap.ui.getCore().byId("idProdCreateCopyCostCenter").setText(oData.Kostl);
                                //sap.ui.getCore().byId("wizardCopyReviewPage").setModel(oModelCostcenter, "costcenterModel");
                                BusyIndicator.hide();
                            }.bind(this),
                            error: function (jqXHR) {
                                let errorMessage = jqXHR.responseText ?
                                        JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                        // Handle errors
                                        MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                                        BusyIndicator.hide();
                            }
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                    var totalVariableDt;
                    lotSize = sap.ui.getCore().byId("idProdCopyCreateReviewLotSize").getValue();
                    totalVariableDt = 0;
                    for (var i = 0; i < avariableDtData.length; i++) {
                        var frequency = avariableDtData[i].freqInProdUom;
                        var duration = avariableDtData[i].durationInMin;
                        var calcVariableDt = parseFloat((lotSize / frequency * duration / 60).toFixed(3));
                        avariableDtData[i].totalVarDT = calcVariableDt;
                        avariableDtData[i].procOrdSize = lotSize;
                        totalVariableDt = (totalVariableDt + calcVariableDt);
                    }
                    this.getView().getModel("globalResponseModel").setProperty("/variableDtData", avariableDtData);
                    plantDesc = sap.ui.getCore().byId("idProdCopyCreateReviewDesc").getValue();
                    sap.ui.getCore().byId("idProdCreateCopyDescription").setText(plantDesc);
                    var validFromDate = sap.ui.getCore().byId("idProdCopyCreateReviewValidFrom").getDateValue();
					 var ModifiedFromDate = sap.ui.getCore().byId("idProdCopyCreateReviewModifiedFrom").getDateValue();
                    var validToDate = sap.ui.getCore().byId("idProdCopyCreateReviewValidTo").getDateValue();
                    var prodStdValidFrom = this.fnFormattedDate(validFromDate);
                    var prodStdModifiedFrom = this.fnFormattedDate(ModifiedFromDate);
                    sap.ui.getCore().byId("idProdCreateCopyValidFrom").setText(prodStdValidFrom);
                    sap.ui.getCore().byId("idProdCreateCopyModifiedFrom").setText(prodStdModifiedFrom);											   
                    sap.ui.getCore().byId("idProdCreateCopyValidTo").setText(this.fnFormattedDate(validToDate));
                    var processOrderLotSize = sap.ui.getCore().byId("idProdCopyCreateReviewLotSize").getValue();
                    sap.ui.getCore().byId("idProdCreateCopyLotSize").setText(processOrderLotSize);
                    mrNo = sap.ui.getCore().byId("idProdCopyCreateReviewMrNo").getValue();
                    sap.ui.getCore().byId("idProdCreateCopyMrNo").setText(mrNo);
                    mrCounter = sap.ui.getCore().byId("idProdCopyCreateReviewMrCounter").getValue();
                    sap.ui.getCore().byId("idProdCreateCopyMrCounter").setText(mrCounter);
                    chargeQty = sap.ui.getCore().byId("idProdCopyCreateReviewChrgQty").getValue();
                    sap.ui.getCore().byId("idProdCreateCopyChrgQty").setText(chargeQty);
                    opQty = sap.ui.getCore().byId("idProdCopyCreateReviewOperationQty").getValue();
                    sap.ui.getCore().byId("idProdCreateCopyOperationQty").setText(opQty);
                    sap.ui.getCore().byId("idProdCreateCopyEff").setText(expectedEfficiency);
                    sap.ui.getCore().byId("idProdCreateCopyCrewSize").setText(totCrewSize);
                    sap.ui.getCore().byId("idProdCreateCopyNS").setText(nominalSpeed);
                    var tempLineStdNo = "LR" + "_" + plant + "_" + changedRes + "_";
                    var formattedProdStdValidFrom = this.fnFormattedDate2(prodStdValidFrom);
                    var surl = `odata/v4/data-services/getProductionLoss(stdPrefix='${tempLineStdNo}',validFromDate=${formattedProdStdValidFrom})`;
                    $.get(surl)
                    .done(function (response) {
                        plannedDtLossVal = (response.value) / 100;
                        var percentageAI = ((processOrderLotSize / nominalSpeed) / ((processOrderLotSize / nominalSpeed / expectedEfficiency / 100) + totalVariableDt / (1 - plannedDtLossVal))).toFixed(3);
                        sap.ui.getCore().byId("idProdCreateCopyAiPercent").setText(percentageAI);
                    }).fail(function (xhr, _status, _error) {
                        let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                xhr.responseJSON.error.message :
                                    this.oResourceBundle().getText("UNKNOWN_ERROR_OCCURRED");
                        MessageToast.show(this.oResourceBundle.getText("PLANNED_DT_RETRIEVE_FAIL") + " " + errorMessage);
                    }.bind(this));
                    sap.ui.getCore().byId("idProdCreateCopyPlant").setText(plant);
                    sap.ui.getCore().byId("wizardCopyNavContainer").to(sap.ui.getCore().byId("wizardCopyReviewPage"));
                    // sap.ui.getCore().byId("copyCreateProductWizard").goToStep(sap.ui.getCore().byId("copyProductTypeStep"));
                }
            },
			  fnProdCopySubCat: function () {
                if (sap.ui.getCore().byId("idProdCopyCreateReviewPlant") !== undefined) {
                    var sPlant = sap.ui.getCore().byId("idProdCopyCreateReviewPlant").getSelectedKey();
                    var sLossCat = sap.ui.getCore().byId("idProdcopyLossCat").getValue();
                    if (sLossCat === "") {
                        sap.ui.getCore().byId("idProdcopySubCat").setValue("");
                        sap.ui.getCore().byId("idProdcopySubCat").setEditable(false);
                    } else {
                        sap.ui.getCore().byId("idProdcopySubCat").setValue("");
                        sap.ui.getCore().byId("idProdcopySubCat").setEditable(true);
                    }
                    var oModelProdSubCat = new sap.ui.model.json.JSONModel();
                    var sUrl = "odata/v4/data-services/LineRelatedLossCatDB?$filter=plant eq '" + sPlant + "' and lossCat eq '" + sLossCat + "'&$select=subCat";
                    jQuery.ajax({
                        url: sUrl,
                        method: "GET",
                        success: function (data) {
                            oModelProdSubCat.setData(data);
                            oModelProdSubCat.setSizeLimit(100);
                            this.getView().setModel(oModelProdSubCat, "ProdSubCatModel");
                        }.bind(this),
                        error: function (oError) {
                            console.log("Error loading SubCat data: ", oError);
                        }
                    });

									   
											 
                }
            },

            handleProdCreateCloseButton: function () {
                if (this._isConfirming) {
                    return;
                }
                this._isConfirming = true;
                sap.m.MessageBox.confirm(
                    "Are you sure you want to cancel?", {
                    onClose: function (oAction) {
                        if (oAction === sap.m.MessageBox.Action.OK) {
                            if (this._ProdCreate) {
                                var fields = [
                                    "idProductCreatePlant", "idCostingLotSize", "idMrNo", "idMrCounter", "idDesc",
                                    "idGetMachine", "idGetResource", "idSpeed", "idNsUoM", "idDestinationKey",
                                    "idControlKey", "idLineEff", "idcapacityNo", "idPeopleNo", "idProdSubCat",
                                    "idDuration", "idFrequency", "idProductCreateValidFrom", "idProductCreateValidTo", "idProdLossCat"
                                ];

                                fields.forEach(function (fieldId) {
                                    var oField = sap.ui.getCore().byId(fieldId);
                                    if (oField) {
                                        oField.setValue("").setValueState("None");
                                    }
                                });

                                sap.ui.getCore().byId("wizardNavContainer").to(sap.ui.getCore().byId("wizardContentPage"));

                                sap.ui.getCore().byId("idGetResource").setEditable(false);
                                sap.ui.getCore().byId("idGetMachine").setEditable(false);
                                sap.ui.getCore().byId("idcapacityNo").setEditable(false);
                                sap.ui.getCore().byId("idProdSubCat").setEditable(false);
                                sap.ui.getCore().byId("idProdLossCat").setEditable(false);
						  

                                var oBottleneckTable = sap.ui.getCore().byId("idBottleneckDB");
                                if (oBottleneckTable) {
                                    var oBottleneckModel = oBottleneckTable.getModel("standardCycleModel");
                                    if (oBottleneckModel) {
                                        oBottleneckModel.setProperty("/standardCycleData", []);
                                    }
                                }
                                var oVariableDtTable = sap.ui.getCore().byId("idVariableDtDB");
                                if (oVariableDtTable) {
                                    var oVariableDtModel = oVariableDtTable.getModel("variableDtDBModel");
                                    if (oVariableDtModel) {
                                        oVariableDtModel.setProperty("/variableDtData", []);
                                    }
                                }
                                var oMaterialTable = sap.ui.getCore().byId("idMaterialDB");
                                if (oMaterialTable) {
                                    var oMaterialModel = oMaterialTable.getModel("materialDBCreateModel");
                                    if (oMaterialModel) {
                                        oMaterialModel.setProperty("/materialData", []);
                                    }
                                }
                                this._ProdCreate.close();
                            }
                        } else {
                            this._isConfirming = false;
                        }
                    }.bind(this)
                }
                );
            },

            handleCloseButton: function () {
                if (this._reworkComment) {
                    this._reworkComment.close();
                    sap.ui.getCore().byId("idProdReworkComment").setValue();
                }
                if (this._oPopover) {
                    this._oPopover.close();   
                }
                if (this._oApproverReviewProd) {
                    this._oApproverReviewProd.close();
                }
                if (this._oExecutorReviewProd) {
                    this._oExecutorReviewProd.close();
                }
            },
            handleMessageBoxCloseButton: function () {
                this._oPopover11.close();
            },
            onSelectSecResource: function (oEvent) {
                var that = this;
                var source = oEvent.getSource();
                var context = source.getBindingContext("secondaryresourceDBModel");
                var index = context.getPath().split("/").pop();
                if (oEvent.getParameter("selectedItem") === null) {
                    var oSecondaryResData = this.getView().getModel("secondaryresourceDBModel").getProperty("/SecondaryResData");
                    for (var i = 1; i < 7; i++) {
                        oSecondaryResData[index]["energy" + i + "Type"] = "";
                        oSecondaryResData[index]["energy" + i + "Uom"] = "";
                        oSecondaryResData[index]["energy" + i + "QtyPerHr"] = "";
                    }
                    this.getView().getModel("secondaryresourceDBModel").setProperty("/SecondaryResData/" + index + "/edit", false);
                    this.getView().getModel("secondaryresourceDBModel").setProperty("/SecondaryResData/" + index + "/enable", true);
                } else {
                    var selectedKey = oEvent.getParameter("selectedItem").getKey();
							  
                    if (sap.ui.getCore().byId("idProductCreatePlant") != undefined) {
                        var plant = sap.ui.getCore().byId("idProductCreatePlant").getSelectedKey();
                    } else if (sap.ui.getCore().byId("idProdUpdatePlant") != undefined) {
                        var plant = sap.ui.getCore().byId("idProdUpdatePlant").getSelectedKey();
                    } else {
                        var plant = sap.ui.getCore().byId("idProdCopyCreateReviewPlant").getSelectedKey();
                    }
                    
                    var oModelActivity = new sap.ui.model.json.JSONModel();
                    var url = "/ETY_ACTIVITY_TYPESet";
                    BusyIndicator.show(0);
                    var oFilterResource = new Filter({
                        filters: [
                            new Filter("ARBPL", FilterOperator.EQ, selectedKey)
                            ]
                    });
                    var oFilterPlant = new Filter({
                        filters: [
                            new Filter("WERKS", FilterOperator.EQ, plant)
                            ]
                    });
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            filters: [oFilterResource, oFilterPlant],
                            success: function (oData) {
                                BusyIndicator.hide();
                                oModelActivity.setData(oData);
                                // Get the existing model data
                                var oSecondaryResData = this.getView().getModel("secondaryresourceDBModel").getProperty("/SecondaryResData");
                                // Get the new data from the temporary model
                                var newData = oModelActivity.getData().results;

                                // Update the existing data with the new data
                                newData.forEach(function (item, idx) {
                                    var columnIndex = idx + 1;
                                    if (columnIndex <= 6) {
                                        oSecondaryResData[index]["energy" + columnIndex + "Type"] = item.MCTXT;
                                        oSecondaryResData[index]["energy" + columnIndex + "Uom"] = item.LEINH;
                                    }
                                });

                                // Update the secondaryresourceDBModel with the modified data
                                this.getView().getModel("secondaryresourceDBModel").setProperty("/SecondaryResData", oSecondaryResData);
                                this.getView().getModel("secondaryresourceDBModel").setProperty("/SecondaryResData/" + index + "/edit", true);
                                this.getView().getModel("secondaryresourceDBModel").setProperty("/SecondaryResData/" + index + "/enable", true);
                                this.getView().getModel("secondaryresourceDBModel").setProperty("/SecondaryResData/" + index + "/SecResource", selectedKey);
                                sap.ui.getCore().byId("idSecondaryResourceDB1").getModel("secondaryresourceDBModel").refresh();
                            }.bind(this),
                            error: function (jqXHR) {
                                let errorMessage = jqXHR.responseText ?
                                        JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                        // Handle errors
                                        MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                            }
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                }
            },
            onAddEnergyResource: function () {
                var table = sap.ui.getCore().byId("idSecondaryResourceDB1");
                var selectedIndices = table.getSelectedIndices();
                if (selectedIndices.length === 1) {
                    var selectedIndex = selectedIndices[0];
                    var selectedData = table.getContextByIndex(selectedIndex).getObject();
                    var newData = Object.assign({}, selectedData);
                    // Modify or reset any properties as needed for the new row
                    newData.id = ""; // For example, reset ID if it should be unique
                    // Add the new data to the model
                    var model = this.getView().getModel("secondaryresourceDBModel");
                    var currentData = model.getProperty("/SecondaryResData");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/ID", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/secResource", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/edit", false);
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy1QtyPerHr", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy2QtyPerHr", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy3QtyPerHr", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy4QtyPerHr", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy5QtyPerHr", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy6QtyPerHr", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy1Type", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy1Uom", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy2Type", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy2Uom", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy3Type", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy3Uom", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy4Type", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy4Uom", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy5Type", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy5Uom", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy6Type", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy6Uom", "");
                    currentData.push(newData);
                    model.setProperty("/SecondaryResData", currentData);
                    model.refresh();
                    sap.ui.getCore().byId("idSecondaryResourceDB1").getModel("secondaryresourceDBModel").refresh();
                } else {
                    this.onShowWarning(this.oResourceBundle.getText("ROW_DUPLICATE_ENGRES_ERROR"));
                }
            },
            onPressSecResource: function(secResFlag) {
                //role = sap.ui.getCore().getModel("loginUserModel").getData().results[0].AuthType;
                var iRowCount = this.getView().getModel("globalResponseModel").getData().standardCycleData.length;
                var aDialogData = [];
                for (var i = 0; i < iRowCount; i++) {
                    aDialogData.push({
                        ID: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.ID  == undefined ? "": this.getView().getModel("globalResponseModel").getData().SecondaryResData[i].ID,
                        resource: this.getView().getModel("globalResponseModel").getData().standardCycleData[i].resource,
                        machine: this.getView().getModel("globalResponseModel").getData().standardCycleData[i].machine,
                        secResource: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.secResource || "",
                                energy1Type: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.energy1Type || "",
                                        energy1Uom: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.energy1Uom || "",
                                                energy1QtyPerHr: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.energy1QtyPerHr || "",
                                                        edit: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.secResource == undefined ? false: true,
                                                        enable: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.secResource == undefined ? false: true,
                                                        energy2Type: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.energy2Type || "",
                                                                energy2Uom: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.energy2Uom || "",
                                                                        energy2QtyPerHr: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.energy2QtyPerHr || "",
                                                                                energy3Type: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.energy3Type || "",
                                                                                        energy3Uom: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.energy3Uom || "",
                                                                                                energy3QtyPerHr: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.energy3QtyPerHr || "",
                                                                                                        energy4Type: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.energy4Type || "",
                                                                                                                energy4Uom: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.energy4Uom || "",
                                                                                                                        energy4QtyPerHr: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.energy4QtyPerHr || "",
                                                                                                                                energy5Type: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.energy5Type || "",
                                                                                                                                        energy5Uom: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.energy5Uom || "",
                                                                                                                                                energy5QtyPerHr: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.energy5QtyPerHr || "",
                                                                                                                                                        energy6Type: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.energy6Type || "",
                                                                                                                                                                energy6Uom: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.energy6Uom || "",
                                                                                                                                                                        energy6QtyPerHr: this.getView().getModel("globalResponseModel").getData().SecondaryResData[i]?.energy6QtyPerHr || "",
                    });
                }
                if (secResFlag !== 1){
                if (!this._oPopover32) {
                    this._oPopover32 = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.SecondaryResourceProdStd", this);
                    this.getView().addDependent(this._oPopover32);
                }
                this._oPopover32.open();
											 
                var secondaryresourceDBModel = new sap.ui.model.json.JSONModel();
                this.getView().getModel("secondaryresourceDBModel").setProperty("/SecondaryResData", aDialogData);
                var oDialogData = {
                        SecondaryResData: aDialogData
                };
                var secondaryresourceDBModel = new sap.ui.model.json.JSONModel(oDialogData);
                sap.ui.getCore().byId("idSecondaryResourceDB1").setModel(secondaryresourceDBModel, "secondaryresourceDBModel");
                }else{
                    var secondaryresourceDBModel = new sap.ui.model.json.JSONModel();
                    this.getView().getModel("globalResponseModel").setProperty("/SecondaryResData", aDialogData);
                }
																																				 
        },
												   
																	  
															   
								   
													   
															
														 
														  
															  
													
																		
																 
																							
																				
																					   
																							   
																							
															
																							 
															  
											   
												  
							  
																 
																							 
															 
							  
															  
																							 
															 
							  
															   
																							 
															 
							  
																   
																							 
															 
							  
						
											
									  
																					
																							  
																						
																						  
																								  
						 
																					   
							   
									 
										
														 
														  
						 
													   
													
																									  
														  
															  
							 
																  
													
																																
																   
																						  
																														
														  
															  
							  
					
				 
            onProdStandardArchive: function () {
                var oTable = this.getView().byId("idProductTable");
                var aSelectedPaths = oTable._aSelectedPaths;
                var that = this;
                var prodStdNos = [];
														 
													  
													   
														   
                if (aSelectedPaths.length >= 1) {
                    for (var i = 0; i < aSelectedPaths.length; i++) {
                        var sSelectedPath = aSelectedPaths[i];
                        var iSelectedIndex = parseFloat(sSelectedPath.split("/")[2], 10);
                        var oModel = this.getView().getModel("productModel");
																				 
																						 
																					  
														 
                        prodStdNos.push(oModel.getData().value[iSelectedIndex].prodStdNo);
														   
											
											   
						   
															  
																						  
														  
						   
														   
																						  
														  
						   
															
																						  
														  
						   
																
																						  
														  
						   
                    }
										 
                    var payload = {
                        "prodStdNos": prodStdNos
																							   
																						 
																						   
																								   
                    };
                    var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                    var nbId = newData[0].Username;
                    var role = newData[0].AuthType;
                    if (role === 'C') {
                        role = "Creator/Editor";
                    } else if (role === 'A') {
                        role = "Approver";
                    } else if (role === 'V' || role === 'E') {
                        role = "Executor/Viewer";
                    }
                    var sUrl = "odata/v4/data-services/archiveProdStdItems";
                    $.ajax({
                        url: sUrl,
                        type: "POST",
                        data: JSON.stringify(payload),
                        contentType: "application/json",
                        headers: {
                            "x-username": nbId,
                            "x-role": role
                        }
                    })
                        .done(function (_response) {
                            BusyIndicator.hide();
                            var message = that.oResourceBundle.getText("PROD_STD_ARCHIVE_SUCCESS");
                            MessageToast.show(message);
												
                            that.getProductStdHeaderData();
                        })
                        .fail(function (xhr, _status, _error) {
                            BusyIndicator.hide();
                            let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                xhr.responseJSON.error.message :
                                that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                            var message = that.oResourceBundle.getText("PROD_STD_ARCHIVE_FAIL") + " " + errorMessage;
                            MessageToast.show(message);
												
                            that.getProductStdHeaderData();
                        });
                }
            },
            deleteMasterRecipeFromECC: function () {
                var that = this;
                var oTable = this.getView().byId("idProductTable");
                var aSelectedPaths = oTable._aSelectedPaths;
                if (aSelectedPaths.length == 1) {
                    var sSelectedPath = aSelectedPaths[0];
                    var iSelectedIndex = parseFloat(sSelectedPath.split("/")[2], 10);
                    var oModel = this.getView().getModel("productModel");
                    if (oModel.getData().value[iSelectedIndex].status !== "Archived - SAP Del") {
                sap.m.MessageBox.confirm(that.oResourceBundle.getText("SELECT_PRD_STD_ARCHIVE_CONFIRM"), {
                    title: "Confirm",
                    onClose: function (oAction) {
                        if (oAction === sap.m.MessageBox.Action.OK) {
                            that.fnProdStandardArchive();
                        }
                        else {
                            MessageToast.show(that.oResourceBundle.getText("ARCHIVE_CANCELED"))
                        }
                    },
                    actions: [sap.m.MessageBox.Action.OK,
                        sap.m.MessageBox.Action.CANCEL],
                        emphasizedAction: sap.m.MessageBox.Action.OK,
                        initialFocus: null,
                        textDirection: sap.ui.core.TextDirection.Inherit,
                        dependentOn: null
                });
            }else {
                var message = this.oResourceBundle.getText("PROD_STD_ARCHIVED");
                this.onShowWarning(message);
            }
        } else {
            var messagetext = this.oResourceBundle.getText("PROD_STD_SELECT");
            this.onShowWarning(messagetext);
        }
        },

            fnProdStandardArchive: function () {
                var oTable = this.getView().byId("idProductTable");
                var aSelectedPaths = oTable._aSelectedPaths;
                var that = this;
                    var sSelectedPath = aSelectedPaths[0];
                    var iSelectedIndex = parseFloat(sSelectedPath.split("/")[2], 10);
                    var oModel = this.getView().getModel("productModel");
                        var plant = oModel.getData().value[iSelectedIndex].plant;
                        var mrCounter = oModel.getData().value[iSelectedIndex].mrCounter;
                        var mrNumber = oModel.getData().value[iSelectedIndex].mrGroup;
                        BusyIndicator.show(0);
                        var url = `/ETY_MR_HEADER_CRSet(PLNNR='${mrNumber}',Werks='${plant}',Plnal='${mrCounter}')`;
                        if (oODataModel) {
                            oODataModel.remove(url, {
                                headers: mHeaders,
                                success: function (res, status, xhr) {
                                    BusyIndicator.hide();
                                    var message = that.oResourceBundle.getText("MASTER_RECP_DELETE_ECC") + " " + mrNumber
                                    that.onShowSuccess(message);
                                    that.onProdStandardArchive();
                                    that._oDialog.close();
                                },
                                error: function (jqXHR, textStatus, error) {
                                    BusyIndicator.hide();
                                    let errorMessage = jqXHR.responseText ?
                                            JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                            var message = that.oResourceBundle.getText("ERROR_SUBMIT_PROD") + " " + errorMessage;
                                            that.onShowError(message);
                                            that._oDialog.close();
                                }
                            });
                        } else {
                            MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                        }
					   
						
																						
				 
            },
            onCreate: function () {
 // Set flag for Cancel confirmation
                this._isConfirming = true;		  
                zone = sap.ui.getCore().getModel("loginUserModel").getData().results[0].Zone;
                var iRowCount = this.getView().getModel("standardCycleModel").getData().standardCycleData.length;
                for (var i = 0; i < iRowCount; i++) {
                    if (this.getView().getModel("standardCycleModel").getData().standardCycleData[i].selected == true) {
                        speedValue = this.getView().getModel("standardCycleModel").getData().standardCycleData[i].speed;
                        bottleneckResource = this.getView().getModel("standardCycleModel").getData().standardCycleData[i].resource;
                        bottleneckSpeedUom = this.getView().getModel("standardCycleModel").getData().standardCycleData[i].nsUoM;
                        var capacityNo = this.getView().getModel("standardCycleModel").getData().standardCycleData[i].capacityNo;
                        var lineEfficiency = this.getView().getModel("standardCycleModel").getData().standardCycleData[i].lineEff;
                        var controlKey = this.getView().getModel("standardCycleModel").getData().standardCycleData[i].controlKey;
                        var destinationKey = this.getView().getModel("standardCycleModel").getData().standardCycleData[i].destinationKey;
                    }
                }

                plant = sap.ui.getCore().byId("idProdCreateReviewPlant").getText();
                var desc = sap.ui.getCore().byId("idProdCreateReviewDescription").getText();
                validFrom = sap.ui.getCore().byId("idProdCreateReviewValidFrom").getText();
                var modifiedFrom = sap.ui.getCore().byId("idProdCreateReviewModifiedFrom").getText();																 
                validTo = sap.ui.getCore().byId("idProdCreateReviewValidTo").getText();
                lotSize = sap.ui.getCore().byId("idProdCreateReviewLotSize").getText();
                mrNo = sap.ui.getCore().byId("idProdCreateReviewMrNo").getText();
                mrCounter = sap.ui.getCore().byId("idProdCreateReviewMrCounter").getText();
                chargeQty = sap.ui.getCore().byId("idProdCreateReviewChrgQty").getText();
                opQty = sap.ui.getCore().byId("idProdCreateReviewOperationQty").getText();
                var bottleneckCorrectVal = sap.ui.getCore().byId("idProdCreateBottleneckCorrect").getText();
                var bottleneckCorrect = (bottleneckCorrectVal === "True") ? "Y" : "N";
                //formula of AI = ('Process Order Size / Costing Lot Size' / 'Nominal speed')/((('Process Order Size / Costing Lot Size' / 'Nominal speed' / '% Line Efficiency') + SUM('Total Variable DT, H') / (1 - 'Total Planned DT Loss' [from Line Standard Headers]))) 
                var percentageAI = sap.ui.getCore().byId("idAIPercent").getText();
                var that = this;
                BusyIndicator.show(0);
                costCenter = sap.ui.getCore().byId("idHeaderProdCreateCostCenter").getText();
                var formattedDate = this.fnFormattedDate2(validFrom);
                var formattedDate3 = this.fnFormattedDate2(modifiedFrom);	 
                var formattedDate1 = this.fnFormattedDate2(validTo);
                // Variant fetch from DB
                var url = `odata/v4/data-services/getVariantProductStd(plant='${plant}',bottleneckResource='${bottleneckResource}',validFrom=${formattedDate})`;
                $.get(url)
                .done(function (response) {
                    var payload = that.onCreateSuccessCallBackData(response,that);
                    var sUrl = "odata/v4/data-services/insertProductStdItems";
                    $.ajax({
                        url: sUrl,
                        type: "POST",
                        data: JSON.stringify(payload),
                        contentType: "application/json"
                    })
                    .done(function (_response) {
                        BusyIndicator.hide();
                        var message = that.oResourceBundle.getText("PROD_STD_CREATION_SUCCESS") + " " + plant + ", Resource :" + bottleneckResource + ", CostCenter :" + costCenter + ".";
                        that.onShowSuccess(message);
                        var initialCallFlag = 0;
                        that.getProductStdHeaderData(initialCallFlag);
                    })
                    .fail(function (xhr, _status, _error) {
                        BusyIndicator.hide();
                        let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                xhr.responseJSON.error.message :
                                    that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                        var message = that.oResourceBundle.getText("PROD_STD_CREATION_FAIL") + " " + errorMessage;
                        that.onShowError(message);
                        var initialCallFlag = 0;
                        that.getProductStdHeaderData(initialCallFlag);
                    });
                    sap.ui.getCore().byId("wizardNavContainer").backToPage(sap.ui.getCore().byId("wizardContentPage"));
                    sap.ui.getCore().byId("CreateProductWizard").goToStep(sap.ui.getCore().byId("LineTypeStep"));
                    that._ProdCreate.close();

                }).fail(function (xhr, _status, _error) {
                    let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                            xhr.responseJSON.error.message :
                                this.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                    MessageToast.show(this.oResourceBundle.getText("VARIANT_ERROR") + " " + errorMessage);
                    BusyIndicator.hide();
                }.bind(this));


            },
            onCreateSuccessCallBackData: function(response,that){
                var variant = response.variant;
                var iRowCount = this.getView().getModel("standardCycleModel").getData().standardCycleData.length;
                for (var i = 0; i < iRowCount; i++) {
                    if (this.getView().getModel("standardCycleModel").getData().standardCycleData[i].selected === true) {
                        
                        bottleneckSpeedUom = this.getView().getModel("standardCycleModel").getData().standardCycleData[i].nsUoM;
                        var capacityNo = this.getView().getModel("standardCycleModel").getData().standardCycleData[i].capacityNo, lineEfficiency = this.getView().getModel("standardCycleModel").getData().standardCycleData[i].lineEff;                    
                       
                    }
                }
                plant = sap.ui.getCore().byId("idProdCreateReviewPlant").getText();
                var bottleneckCorrectVal = sap.ui.getCore().byId("idProdCreateBottleneckCorrect").getText();
                var bottleneckCorrect = (bottleneckCorrectVal === "True") ? "Y" : "N";
                //formula of AI = ('Process Order Size / Costing Lot Size' / 'Nominal speed')/((('Process Order Size / Costing Lot Size' / 'Nominal speed' / '% Line Efficiency') + SUM('Total Variable DT, H') / (1 - 'Total Planned DT Loss' [from Line Standard Headers])))
                var insertProdStdHdrData = that.onCreateGetProdHeaderData(bottleneckResource,variant,capacityNo,speedValue,bottleneckSpeedUom,totcrewSize,lineEfficiency,zone);

                // Get the table and its binding context
                var oMaterialTable = sap.ui.getCore().byId("idMaterialDB1");
                var oMaterialTableModel = oMaterialTable.getModel("materialDBCreateModel");
                var aMaterialTableData = oMaterialTableModel.getProperty("/materialData");

                // Prepare the material data
                var insertProdStdMaterialData = [];
                aMaterialTableData.forEach(function (rowData) {
                    insertProdStdMaterialData.push({
                        prodStdNo: "PR" + "_" + plant + "_" + bottleneckResource + "_" + validFrom + "_"+ variant,
                        material: parseInt((rowData.material),10),
                        materialDesc: rowData.materialDesc,
                        status: "Created"

                    });
                });

                // Get the table and its binding context
                var oVariableDtTable = sap.ui.getCore().byId("idVariableDtDB1");
                var oVariableDtTableModel = oVariableDtTable.getModel("variableDtDBModel");
                var aVariableDtTableData = oVariableDtTableModel.getProperty("/variableDtData");

                // Prepare the Variable DT data
                var insertProdStdVarDtData = [];
                aVariableDtTableData.forEach(function (rowData) {
                    insertProdStdVarDtData.push({
                        prodStdNo: "PR" + "_" + plant + "_" + bottleneckResource + "_" + validFrom + "_"+ variant,
                        lossCat: rowData.lossCat,
                        subCat: rowData.subCat,
                        durationInMin: rowData.duration,
                        freqInProdUom: rowData.frequency,
                        status: "Created",
                        procOrdrSizeOrCostingLotSize: rowData.processOrderLotSize,
                        totalVarDT: rowData.totVariableDt
                    });
                });

                var insertProdStdSecResData = that.onCreateProdStdSecResData(bottleneckResource,variant);
                // Get the table and its binding context
                var oBottleneckTable = sap.ui.getCore().byId("idBottleneckDB1");
                var oBottleneckTableModel = oBottleneckTable.getModel("standardCycleModel");
                var aBottleneckTableData = oBottleneckTableModel.getProperty("/standardCycleData");
                // Prepare the Bottleneck data
                var insertProdStdBottleneckData = [];
                aBottleneckTableData.forEach(function (rowData) {
                    insertProdStdBottleneckData.push({
                        prodStdNo: "PR" + "_" + plant + "_" + bottleneckResource + "_" + validFrom + "_"+ variant,
                        resource: rowData.resource,
                        status: "Created",
                        machine: rowData.machine,
                        nominalSpeed: rowData.speed,
                        nsUom: rowData.nsUoM,
                        bottleNckInd: bottleneckCorrect,
                        numOfPeople: rowData.peopleNo,
                        destinationKey: rowData.destinationKey,
                        controlKey: rowData.controlKey,
                        pctlineEfficiency: rowData.lineEff,
                        capacityNo: rowData.capacityNo
                    });
                });
                // Create the payload
                var payload = {
                        "insertProdStdHdrData": insertProdStdHdrData,
                        "insertProdStdMaterialData": insertProdStdMaterialData,
                        "insertProdStdVarDtData": insertProdStdVarDtData,
                        "insertProdStdSecResData": insertProdStdSecResData,
                        "insertProdStdBottleneckData": insertProdStdBottleneckData

                };
                return payload;
            },
            onCreateGetProdHeaderData: function( bottleneckResource,variant,capacityNo,speedValue,bottleneckSpeedUom,totcrewSize,lineEfficiency,zone){
                plant = sap.ui.getCore().byId("idProdCreateReviewPlant").getText();
                var desc = sap.ui.getCore().byId("idProdCreateReviewDescription").getText();
                validFrom = sap.ui.getCore().byId("idProdCreateReviewValidFrom").getText();
                var modifiedFrom = sap.ui.getCore().byId("idProdCreateReviewModifiedFrom").getText();															 
                validTo = sap.ui.getCore().byId("idProdCreateReviewValidTo").getText();
                lotSize = sap.ui.getCore().byId("idProdCreateReviewLotSize").getText();
                mrNo = sap.ui.getCore().byId("idProdCreateReviewMrNo").getText();
                mrCounter = sap.ui.getCore().byId("idProdCreateReviewMrCounter").getText();
                chargeQty = sap.ui.getCore().byId("idProdCreateReviewChrgQty").getText();
                opQty = sap.ui.getCore().byId("idProdCreateReviewOperationQty").getText();
                var semicreatedFlag = role === "S" ? true: false;
                //var semicreatedFlag = "";
                var bottleneckCorrectVal = sap.ui.getCore().byId("idProdCreateBottleneckCorrect").getText();
                var bottleneckCorrect = (bottleneckCorrectVal === "True") ? "Y" : "N";
                //formula of AI = ('Process Order Size / Costing Lot Size' / 'Nominal speed')/((('Process Order Size / Costing Lot Size' / 'Nominal speed' / '% Line Efficiency') + SUM('Total Variable DT, H') / (1 - 'Total Planned DT Loss' [from Line Standard Headers])))
                var percentageAI = sap.ui.getCore().byId("idAIPercent").getText();
                costCenter = sap.ui.getCore().byId("idHeaderProdCreateCostCenter").getText();
                var formattedDate = this.fnFormattedDate2(validFrom);
                var formattedDate1 = this.fnFormattedDate2(validTo);
				var formattedDate3 = this.fnFormattedDate2(modifiedFrom);														 
                var insertProdStdHdrData = [{
                    prodStdNo: "PR" + "_" + plant + "_" + bottleneckResource + "_" + validFrom + "_"+ variant,
                    configNo: plant + "_" + "PR" + "_" + bottleneckResource + "_" + costCenter,
                    plant: plant,
                    masterRecipeDesc: desc,
                    status: "Created",
                    bottleneckResource: bottleneckResource,
                    capacityNumber: capacityNo,
                    variant: variant,
                    costCenter: costCenter,
                    bottleneckCorrect: bottleneckCorrect,
                    validFrom: formattedDate,
					modifiedFrom: formattedDate3,							 
                    validTo: formattedDate1,
                    mrGroup: mrNo,
                    mrCounter: isNaN(parseFloat(mrCounter)) ? null : mrCounter,
                            nominalSpeed: speedValue,
                            nsUom: bottleneckSpeedUom,
                            crewSize: isNaN(parseFloat(totcrewSize)) ? "0" : totcrewSize,
                                    lineEfficiency: lineEfficiency,
                                    procOrdrSizeOrCostingLotSize: lotSize,
                                    chargeQty: chargeQty,
                                    operationQty: opQty,
                                    pctAI: percentageAI,
                                    ecm: "",
                                    auditInfoChannel: zone,
                                    stdApprLvl: 0,
                                    executionState: 0,
                                    executorsIDs: [],
                                    createdBySemiCreator:semicreatedFlag
                }];
                return insertProdStdHdrData
            },

            onCreateProdStdSecResData: function(bottleneckResource,variant){
                var plant = sap.ui.getCore().byId("idProdCreateReviewPlant").getText();
                var validFrom = sap.ui.getCore().byId("idProdCreateReviewValidFrom").getText();
                var oSecResTable = sap.ui.getCore().byId("idSecondaryResourceDB2");
                var oSecResTableModel = oSecResTable.getModel("secondaryresourceDBModel");
                var aSecResTableData = oSecResTableModel.getProperty("/SecondaryResData");

                // Prepare the Secondary resource data
                var insertProdStdSecResData = [];
                aSecResTableData.forEach(function (rowData) {
                    insertProdStdSecResData.push({
                        prodStdNo: "PR" + "_" + plant + "_" + bottleneckResource + "_" + validFrom + "_"+ variant,
                        resource: rowData.resource,
                        machine: rowData.machine,
                        secResource: rowData.secResource,
                        status: "Created",
                        energy1Type: rowData.energy1Type,
                        energy1Uom: rowData.energy1Uom,
                        energy1QtyPerHr: isNaN(parseFloat(rowData.energy1QtyPerHr)) ? null : parseFloat(rowData.energy1QtyPerHr),
                                energy2Type: rowData.energy2Type,
                                energy2Uom: rowData.energy2Uom,
                                energy2QtyPerHr: isNaN(parseFloat(rowData.energy2QtyPerHr)) ? null : parseFloat(rowData.energy2QtyPerHr),
                                        energy3Type: rowData.energy3Type,
                                        energy3Uom: rowData.energy3Uom,
                                        energy3QtyPerHr: isNaN(parseFloat(rowData.energy3QtyPerHr)) ? null : parseFloat(rowData.energy3QtyPerHr),
                                                energy4Type: rowData.energy4Type,
                                                energy4Uom: rowData.energy4Uom,
                                                energy4QtyPerHr: isNaN(parseFloat(rowData.energy4QtyPerHr)) ? null : parseFloat(rowData.energy4QtyPerHr),
                                                        energy5Type: rowData.energy5Type,
                                                        energy5Uom: rowData.energy5Uom,
                                                        energy5QtyPerHr: isNaN(parseFloat(rowData.energy5QtyPerHr)) ? null : parseFloat(rowData.energy5QtyPerHr),
                                                                energy6Type: rowData.energy6Type,
                                                                energy6Uom: rowData.energy6Uom,
                                                                energy6QtyPerHr: isNaN(parseFloat(rowData.energy6QtyPerHr)) ? null : parseFloat(rowData.energy6QtyPerHr),
                    });
                });
                return insertProdStdSecResData;
            },
            onProductionStdDBCreate: function () {								   
				 // Set flag for Cancel confirmation
                this._isConfirming = true;						  
                zone = sap.ui.getCore().getModel("loginUserModel").getData().results[0].Zone;
                var iRowCount = this.getView().getModel("globalResponseModel").getData().standardCycleData.length;
                for (var i = 0; i < iRowCount; i++) {
                    if (this.getView().getModel("globalResponseModel").getData().standardCycleData[i].controlKey === ("YBN1" || "YBN2" || "YBN3")) {
                        speedValue = this.getView().getModel("globalResponseModel").getData().standardCycleData[i].nominalSpeed;
                        bottleneckResource = this.getView().getModel("globalResponseModel").getData().standardCycleData[i].resource;
                        bottleneckSpeedUom = this.getView().getModel("globalResponseModel").getData().standardCycleData[i].nsUom;
                    }
                }
 
                plant = sap.ui.getCore().byId("idProdCreateCopyPlant").getText();
                validFrom = sap.ui.getCore().byId("idProdCreateCopyValidFrom").getText();
                var modifiedFrom = sap.ui.getCore().byId("idProdCreateCopyModifiedFrom").getText();																				   
                validTo = sap.ui.getCore().byId("idProdCreateCopyValidTo").getText();
                lotSize = sap.ui.getCore().byId("idProdCreateCopyLotSize").getText();
                mrNo = sap.ui.getCore().byId("idProdCreateCopyMrNo").getText();
                mrCounter = sap.ui.getCore().byId("idProdCreateCopyMrCounter").getText();
                chargeQty = sap.ui.getCore().byId("idProdCreateCopyChrgQty").getText();
                opQty = sap.ui.getCore().byId("idProdCreateCopyOperationQty").getText();
                var costCenter = sap.ui.getCore().byId("idProdCreateCopyCostCenter").getText();
				var formattedDate = this.fnFormattedDate2(validFrom);
                var formattedDate1 = this.fnFormattedDate2(validTo);
                var formattedDate3 = this.fnFormattedDate2(modifiedFrom);												 
                var that = this;
                BusyIndicator.show(0); //show busy indicator
                // Variant fetch from DB
                var url = `odata/v4/data-services/getVariantProductStd(plant='${plant}',bottleneckResource='${bottleneckResource}',validFrom=${formattedDate})`;
                $.get(url)
                    .done(function (response) {
                       
                        var payload = that.onProdCopySTDBCreatePayloadData(response,that);
                        var sUrl = "odata/v4/data-services/insertProductStdItems";
                        BusyIndicator.show(0);
                        $.ajax({
                            url: sUrl,
                            type: "POST",
                            data: JSON.stringify(payload),
                            contentType: "application/json"
                        })
                            .done(function (response) {
                                BusyIndicator.hide();
                                var message = that.oResourceBundle.getText("PROD_STD_CREATION_SUCCESS") + " " + plant + ", Resource :" + bottleneckResource + ", CostCenter :" + costCenter + ".";
                                that.onShowSuccess(message);
                                var initialCallFlag = 0;
                                that.getProductStdHeaderData(initialCallFlag);
                            })
                            .fail(function (xhr, _status, _error) {
                                BusyIndicator.hide();
                                let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                    xhr.responseJSON.error.message :
                                    that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                var message = that.oResourceBundle.getText("PROD_STD_CREATION_FAIL") + " " + errorMessage;
                                that.onShowError(message);
                                var initialCallFlag = 0;
                                that.getProductStdHeaderData(initialCallFlag);
                            });
                        //sap.ui.getCore().byId("wizardNavContainer").backToPage(sap.ui.getCore().byId("wizardContentPage"));
                        // sap.ui.getCore().byId("CreateProductWizard").goToStep(sap.ui.getCore().byId("LineTypeStep"));
                        that._oProdCopyCreateDialog.close();
 
                    }).fail(function (xhr, _status, _error) {
                        let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                            xhr.responseJSON.error.message :
                            this.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                        MessageToast.show(this.oResourceBundle.getText("VARIANT_ERROR") + " " + errorMessage);
                        BusyIndicator.hide();
                    }.bind(this));
            },
            onProdCopySTDBCreatePayloadData: function(response,that){
                var variant = response.variant;
                var iRowCount = this.getView().getModel("globalResponseModel").getData().standardCycleData.length;
                for (var i = 0; i < iRowCount; i++) {
                    if (this.getView().getModel("globalResponseModel").getData().standardCycleData[i].controlKey == ("YBN1" || "YBN2" || "YBN3")) {
                        var lineEfficiency = this.getView().getModel("globalResponseModel").getData().standardCycleData[i].pctlineEfficiency;
                        var capacityNumber = this.getView().getModel("globalResponseModel").getData().standardCycleData[i].capacityNo;
                    }
                }
                var bottleneckCorrectVal = sap.ui.getCore().byId("idProdCreateCopyBottleneckCorrect").getText();
                var bottleneckCorrect = (bottleneckCorrectVal === "True") ? "Y" : "N";
                var insertProdStdHdrData = that.onProdCopySTDDBCreateHeaderData(variant, capacityNumber, ecn);
                var insertProdStdSecResData = that.onProdCopySTDDBSecResData(variant);
                var oMaterialTable = sap.ui.getCore().byId("idMaterialDB3");
                var oMaterialTableModel = oMaterialTable.getModel("globalResponseModel");
                var aMaterialTableData = oMaterialTableModel.getProperty("/materialData");
               
                // Prepare the material data
                var insertProdStdMaterialData = [];
                aMaterialTableData.forEach(function (rowData) {
                    insertProdStdMaterialData.push({
                        prodStdNo: "PR" + "_" + plant + "_" + bottleneckResource + "_" + validFrom + "_" + variant,
                        material: parseInt((rowData.material), 10),
                        materialDesc: rowData.materialDesc,
                        status: "Created"
                    });
                });
               
                // Get the table and its binding context
                var oVariableDtTable = sap.ui.getCore().byId("idVariableDtDB3");
                var oVariableDtTableModel = oVariableDtTable.getModel("globalResponseModel");
                var aVariableDtTableData = oVariableDtTableModel.getProperty("/variableDtData");
                // Prepare the Variable DT data
                var insertProdStdVarDtData = [];
                aVariableDtTableData.forEach(function (rowData) {
                    insertProdStdVarDtData.push({
                        prodStdNo: "PR" + "_" + plant + "_" + bottleneckResource + "_" + validFrom + "_" + variant,
                        lossCat: rowData.lossCat,
                        subCat: rowData.subCat,
                        durationInMin: rowData.durationInMin,
                        freqInProdUom: rowData.freqInProdUom,
                        status: "Created",
                        procOrdrSizeOrCostingLotSize: rowData.procOrdrSizeOrCostingLotSize,
                        totalVarDT: rowData.totalVarDT
                    });
                });
               
                var oBottleneckTable = sap.ui.getCore().byId("idBottleneckDB2");
                var oBottleneckTableModel = oBottleneckTable.getModel("globalResponseModel");
                var aBottleneckTableData = oBottleneckTableModel.getProperty("/standardCycleData");
               
                // Prepare the Bottleneck data
                var insertProdStdBottleneckData = [];
                aBottleneckTableData.forEach(function (rowData) {
                    insertProdStdBottleneckData.push({
                        prodStdNo: "PR" + "_" + plant + "_" + bottleneckResource + "_" + validFrom + "_" + variant,
                        resource: rowData.resource,
                        status: "Created",
                        machine: rowData.machine,
                        nominalSpeed: rowData.nominalSpeed,
                        nsUom: rowData.nsUom,
                        bottleNckInd: bottleneckCorrect,
                        numOfPeople: rowData.numOfPeople,
                        destinationKey: rowData.destinationKey,
                        controlKey: rowData.controlKey,
                        pctlineEfficiency: rowData.pctlineEfficiency,
                        capacityNo: rowData.capacityNo
                    });
                });
                var payload = {
                    "insertProdStdHdrData": insertProdStdHdrData,
                    "insertProdStdMaterialData": insertProdStdMaterialData,
                    "insertProdStdVarDtData": insertProdStdVarDtData,
                    "insertProdStdSecResData": insertProdStdSecResData,
                    "insertProdStdBottleneckData": insertProdStdBottleneckData
                };
                return payload;
            },
            onProdCopySTDDBCreateHeaderData: function (variant, capacityNumber, ecn) {
                //role = sap.ui.getCore().getModel("loginUserModel").getData().results[0].AuthType;
                var semicreatedFlag = role === "S" ? true: false;
                var desc = sap.ui.getCore().byId("idProdCreateCopyDescription").getText(), costCenter = sap.ui.getCore().byId("idProdCreateCopyCostCenter").getText();

                var percentageAI = sap.ui.getCore().byId("idProdCreateCopyAiPercent").getText();
                var lineEfficiency = sap.ui.getCore().byId("idProdCreateCopyEff").getText();
                var totCrewSize = sap.ui.getCore().byId("idProdCreateCopyCrewSize").getText();
				var modifiedFrom = sap.ui.getCore().byId("idProdCreateCopyModifiedFrom").getText();
                var bottleneckCorrectVal = sap.ui.getCore().byId("idProdCreateCopyBottleneckCorrect").getText();
                var bottleneckCorrect = (bottleneckCorrectVal === "True") ? "Y" : "N";

                var formattedDate = this.fnFormattedDate2(validFrom);
                var formattedDate1 = this.fnFormattedDate2(validTo);
				var formattedDate3 = this.fnFormattedDate2(modifiedFrom);														 
                var insertProdStdHdrData = [{
                    prodStdNo: "PR" + "_" + plant + "_" + bottleneckResource + "_" + validFrom + "_" + variant,
                    configNo: plant + "_" + "PR" + "_" + bottleneckResource + "_" + costCenter,
                    plant: plant,
                    status: "Created",
                    bottleneckResource: bottleneckResource,
                    masterRecipeDesc: desc,
                    capacityNumber: capacityNumber,
                    variant: variant,
                    costCenter: costCenter,
                    bottleneckCorrect: bottleneckCorrect,
                    validFrom: formattedDate,
					modifiedFrom: formattedDate3,							 
                    validTo: formattedDate1,
                    mrGroup: mrNo,
                    mrCounter: isNaN(parseFloat(mrCounter)) ? null : mrCounter,
                    nominalSpeed: speedValue,
                    nsUom: bottleneckSpeedUom,
                    crewSize: isNaN(parseFloat(totCrewSize)) ? "0" : totCrewSize,
                    lineEfficiency: lineEfficiency,
                    procOrdrSizeOrCostingLotSize: lotSize,
                    chargeQty: chargeQty,
                    operationQty: opQty,
                    pctAI: percentageAI,
                    ecm: ecn,
                    auditInfoChannel: zone,
                    stdApprLvl: 0,
                    executionState: 0,
                    executorsIDs: [],
                    createdBySemiCreator:semicreatedFlag
                }];
                return insertProdStdHdrData;
            },
            onProdCopySTDDBSecResData: function(variant){
                // Get the table and its binding context
                var oSecResTable = sap.ui.getCore().byId("idSecondaryResourceDB3");
                var oSecResTableModel = oSecResTable.getModel("globalResponseModel");
                var aSecResTableData = oSecResTableModel.getProperty("/SecondaryResData");
                // Prepare the Secondary resource data
                var insertProdStdSecResData = [];
                aSecResTableData.forEach(function (rowData) {
                    insertProdStdSecResData.push({
                        prodStdNo: "PR" + "_" + plant + "_" + bottleneckResource + "_" + validFrom + "_" + variant,
                        resource: rowData.resource,
                        machine: rowData.machine,
                        secResource: rowData.secResource,
                        status: "Created",
                        energy1Type: rowData.energy1Type,
                        energy1Uom: rowData.energy1Uom,
                        energy1QtyPerHr: isNaN(parseFloat(rowData.energy1QtyPerHr)) ? null : parseFloat(rowData.energy1QtyPerHr),
                        energy2Type: rowData.energy2Type,
                        energy2Uom: rowData.energy2Uom,
                        energy2QtyPerHr: isNaN(parseFloat(rowData.energy2QtyPerHr)) ? null : parseFloat(rowData.energy2QtyPerHr),
                        energy3Type: rowData.energy3Type,
                        energy3Uom: rowData.energy3Uom,
                        energy3QtyPerHr: isNaN(parseFloat(rowData.energy3QtyPerHr)) ? null : parseFloat(rowData.energy3QtyPerHr),
                        energy4Type: rowData.energy4Type,
                        energy4Uom: rowData.energy4Uom,
                        energy4QtyPerHr: isNaN(parseFloat(rowData.energy4QtyPerHr)) ? null : parseFloat(rowData.energy4QtyPerHr),
                        energy5Type: rowData.energy5Type,
                        energy5Uom: rowData.energy5Uom,
                        energy5QtyPerHr: isNaN(parseFloat(rowData.energy5QtyPerHr)) ? null : parseFloat(rowData.energy5QtyPerHr),
                        energy6Type: rowData.energy6Type,
                        energy6Uom: rowData.energy6Uom,
                        energy6QtyPerHr: isNaN(parseFloat(rowData.energy6QtyPerHr)) ? null : parseFloat(rowData.energy6QtyPerHr),
                    });
                });
               return insertProdStdSecResData;
           },
           handleCloseButtonProdCopyCreate: function () {
                if (this._isConfirming) {
                    return;
                }
                this._isConfirming = true;
                sap.m.MessageBox.confirm(
                    "Are you sure you want to cancel? Any unsaved changes will be lost.",
                    {
                        onClose: function (oAction) {
                            if (oAction === sap.m.MessageBox.Action.OK) {
                                sap.ui.getCore().byId("idProdCopyCreateReviewDesc").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdCopyCreateReviewValidFrom").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdCopyCreateReviewModifiedFrom").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdCopyCreateReviewValidTo").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdCopyCreateReviewLotSize").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdCopyCreateReviewMrNo").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdCopyCreateReviewMrCounter").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdCopySpeed").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdCopyNsUoM").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdCopyDestinationKey").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdCopyControlKey").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdCopyLineEff").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdCopyPeopleNo").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdCopyDuration").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdCopyFrequency").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdcopyLossCat").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdcopySubCat").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdCopyGetMachine").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdCopycapacityNo").setValue("").setValueState("None");
                                var oResourceField = sap.ui.getCore().byId("idProdCopyGetResource");
                                if (oResourceField) {
                                    oResourceField.setSelectedKey("");
                                }
                                sap.ui.getCore().byId("idProdCopyGetResource").setEditable(true);
                                sap.ui.getCore().byId("idProdCopyGetMachine").setEditable(false);
                                sap.ui.getCore().byId("idProdCopyMachineDesc").setEditable(false);
                                sap.ui.getCore().byId("idProdCopycapacityNo").setEditable(false);
                                sap.ui.getCore().byId("idProdCopyCreateReviewChrgQty").setValue("1").setValueState("None");
                                sap.ui.getCore().byId("idProdCopyCreateReviewOperationQty").setValue("1").setValueState("None");
                                var oGlobalModel = this.getView().getModel("globalResponseModel");
                                if (oGlobalModel) {
                                    oGlobalModel.setProperty("/materialData", []);
                                }
                                var oWizard = sap.ui.getCore().byId("copyCreateProductWizard");
                                if (oWizard) {
                                    var oFirstStep = oWizard.getSteps()[0];
                                    oWizard.discardProgress(oFirstStep);
                                    oFirstStep.setValidated(true);
                                }
                                sap.ui.getCore().byId("wizardCopyNavContainer").to(sap.ui.getCore().byId("wizardCopyReviewPage"));
                                this._oProdCopyCreateDialog.close();
                            } else {
                                this._isConfirming = false;
                            }
                        }.bind(this)
                    }
																					 
																											   
																												

																											   
																													

																					  
									   
																							   
					 

											
																				   
								  
															   
                );
													  
					 

																	
																													  

									   
														
				 
            },
            handleCloseProdEditButton: function () {
                if (this._isConfirming) {
                    return;
                }
                this._isConfirming = true;
                sap.m.MessageBox.confirm(
                    "Are you sure you want to cancel? Any unsaved changes will be lost.",
                    {
                        onClose: function (oAction) {
                            if (oAction === sap.m.MessageBox.Action.OK) {
                                sap.ui.getCore().byId("idProdUpdateDesc").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdUpdateValidFrom").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idUpdateModifiedFrom").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdUpdateValidTo").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdUpdateLotSize").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdUpdateMrNo").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdUpdateMrCounter").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdUpdateSpeed").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdUpdateNsUoM").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdUpdateDestinationKey").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdUpdateControlKey").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdUpdateLineEff").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdUpdatePeopleNo").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdUpdateDuration").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdUpdateFrequency").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdUpdateLossCat").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdUpdateSubCat").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdUpdateGetMachine").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdUpdateMachineDesc").setValue("").setValueState("None");
                                sap.ui.getCore().byId("idProdUpdatecapacityNo").setValue("").setValueState("None");
                                var oResourceField = sap.ui.getCore().byId("idProdUpdateGetResource");
                                if (oResourceField) {
                                    oResourceField.setSelectedKey("");
                                }
                                sap.ui.getCore().byId("idProdUpdateGetResource").setEditable(true);
                                sap.ui.getCore().byId("idProdUpdateGetMachine").setEditable(false);
                                sap.ui.getCore().byId("idProdUpdateMachineDesc").setEditable(false);
                                sap.ui.getCore().byId("idProdUpdatecapacityNo").setEditable(false);
                                sap.ui.getCore().byId("idProdUpdateChrgQty").setValue("1").setValueState("None");
                                sap.ui.getCore().byId("idProdUpdateOperationQty").setValue("1").setValueState("None");
                                var oGlobalModel = this.getView().getModel("globalResponseModel");
                                if (oGlobalModel) {
                                    oGlobalModel.setProperty("/materialData", []);
                                }
                                var oWizard = sap.ui.getCore().byId("updateProductWizard");
                                if (oWizard) {
                                    var oFirstStep = oWizard.getSteps()[0];
                                    oWizard.discardProgress(oFirstStep);
                                    oFirstStep.setValidated(true);
                                }
                                sap.ui.getCore().byId("wizardProdUpdateNavContainer").to(sap.ui.getCore().byId("wizardProdUpdateContentPage"));
                                this._ProductUpdate.close();
                            } else {
                                this._isConfirming = false;
                            }
                        }.bind(this)
                    }
			  
															   
                );	 
            },
            // handleCloseProdEditButton: function () {
            //     if (this._isConfirming) {
            //         return;
												
            //     }
            //     this._isConfirming = true;
            //     sap.m.MessageBox.confirm(
            //         "Are you sure you want to cancel? Any unsaved changes will be lost.",
            //         {
            //             onClose: function (oAction) {
            //                 if (oAction === sap.m.MessageBox.Action.OK) {
            //                     if (this._ProductUpdate) {
            //                         this._ProductUpdate.close();
            //                     }
            //                 } else {
            //                     this._isConfirming = false;
            //                 }
            //             }.bind(this)
            //         }
            //     );
            // },
            onProductionStdDBUpdate: function () {
												   
				 this._isConfirming = true;						  
                zone = sap.ui.getCore().getModel("loginUserModel").getData().results[0].Zone;
                var iRowCount = this.getView().getModel("globalResponseModel").getData().standardCycleData.length;
								   
                for (var i = 0; i < iRowCount; i++) {
                    if (this.getView().getModel("globalResponseModel").getData().standardCycleData[i].controlKey === ("YBN1" || "YBN2" || "YBN3")) {
                        speedValue = this.getView().getModel("globalResponseModel").getData().standardCycleData[i].nominalSpeed;
                        bottleneckResource = this.getView().getModel("globalResponseModel").getData().standardCycleData[i].resource;
                        bottleneckSpeedUom = this.getView().getModel("globalResponseModel").getData().standardCycleData[i].nsUom;
                        var lineEfficiency = this.getView().getModel("globalResponseModel").getData().standardCycleData[i].pctlineEfficiency;
                        var capacityNumber = this.getView().getModel("globalResponseModel").getData().standardCycleData[i].capacityNo;
                    }
                }
                //role = sap.ui.getCore().getModel("loginUserModel").getData().results[0].AuthType;
                if (semicreatedFlagEnbaled === false){
                    if (role === "S"){
                        var semicreatedFlag = true;
                    }else{
                        var semicreatedFlag = false;
                    }
                }
                
                plant = sap.ui.getCore().byId("idProdUpdateReviewPlant").getText();
                var desc = sap.ui.getCore().byId("idProdUpdateReviewDescription").getText();
				var modifiedFrom = sap.ui.getCore().byId("idProdUpdateReviewModifiedFrom").getText();
                validFrom = sap.ui.getCore().byId("idProdUpdateReviewValidFrom").getText();
                validTo = sap.ui.getCore().byId("idProdUpdateReviewValidTo").getText();
                lotSize = sap.ui.getCore().byId("idProdUpdateReviewLotSize").getText();
                mrNo = sap.ui.getCore().byId("idProdUpdateReviewMrNo").getText();
                mrCounter = sap.ui.getCore().byId("idProdUpdateReviewMrCounter").getText();
                chargeQty = sap.ui.getCore().byId("idProdUpdateReviewChrgQty").getText();
                opQty = sap.ui.getCore().byId("idProdUpdateReviewOperationQty").getText();
                var lineEfficiency = sap.ui.getCore().byId("idProdUpdateReviewEff").getText();
                var percentageAI = sap.ui.getCore().byId("idProdUpdateReviewAiPercent").getText();
                var totCrewSize = sap.ui.getCore().byId("idProdUpdateReviewCrewSize").getText();
                var bottleneckCorrectVal = sap.ui.getCore().byId("idProdUpdateReviewBottleneckCorrect").getText();
                var bottleneckCorrect = (bottleneckCorrectVal === "True") ? "Y" : "N";
                var that = this;
                costCenter = sap.ui.getCore().byId("idProdUpdateReviewCostCenter").getText();
                var formattedDate = this.fnFormattedDate2(validFrom);
                var formattedDate1 = this.fnFormattedDate2(validTo);
                var formattedDate3 = this.fnFormattedDate2(modifiedFrom);														 
                //var currentPrdStdNo = "PR" + "_" + plant + "_" + bottleneckResource + "_" + validFrom + "_" + variant;
                // if (currentPrdStdNo != prdStandardNo) {
                //     this.onShowWarning(this.oResourceBundle.getText("WARNING_DO_NOT_CHANGE"))
                // }
                //  else {
                    var updateProdStdHdrData = [{
                        ID: ID,
                        prodStdNo: prdStandardNo,
                        //configNo: plant + "_" + "PR" + "_" + currentBottleneckRes + "_" + currentCostCenter,
                        plant: plant,
                        status: "Modified",
                        bottleneckResource: bottleneckResource,
                        masterRecipeDesc: desc,
                        capacityNumber: capacityNumber,
                        variant: variant,
                        costCenter: costCenter,
                        bottleneckCorrect: bottleneckCorrect,
						modifiedFrom: formattedDate3,
                        //validFrom: formattedDate,
                        validTo: formattedDate1,
                        mrGroup: mrNo,
                        mrCounter: isNaN(parseFloat(mrCounter)) ? null : mrCounter,
                                nominalSpeed: speedValue,
                                nsUom: bottleneckSpeedUom,
                                crewSize: totCrewSize,
                                lineEfficiency: lineEfficiency,
                                procOrdrSizeOrCostingLotSize: lotSize,
                                chargeQty: chargeQty,
                                operationQty: opQty,
                                pctAI: percentageAI,
                                ecm: ecn,
                                auditInfoChannel: zone,
                                stdApprLvl: 0,
                                executionState: 0,
                                executorsIDs: [],
                                reworkComment: null,
                                createdBySemiCreator: semicreatedFlag
                    }];
                    // Get the table and its binding context
                    var oMaterialTable = sap.ui.getCore().byId("idMaterialDB6");
                    var oMaterialTableModel = oMaterialTable.getModel("globalResponseModel");
                    var aMaterialTableData = oMaterialTableModel.getProperty("/materialData");

                    // Prepare the material data
                    var updateProdStdMaterialData = [];
                    aMaterialTableData.forEach(function (rowData) {
                        updateProdStdMaterialData.push({
                            ID: rowData.ID,
                            prodStdNo: prdStandardNo,
                            material: parseInt((rowData.material),10),
                            materialDesc: rowData.materialDesc,
                            status: "Modified"
                        });
                    });
				   
                    // Get the table and its binding context
                    var oVariableDtTable = sap.ui.getCore().byId("idVariableDtDB6");
                    var oVariableDtTableModel = oVariableDtTable.getModel("globalResponseModel");
                    var aVariableDtTableData = oVariableDtTableModel.getProperty("/variableDtData");
                    // Prepare the Variable DT data
                    var updateProdStdVarDtData = [];
                    aVariableDtTableData.forEach(function (rowData) {
                        updateProdStdVarDtData.push({
                            ID: rowData.ID,
                            prodStdNo: prdStandardNo,														
                            lossCat: rowData.lossCat,
                            subCat: rowData.subCat,
                            durationInMin: rowData.durationInMin,
                            freqInProdUom: rowData.freqInProdUom,
                            status: "Modified",
                            procOrdrSizeOrCostingLotSize: rowData.procOrdrSizeOrCostingLotSize,
                            totalVarDT: rowData.totalVarDT
                        });
                    });
                    // Get the table and its binding context
                    var oSecResTable = sap.ui.getCore().byId("idSecondaryResourceDB6");
                    var oSecResTableModel = oSecResTable.getModel("globalResponseModel");
                    var aSecResTableData = oSecResTableModel.getProperty("/SecondaryResData");
                    // Prepare the Secondary resource data
                    var updateProdStdSecResData = [];
                    aSecResTableData.forEach(function (rowData) {
                        let updateData = {
                            prodStdNo: prdStandardNo,
                            resource: rowData.resource,
                            machine: rowData.machine,
                            secResource: rowData.secResource,
                            status: "Modified",
                            energy1Type: rowData.energy1Type,
                            energy1Uom: rowData.energy1Uom,
                            energy1QtyPerHr: isNaN(parseFloat(rowData.energy1QtyPerHr)) ? null : parseFloat(rowData.energy1QtyPerHr),
                            energy2Type: rowData.energy2Type,
                            energy2Uom: rowData.energy2Uom,
                            energy2QtyPerHr: isNaN(parseFloat(rowData.energy2QtyPerHr)) ? null : parseFloat(rowData.energy2QtyPerHr),
                            energy3Type: rowData.energy3Type,
                            energy3Uom: rowData.energy3Uom,
                            energy3QtyPerHr: isNaN(parseFloat(rowData.energy3QtyPerHr)) ? null : parseFloat(rowData.energy3QtyPerHr),
                            energy4Type: rowData.energy4Type,
                            energy4Uom: rowData.energy4Uom,
                            energy4QtyPerHr: isNaN(parseFloat(rowData.energy4QtyPerHr)) ? null : parseFloat(rowData.energy4QtyPerHr),
                            energy5Type: rowData.energy5Type,
                            energy5Uom: rowData.energy5Uom,
                            energy5QtyPerHr: isNaN(parseFloat(rowData.energy5QtyPerHr)) ? null : parseFloat(rowData.energy5QtyPerHr),
                            energy6Type: rowData.energy6Type,
                            energy6Uom: rowData.energy6Uom,
                            energy6QtyPerHr: isNaN(parseFloat(rowData.energy6QtyPerHr)) ? null : parseFloat(rowData.energy6QtyPerHr)
                        };
                    
                        // Only add the ID property if rowData.ID is not empty
                        if (rowData.ID && rowData.ID.trim() !== "") {
                            updateData.ID = rowData.ID;
                        }
                    
                        // Push the updated data to the array
                        updateProdStdSecResData.push(updateData);
                    });
                    
                    // Get the table and its binding context
                    var oBottleneckTable = sap.ui.getCore().byId("idBottleneckDB6");
                    var oBottleneckTableModel = oBottleneckTable.getModel("globalResponseModel");
                    var aBottleneckTableData = oBottleneckTableModel.getProperty("/standardCycleData");

                    // Prepare the Bottleneck data
                    var updateProdStdBottleneckData = [];
                    aBottleneckTableData.forEach(function (rowData) {
                        updateProdStdBottleneckData.push({
                            ID: rowData.ID,
                            prodStdNo: prdStandardNo,
                            resource: rowData.resource,
                            status: "Modified",
                            machine: rowData.machine,
                            nominalSpeed: rowData.nominalSpeed,
                            nsUom: rowData.nsUom,
                            bottleNckInd: bottleneckCorrect,
                            numOfPeople: rowData.numOfPeople,
                            destinationKey: rowData.destinationKey,
                            controlKey: rowData.controlKey,
                            pctlineEfficiency: rowData.pctlineEfficiency,
                            capacityNo: rowData.capacityNo
                        });
                    });
				   

                    // Create the payload
                    var payload = {
                            "updateProdStdHdrData": updateProdStdHdrData,
                            "updateProdStdMaterialData": updateProdStdMaterialData,
                            "updateProdStdVarDtData": updateProdStdVarDtData,
                            "updateProdStdSecResData": updateProdStdSecResData,
                            "updateProdStdBottleneckData": updateProdStdBottleneckData,
                            "deleteProdStdMaterialData": deleteProdStdMaterialData,
                            "deleteProdStdVarDtData": deleteProdStdVarDtData,
                            "deleteProdStdSecResData": deleteProdStdSecResData,
                            "deleteProdStdBottleneckData": deleteProdStdBottleneckData
                    };
                    var sUrl = "odata/v4/data-services/upsertProductStdItems";
                    BusyIndicator.show(0);
                    $.ajax({
                        url: sUrl,
                        type: "POST",
                        data: JSON.stringify(payload),
                        contentType: "application/json"
                    })
                    .done(function (response) {
                        BusyIndicator.hide();
                        var message = that.oResourceBundle.getText("PROD_STD_UPDATE_SUCCESS") + " " + plant + ", Resource :" + bottleneckResource + ", CostCenter :" + costCenter + ".";
                        that.onShowSuccess(message);
                        var initialCallFlag = 0;
                        that.getProductStdHeaderData(initialCallFlag);
                    })
                    .fail(function (xhr, status, error) {
                        BusyIndicator.hide();
                        let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                xhr.responseJSON.error.message :
                                    that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                        var message = that.oResourceBundle.getText("PROD_STD_UPDATE_FAIL") + " " + errorMessage;
                        that.onShowError(message);
                        var initialCallFlag = 0;
                        that.getProductStdHeaderData(initialCallFlag);
                    });
                    //sap.ui.getCore().byId("wizardNavContainer").backToPage(sap.ui.getCore().byId("wizardContentPage"));
                    //sap.ui.getCore().byId("CreateProductWizard").goToStep(sap.ui.getCore().byId("LineTypeStep"));
                    this._ProductUpdate.close();
            

            },
            fnDateFormatted: function (validdate) {
                const monthNames = [
                    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
                    ];

                // Split the input date string (assuming the format is "DD-MM-YYYY")
                const parts = validdate.split('-');
                const day = parseInt(parts[0], 10);   // Day
                const month = parseInt(parts[1], 10) - 1; // Month (0-based index)
                const year = parseInt(parts[2], 10);   // Year

                // Create a new Date object
                const date = new Date(year, month, day);

                // Format the date
                const formattedDateVal = `${monthNames[date.getMonth()]} ${day}, ${year}`;
                return formattedDateVal;
            },

            fnFormattedDate: function (validdate) {
                const date = new Date(validdate);
                const day = String(date.getDate()).padStart(2, '0');
                const month = String(date.getMonth() + 1).padStart(2, '0');
                const year = date.getFullYear();
                formattedDateVal = `${day}-${month}-${year}`;
                return formattedDateVal;
            },
            fnFormattedDate1: function (date) {
                var parts = date.split('-');
                var year = parts[0];
                var month = parts[1];
                var day = parts[2];
                var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
                    ];
                var monthName = monthNames[parseInt(month, 10) - 1];
                formattedDateVal = monthName + " " + parseInt(day, 10) + ", " + year;
                return formattedDateVal;
            },
            fnFormattedDate2: function (date) {
                let part1 = date.split("-");
                let day1 = part1[0];
                let month1 = part1[1];
                let year1 = part1[2];
                // Format the date as YYYY-MM-DD
                formattedDateVal = `${year1}-${month1}-${day1}`;
                return formattedDateVal;
            },
            // fnAskMe: function(){
            //     var that = this;
            //     if (!this._oQnADialog) {
            //         this._oQnADialog = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.MasterRecipeSimulation", this);
            //         this.getView().addDependent(this._oQnADialog);
            //     }
            //     this._oQnADialog.open();
            //     var phaseModel = new sap.ui.model.json.JSONModel();
            //     phaseModel.setData({
			// 			"phaseData": [{
			// 				Phase: "Runtime Phase",
            //                 PhaseNo: "110"
			// 			},
			// 			{
			// 				Phase: "Runtime Phase",
            //                 PhaseNo: "120"
			// 			},
			// 			{
			// 				Phase: "Quality Phase",
            //                 PhaseNo: "130"
			// 			},
			// 			{
			// 				Phase: "Runtime Phase",
            //                 PhaseNo: "210"
			// 			},
            //             {
			// 				Phase: "Quality Phase",
            //                 PhaseNo: "220"
			// 			}
			// 			],
			// 		});
			// 		this.getView().setModel(phaseModel, "phaseModel");
            // //     var sUrl = "odata/v4/data-services/LineAndLaborAIService";
            // //     BusyIndicator.show(0);
            // //     $.ajax({
            // //         url: sUrl,
            // //         method: 'GET',
                   
            // //         success: function (data) {
            // //             BusyIndicator.hide();
            // //             var oQnAModel = new sap.ui.model.json.JSONModel(data);
                        
            // //             oQnAModel.setProperty("/answer", "");
	
                       
            // //             //that.byId("questionSelect").setSelectedKey();
                        
            // //             that.getView().setModel(oQnAModel,"oQnAModel");
            // //             //MessageToast.show(that.oResourceBundle.getText("PROD_FILTER_LOAD_SUCCESS"));
            // //         },
            // //         error: function (xhr, status, error) {
            // //             BusyIndicator.hide();
            // //             let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
            // //                     xhr.responseJSON.error.message :
            // //                         that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
            // //             //MessageToast.show(that.oResourceBundle.getText("PROD_FILTER_LOAD_FAIL") + " " + errorMessage);
            // //         }
            // //     });
            // // },
            // // handleCloseQnADialog: function(){
            // //     this._oQnADialog.close();
          
            // // },
            // // onQuestionChange: function (oEvent) {
                
            // //     var sSelectedKey = oEvent.getSource().getSelectedKey();
            // //     var oModel = this.getView().getModel("oQnAModel");
            // //     var aQuestions = oModel.getProperty("/value");
            // //     var oSelectedQuestion = aQuestions.find(function (question) {
            // //         return question.AI_ID === sSelectedKey;
            // //     });
            // //     if (oSelectedQuestion) {
            // //         // Set the answer property based on the selected question's feedbackProvidedByAI
            // //         //that.byId("answerLbl").setVisible(true);
            // //         oModel.setProperty("/answer", oSelectedQuestion.feedbackProvidedByAI);
            // //        // this.getView().getId("answerText").setText(oSelectedQuestion.feedbackProvidedByAI)
            // //         console.log("Answer set: ", oSelectedQuestion.feedbackProvidedByAI);
                  

            // //     } else {
            // //         console.log("No answer found for selected question: ", sSelectedKey);
            // //     }
                
            // //     // Refresh model to ensure UI is updated
            // //     oModel.refresh(true);
            // },
            handleCloseMRSimulationButton: function(){
                if(this._oSimulationDialog){
                this._oSimulationDialog.close();
                }        
            },
            onUpArrowPress: function(){
                var oTable = this.getView().byId("idMRSimulationTable");
                var oSelectedTableIndex = oTable.getSelectedIndices();
                var simulatedDataModel = oTable.getModel("phaseSimulationModel");
                var simulatedData = oTable.getModel("phaseSimulationModel").getData();
                if(oSelectedTableIndex.length>1){
                    var message =  this.oResourceBundle.getText("MR_SIMULATION_ROW_SELECTION_MULTIPLE_WARNING");
                    this.onShowWarning(message);
                }else{
                     if ((simulatedData.HeaderToOperation[oSelectedTableIndex].PhaseType === "R")||(simulatedData.HeaderToOperation[oSelectedTableIndex].PhaseType === undefined) ){
                        var message =  this.oResourceBundle.getText("MR_SIMULATION_ROW_PHASE_SELECTION_WARNING");
                        this.onShowWarning(message);
                    }else if (oSelectedTableIndex.length === 0){
                        var message =  this.oResourceBundle.getText("MR_SIMULATION_ROW_NO_SELECTION_WARNING");
                        this.onShowWarning(message);
                    }else if (oSelectedTableIndex-2 === -1){
                        var message =  this.oResourceBundle.getText("MR_SIMULATION_ROW_UP_SELECTION_WARNING");
                        this.onShowWarning(message);
                    }
                    else if (simulatedData.HeaderToOperation[oSelectedTableIndex-2].Loekz === "D"){
                        var message =  this.oResourceBundle.getText("MR_SIMULATION_ROW_UP_DELETION_WARNING");
                        this.onShowWarning(message);
                    }else if (simulatedData.HeaderToOperation[oSelectedTableIndex-1].PhaseType === undefined){
                        var oSelectedRow = { ...simulatedData.HeaderToOperation[oSelectedTableIndex]};
                        var selectedPhaseNo = simulatedData.HeaderToOperation[oSelectedTableIndex].Vornr;
                        var oTargetRow = { ...simulatedData.HeaderToOperation[oSelectedTableIndex-2]};
                        var targetPhaseNo = simulatedData.HeaderToOperation[oSelectedTableIndex-2].Vornr;
                        // simulatedData.HeaderToOperation[oSelectedTableIndex-2] = oSelectedRow;
                        //simulatedData.HeaderToOperation[oSelectedTableIndex-2].Origin_Act_Num = targetPhaseNo;
                        var newPhaseNo = (parseInt(targetPhaseNo) + 10).toString().padStart(4,"0");
                        var newRow = {
                            ...oSelectedRow, // Copy the selected row's data
                            Vornr: newPhaseNo, // Set the new row's phase number (incremented by 10)
                            Pvznr: simulatedData.HeaderToOperation[oSelectedTableIndex[0]-2].Pvznr
                        };
                        simulatedData.HeaderToOperation.splice(oSelectedTableIndex - 1, 0, newRow);
                        simulatedData.HeaderToOperation.splice(oSelectedTableIndex[0]+1, 1);
                        for (var m = oSelectedTableIndex[0]+1; m <simulatedData.HeaderToOperation.length; m ++){
                            if(simulatedData.HeaderToOperation[m].PhaseType === undefined){
                                break;
                        }else{
                        var currentPhaseNo = parseInt(simulatedData.HeaderToOperation[m].Vornr);
                        simulatedData.HeaderToOperation[m].Vornr = (currentPhaseNo -10).toString().padStart(4,"0");
                        }
                    }

                    }else{
                        var oSelectedRow = { ...simulatedData.HeaderToOperation[oSelectedTableIndex]};
                        var selectedPhaseNo = simulatedData.HeaderToOperation[oSelectedTableIndex].Vornr;
                        var oTargetRow = { ...simulatedData.HeaderToOperation[oSelectedTableIndex-1]};
                        var targetPhaseNo = simulatedData.HeaderToOperation[oSelectedTableIndex-1].Vornr;
                        var selectedOriginPhaseNo = simulatedData.HeaderToOperation[oSelectedTableIndex].Origin_Act_Num;
                        var targetOriginPhaseNo = simulatedData.HeaderToOperation[oSelectedTableIndex-1].Origin_Act_Num;
                        simulatedData.HeaderToOperation[oSelectedTableIndex]= oTargetRow;
                        simulatedData.HeaderToOperation[oSelectedTableIndex].Vornr = selectedPhaseNo;
                        simulatedData.HeaderToOperation[oSelectedTableIndex].Origin_Act_Num = targetOriginPhaseNo;
                        simulatedData.HeaderToOperation[oSelectedTableIndex-1] = oSelectedRow;
                        simulatedData.HeaderToOperation[oSelectedTableIndex-1].Vornr = targetPhaseNo;
                        simulatedData.HeaderToOperation[oSelectedTableIndex-1].Origin_Act_Num = selectedOriginPhaseNo;
                        
                       
                }
             }
             oTable.clearSelection();
            
             simulatedDataModel.refresh();
           

            },
            onDownArrowPress: function(){
                var oTable = this.getView().byId("idMRSimulationTable");
                var oSelectedTableIndex = oTable.getSelectedIndices();
                var simulatedDataModel = oTable.getModel("phaseSimulationModel");
                var simulatedData = oTable.getModel("phaseSimulationModel").getData();
                if(oSelectedTableIndex.length>1){
                    var message =  this.oResourceBundle.getText("MR_SIMULATION_ROW_SELECTION_MULTIPLE_WARNING");
                    this.onShowWarning(message);
                }else{
                     if ((simulatedData.HeaderToOperation[oSelectedTableIndex].PhaseType === "R")||(simulatedData.HeaderToOperation[oSelectedTableIndex].PhaseType === undefined) ){
                        var message =  this.oResourceBundle.getText("MR_SIMULATION_ROW_PHASE_SELECTION_WARNING");
                        this.onShowWarning(message);
                    }else if (oSelectedTableIndex.length === 0){
                        var message =  this.oResourceBundle.getText("MR_SIMULATION_ROW_NO_SELECTION_WARNING");
                        this.onShowWarning(message);
                    }else if (oSelectedTableIndex[0]+1 === simulatedData.HeaderToOperation.length){
                        var message =  this.oResourceBundle.getText("MR_SIMULATION_ROW_DOWN_SELECTION_WARNING");
                        this.onShowWarning(message);
                    }else if (simulatedData.HeaderToOperation[oSelectedTableIndex[0]+1].PhaseType === undefined){
                        var oSelectedRow = { ...simulatedData.HeaderToOperation[oSelectedTableIndex]};
                        var selectedPhaseNo = simulatedData.HeaderToOperation[oSelectedTableIndex].Vornr;
                        var targetPhaseNo = simulatedData.HeaderToOperation[oSelectedTableIndex[0]+1].Vornr;
                        // simulatedData.HeaderToOperation[oSelectedTableIndex[0]+2] = oSelectedRow;
                        // simulatedData.HeaderToOperation[oSelectedTableIndex[0]+2].Pvznr = targetPhaseNo;
                        var newPhaseNo = (parseInt(targetPhaseNo) + 10).toString().padStart(4,"0");
                        var newRow = {
                            ...oSelectedRow, // Copy the selected row's data
                            Vornr: newPhaseNo, // Set the new row's phase number (incremented by 10)
                            Pvznr: simulatedData.HeaderToOperation[oSelectedTableIndex[0]+1].Vornr
                        };
                        simulatedData.HeaderToOperation.splice(oSelectedTableIndex[0] + 2, 0, newRow);
                        simulatedData.HeaderToOperation.splice(oSelectedTableIndex[0], 1);
                        for (var m = oSelectedTableIndex[0]+2; m <simulatedData.HeaderToOperation.length; m ++){
                            if(simulatedData.HeaderToOperation[m].PhaseType === undefined){
                                break;
                        }else{
                        var currentPhaseNo = parseInt(simulatedData.HeaderToOperation[m].Vornr);
                        simulatedData.HeaderToOperation[m].Vornr = (currentPhaseNo +10).toString().padStart(4,"0");
                        }
                    }
                    
                    }else{
                        var oSelectedRow = { ...simulatedData.HeaderToOperation[oSelectedTableIndex]};
                        var selectedPhaseNo = simulatedData.HeaderToOperation[oSelectedTableIndex].Vornr;
                        var oTargetRow = { ...simulatedData.HeaderToOperation[oSelectedTableIndex[0]+1]};
                        var targetPhaseNo = simulatedData.HeaderToOperation[oSelectedTableIndex[0]+1].Vornr;
                        var selectedOriginPhaseNo = simulatedData.HeaderToOperation[oSelectedTableIndex].Origin_Act_Num;
                        var targetOriginPhaseNo = simulatedData.HeaderToOperation[oSelectedTableIndex[0]+1].Origin_Act_Num;
                        simulatedData.HeaderToOperation[oSelectedTableIndex]= oTargetRow;
                        simulatedData.HeaderToOperation[oSelectedTableIndex].Vornr = selectedPhaseNo;
                        simulatedData.HeaderToOperation[oSelectedTableIndex].Origin_Act_Num = targetOriginPhaseNo;
                        simulatedData.HeaderToOperation[oSelectedTableIndex[0]+1] = oSelectedRow;
                        simulatedData.HeaderToOperation[oSelectedTableIndex[0]+1].Vornr = targetPhaseNo;
                        simulatedData.HeaderToOperation[oSelectedTableIndex[0]+1].Origin_Act_Num = selectedOriginPhaseNo;
                }
             }
             oTable.clearSelection();
            
             simulatedDataModel.refresh();

            },
           
            onShowConfirmation: function (message,ID,prdStdNo,semiFlag) {
                var that = this;
                sap.m.MessageBox.confirm(
                    message, {
                      title: "Confirmation",
                      actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
                      onClose: function (sAction) {
                        if (sAction === sap.m.MessageBox.Action.OK) {
                            if(semiFlag == 1){
                            if (!that._oSemiCreatedPrdStdDialog) {
                                var oView = that.getView();
                                that._oSemiCreatedPrdStdDialog = sap.ui.xmlfragment(oView.getId(), "l8gttpmgllpstdui.view.fragment.SemiCreatedProdStdUpdate", that); // Load the fragment             
                                oView.addDependent(that._oSemiCreatedPrdStdDialog); // Add the fragment to the view
                            
                            } 
                            BusyIndicator.show(0);
                            that._oSemiCreatedPrdStdDialog.open();
                            that.getSemicreatedData(ID,prdStdNo);
                        }
                            else{
                                if (!that._oSimulationDialog) {
                                    var oView = that.getView();
                                    that._oSimulationDialog = sap.ui.xmlfragment(oView.getId(), "l8gttpmgllpstdui.view.fragment.MasterRecipeSimulation", that); // Load the fragment             
                                    oView.addDependent(that._oSimulationDialog); // Add the fragment to the view
                                }
                                BusyIndicator.show(0);
                                that.onSubmitECNDialog();
                            }
                        }else{
                            that._oSemiCreatedPrdStdDialog.close();
                        }
                       }
                    }
                );
              },
              getSemicreatedData: function(ID,prdStdNo){
                prdStandardNo = prdStdNo;
                var that = this;
                var url = `odata/v4/data-services/ProductRelStandardHeadersDB(ID=${ID},prodStdNo='${prdStdNo}')?$expand=ProdStdToProdBttlnckDataNav($filter=modificationType ne 'D'),ProdStdToProdSecResDataNav,ProdStdToProdVarDtDataNav,ProdStdToProdMatrAllDataNav`;
                $.ajax({
                    url: url,
                    method: 'GET',
                    headers: {
                        'x-username': nbId,
                        'x-zone': zone,
                        'x-plants': plantsParam,
                        'x-role': "Creator/Editor"
                    },
                    success: function (response) {
                        var prodBttlnckData = response.ProdStdToProdBttlnckDataNav;
                        var prodSecResData = response.ProdStdToProdSecResDataNav;
                        var prodVarDtData = response.ProdStdToProdVarDtDataNav;
                        var prodMatrData = response.ProdStdToProdMatrAllDataNav;
                        that.oglobalResponseModel.setData({
                            standardCycleData: prodBttlnckData,
                            variableDtData: prodVarDtData,
                            materialData: prodMatrData,
                            SecondaryResData: prodSecResData
                        });
                        ecn = response.ecm;
                        that.getView().byId("idProdSemiCreatedPlant").setText(response.plant);
                        that.getView().byId("idProdSemiCreatedValidFrom").setText(that.getDateFormat(response.validFrom));
                        that.getView().byId("idProdSemiCreatedValidTo").setText(that.getDateFormat(response.validTo));
                        that.getView().byId("idProdSemiCreatedLotSize").setText(response.procOrdrSizeOrCostingLotSize);
                        that.getView().byId("idProdSemiCreatedMrNo").setText(response.mrGroup);
                        that.getView().byId("idProdSemiCreatedCostCenter").setText(response.costCenter);
                        that.getView().byId("idProdSemiCreatedMrCounter").setText(response.mrCounter);
                        that.getView().byId("idProdSemiCreatedAiPercent").setText(response.pctAI);
                        that.getView().byId("idProdSemiCreatedEff").setText(response.lineEfficiency);
                        that.getView().byId("idProdSemiCreatedNS").setText(response.nominalSpeed);
                        that.getView().byId("idProdSemiCreatedOperationQty").setText(response.operationQty);
                        that.getView().byId("idProdSemiCreatedChrgQty").setText(response.chargeQty);
                        var bottleneckCorrect = (response.bottleneckCorrect === "Y") ? "True" : "False";
                        that.getView().byId("idProdSemiCreatedBottleneckCorrect").setText(bottleneckCorrect);
                        that.getView().byId("idProdSemiCreatedDescription").setText(response.masterRecipeDesc);
                        that.getView().byId("idProdSemiCreatedCrewSize").setText(response.crewSize);
                        that.getView().byId("idProdSemiCreatedCostCenter").setText(response.costCenter);
                        that.getView().byId("idProdSemiCreatedBottleneckCorrect")
                        .addStyleClass((bottleneckCorrect === "True") ? "greenText" : "redText")
                        .removeStyleClass((bottleneckCorrect === "True") ? "redText" : "greenText")
                        BusyIndicator.hide();
                        that.getDestinationModel(response.plant);
                        var url = "/ETY_RESOURCE_SHSet";
                        var oFilterPlant = new Filter({
                        filters: [
                            new Filter("Werks", FilterOperator.EQ, response.plant)
                            ]
                    });
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            filters: [oFilterPlant],
                            success: function (oData) {
                                // Create and set the JSONModel with the data received
                                var oModelResource = new sap.ui.model.json.JSONModel();
                                oModelResource.setData(oData);
                                that.getView().setModel(oModelResource, "resourceModel");
                            }.bind(this),
                            error: function (jqXHR) {
                                let errorMessage = jqXHR.responseText ?
                                        JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                        // Handle errors
                                        MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                                        BusyIndicator.hide();
                                    }
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                        var url_1 = "/ETY_CONTROL_KEYSet";
                        if (oODataModel) {
                            oODataModel.read(url_1, {
                                headers: mHeaders,
                                success: function (oData) {
                                    var oModelControlKey = new sap.ui.model.json.JSONModel();
                                    oModelControlKey.setData(oData);
                                    that.getView().setModel(oModelControlKey, "controlKeyModel");
                                }.bind(this),
                                error: function (jqXHR) {
                                    let errorMessage = jqXHR.responseText ?
                                            JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                            // Handle errors
                                            MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                                            BusyIndicator.hide();
                                        }
                            });
                        } else {
                            MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                        }
                    },
                    error: function (xhr, status, error) {
                        let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                                xhr.responseJSON.error.message :
                                    that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                        MessageToast.show(that.oResourceBundle.getText("PROD_STD_DB_FAIL") + " " + errorMessage);
                        BusyIndicator.hide();
                    }
                })
            },
            onSemiCreatedSelectSecResource: function (oEvent) {
                var that = this;
                var source = oEvent.getSource();
                var context = source.getBindingContext("globalResponseModel");
                var index = context.getPath().split("/").pop();
                if (oEvent.getParameter("selectedItem") === null) {
                    var oSecondaryResData = this.getView().getModel("globalResponseModel").getProperty("/SecondaryResData");
                    for (var i = 1; i < 7; i++) {
                        oSecondaryResData[index]["energy" + i + "Type"] = "";
                        oSecondaryResData[index]["energy" + i + "Uom"] = "";
                        oSecondaryResData[index]["energy" + i + "QtyPerHr"] = "";
                    }
                    this.getView().getModel("globalResponseModel").setProperty("/SecondaryResData/" + index + "/edit", false);
                    this.getView().getModel("globalResponseModel").setProperty("/SecondaryResData/" + index + "/enable", true);
                } else {
                    var selectedKey = oEvent.getParameter("selectedItem").getKey();
                    var plant = this.getView().byId("idProdSemiCreatedPlant").getText();
                    var oModelActivity = new sap.ui.model.json.JSONModel();
                    var url = "/ETY_ACTIVITY_TYPESet";
                    BusyIndicator.show(0);
                    var oFilterResource = new Filter({
                        filters: [
                            new Filter("ARBPL", FilterOperator.EQ, selectedKey)
                            ]
                    });
                    var oFilterPlant = new Filter({
                        filters: [
                            new Filter("WERKS", FilterOperator.EQ, plant)
                            ]
                    });
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            filters: [oFilterResource, oFilterPlant],
                            success: function (oData) {
                                BusyIndicator.hide();
                                oModelActivity.setData(oData);
                                var oSecondaryResData = this.getView().getModel("globalResponseModel").getProperty("/SecondaryResData");
                                var newData = oModelActivity.getData().results;
                                newData.forEach(function (item, idx) {
                                    var columnIndex = idx + 1;
                                    if (columnIndex <= 6) {
                                        oSecondaryResData[index]["energy" + columnIndex + "Type"] = item.MCTXT;
                                        oSecondaryResData[index]["energy" + columnIndex + "Uom"] = item.LEINH;
                                    }
                                });
                                this.getView().getModel("globalResponseModel").setProperty("/SecondaryResData", oSecondaryResData);
                                this.getView().getModel("globalResponseModel").setProperty("/SecondaryResData/" + index + "/edit", true);
                                this.getView().getModel("globalResponseModel").setProperty("/SecondaryResData/" + index + "/enable", true);
                                this.getView().getModel("globalResponseModel").setProperty("/SecondaryResData/" + index + "/SecResource", selectedKey);
                                this.getView().byId("idSecondaryResourceDB10").getModel("globalResponseModel").refresh();
                            }.bind(this),
                            error: function (jqXHR) {
                                let errorMessage = jqXHR.responseText ?
                                        JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                        // Handle errors
                                        MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                            }
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                }
            },
            onSemiCreatedEnergyResourceAdd: function () {
                var table = this.getView().byId("idSecondaryResourceDB10");
                var selectedIndices = table.getSelectedIndices();
                if (selectedIndices.length === 1) {
                    var selectedIndex = selectedIndices[0];
                    var selectedData = table.getContextByIndex(selectedIndex).getObject();
                    var newData = Object.assign({}, selectedData);
                    // Modify or reset any properties as needed for the new row
                    newData.id = ""; // For example, reset ID if it should be unique
                    // Add the new data to the model
                    var model = this.getView().getModel("globalResponseModel");
                    var currentData = model.getProperty("/SecondaryResData");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/ID", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/secResource", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/edit", false);
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy1QtyPerHr", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy2QtyPerHr", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy3QtyPerHr", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy4QtyPerHr", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy5QtyPerHr", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy6QtyPerHr", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy1Type", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy1Uom", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy2Type", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy2Uom", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy3Type", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy3Uom", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy4Type", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy4Uom", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy5Type", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy5Uom", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy6Type", "");
                    model.setProperty("/SecondaryResData/" + selectedIndex + "/energy6Uom", "");
                    currentData.push(newData);
                    model.setProperty("/SecondaryResData", currentData);
                    model.refresh();
                    this.getView().byId("idSecondaryResourceDB10").getModel("globalResponseModel").refresh();
                } else {
                    this.onShowWarning(this.oResourceBundle.getText("ROW_DUPLICATE_ENGRES_ERROR"));
                }
            },

            fnCloseSemiCreatedProdStd: function(){
                if (this._oSemiCreatedPrdStdDialog) {
                this._oSemiCreatedPrdStdDialog.close();
                }
               
            },
            onSemiCreatedProductionStdDBUpdate: function(){
                var that = this;
                var oBottleneckTable = this.getView().byId("idBottleneckDB10");
                var oBottleneckTableModel = oBottleneckTable.getModel("globalResponseModel");
                var aData = oBottleneckTableModel.getData().standardCycleData;
                var bBlankKeyFound = false;
                for (var x = 0; x < aData.length; x++) {
                    var oDataItem = aData[x];
                    if (!oDataItem.controlKey || !oDataItem.destinationKey) {
                        bBlankKeyFound = true;
                        break; 
                    }
                }
                if (bBlankKeyFound) {
                    var message = this.oResourceBundle.getText("SEMICREATOR_CTRL_DEST_KEY_BLANK")
                    this.onShowError(message);
                }else{
                var oSecResTable = this.getView().byId("idSecondaryResourceDB10");
                var oSecResTableModel = oSecResTable.getModel("globalResponseModel");
                var aSecResTableData = oSecResTableModel.getProperty("/SecondaryResData");

                // Prepare the Secondary resource data
                var updateProdStdSecResData = [];
                aSecResTableData.forEach(function (rowData) {
                    let updateData = {
                        prodStdNo: prdStandardNo,
                        resource: rowData.resource,
                        machine: rowData.machine,
                        secResource: rowData.secResource,
                        energy1Type: rowData.energy1Type,
                        energy1Uom: rowData.energy1Uom,
                        energy1QtyPerHr: isNaN(parseFloat(rowData.energy1QtyPerHr)) ? null : parseFloat(rowData.energy1QtyPerHr),
                                energy2Type: rowData.energy2Type,
                                energy2Uom: rowData.energy2Uom,
                                energy2QtyPerHr: isNaN(parseFloat(rowData.energy2QtyPerHr)) ? null : parseFloat(rowData.energy2QtyPerHr),
                                        energy3Type: rowData.energy3Type,
                                        energy3Uom: rowData.energy3Uom,
                                        energy3QtyPerHr: isNaN(parseFloat(rowData.energy3QtyPerHr)) ? null : parseFloat(rowData.energy3QtyPerHr),
                                                energy4Type: rowData.energy4Type,
                                                energy4Uom: rowData.energy4Uom,
                                                energy4QtyPerHr: isNaN(parseFloat(rowData.energy4QtyPerHr)) ? null : parseFloat(rowData.energy4QtyPerHr),
                                                        energy5Type: rowData.energy5Type,
                                                        energy5Uom: rowData.energy5Uom,
                                                        energy5QtyPerHr: isNaN(parseFloat(rowData.energy5QtyPerHr)) ? null : parseFloat(rowData.energy5QtyPerHr),
                                                                energy6Type: rowData.energy6Type,
                                                                energy6Uom: rowData.energy6Uom,
                                                                energy6QtyPerHr: isNaN(parseFloat(rowData.energy6QtyPerHr)) ? null : parseFloat(rowData.energy6QtyPerHr),

                    };
                    if (rowData.ID && rowData.ID.trim() !== "") {
                        updateData.ID = rowData.ID;
                    }
                    updateProdStdSecResData.push(updateData);
                });
                // Get the table and its binding context
                var oBottleneckTable = this.getView().byId("idBottleneckDB10");
                var oBottleneckTableModel = oBottleneckTable.getModel("globalResponseModel");
                var aBottleneckTableData = oBottleneckTableModel.getProperty("/standardCycleData");

                
                
                // Prepare the Bottleneck data
                var updateProdStdBottleneckData = [];
                aBottleneckTableData.forEach(function (rowData) {
                    updateProdStdBottleneckData.push({
                        ID: rowData.ID,
                        prodStdNo: prdStandardNo,                      
                        destinationKey: rowData.destinationKey,
                        controlKey: rowData.controlKey,
                    });
                });
                var updateProdStdHdrData = [];
                var updateProdStdMaterialData = [];
                var updateProdStdVarDtData = [];
                // Create the payload
                var payload = {
                        "updateProdStdHdrData": updateProdStdHdrData,
                        "updateProdStdMaterialData": updateProdStdMaterialData,
                        "updateProdStdVarDtData": updateProdStdVarDtData,
                        "updateProdStdSecResData": updateProdStdSecResData,
                        "updateProdStdBottleneckData": updateProdStdBottleneckData,
                        "deleteProdStdMaterialData": deleteProdStdMaterialData,
                        "deleteProdStdVarDtData": deleteProdStdVarDtData,
                        "deleteProdStdSecResData": deleteProdStdSecResData,
                        "deleteProdStdBottleneckData": deleteProdStdBottleneckData
                };
                var sUrl = "odata/v4/data-services/upsertProductStdItems";
                BusyIndicator.show(0);
                $.ajax({
                    url: sUrl,
                    type: "POST",
                    data: JSON.stringify(payload),
                    contentType: "application/json"
                })
                .done(function (response) {
                    BusyIndicator.hide();
                    // var message = that.oResourceBundle.getText("PROD_STD_UPDATE_SUCCESS") + " " + plant + ", Resource :" + bottleneckResource + ", CostCenter :" + costCenter + ".";
                    // that.onShowSuccess(message);
                    that._oSemiCreatedPrdStdDialog.close();
                    that.fnCompletePrdStdSubmit();
                })
                .fail(function (xhr, status, error) {
                    BusyIndicator.hide();
                    let errorMessage = xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ?
                            xhr.responseJSON.error.message :
                                that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                    var message = that.oResourceBundle.getText("PROD_STD_UPDATE_FAIL") + " " + errorMessage;
                    that.onShowError(message);
                    that._oSemiCreatedPrdStdDialog.close();
                    var initialCallFlag = 0;
                    that.getProductStdHeaderData(initialCallFlag);
                });
            }
            },
            fnCompletePrdStdSubmit: function(){
                if (!this._oSimulationDialog) {
                    var oView = this.getView();
                    this._oSimulationDialog = sap.ui.xmlfragment(oView.getId(), "l8gttpmgllpstdui.view.fragment.MasterRecipeSimulation", this); // Load the fragment             
                    oView.addDependent(this._oSimulationDialog); // Add the fragment to the view
                }
                this.onSubmitECNDialog();
            },
            onRoleSheetButtonPress: function(oEvent){
                var oButton = oEvent.getSource();
			    this.byId("actionSheet").openBy(oButton);
                var newData = sap.ui.getCore().getModel("loginUserModel").getData();
                for (var i = 0; i< newData.results.length; i++){
                    var authType = newData.results[i].AuthType;
                    if (authType === "C"){
                        this.getView().byId("creatorId").setVisible(true);
                    }else if (authType === "V"){
                        this.getView().byId("viewerId").setVisible(true);
                    }else if (authType === "S"){
                        this.getView().byId("semicreatorId").setVisible(true);
                    }else{
                    this.getView().byId("approverId").setVisible(true);
                    }
                }
            },
            fnGetCreatorData: function(){
                BusyIndicator.show(0);
                var initialCallFlag = 0;
                role = "C";
                this.getProductStdHeaderData(initialCallFlag);              
            },
            fnGetViewerData: function(){
                role = "V";
                BusyIndicator.show(0);
                var url2 = "/ETY_PLANT_SHSet";
                var oFilterRole = new Filter({
                    filters: [
                        new Filter("User_Type", FilterOperator.EQ, role)
                        ]
                });
                if (oODataModel) {
                    oODataModel.read(url2, {
                        headers: mHeaders,
                        filters: [oFilterRole],
                        success: function (oData) {
                            var oModelPlant = new sap.ui.model.json.JSONModel();
                            oModelPlant.setData(oData);
                            oModelPlant.setSizeLimit(3000);
                            this.getView().setModel(oModelPlant, "plantModel1");
                            var aPlantData = this.getView().getModel("plantModel1").getData().results;
                            var plantIds = [];
                            for (var i = 0; i < aPlantData.length; i++) {
                                var plant = aPlantData[i].Werks;
                                plantIds.push(plant);
                            }
                            plantsParam = plantIds.join(',');
                            this.fnProdViewRecords();
                            
                        }.bind(this),
                        error: function (jqXHR) {
                            let errorMessage = jqXHR.responseText ?
                                    JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
                                    // Handle errors
                                    MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
            },
            fnGetApproverData: function(){
                BusyIndicator.show(0);
                var initialCallFlag = 0;
                role = "A";
                this.getProductStdHeaderData(initialCallFlag);
            },
            fnGetSemicreatorData: function(){
                BusyIndicator.show(0);
                var initialCallFlag = 0;
                role = "S";
                this.getProductStdHeaderData(initialCallFlag);
            },
            fnGetExecutorData: function(){
                BusyIndicator.show(0);
                role = "E";
                this.fnProdExecutionRecords();
            },
            onRefreshData: function(){
                BusyIndicator.show(0);
                if (role === "V"){
                    this.fnGetViewerData();
                }else{
                var initialCallFlag = 0;
                this.getProductStdHeaderData(initialCallFlag);
            }
        }


            ///////////////////////////////END OF CONTROLLER///////////////////////////////////END OF CONTROLLER///////////////////////////END OF CONTROLLER/////////////////////////////////////END OF CONTROLLER////////////////////////////////////END OF CONTROLLER///////////////////////////////////////////END OF CONTROLLER/////////////////////////////////////////////END OF CONTROLLER
        });
    });