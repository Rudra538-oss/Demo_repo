sap.ui.define(
    [
        "l8gttpmgllpstdui/controller/BaseController",
        "sap/ui/core/mvc/Controller",
        "l8gttpmgllpstdui/model/formatter",
        'sap/m/MessageToast',
        "sap/ui/core/routing/History",
        'sap/ui/core/BusyIndicator',
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/m/MessageBox"
    ],
    function (BaseController, Controller, formatter, MessageToast, History, BusyIndicator, Filter, FilterOperator, MessageBox) {
        "use strict";
        var tableIndex, toggleUser = 1, toggle = 1, roleVal, userRole, iSelectedRowIndex,role;
        var plant, material, resource, plantDesc, destinationKey, costCenter, validFrom, validTo, lotSize, mrNo, mrCounter, chargeQty, opQty, lineEff, totalVariableDt = 0, createdOn, lastChangedOn, lineStatus, standard;
        var iLineApproveSelIndex, oODataModel, iLineExecutorSelIndex, apikey, approverLevel;
        var mHeaders = [];
        return BaseController.extend("l8gttpmgllpstdui.controller.LineStandardView", {
            formatter: formatter,
            onInit: function () {
                const oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                const oHistory = sap.ui.core.routing.History.getInstance();
                const sPreviousHash = oHistory.getPreviousHash();
                oRouter.getRoute("LineStandardView").attachPatternMatched(this.onObjectMatched, this);
                // If there is no previous hash, navigate to HomeView
                if (sPreviousHash === undefined) {
                    oRouter.navTo("RouteHomeView", true);
                } else {
                    oRouter.getRoute("LineStandardView").attachPatternMatched(this.onObjectMatched, this);
                }
                this.oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();

            },
            onNavBack: function () {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("RouteHomeView", true);
            },
            onObjectMatched: function () {
                var that = this;
                oODataModel = this.getOwnerComponent().getModel();
                //initial setting for Line table button
                this.getView().byId("idLineTable").removeSelections(true);
                this.getView().byId("idLineCopyCreate").setEnabled(true);
                this.getView().byId("idArchive").setEnabled(false);
                this.getView().byId("idCreate").setEnabled(true);
                this.getView().byId("idSubmitForApproval").setEnabled(false);
                var createLineStandardModel = new sap.ui.model.json.JSONModel();
                createLineStandardModel.setData({});
                this.getView().setModel(createLineStandardModel, "createLineStandardModel");
                this.getOwnerComponent().setModel(createLineStandardModel, "createLineStandardModel");
                var LineStandardFilterModel = new sap.ui.model.json.JSONModel();
                LineStandardFilterModel.setData({});
                this.getView().setModel(LineStandardFilterModel, "LineStandardFilterModel");
                this.getOwnerComponent().setModel(LineStandardFilterModel, "LineStandardFilterModel");
                // initital setting for Line Standard filters
                var oView = this.getView();
                var parts = sap.ui.core.routing.History.getInstance().getPreviousHash().split('/');    
                var firstPart = parts[0];
                if(firstPart !== "onViewStandard"){
                // Fetch controls by their IDs
                oView.byId("idLineFilterPlant").setSelectedItem(null);
                oView.byId("idLineFilterPlant").setValue("");
                oView.byId("idLineFilterResource").setValue("");
                oView.byId("idCostCenterFilter").setValue("");
                oView.byId("DPValidFrom").setValue("");
                oView.byId("DPValidTo").setValue("");
                oView.byId("DPCreatedOn").setValue("");
                oView.byId("DPLastChangedOn").setValue("");
                oView.byId("idLineStatusFilter").setSelectedItems([]);
                // oView.byId("idLineStatusFilter").clearSelection();
                // oView.byId("idLineStatusFilter").setValue("");
                oView.byId("idProdCycleDaysRangSlider").setValue("");
                oView.byId("idLineFilterShiftInDays").setValue("");
                oView.byId("idFilterShitsInCycle").setValue("");
                oView.byId("idLineFilterCycleHrs").setValue("");
                oView.byId("idLineFilterCyclesInYear").setValue("");
                oView.byId("idLineFilterTotOccuTime").setValue("");

                if (this.getView().getModel("statusFilterModel") != undefined) {
                    this.getView().getModel("statusFilterModel").setProperty("/value", []);
                }
            }

                var statusFilterModel = new sap.ui.model.json.JSONModel();
                var url = 'odata/v4/data-services/LineAndProductRelStandardStatusDb?$filter=lineFlag eq 1&$select=status'
                statusFilterModel.loadData(url);
                statusFilterModel.setSizeLimit(100);
                this.getView().setModel(statusFilterModel, "statusFilterModel");

                if (this.getView().getModel("plantModel1") != undefined) {
                    this.getView().getModel("plantModel1").setProperty("/results", []);
                }
               
               
                ////////////////////////////// Line standard user logedIn and filter///////////////////////////////////////////////////

                var aFilter = [];

                var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                var nbId = newData[0].Username;
                var zone = newData[0].Zone;
                var currentURL = window.location.href;
                var url = new URL(currentURL);
                var host = url.host;
                var oResourceBundle = this.getView().getModel("util").getResourceBundle();
                if (host.startsWith("dev") || host.startsWith("poc")) {
                    apikey = oResourceBundle.getText("apiKey_Dev");
                } else if (host.startsWith("ppd")) {
                    apikey = oResourceBundle.getText("apiKey_PPD");
                } else {
                    apikey = oResourceBundle.getText("apiKey_PRD");
                }
                var alias = zone === "AOA" ? oResourceBundle.getText("zoneAOA_Alias") :
                    zone === "EUR" ? oResourceBundle.getText("zoneEUR_Alias") :
                        zone === "AMS" ? oResourceBundle.getText("zoneAMS_Alias") :
                            "";

                mHeaders = {
                    "apikey": apikey,
                    "username": nbId,
                    "sysali": alias
                };
                var proceedFlag = 1;
                var initialCallFlag ;
                if(firstPart === "onViewStandard"){
                    if(oView.byId("idLineFilterPlant").getSelectedItem()!== null||
                    oView.byId("idLineFilterPlant").getValue()!==""||
                    oView.byId("idLineFilterResource").getValue()!==""||
                    oView.byId("idCostCenterFilter").getValue()!==""||
                    oView.byId("DPValidFrom").getValue()!==""||
                    oView.byId("DPValidTo").getValue()!==""||
                    oView.byId("DPCreatedOn").getValue()!==""||
                    oView.byId("DPLastChangedOn").getValue()!==""||
                    oView.byId("idLineStatusFilter").getSelectedItems().length!==0||
                    oView.byId("idProdCycleDaysRangSlider").getValue()!==""||
                    oView.byId("idLineFilterShiftInDays").getValue()!==""||
                    oView.byId("idFilterShitsInCycle").getValue()!==""||
                    oView.byId("idLineFilterCycleHrs").getValue()!==""||
                    oView.byId("idLineFilterCyclesInYear").getValue()!==""||
                    oView.byId("idLineFilterTotOccuTime").getValue()!=="")
                {
                    var proceedFlag = 0;
                    var url = "/ETY_PLANT_SHSet";
                    var oFilterRole = new Filter({
                        filters: [
                            new Filter("User_Type", FilterOperator.EQ, role)
                            ]
                    });    
                    BusyIndicator.show(0);
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            filters: [oFilterRole],
                            success: function (oData) {
                                var oModelPlant = new sap.ui.model.json.JSONModel();
                                oModelPlant.setData(oData);
                                oModelPlant.setSizeLimit(3000);
                                this.getView().setModel(oModelPlant, "plantModel1");
                                this.onLineStdSearchPress();
                            }.bind(this),
                            error: function (oError) {
                                BusyIndicator.hide();
                                // Handle errors
                                MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
                            }
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                   
                }else{
                    var proceedFlag = 1;
                }
            }
            if(proceedFlag === 1){
               if(initialCallFlag === undefined && firstPart !== "onViewStandard"){
                if (newData.length>1){
                    var url = "/ETY_PLANT_SHSet";
                    var oFilterRole = new Filter({
                        filters: [
                            new Filter("User_Type", FilterOperator.EQ, role)
                            ]
                    });
                    BusyIndicator.show(0);
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            filters: [oFilterRole],
                            success: function (oData) {
                                BusyIndicator.hide();
                                var oModelPlant = new sap.ui.model.json.JSONModel();
                                oModelPlant.setData(oData);
                                oModelPlant.setSizeLimit(3000);
                                this.getView().setModel(oModelPlant, "plantModel1");
    
                                // this.getOwnerComponent().setModel(oModelPlant, "plantModel1");
                                this.fnUpdateLossCat();
                                this.fnReadLineStdViewerTableData();
                            }.bind(this),
                            error: function (oError) {
                                BusyIndicator.hide();
                                // Handle errors
                                MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
                            }
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                    }else{
                role="V";
                var url = "/ETY_PLANT_SHSet";
                var oFilterRole = new Filter({
                    filters: [
                        new Filter("User_Type", FilterOperator.EQ, role)
                        ]
                });
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        filters: [oFilterRole],
                        success: function (oData) {
                            BusyIndicator.hide();
                            var oModelPlant = new sap.ui.model.json.JSONModel();
                            oModelPlant.setData(oData);
                            oModelPlant.setSizeLimit(3000);
                            this.getView().setModel(oModelPlant, "plantModel1");

                            // this.getOwnerComponent().setModel(oModelPlant, "plantModel1");
                            this.fnUpdateLossCat();
                            this.fnReadLineStdExecutorConfigData();
                        }.bind(this),
                        error: function (oError) {
                            BusyIndicator.hide();
                            // Handle errors
                            MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
            }

               
               }else{

                if (role === "V") {
                    var url = "/ETY_PLANT_SHSet";
                    var oFilterRole = new Filter({
                        filters: [
                            new Filter("User_Type", FilterOperator.EQ, role)
                            ]
                    });
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            filters: [oFilterRole],
                            success: function (oData) {
                                BusyIndicator.hide();
                                var oModelPlant = new sap.ui.model.json.JSONModel();
                                oModelPlant.setData(oData);
                                oModelPlant.setSizeLimit(3000);
                                this.getView().setModel(oModelPlant, "plantModel1");

                                // this.getOwnerComponent().setModel(oModelPlant, "plantModel1");
                                this.fnUpdateLossCat();
                                // function call to get Line Header table data
                                firstPart !== "onViewStandard"? this.fnReadLineStdExecutorConfigData():this.fnReadLineStdViewerTableData();
                            }.bind(this),
                            error: function (oError) {
                                BusyIndicator.hide();
                                // Handle errors
                                MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
                            }
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                }
                if ((role == "C")|| (role === "S")) {
                    this.getView().byId("idCreate").setVisible(true);

                    this.getView().byId("idLineCopyCreate").setVisible(true);
                    toggleUser = 1;
                    this.getView().byId("idMenu1").setVisible(false);
                    this.getView().byId("idMenu2").setVisible(false);
                    this.getView().byId("idMenu3").setVisible(false);
                    this.getView().byId("idCreatorMenu1").setVisible(true);
                    this.getView().byId("idArchive").setVisible(true);
                    
                    var url = "/ETY_PLANT_SHSet";
                    var oFilterRole = new Filter({
                        filters: [
                            new Filter("User_Type", FilterOperator.EQ, role)
                            ]
                    });
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            filters: [oFilterRole],
                            success: function (oData) {
                                BusyIndicator.hide();
                                var oModelPlant = new sap.ui.model.json.JSONModel();
                                oModelPlant.setData(oData);
                                oModelPlant.setSizeLimit(3000);
                                this.getView().setModel(oModelPlant, "plantModel1");

                                // this.getOwnerComponent().setModel(oModelPlant, "plantModel1");
                                this.fnUpdateLossCat();
                                // function call to get Line Header table data
                                this.fnReadLineStdHeaderTableData();
                            }.bind(this),
                            error: function (oError) {
                                BusyIndicator.hide();
                                // Handle errors
                                MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
                            }
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }
                }
                if (role === "A") {
                    var url = "/ETY_PLANT_SHSet";
                    var oFilterRole = new Filter({
                        filters: [
                            new Filter("User_Type", FilterOperator.EQ, role)
                            ]
                    });
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            filters: [oFilterRole],
                            success: function (oData) {
                                BusyIndicator.hide();
                                var oModelPlant = new sap.ui.model.json.JSONModel();
                                oModelPlant.setData(oData);
                                oModelPlant.setSizeLimit(3000);
                                this.getView().setModel(oModelPlant, "plantModel1");

                                // this.getOwnerComponent().setModel(oModelPlant, "plantModel1");
                                this.fnUpdateLossCat();
                                // function call to get Line Header table data
                                this.fnReadLineStdApproverTableData();
                            }.bind(this),
                            error: function (oError) {
                                // Handle errors
                                MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
                            }
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }



                }
              
                // filter binding
                var oList = this.getView().byId("idLineTable");
                var oBinding = oList.getBinding("items");
                //  oBinding.filter(aFilter);

                ////////////////////////////// Line standard user logedIn and filter///////////////////////////////////////////////////
            }
        }

    },
            // Line Standard Header table data get/read
            fnReadLineStdHeaderTableData: function (sUrl) {
                var that = this;
                BusyIndicator.show(0);
                if (sUrl != undefined) {
                    //sUrl = sUrl;
                }
                else {
                    sUrl = "odata/v4/data-services/LineRelStandardHeadersDB"
                }

                var aPlantData = this.getView().getModel("plantModel1").getData().results;
                var plantIds = [];
                for (var i = 0; i < aPlantData.length; i++) {
                    var plant = aPlantData[i].Werks;
                    plantIds.push(plant);
                }
                const plantsParam = plantIds.join(',');

                var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                var nbId = newData[0].Username;
                var zone = newData[0].Zone;

                if ((role === 'C')|| (role === "S")) {
                    this.getView().byId("idCreate").setVisible(true);

                    this.getView().byId("idLineCopyCreate").setVisible(true);
                    toggleUser = 1;
                    this.getView().byId("idMenu1").setVisible(false);
                    this.getView().byId("idMenu2").setVisible(false);
                    this.getView().byId("idMenu3").setVisible(false);
                    this.getView().byId("idCreatorMenu1").setVisible(true);
                    this.getView().byId("idArchive").setVisible(true);
                    this.getView().byId("idSubmitForApproval").setVisible(true);
                    var currentRole = "Creator/Editor"
                }
                if (role == 'A') {
                    this.getView().byId("idCreate").setVisible(false);
                    this.getView().byId("idLineCopyCreate").setVisible(false);
                    this.getView().byId("idMenu1").setVisible(false);
                    this.getView().byId("idMenu2").setVisible(true);
                    this.getView().byId("idMenu3").setVisible(false);
                    this.getView().byId("idCreatorMenu1").setVisible(false);
                    this.getView().byId("idArchive").setVisible(false);
                    this.getView().byId("idSubmitForApproval").setVisible(false);
                    var currentRole = "Approver"
                }
                if (role == 'V') {
                    this.getView().setModel(oTableModel, "lineStandardHeaderModel");
                    this.getView().byId("idCreate").setVisible(false);
                    this.getView().byId("idLineCopyCreate").setVisible(false);
                    this.getView().byId("idMenu1").setVisible(false);
                    this.getView().byId("idMenu2").setVisible(false);
                    this.getView().byId("idMenu3").setVisible(true);
                    this.getView().byId("idCreatorMenu1").setVisible(false);
                    this.getView().byId("idArchive").setVisible(false);
                    this.getView().byId("idSubmitForApproval").setVisible(false);
                    
                    var currentRole = "Executor/Viewer"
                }
               

                $.get({
                    url: sUrl,
                    method: 'GET',
                    headers: {
                        'x-username': nbId,
                        'x-zone': zone,
                        'x-plants': plantsParam,
                        'x-role': currentRole
                    }
                }).done(function (data) {
                    // 'data' here should contain the response from the OData endpoint                   
                    BusyIndicator.hide();
                    // Process or display the 'data' object as needed
                    var oTableModel = new sap.ui.model.json.JSONModel(data);
                    that.getView().setModel(oTableModel, "lineStandardHeaderModel");
                    //Setting model at component level
                    that.getOwnerComponent().setModel(oTableModel, "lineStandardHeaderModel");
                    MessageToast.show(that.oResourceBundle.getText("LINE_STANDARD_DATA_LOADED"));;

                    var aHeaderData = that.getView().getModel("lineStandardHeaderModel").getProperty("/value");
                    for (var i = 0; i < aHeaderData.length; i++) {
                        if (that.getView().getModel("lineStandardHeaderModel").getProperty("/value/" + i + "/status") == "Archived") {
                            that.getView().getModel("lineStandardHeaderModel").setProperty("/value/" + i + "/enable", false);
                            that.getView().getModel("lineStandardHeaderModel").setProperty("/value/" + i + "/archiveMenuVisible", true);
                        }
                    }
                   
                    // alert(JSON.stringify(data)); // Convert data to string for alert
                }).fail(function (_xhr, _status, _error) {
                    BusyIndicator.hide();
                    // Handle errors if the request fails
                    MessageToast.show(that.oResourceBundle.getText("ERROR_LINE_STANDARD_DATA_NOT_LOADED"));
                });

            },

            fnReadLineStdApproverTableData: function (sUrl) {
                var that = this;
                BusyIndicator.show(0);
                var aPlantData = this.getView().getModel("plantModel1").getData().results;
                var plantIds = [];
                for (var i = 0; i < aPlantData.length; i++) {
                    var plant = aPlantData[i].Werks;
                    plantIds.push(plant);
                }
                const plantsParam = plantIds.join(',');
                var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                var nbId = newData[0].Username;
                var zone = newData[0].Zone;
                if (role == 'A') {
                   var currentRole = "Approver"
                }
                // var sUrl="odata/v4/data-services/getApproverLineStd(approver='" + nbId + "',auditInfoChannel='" + zone + "')"
                if (sUrl != undefined) {
                    //sUrl = sUrl;
                }
                else {
                    sUrl = "odata/v4/data-services/LineRelStandardHeadersDB"
                }
                // var sUrl= "odata/v4/data-services/LineRelStandardHeadersDB"
                $.get(
                    {
                        url: sUrl,
                        type: "GET",
                        contentType: "application/json",
                        dataType: "json",
                        headers: {
                            "x-username": nbId,
                            "x-zone": zone,
                            "x-plants": plantsParam,
                            "x-role": currentRole

                        }

                    }).done(function (data) {
                        // 'data' here should contain the response from the OData endpoint
                        BusyIndicator.hide();
                        MessageToast.show(that.oResourceBundle.getText("LINE_STANDARDS_APPROVER_LOADED"));
                        // Process or display the 'data' object as needed
                        that.getView().byId("idCreate").setVisible(false);
                        that.getView().byId("idLineCopyCreate").setVisible(false);
                        that.getView().byId("idMenu1").setVisible(false);
                        that.getView().byId("idMenu2").setVisible(true);
                        that.getView().byId("idMenu3").setVisible(false);
                        that.getView().byId("idCreatorMenu1").setVisible(false);
                        that.getView().byId("idArchive").setVisible(false);
                        that.getView().byId("idSubmitForApproval").setVisible(false);
                        var oTableModel = new sap.ui.model.json.JSONModel(data);
                        that.getView().setModel(oTableModel, "lineStandardHeaderModel");
                        //Setting model at component level
                        that.getOwnerComponent().setModel(oTableModel, "lineStandardHeaderModel");
                        var aHeaderData = that.getView().getModel("lineStandardHeaderModel").getProperty("/value");
                        for (var i = 0; i < aHeaderData.length; i++) {
                            if (that.getView().getModel("lineStandardHeaderModel").getProperty("/value/" + i + "/status") == "Archived") {
                                that.getView().getModel("lineStandardHeaderModel").setProperty("/value/" + i + "/enable", false);
                            }
                        }
                       
                    }).fail(function (xhr, status, error) {
                        BusyIndicator.hide();
                        // Handle errors if the request fails
                        MessageToast.show(that.oResourceBundle.getText("LINE_STANDARDS_APPROVER_NOT_LOADED"));

                    });

            },
            ////////////////////////////////////////////////////////////////////////////////////////
            fnReadLineStdExecutorConfigData: function (sUrl) {
                var that = this;
                BusyIndicator.show(0);
                var aPlantData = this.getView().getModel("plantModel1").getData().results;
                var plantIds = [];
                for (var i = 0; i < aPlantData.length; i++) {
                    var plant = aPlantData[i].Werks;
                    plantIds.push(plant);
                }
                const plantsParam = plantIds.join(',');
                var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                var nbId = newData[0].Username;
                var zone = newData[0].Zone;
                if (role === 'E') {
                   var currentRole = "Executor/Viewer"
                }
                if (sUrl !== undefined) {
                    // sUrl = sUrl;
                }
                else {
                    sUrl = "odata/v4/data-services/LineRelStandardHeadersDB"
                }
                $.get({
                    url: sUrl,
                    method: 'GET',
                    headers: {
                        'x-username': nbId,
                        'x-zone': zone,
                        'x-plants': plantsParam,
                        'x-role': currentRole
                    }
                }).done(function (data, _textStatus, xhr) {
                    BusyIndicator.hide();
                    var oTableModel = new sap.ui.model.json.JSONModel(data);
                    that.getView().setModel(oTableModel, "lineStandardHeaderModel");
                    userRole = xhr.getResponseHeader('x-userrole');

                    if (userRole === "Viewer"){
                        that.getView().byId("viewerId").setVisible(true);
                        that.getView().byId("executorId").setVisible(false);
                    } else{
                        that.getView().byId("viewerId").setVisible(true);
                        that.getView().byId("executorId").setVisible(true);
                    }  
                    that.fnReadLineStdViewerTableData();
                }).fail(function (_xhr, _status, _error) {
                    BusyIndicator.hide();
                    MessageToast.show(that.oResourceBundle.getText("LINE_EXE_VIEWER_LOAD_FAIL"));
                });
            },
            fnReadLineStdExecutorTableData: function (sUrl) {
                var that = this;
                BusyIndicator.show(0);
                var aPlantData = this.getView().getModel("plantModel1").getData().results;
                var plantIds = [];
                for (var i = 0; i < aPlantData.length; i++) {
                    var plant = aPlantData[i].Werks;
                    plantIds.push(plant);
                }
                const plantsParam = plantIds.join(',');
                var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                var nbId = newData[0].Username;
                var zone = newData[0].Zone;
                var currentRole = "Executor/Viewer";

                if (sUrl != undefined) {
                    // sUrl = sUrl;
                }
                else {
                    sUrl = "odata/v4/data-services/LineRelStandardHeadersDB"
                }
                $.get({
                    url: sUrl,
                    method: 'GET',
                    headers: {
                        'x-username': nbId,
                        'x-zone': zone,
                        'x-plants': plantsParam,
                        'x-role': currentRole
                    }
                }).done(function (data) {
                    // 'data' here should contain the response from the OData endpoint                    
                    BusyIndicator.hide();
                    // Process or display the 'data' object as needed
                    var oTableModel = new sap.ui.model.json.JSONModel(data);
                    that.getView().setModel(oTableModel, "lineStandardHeaderModel");
                    that.getView().byId("idCreate").setVisible(false);
                    that.getView().byId("idLineCopyCreate").setVisible(false);
                    that.getView().byId("idMenu1").setVisible(false);
                    that.getView().byId("idMenu2").setVisible(false);
                    that.getView().byId("idMenu3").setVisible(true);
                    that.getView().byId("idCreatorMenu1").setVisible(false);
                    that.getView().byId("idArchive").setVisible(false);
                    
                    //Setting model at component level
                    that.getOwnerComponent().setModel(oTableModel, "lineStandardHeaderModel");
                    MessageToast.show(that.oResourceBundle.getText("LINE_STANDARDS_EXECUTOR_LOADED_SUCCESS"));
                    var aHeaderData = that.getView().getModel("lineStandardHeaderModel").getProperty("/value");
                    for (var i = 0; i < aHeaderData.length; i++) {
                        if (that.getView().getModel("lineStandardHeaderModel").getProperty("/value/" + i + "/status") == "Archived") {
                            that.getView().getModel("lineStandardHeaderModel").setProperty("/value/" + i + "/enable", false);
                        }
                    }
                   
                }).fail(function (xhr, status, error) {
                    BusyIndicator.hide();
                    // Handle errors if the request fails
                    MessageToast.show(that.oResourceBundle.getText("LINE_STANDARDS_EXECUTOR_LOADING_FAILED"));
                });
            },
            ////////////////////////////////////////////////////////////////////////////////////////
            fnReadLineStdViewerTableData: function (sUrl) {
                role = "V"
                var that = this;
                var aPlantData = this.getView().getModel("plantModel1").getData().results;
                var plantIds = [];
                for (var i = 0; i < aPlantData.length; i++) {
                    var plant = aPlantData[i].Werks;
                    plantIds.push(plant);
                }
                const plantsParam = plantIds.join(',');
                var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                var nbId = newData[0].Username;
                var zone = newData[0].Zone;
                roleVal = "V";
                this.getView().byId("idCreate").setVisible(false);
                this.getView().byId("idLineCopyCreate").setVisible(false);
                this.getView().byId("idCreatorMenu1").setVisible(false);
                this.getView().byId("idSubmitForApproval").setVisible(false);
                //toggleUser = 1;

                this.getView().byId("idMenu1").setVisible(true);
                this.getView().byId("idMenu2").setVisible(false);
                this.getView().byId("idMenu3").setVisible(false);
                this.getView().byId("idArchive").setVisible(false);

                if (sUrl === undefined) {
                    sUrl = "odata/v4/data-services/LineRelStandardHeadersDB"
                }
                BusyIndicator.show(0);
                $.get({
                    url: sUrl,
                    method: 'GET',
                    headers: {
                        'x-username': nbId,
                        'x-zone': zone,
                        'x-plants': plantsParam,
                        'x-role': "View"
                    }
                }).done(function (data) {
                    // 'data' here should contain the response from the OData endpoint                   
                    BusyIndicator.hide();
                    // Process or display the 'data' object as needed
                    var oTableModel = new sap.ui.model.json.JSONModel(data);
                    that.getView().setModel(oTableModel, "lineStandardHeaderModel");
                    //Setting model at component level
                    that.getOwnerComponent().setModel(oTableModel, "lineStandardHeaderModel");
                    MessageToast.show(that.oResourceBundle.getText("LINE_STD_VIEWER_SUCCESS"));
                    var aHeaderData = that.getView().getModel("lineStandardHeaderModel").getProperty("/value");
                    for (var i = 0; i < aHeaderData.length; i++) {
                        if (that.getView().getModel("lineStandardHeaderModel").getProperty("/value/" + i + "/status") == "Archived") {
                            that.getView().getModel("lineStandardHeaderModel").setProperty("/value/" + i + "/enable", false);
                        }
                    }
                   
                    // alert(JSON.stringify(data)); // Convert data to string for alert
                }).fail(function (xhr, status, error) {
                    BusyIndicator.hide();
                    // Handle errors if the request fails
                    MessageToast.show(that.oResourceBundle.getText("LINE_STD_VIEWER_FAIL"));
                });
            },
            fnLineExecutorNA: function () {
                var that = this;
                if (this.getView().byId("idLineTable").getSelectedItems()[0] != undefined) {
                    var sPath = this.getView().byId("idLineTable").getSelectedItems()[0].getBindingContext("lineStandardHeaderModel").sPath;
                }
                else {
                    var sPath = iLineExecutorSelIndex;
                }
                var oData = this.getView().getModel("lineStandardHeaderModel").getProperty(sPath);
                var sConfigNo = oData.configNo;
                var sLineStdNo = oData.lineStdNo;
                var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                var nbId = newData[0].Username;
                var executor = nbId;
                var oPayload = {
                    "stdNo": sLineStdNo,
                    "configNo": sConfigNo,
                    "executor": executor
                }
                //POST
                BusyIndicator.show();
                $.ajax({
                    url: "odata/v4/data-services/onExecutorNALineStd",
                    type: "POST",
                    data: JSON.stringify(oPayload),
                    contentType: "application/json",
                    dataType: "json",
                }).done(function (response) {
                    BusyIndicator.hide();
                    MessageToast.show(that.oResourceBundle.getText("EXECUTOR_NA_SENT_SUCCESS"));
                    var message = that.oResourceBundle.getText("EXECUTOR_NA_SENT_SUCCESS") + "\n";
                    that.onShowSuccess(message);
                    that.fnReadLineStdExecutorTableData();
                }).fail(function (xhr, status, error) {
                    BusyIndicator.hide();
                    MessageToast.show(that.oResourceBundle.getText("EXECUTOR_NA_FAILED") + ": " + xhr.responseJSON.error.message);
                    var message = that.oResourceBundle.getText("EXECUTOR_NA_FAILED") + ":\n" + xhr.responseJSON.error.code + ": " + xhr.responseJSON.error.message;

                    that.onShowError(message);
                    that.fnReadLineStdExecutorTableData();
                });
                ///////////////////////////////////////////////////////////////////////
                if (this._ExecutorReviewLine) {
                    this._ExecutorReviewLine.close();
                }
            },
            fnLineExecutorExecute: function () {
                var that = this;
                if (this.getView().byId("idLineTable").getSelectedItems()[0] != undefined) {
                    var sPath = this.getView().byId("idLineTable").getSelectedItems()[0].getBindingContext("lineStandardHeaderModel").sPath;
                } else {
                    var sPath = iLineExecutorSelIndex;
                }
                var oData = this.getView().getModel("lineStandardHeaderModel").getProperty(sPath);
                var sConfigNo = oData.configNo;
                var sLineStdNo = oData.lineStdNo;
                var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                var nbId = newData[0].Username;
                var executor = nbId;
                var oPayload = {
                    "stdNo": sLineStdNo,
                    "configNo": sConfigNo,
                    "executor": executor
                }
                //POST
                BusyIndicator.show();
                $.ajax({
                    url: "odata/v4/data-services/onExecutorNALineStd",
                    type: "POST",
                    data: JSON.stringify(oPayload),
                    contentType: "application/json",
                    dataType: "json",
                }).done(function (response) {
                    BusyIndicator.hide();
                    MessageToast.show(that.oResourceBundle.getText("EXECUTOR_EXECUTE_SUCCESS"));
                    var message = that.oResourceBundle.getText("EXECUTOR_EXECUTE_SUCCESS_MESSAGE") + "\n";
                    that.onShowSuccess(message);
                    that.fnReadLineStdExecutorTableData();
                }).fail(function (xhr, status, error) {
                    BusyIndicator.hide();
                    MessageToast.show(xhr.responseJSON.error.message + " " + that.oResourceBundle.getText("EXECUTOR_EXECUTE_FAILED"));
                    var message = that.oResourceBundle.getText("EXECUTOR_EXECUTE_FAILED_MESSAGE") + "\n" + xhr.responseJSON.error.code + ": " + xhr.responseJSON.error.message;
                    that.onShowError(message);
                    that.fnReadLineStdExecutorTableData();
                });
                ///////////////////////////////////////////////////////////////////////
                if (this._ExecutorReviewLine) {
                    this._ExecutorReviewLine.close();
                }
            },
            ////////////////////////////////////////////////////////////////////////////////////////
            onLineStdSearchPress: function () {
                //console.log(userRole);
                var oView = this.getView();
                var oTable = this.getView().byId("idLineTable");

                oTable.removeSelections(true); // Clear selections
                this.fnLineStandardTableRowSelected();
                var sUrl = "odata/v4/data-services/LineRelStandardHeadersDB?$filter=(";

                var oPlantComboBox = oView.byId("idLineFilterPlant").getSelectedKey();
                var count = 0;
                if (oPlantComboBox != "") {
                    sUrl = sUrl + "contains(plant,'" + oPlantComboBox + "')";
                    count++;
                }
                var oResourceComboBox = oView.byId("idLineFilterResource").getValue();
                if (oResourceComboBox != "") {
                    if (count != 0) {
                        sUrl = sUrl + " and contains(resource,'" + oResourceComboBox + "')";
                    }
                    else {
                        sUrl = sUrl + " contains(resource,'" + oResourceComboBox + "')";
                        count++;
                    }
                }
                var oCostCenterMultiComboBox = oView.byId("idCostCenterFilter").getValue();
                if (oCostCenterMultiComboBox != "") {
                    if (count != 0) {
                        sUrl = sUrl + " and contains(costCenter,'" + oCostCenterMultiComboBox + "')";
                    }
                    else {
                        sUrl = sUrl + " contains(costCenter,'" + oCostCenterMultiComboBox + "')";
                        count++;
                    }
                }
                if (this.getView().getModel("LineStandardFilterModel") != undefined) {
                    var oData = this.getView().getModel("LineStandardFilterModel").getData();
                    if (oData.validFrom != undefined) {
                        var dTo = oData.validFrom.to;
                        var dFrom = oData.validFrom.from;
                        if (oData.validFrom.to != "undefined-undefined-undefined" && oData.validFrom.from != "undefined-undefined-undefined") {
                            if (count != 0) {
                                sUrl = sUrl + " and validFrom ge " + dFrom + " and validFrom le " + dTo;
                            }
                            else {
                                sUrl = sUrl + " validFrom ge " + dFrom + " and validFrom le " + dTo;
                                count++;
                            }
                        }
                    }
                    if (this.getView().getModel("LineStandardFilterModel") != undefined) {
                        var oData = this.getView().getModel("LineStandardFilterModel").getData();
                        if (oData.modifiedFrom != undefined) {
                            var dTo = oData.modifiedFrom.to;
                            var dFrom = oData.modifiedFrom.from;
                            if (oData.modifiedFrom.to != "undefined-undefined-undefined" && oData.modifiedFrom.from != "undefined-undefined-undefined") {
                                if (count != 0) {
                                    sUrl = sUrl + " and modifiedFrom ge " + dFrom + " and modifiedFrom le " + dTo;
                                }
                                else {
                                    sUrl = sUrl + " modifiedFrom ge " + dFrom + " and modifiedFrom le " + dTo;
                                    count++;
                                }
                            }
                        }
                    }
                    if (oData.validTo != undefined) {

                        var dValidTo = oData.validTo.to;
                        var dValidFrom = oData.validTo.from;

                        if (oData.validTo.to != "undefined-undefined-undefined" && oData.validTo.from != "undefined-undefined-undefined") {

                            if (count != 0) {
                                sUrl = sUrl + " and validTo ge " + dValidFrom + " and validTo le " + dValidTo;
                            }
                            else {
                                sUrl = sUrl + " validTo ge " + dValidFrom + " and validTo le " + dValidTo;
                                count++;
                            }

                        }
                    }
                    if (oData.createdOn != undefined) {
                        var dCreatedTo = oData.createdOn.to;
                        var dCreatedFrom = oData.createdOn.from;
                        if (oData.createdOn.to != "undefined-undefined-undefined" && oData.createdOn.from != "undefined-undefined-undefined") {

                            if (count != 0) {
                                sUrl = sUrl + " and createdOn ge " + dCreatedFrom + "T00:00:00.000Z" + " and createdOn le " + dCreatedTo + "T23:59:59.000Z";
                            }
                            else {
                                sUrl = sUrl + " createdOn ge " + dCreatedFrom + "T00:00:00.000Z" + " and createdOn le " + dCreatedTo + "T23:59:59.000Z";
                                count++;
                            }
                        }
                    }
                    if (oData.lastChangedOn != undefined) {
                        var dLastTo = oData.lastChangedOn.to;
                        var dLastFrom = oData.lastChangedOn.from;
                        if (oData.lastChangedOn.to != "undefined-undefined-undefined" && oData.lastChangedOn.from != "undefined-undefined-undefined") {

                            if (count != 0) {
                                sUrl = sUrl + " and lastChangedOn ge " + dLastFrom + "T00:00:00.000Z" + " and lastChangedOn le " + dLastTo + "T23:59:59.000Z";
                            }
                            else {
                                sUrl = sUrl + " lastChangedOn ge " + dLastFrom + "T00:00:00.000Z" + " and lastChangedOn le " + dLastTo + "T23:59:59.000Z";
                                count++;
                            }
                        }
                    }
                }


                var iValid = 0;
                if (this.getView().byId("idProdCycleDaysRangSlider").getValue() != "") {
                    var sProdCycleDays = this.getView().byId("idProdCycleDaysRangSlider").getValue();
                    var patternRange = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                    var patternComma = /^[0-9]*(\.\d{1,3})?(,[0-9]*(\.\d{1,3})?)*$/;
                
                    if (patternRange.test(sProdCycleDays)) {
                        this.getView().byId("idProdCycleDaysRangSlider").setValueState("None");
                        var aProdCycleMinMax = sProdCycleDays.split('-');
                        var ProdCyMin = aProdCycleMinMax[0];
                        var ProdCyMax = aProdCycleMinMax[1];
                
                        if (count != 0) {
                            sUrl = sUrl + " and prodCyclesInDays ge " + ProdCyMin + " and prodCyclesInDays le " + ProdCyMax;
                        } else {
                            sUrl = sUrl + " prodCyclesInDays ge " + ProdCyMin + " and prodCyclesInDays le " + ProdCyMax;
                            count++;
                        }
                    } else if (patternComma.test(sProdCycleDays)) {
                        this.getView().byId("idProdCycleDaysRangSlider").setValueState("None");
                        var aCommaSeparatedValues = sProdCycleDays.split(',');
                        var sOrConditions = aCommaSeparatedValues.map(function (value) {
                            return "prodCyclesInDays eq " + value.trim();
                        }).join(" or ");
                
                        if (count != 0) {
                            sUrl = sUrl + " and (" + sOrConditions + ")";
                        } else {
                            sUrl = sUrl + " (" + sOrConditions + ")";
                            count++;
                        }
                    } else {
                        this.getView().byId("idProdCycleDaysRangSlider").setValueState("Error");
                        this.getView().byId("idProdCycleDaysRangSlider").setValueStateText("Enter a valid range (e.g., 10.876-15.456) or comma-separated values (e.g., 10.5,15.6)");
                        iValid = 1;
                    }
                }
                // if (this.getView().byId("idLineFilterShiftInDays").getValue() != "") {

                //     var sProdCycleDays = this.getView().byId("idLineFilterShiftInDays").getValue();
                //     var pattern = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                //     var bFlag = pattern.test(sProdCycleDays);
                //     if (bFlag) {
                //         this.getView().byId("idLineFilterShiftInDays").setValueState("None");

                //         var aShiftInDay = this.getView().byId("idLineFilterShiftInDays").getValue().split('-');
                //         if (aShiftInDay.length == 2) {
                //             var ShiftInDayMin = aShiftInDay[0];
                //             var ShiftInDayMax = aShiftInDay[1];
                //         }
                //         if (count != 0) {
                //             sUrl = sUrl + " and shiftsInDay ge " + ShiftInDayMin + " and shiftsInDay le " + ShiftInDayMax;
                //         }
                //         else {
                //             sUrl = sUrl + " shiftsInDay ge " + ShiftInDayMin + " and shiftsInDay le " + ShiftInDayMax;
                //             count++;
                //         }
                //     } else {
                //         this.getView().byId("idLineFilterShiftInDays").setValueState("Error");
                //         this.getView().byId("idLineFilterShiftInDays").setValueStateText(this.oResourceBundle.getText("LINE_SEARCH_MIN_MAX_ERROR"));

                //         iValid = 1;
                //     }


                // }
                if (this.getView().byId("idLineFilterShiftInDays").getValue() != "") {

                    var sShifinDays = this.getView().byId("idLineFilterShiftInDays").getValue();
                    var patternRange = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                    var patternComma = /^[0-9]*(\.\d{1,3})?(,[0-9]*(\.\d{1,3})?)*$/;
                
                    if (patternRange.test(sShifinDays)) {
                        this.getView().byId("idLineFilterShiftInDays").setValueState("None");
                
                        var aShiftInDays = sShifinDays.split('-');
                        if (aShiftInDays.length == 2) {
                            var ShiftDaysMin = aShiftInDays[0];
                            var ShiftDaysMax = aShiftInDays[1];
                        }
                        if (count != 0) {
                            sUrl = sUrl + " and shiftsInDay ge " + ShiftDaysMin + " and shiftsInDay le " + ShiftDaysMax;
                        } else {
                            sUrl = sUrl + " shiftsInDay ge " + ShiftDaysMin + " and shiftsInDay le " + ShiftDaysMax;
                            count++;
                        }
                    } else if (patternComma.test(sShifinDays)) {
                        this.getView().byId("idLineFilterShiftInDays").setValueState("None");
                
                        var aValues = sShifinDays.split(',');
                        var sOrConditions = aValues.map(function (value) {
                            return "shiftsInDay eq " + value.trim();
                        }).join(" or ");
                
                        if (count != 0) {
                            sUrl = sUrl + " and (" + sOrConditions + ")";   
                        } else {
                            sUrl = sUrl + " (" + sOrConditions + ")";
                            count++;
                        }
                    } else {
                        this.getView().byId("idLineFilterShiftInDays").setValueState("Error");
                        this.getView().byId("idLineFilterShiftInDays").setValueStateText(this.oResourceBundle.getText("LINE_SEARCH_MIN_MAX_ERROR"));
                        iValid = 1;
                    }
                
                }

                // if (this.getView().byId("idFilterShitsInCycle").getValue() != "") {

                //     var sProdCycleDays = this.getView().byId("idFilterShitsInCycle").getValue();
                //     var pattern = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                //     var bFlag = pattern.test(sProdCycleDays);
                //     if (bFlag) {
                //         this.getView().byId("idFilterShitsInCycle").setValueState("None");


                //         var aShiftInCycle = this.getView().byId("idFilterShitsInCycle").getValue().split('-');
                //         if (aShiftInCycle.length == 2) {
                //             var ShiftCycleMin = aShiftInCycle[0];
                //             var ShiftCycleMax = aShiftInCycle[1];
                //         }
                //         if (count != 0) {
                //             sUrl = sUrl + " and shiftsInCycle ge " + ShiftCycleMin + " and shiftsInCycle le " + ShiftCycleMax;
                //         }
                //         else {
                //             sUrl = sUrl + " shiftsInCycle ge " + ShiftCycleMin + " and shiftsInCycle le " + ShiftCycleMax;
                //             count++;
                //         }
                //     } else {
                //         this.getView().byId("idFilterShitsInCycle").setValueState("Error");
                //         this.getView().byId("idFilterShitsInCycle").setValueStateText(this.oResourceBundle.getText("LINE_SEARCH_MIN_MAX_ERROR"));
                //         iValid = 1;
                //     }
                // }
                if (this.getView().byId("idFilterShitsInCycle").getValue() != "") {

                    var sProdCycleDays = this.getView().byId("idFilterShitsInCycle").getValue();
                    var patternRange = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                    var patternComma = /^[0-9]*(\.\d{1,3})?(,[0-9]*(\.\d{1,3})?)*$/;
                    if (patternRange.test(sProdCycleDays)) {
                        this.getView().byId("idFilterShitsInCycle").setValueState("None");
                
                        var aShiftInCycle = sProdCycleDays.split('-');
                        var ShiftCycleMin = aShiftInCycle[0];
                        var ShiftCycleMax = aShiftInCycle[1];
                
                        if (count != 0) {
                            sUrl = sUrl + " and shiftsInCycle ge " + ShiftCycleMin + " and shiftsInCycle le " + ShiftCycleMax;
                        } else {
                            sUrl = sUrl + " shiftsInCycle ge " + ShiftCycleMin + " and shiftsInCycle le " + ShiftCycleMax;
                            count++;
                        }
                    }
                    else if (patternComma.test(sProdCycleDays)) {
                        this.getView().byId("idFilterShitsInCycle").setValueState("None");
                
                        var aCommaSeparatedValues = sProdCycleDays.split(',');
                        var sOrConditions = aCommaSeparatedValues.map(function (value) {
                            return "shiftsInCycle eq " + value.trim();
                        }).join(" or ");
                
                        if (count != 0) {
                            sUrl = sUrl + " and (" + sOrConditions + ")";
                        } else {
                            sUrl = sUrl + " (" + sOrConditions + ")";
                            count++;
                        }
                    }
                    else {
                        this.getView().byId("idFilterShitsInCycle").setValueState("Error");
                        this.getView().byId("idFilterShitsInCycle").setValueStateText(this.oResourceBundle.getText("LINE_SEARCH_MIN_MAX_ERROR"));
                        iValid = 1;
                    }
                }
                // if (this.getView().byId("idLineFilterCycleHrs").getValue() != "") {

                //     var sProdCycleDays = this.getView().byId("idLineFilterCycleHrs").getValue();
                //     var pattern = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                //     var bFlag = pattern.test(sProdCycleDays);
                //     if (bFlag) {
                //         this.getView().byId("idLineFilterCycleHrs").setValueState("None");

                //         var aCycleHrs = this.getView().byId("idLineFilterCycleHrs").getValue().split('-');
                //         if (aCycleHrs.length == 2) {
                //             var cycleHrsMin = aCycleHrs[0];
                //             var cycleHrsMax = aCycleHrs[1];
                //         }
                //         if (count != 0) {
                //             sUrl = sUrl + " and cycleHrs ge " + cycleHrsMin + " and cycleHrs le " + cycleHrsMax;
                //         }
                //         else {
                //             sUrl = sUrl + " cycleHrs ge " + cycleHrsMin + " and cycleHrs le " + cycleHrsMax;
                //             count++;
                //         }
                //     } else {
                //         this.getView().byId("idLineFilterCycleHrs").setValueState("Error");
                //         this.getView().byId("idLineFilterCycleHrs").setValueStateText(this.oResourceBundle.getText("LINE_SEARCH_MIN_MAX_ERROR"));
                //         iValid = 1;
                //     }

                // }
                if (this.getView().byId("idLineFilterCycleHrs").getValue() != "") {

                    var sProdCycleDays = this.getView().byId("idLineFilterCycleHrs").getValue();
                    var patternRange = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                    var patternComma = /^[0-9]*(\.\d{1,3})?(,[0-9]*(\.\d{1,3})?)*$/;
                
                    if (patternRange.test(sProdCycleDays)) {
                        this.getView().byId("idLineFilterCycleHrs").setValueState("None");
                
                        var aCycleHrs = sProdCycleDays.split('-');
                        var cycleHrsMin = aCycleHrs[0];
                        var cycleHrsMax = aCycleHrs[1];
                
                        if (count != 0) {
                            sUrl = sUrl + " and cycleHrs ge " + cycleHrsMin + " and cycleHrs le " + cycleHrsMax;
                        } else {
                            sUrl = sUrl + " cycleHrs ge " + cycleHrsMin + " and cycleHrs le " + cycleHrsMax;
                            count++;
                        }
                    }
                    else if (patternComma.test(sProdCycleDays)) {
                        this.getView().byId("idLineFilterCycleHrs").setValueState("None");
                
                        var aCommaSeparatedValues = sProdCycleDays.split(',');
                        var sOrConditions = aCommaSeparatedValues.map(function (value) {
                            return "cycleHrs eq " + value.trim();
                        }).join(" or ");
                
                        if (count != 0) {
                            sUrl = sUrl + " and (" + sOrConditions + ")";
                        } else {
                            sUrl = sUrl + " (" + sOrConditions + ")";
                            count++;
                        }
                    }
                    else {
                        this.getView().byId("idLineFilterCycleHrs").setValueState("Error");
                        this.getView().byId("idLineFilterCycleHrs").setValueStateText(this.oResourceBundle.getText("LINE_SEARCH_MIN_MAX_ERROR"));
                        iValid = 1;
                    }
                }

                // if (this.getView().byId("idLineFilterCyclesInYear").getValue() != "") {

                //     var sProdCycleDays = this.getView().byId("idLineFilterCyclesInYear").getValue();
                //     var pattern = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                //     var bFlag = pattern.test(sProdCycleDays);
                //     if (bFlag) {


                //         this.getView().byId("idLineFilterCyclesInYear").setValueState("None");

                //         var aCycleInYear = this.getView().byId("idLineFilterCyclesInYear").getValue().split('-');
                //         if (aCycleInYear.length == 2) {
                //             var cycleInYearMin = aCycleInYear[0];
                //             var cycleInYearMax = aCycleInYear[1];
                //         }
                //         if (count != 0) {
                //             sUrl = sUrl + " and cyclesInYear ge " + cycleInYearMin + " and cyclesInYear le " + cycleInYearMax;
                //         }
                //         else {
                //             sUrl = sUrl + " cyclesInYear ge " + cycleInYearMin + " and cyclesInYear le " + cycleInYearMax;
                //             count++;
                //         }
                //     } else {
                //         this.getView().byId("idLineFilterCyclesInYear").setValueState("Error");
                //         this.getView().byId("idLineFilterCyclesInYear").setValueStateText(this.oResourceBundle.getText("LINE_SEARCH_MIN_MAX_ERROR"));
                //         iValid = 1;
                //     }

                // }
                if (this.getView().byId("idLineFilterCyclesInYear").getValue() != "") {

                    var sProdCycleDays = this.getView().byId("idLineFilterCyclesInYear").getValue();
                    var patternRange = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                    var patternComma = /^[0-9]*(\.\d{1,3})?(,[0-9]*(\.\d{1,3})?)*$/;
                
                    if (patternRange.test(sProdCycleDays)) {
                        this.getView().byId("idLineFilterCyclesInYear").setValueState("None");
                
                        var aCycleInYear = sProdCycleDays.split('-');
                        var cycleInYearMin = aCycleInYear[0];
                        var cycleInYearMax = aCycleInYear[1];
                
                        if (count != 0) {
                            sUrl = sUrl + " and cyclesInYear ge " + cycleInYearMin + " and cyclesInYear le " + cycleInYearMax;
                        } else {
                            sUrl = sUrl + " cyclesInYear ge " + cycleInYearMin + " and cyclesInYear le " + cycleInYearMax;
                            count++;
                        }
                    }
                    else if (patternComma.test(sProdCycleDays)) {
                        this.getView().byId("idLineFilterCyclesInYear").setValueState("None");
                
                        var aCommaSeparatedValues = sProdCycleDays.split(',');
                        var sOrConditions = aCommaSeparatedValues.map(function (value) {
                            return "cyclesInYear eq " + value.trim();
                        }).join(" or ");
                
                        if (count != 0) {
                            sUrl = sUrl + " and (" + sOrConditions + ")";
                        } else {
                            sUrl = sUrl + " (" + sOrConditions + ")";
                            count++;
                        }
                    }
                    else {
                        this.getView().byId("idLineFilterCyclesInYear").setValueState("Error");
                        this.getView().byId("idLineFilterCyclesInYear").setValueStateText(this.oResourceBundle.getText("LINE_SEARCH_MIN_MAX_ERROR"));
                        iValid = 1;
                    }
                }

                // if (this.getView().byId("idLineFilterTotOccuTime").getValue() != "") {

                //     var sProdCycleDays = this.getView().byId("idLineFilterTotOccuTime").getValue();
                //     var pattern = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                //     var bFlag = pattern.test(sProdCycleDays);
                //     if (bFlag) {
                //         this.getView().byId("idLineFilterTotOccuTime").setValueState("None");


                //         var aTotalOccuTime = this.getView().byId("idLineFilterTotOccuTime").getValue().split('-');
                //         if (aTotalOccuTime.length == 2) {
                //             var totalOccuMin = aTotalOccuTime[0];
                //             var totalOccuMax = aTotalOccuTime[1];
                //         }
                //         if (count != 0) {
                //             sUrl = sUrl + " and totalOccupiedTime ge " + totalOccuMin + " and totalOccupiedTime le " + totalOccuMax;
                //         }
                //         else {
                //             sUrl = sUrl + " totalOccupiedTime ge " + totalOccuMin + " and totalOccupiedTime le " + totalOccuMax;
                //             count++;
                //         }
                //     } else {
                //         this.getView().byId("idLineFilterTotOccuTime").setValueState("Error");
                //         this.getView().byId("idLineFilterTotOccuTime").setValueStateText(this.oResourceBundle.getText("LINE_SEARCH_MIN_MAX_ERROR"));
                //         iValid = 1;
                //     }

                // }
                if (this.getView().byId("idLineFilterTotOccuTime").getValue() != "") {

                    var sProdCycleDays = this.getView().byId("idLineFilterTotOccuTime").getValue();
                    var patternRange = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                    var patternComma = /^[0-9]*(\.\d{1,3})?(,[0-9]*(\.\d{1,3})?)*$/;

                    if (patternRange.test(sProdCycleDays)) {
                        this.getView().byId("idLineFilterTotOccuTime").setValueState("None");
                
                        var aTotalOccuTime = sProdCycleDays.split('-');
                        var totalOccuMin = aTotalOccuTime[0];
                        var totalOccuMax = aTotalOccuTime[1];
                
                        if (count != 0) {
                            sUrl = sUrl + " and totalOccupiedTime ge " + totalOccuMin + " and totalOccupiedTime le " + totalOccuMax;
                        } else {
                            sUrl = sUrl + " totalOccupiedTime ge " + totalOccuMin + " and totalOccupiedTime le " + totalOccuMax;
                            count++;
                        }
                    }
                    else if (patternComma.test(sProdCycleDays)) {
                        this.getView().byId("idLineFilterTotOccuTime").setValueState("None");
                
                        var aCommaSeparatedValues = sProdCycleDays.split(',');
                        var sOrConditions = aCommaSeparatedValues.map(function (value) {
                            return "totalOccupiedTime eq " + value.trim();
                        }).join(" or ");
                
                        if (count != 0) {
                            sUrl = sUrl + " and (" + sOrConditions + ")";
                        } else {
                            sUrl = sUrl + " (" + sOrConditions + ")";
                            count++;
                        }
                    }
                    else {
                        this.getView().byId("idLineFilterTotOccuTime").setValueState("Error");
                        this.getView().byId("idLineFilterTotOccuTime").setValueStateText(this.oResourceBundle.getText("LINE_SEARCH_MIN_MAX_ERROR"));
                        iValid = 1;
                    }
                }

                var oStatusComboBox = oView.byId("idLineStatusFilter").getSelectedItems();
                if (oStatusComboBox.length > 0) {
                    for (var i = 0; i < oStatusComboBox.length; i++) {
                        if (count != 0) {
                            if (i == 0) {
                                sUrl = sUrl + " and (status eq '" + oStatusComboBox[i].mProperties.text + "'";
                            }
                            else {
                                sUrl = sUrl + " or status eq '" + oStatusComboBox[i].mProperties.text + "'";
                            }

                        }
                        else {
                            sUrl = sUrl + "(status eq '" + oStatusComboBox[i].mProperties.text + "'";
                            count++;
                        }
                        if (i == oStatusComboBox.length - 1) {
                            sUrl = sUrl + ")";
                        }

                    }
                }
                sUrl = sUrl + ")";
                if (count !== 0) {
                    // this.getProductStdHeaderData();  
                    //sap.m.MessageBox.warning(this.oResourceBundle.getText("BLANK_PRODSTD_SEARCH"));
                    
                    if ((role === 'C')|| (role === "S")) {
                        this.fnReadLineStdHeaderTableData(sUrl);
                    }
                    else if (role === 'A') {
                        this.fnReadLineStdApproverTableData(sUrl);                      
                    }
                    else if (role === 'E') {                       
                        this.fnReadLineStdExecutorTableData(sUrl);                      
                    }
                    else{
                        this.fnReadLineStdViewerTableData(sUrl);
                    }

                }

            },

            onLineFilterReset: function () {
                var oView = this.getView();
                var oTable = this.getView().byId("idLineTable");
                oTable.removeSelections(true); // Clear selections
                this.fnLineStandardTableRowSelected();
                // Fetch controls by their IDs
                var oPlantComboBox = oView.byId("idLineFilterPlant");
                var oResourceComboBox = oView.byId("idLineFilterResource");
                var oCostCenterMultiComboBox = oView.byId("idCostCenterFilter");
                var oValidFromDatePicker = oView.byId("DPValidFrom");
                var oModifiedFromDatePicker = oView.byId("DPModifiedfrom");
                var oValidToDatePicker = oView.byId("DPValidTo");
                var oCreatedOnDatePicker = oView.byId("DPCreatedOn");
                var oLastChangedOnDatePicker = oView.byId("DPLastChangedOn");
                var oStatus = oView.byId("idLineStatusFilter");
                var oProdCycleInDays = oView.byId("idProdCycleDaysRangSlider");
                var oShiftsInDays = oView.byId("idLineFilterShiftInDays");
                var oShiftsInCycle = oView.byId("idFilterShitsInCycle");
                var oCycleHours = oView.byId("idLineFilterCycleHrs");
                var oCyclesInYear = oView.byId("idLineFilterCyclesInYear");
                var oTotalOccupiedTime = oView.byId("idLineFilterTotOccuTime");

                if (oPlantComboBox) {
                    //  oPlantComboBox.setSelectedItems([]);
                    oPlantComboBox.setValue('');
                }

                if (oResourceComboBox) {
                    // oResourceComboBox.setSelectedItems([]);
                    oResourceComboBox.setValue('');
                }

                if (oCostCenterMultiComboBox) {
                    // oCostCenterMultiComboBox.setSelectedItems([]);
                    oCostCenterMultiComboBox.setValue('');
                }

                if (oStatus) {
                    oStatus.setSelectedItems([]);
                    // oStatus.setValue();
                }
                if (oValidFromDatePicker) {
                    oValidFromDatePicker.setValue("");
                }
                if (oModifiedFromDatePicker) {
                    oModifiedFromDatePicker.setValue("");
                }

                if (oValidToDatePicker) {
                    oValidToDatePicker.setValue("");
                }
                if (oCreatedOnDatePicker) {
                    oCreatedOnDatePicker.setValue("");
                }
                if (oLastChangedOnDatePicker) {
                    oLastChangedOnDatePicker.setValue("");
                }
                // Clear the Date filter model
                this.getView().getModel("LineStandardFilterModel").setData({});

                if (oProdCycleInDays) {
                    oProdCycleInDays.setValue("");
                    // oProdCycleInDays.setValue("");
                }
                if (oShiftsInDays) {
                    oShiftsInDays.setValue("");
                    // oShiftsInDays.setValue("");
                }
                if (oShiftsInCycle) {
                    oShiftsInCycle.setValue("");
                    //  oShiftsInCycle.setValue("");
                }
                if (oCycleHours) {
                    oCycleHours.setValue("");
                    //  oCycleHours.setValue("");
                }
                if (oCyclesInYear) {
                    oCyclesInYear.setValue("");
                    // oCyclesInYear.setValue("");
                }
                if (oTotalOccupiedTime) {
                    oTotalOccupiedTime.setValue("");
                }
                var oTable = this.getView().byId("idLineTable");
                var oBinding = oTable.getBinding("items");
                var sUrl = "odata/v4/data-services/LineRelStandardHeadersDB";
                if ((role === 'C')|| (role === "S")) {
                    this.fnReadLineStdHeaderTableData(sUrl);
                }
                else if (role === 'A') {
                    this.fnReadLineStdApproverTableData(sUrl);                      
                }
                else if (role === 'E') {                       
                    this.fnReadLineStdExecutorTableData(sUrl);                      
                }
                else{
                    this.fnReadLineStdViewerTableData(sUrl);
                }
            },
            ////////////////////////////////////////////////////////////
            onConfiguration: function () {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("ConFigView");
            },
            //////////////////////////////// Line standard  create step2 Add Functionality //////////////////////////////////////////
            AddStandardCyclesDB: function (oEvent) {

                var condition = sap.ui.getCore().byId("idCondition").getValue();
                var conDescrip = sap.ui.getCore().byId("idConditionDesc").getValue();
                var shiftLen = Number(sap.ui.getCore().byId("idShiftLength").getValue());
                var productionCycle = Number(sap.ui.getCore().byId("idProductionCycle").getValue());
                var shiftInDays = Number(sap.ui.getCore().byId("idShiftDays").getValue());
                var cycleInYear = Number(sap.ui.getCore().byId("idcycleYear").getValue());

                //calculcated fields(additional fields not shown in screen) for cycles DB 
                var shiftInCycleInt = Number(productionCycle.toFixed(3)) * Number(shiftInDays.toFixed(3));
                var cycleHoursInt = Number(shiftInCycleInt.toFixed(3)) * Number(shiftLen.toFixed(3));
                var totalOccupiedTimeInt = Number(cycleHoursInt.toFixed(3)) * Number(cycleInYear.toFixed(3));

                var obj = {};
                obj.condition = condition;
                obj.conditionDesc = conDescrip;
                obj.shiftLength = Number(shiftLen.toFixed(3));
                obj.prodCyclesInDays = Number(productionCycle.toFixed(3));
                obj.shiftsInDays = Number(shiftInDays.toFixed(3));
                obj.cyclesInYear = Number(cycleInYear.toFixed(3));
                //calculcated fields(additional fields not shown in screen) for cycles DB 
                obj.shiftsInCycle = Number(shiftInCycleInt.toFixed(3));
                obj.cycleHrs = Number(cycleHoursInt.toFixed(3));
                obj.totalOccupiedTime = Number(totalOccupiedTimeInt.toFixed(3));
                var iSum = 0;
                var iCycInYearCeiling;
                if (this.getView().getModel("createLineStandardModel").getProperty("/LineHdrToCyclesDataNav") == undefined) {
                    iCycInYearCeiling = Number((365 / obj.prodCyclesInDays).toFixed(3));
                }
                else {
                    var aCyclesDbData = this.getView().getModel("createLineStandardModel").getProperty("/LineHdrToCyclesDataNav");
                    for (var i = 0; i < aCyclesDbData.length; i++) {
                        iSum = Number((aCyclesDbData[i].prodCyclesInDays * aCyclesDbData[i].cyclesInYear).toFixed(3)) + iSum;
                    }
                    iCycInYearCeiling = Number((((365 - iSum)) / obj.prodCyclesInDays).toFixed(3));
                }





                if (condition != "" && conDescrip != "" && shiftLen != "" && shiftLen <= 24 && productionCycle != "" && productionCycle <= 365 && shiftInDays != "" && shiftInDays <= (24 / shiftLen) && cycleInYear != "" && cycleInYear <= iCycInYearCeiling && cycleInYear > 0) {
                    if (this.getView().getModel("createLineStandardModel").getProperty("/LineHdrToCyclesDataNav") == undefined) {
                        var aCurrentData = [];
                        aCurrentData.push(obj);
                    }
                    else {
                        var aCurrentData = this.getView().getModel("createLineStandardModel").getProperty("/LineHdrToCyclesDataNav");
                        aCurrentData.push(obj);
                    }
                    this.getView().getModel("createLineStandardModel").setProperty("/LineHdrToCyclesDataNav", aCurrentData);
                    sap.ui.getCore().byId("idCondition").setValue("");
                    sap.ui.getCore().byId("idConditionDesc").setValue("");
                    sap.ui.getCore().byId("idShiftLength").setValue("");
                    sap.ui.getCore().byId("idProductionCycle").setValue("");
                    sap.ui.getCore().byId("idShiftDays").setValue("");
                    sap.ui.getCore().byId("idcycleYear").setValue("");

                    sap.ui.getCore().byId("idCondition").setValueState("None");
                    sap.ui.getCore().byId("idConditionDesc").setValueState("None");
                    sap.ui.getCore().byId("idShiftLength").setValueState("None");
                    sap.ui.getCore().byId("idProductionCycle").setValueState("None");
                    sap.ui.getCore().byId("idShiftDays").setValueState("None");
                    sap.ui.getCore().byId("idcycleYear").setValueState("None");

                } else {

                    if (condition == "") {
                        sap.ui.getCore().byId("idCondition").setValueState("Error");
                        sap.ui.getCore().byId("idCondition").setValueStateText(this.oResourceBundle.getText("ERROR_CONDITION"));
                    } else {
                        sap.ui.getCore().byId("idCondition").setValueState("None");
                    }
                    if (conDescrip == "") {
                        sap.ui.getCore().byId("idConditionDesc").setValueState("Error");
                        sap.ui.getCore().byId("idConditionDesc").setValueStateText(this.oResourceBundle.getText("ERROR_CONDITION_DESC"));
                    } else {
                        sap.ui.getCore().byId("idConditionDesc").setValueState("None");
                    }
                    if (shiftLen == "" || shiftLen > 24) {
                        sap.ui.getCore().byId("idShiftLength").setValueState("Error");
                        sap.ui.getCore().byId("idShiftLength").setValueStateText(this.oResourceBundle.getText("ERROR_SHIFT_LENGTH"));
                    } else {
                        sap.ui.getCore().byId("idShiftLength").setValueState("None");
                    }
                    if (productionCycle == "" || productionCycle > 365) {
                        sap.ui.getCore().byId("idProductionCycle").setValueState("Error");
                        sap.ui.getCore().byId("idProductionCycle").setValueStateText(this.oResourceBundle.getText("ERROR_PRODUCTION_CYCLE"));
                    } else {
                        sap.ui.getCore().byId("idProductionCycle").setValueState("None");
                    }
                    if (shiftInDays == "" || shiftInDays > (24 / shiftLen)) {
                        sap.ui.getCore().byId("idShiftDays").setValueState("Error");
                        sap.ui.getCore().byId("idShiftDays").setValueStateText(this.oResourceBundle.getText("ERROR_SHIFT_DAYS") + " < 24/" + shiftLen + ", " + this.oResourceBundle.getText("ERROR_LESS_THAN") + Number((24 / shiftLen).toFixed(3)));
                    } else {
                        sap.ui.getCore().byId("idShiftDays").setValueState("None");
                    }


                    // if (cycleInYear == "" || cycleInYear > (365 / cycleHoursInt)) {
                    if (cycleInYear == "" || cycleInYear > iCycInYearCeiling || cycleInYear < 0) {
                        sap.ui.getCore().byId("idcycleYear").setValueState("Error");
                        sap.ui.getCore().byId("idcycleYear").setValueStateText(this.oResourceBundle.getText("ERROR_CYCLE_IN_YEAR") + " " + iCycInYearCeiling);
                        //sap.ui.getCore().byId("idcycleYear").setValueStateText("Enter the cycle in year <= 365/" + productionCycle + ", i.e less than:" + Number((365 / Number(productionCycle).toFixed(3)).toFixed(3)));
                    } else {
                        sap.ui.getCore().byId("idcycleYear").setValueState("None");
                    }
                }
            },

            // Line standard Create ADD  Cycles EventsDB function
            AddStandardCyclesEventsDB: function (oEvent) {

                var lossCat = sap.ui.getCore().byId("idLossCat").getSelectedKey();
                var subCat = sap.ui.getCore().byId("idSubCat").getValue(); //getSelectedKey();
                var crewSize = Number(sap.ui.getCore().byId("idExpectedCrewSize").getValue());
                var ExpFrequency = Number(sap.ui.getCore().byId("idExpectedFreq").getValue());
                var ExpEventDur = Number(sap.ui.getCore().byId("idExpectEventDuration").getValue());

                if (lossCat != "" && subCat != "" && ExpFrequency != "" && ExpEventDur != "") {
                    var obj = {};
                    obj.lossCat = lossCat;
                    obj.subCat = subCat;
                    obj.expectedCrewSize = Number(crewSize.toFixed(3));
                    obj.expectedFreqPerCycle = Number(ExpFrequency.toFixed(3));
                    obj.expectedEvtDur = Number(ExpEventDur.toFixed(3));

                    if (this.getView().getModel("createLineStandardModel").getProperty("/LineHdrToCyclesEvtDataNav") == undefined) {
                        var aCurrentData = [];
                        aCurrentData.push(obj);
                    }
                    else {
                        var aCurrentData = this.getView().getModel("createLineStandardModel").getProperty("/LineHdrToCyclesEvtDataNav");
                        aCurrentData.push(obj);
                    }
                    this.getView().getModel("createLineStandardModel").setProperty("/LineHdrToCyclesEvtDataNav", aCurrentData);
                    sap.ui.getCore().byId("idLossCat").setValueState("None");
                    sap.ui.getCore().byId("idSubCat").setValueState("None");
                    sap.ui.getCore().byId("idExpectedFreq").setValueState("None");
                    sap.ui.getCore().byId("idExpectEventDuration").setValueState("None");
                    sap.ui.getCore().byId("idLossCat").setValue("");
                    sap.ui.getCore().byId("idSubCat").setValue("");
                    sap.ui.getCore().byId("idSubCat").setEditable(false);
                    sap.ui.getCore().byId("idExpectedCrewSize").setValue("");
                    sap.ui.getCore().byId("idExpectedCrewSize").setEditable(false);
                    sap.ui.getCore().byId("idExpectedFreq").setValue("");
                    sap.ui.getCore().byId("idExpectedFreq").setEditable(false);
                    sap.ui.getCore().byId("idExpectEventDuration").setValue("");
                    sap.ui.getCore().byId("idExpectEventDuration").setEditable(false);
                } else {
                    if (lossCat == "") {
                        sap.ui.getCore().byId("idLossCat").setValueState("Error");
                        sap.ui.getCore().byId("idLossCat").setValueStateText(this.oResourceBundle.getText("ERROR_LOSS_CATEGORY"));
                    } else {
                        sap.ui.getCore().byId("idLossCat").setValueState("None");
                    }
                    if (subCat == "") {
                        sap.ui.getCore().byId("idSubCat").setValueState("Error");
                        sap.ui.getCore().byId("idSubCat").setValueStateText(this.oResourceBundle.getText("ERROR_SUB_CATEGORY"));
                    } else {
                        sap.ui.getCore().byId("idSubCat").setValueState("None");
                    }
                    if (ExpFrequency == "") {
                        sap.ui.getCore().byId("idExpectedFreq").setValueState("Error");
                        sap.ui.getCore().byId("idExpectedFreq").setValueStateText(this.oResourceBundle.getText("ERROR_EXPECTED_FREQUENCY"));
                    } else {
                        sap.ui.getCore().byId("idExpectedFreq").setValueState("None");
                    }
                    if (ExpEventDur == "") {
                        sap.ui.getCore().byId("idExpectEventDuration").setValueState("Error");
                        sap.ui.getCore().byId("idExpectEventDuration").setValueStateText(this.oResourceBundle.getText("ERROR_EXPECTED_DURATION"));
                    } else {
                        sap.ui.getCore().byId("idExpectEventDuration").setValueState("None");
                    }
                }
            },
            // Line standard Create step4  AnnualEventsDB Add function 
            AddStandardAnnualEventsDB: function (oEvent) {

                var lossCat = sap.ui.getCore().byId("idAnnualLossCat").getSelectedKey();
                var subCat = sap.ui.getCore().byId("idAnnualSubCat").getValue(); //getSelectedKey();
                var crewSize = Number(Number(sap.ui.getCore().byId("idAnnualCrewSize").getValue()).toFixed(3));
                var ExpFrequency = Number(Number(sap.ui.getCore().byId("idAnnaulFreq").getValue()).toFixed(3));
                var ExpEventDur = Number(Number(sap.ui.getCore().byId("idAnnualEventDur").getValue()).toFixed(3));
                var cycleInYear = Number(Number(sap.ui.getCore().byId("idAnnualCycleYear").getValue()).toFixed(3));

                if (lossCat == "") {
                    sap.ui.getCore().byId("idAnnualLossCat").setValueState("Error");
                    sap.ui.getCore().byId("idAnnualLossCat").setValueStateText(this.oResourceBundle.getText("ERROR_LOSS_CATEGORY"));
                } else {
                    sap.ui.getCore().byId("idAnnualLossCat").setValueState("None");
                }
                if (subCat == "") {
                    sap.ui.getCore().byId("idAnnualSubCat").setValueState("Error");
                    sap.ui.getCore().byId("idAnnualSubCat").setValueStateText(this.oResourceBundle.getText("ERROR_SUB_CATEGORY"));
                } else {
                    sap.ui.getCore().byId("idAnnualSubCat").setValueState("None");
                }
                if (crewSize == "") {
                    sap.ui.getCore().byId("idAnnualCrewSize").setValueState("Error");
                    sap.ui.getCore().byId("idAnnualCrewSize").setValueStateText(this.oResourceBundle.getText("ERROR_EXPECTED_CREWSIZE"));
                } else {
                    sap.ui.getCore().byId("idAnnualCrewSize").setValueState("None");
                }
                if (ExpFrequency == "") {
                    sap.ui.getCore().byId("idAnnaulFreq").setValueState("Error");
                    sap.ui.getCore().byId("idAnnaulFreq").setValueStateText(this.oResourceBundle.getText("ERROR_EXPECTED_FREQUENCY"));
                } else {
                    sap.ui.getCore().byId("idAnnaulFreq").setValueState("None");
                }
                if (ExpEventDur == "") {
                    sap.ui.getCore().byId("idAnnualEventDur").setValueState("Error");
                    sap.ui.getCore().byId("idAnnualEventDur").setValueStateText(this.oResourceBundle.getText("ERROR_EXP_EVENT_DUR"));
                } else {
                    sap.ui.getCore().byId("idAnnualEventDur").setValueState("None");
                }
                if (cycleInYear == "") {
                    sap.ui.getCore().byId("idAnnualCycleYear").setValueState("Error");
                    sap.ui.getCore().byId("idAnnualCycleYear").setValueStateText(this.oResourceBundle.getText("ERROR_CYCLE_IN_YEAR"));
                } else {
                    sap.ui.getCore().byId("idAnnualCycleYear").setValueState("None");
                }
                if (lossCat != "" && subCat != "" && crewSize != "" && ExpFrequency != "" && ExpEventDur != "" && cycleInYear != "") {
                    var obj = {};
                    obj.lossCat = lossCat;
                    obj.subCat = subCat;
                    obj.expectedCrewSize = Number(crewSize);
                    obj.expectedFrequency = Number(ExpFrequency);
                    obj.expectedEvtDur = Number(ExpEventDur);
                    obj.cyclesInYear = Number(cycleInYear);

                    if (this.getView().getModel("createLineStandardModel").getProperty("/LineHdrToAnnualEvtDataNav") == undefined) {
                        var aCurrentData = [];
                        aCurrentData.push(obj);
                    }
                    else {
                        var aCurrentData = this.getView().getModel("createLineStandardModel").getProperty("/LineHdrToAnnualEvtDataNav");
                        aCurrentData.push(obj);
                    }
                    this.getView().getModel("createLineStandardModel").setProperty("/LineHdrToAnnualEvtDataNav", aCurrentData);

                    sap.ui.getCore().byId("idAnnualLossCat").setValueState("None");
                    sap.ui.getCore().byId("idAnnualSubCat").setValueState("None");
                    sap.ui.getCore().byId("idAnnualCrewSize").setValueState("None");
                    sap.ui.getCore().byId("idAnnaulFreq").setValueState("None");
                    sap.ui.getCore().byId("idAnnualEventDur").setValueState("None");
                    sap.ui.getCore().byId("idAnnualCycleYear").setValueState("None");

                    sap.ui.getCore().byId("idAnnualLossCat").setValue("");
                    sap.ui.getCore().byId("idAnnualSubCat").setValue("");
                    sap.ui.getCore().byId("idAnnualCrewSize").setValue("");
                    sap.ui.getCore().byId("idAnnaulFreq").setValue("");
                    sap.ui.getCore().byId("idAnnualEventDur").setValue("");
                    sap.ui.getCore().byId("idAnnualCycleYear").setValue("");

                    sap.ui.getCore().byId("idAnnualSubCat").setEditable(false);
                    sap.ui.getCore().byId("idAnnualCrewSize").setEditable(false);
                    sap.ui.getCore().byId("idAnnaulFreq").setEditable(false);
                    sap.ui.getCore().byId("idAnnualEventDur").setEditable(false);
                    sap.ui.getCore().byId("idAnnualCycleYear").setEditable(false);
                }
            },
            //////////////////line update add function start///////////////////////////////////////////////////////////////////////
            // Line standard update step2 Add Functionality 
            AddStandardCyclesDBupdate: function (_oEvent) {

                var condition = sap.ui.getCore().byId("idConditionUpdate").getValue();
                var conDescrip = sap.ui.getCore().byId("idConditionDescupdate").getValue();
                var shiftLen = Number(sap.ui.getCore().byId("idShiftLengthupdate").getValue());
                var productionCycle = Number(sap.ui.getCore().byId("idProductionCycleupdate").getValue());
                var shiftInDays = Number(sap.ui.getCore().byId("idShiftDaysupdate").getValue());
                var cycleInYear = Number(sap.ui.getCore().byId("idcycleYearupdate").getValue());

                //calculcated fields(additional fields not shown in screen) for cycles DB 
                var shiftInCycleInt = Number(productionCycle.toFixed(3)) * Number(shiftInDays.toFixed(3));
                var cycleHoursInt = Number(shiftInCycleInt.toFixed(3)) * Number(shiftLen.toFixed(3));
                var totalOccupiedTimeInt = Number(cycleHoursInt.toFixed(3)) * Number(cycleInYear.toFixed(3));

                var obj = {};
                obj.condition = condition;
                obj.conditionDesc = conDescrip;
                obj.shiftLength = Number(shiftLen.toFixed(3));
                obj.prodCyclesInDays = Number(productionCycle.toFixed(3));
                obj.shiftsInDays = Number(shiftInDays.toFixed(3));
                obj.cyclesInYear = Number(cycleInYear.toFixed(3));
                //calculcated fields(additional fields not shown in screen) for cycles DB 
                obj.shiftsInCycle = Number(shiftInCycleInt.toFixed(3));
                obj.cycleHrs = Number(cycleHoursInt.toFixed(3));
                obj.totalOccupiedTime = Number(totalOccupiedTimeInt.toFixed(3));

                var iSum = 0;
                var iCycInYearCeiling;
                if (this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesDataNav") == undefined) {
                    iCycInYearCeiling = Number((365 / obj.prodCyclesInDays).toFixed(3));
                }
                else {
                    var aCyclesDbData = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesDataNav");
                    for (var i = 0; i < aCyclesDbData.length; i++) {
                        iSum = Number((aCyclesDbData[i].prodCyclesInDays * aCyclesDbData[i].cyclesInYear).toFixed(3)) + iSum;
                    }
                    iCycInYearCeiling = Number((((365 - iSum)) / obj.prodCyclesInDays).toFixed(3));
                }

                if (condition != "" && conDescrip != "" && shiftLen != "" && shiftLen <= 24 && productionCycle != "" && productionCycle <= 365 && shiftInDays != "" && shiftInDays <= (24 / shiftLen) && cycleInYear != "" && cycleInYear <= iCycInYearCeiling && cycleInYear > 0) {
                    if (this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesDataNav") == undefined) {
                        var aCurrentData = [];
                        aCurrentData.push(obj);
                    }
                    else {
                        var aCurrentData = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesDataNav");
                        aCurrentData.push(obj);
                    }
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav", aCurrentData);
                    sap.ui.getCore().byId("idConditionUpdate").setValue("");
                    sap.ui.getCore().byId("idConditionDescupdate").setValue("");
                    sap.ui.getCore().byId("idShiftLengthupdate").setValue("");
                    sap.ui.getCore().byId("idProductionCycleupdate").setValue("");
                    sap.ui.getCore().byId("idShiftDaysupdate").setValue("");
                    sap.ui.getCore().byId("idcycleYearupdate").setValue("");

                    sap.ui.getCore().byId("idConditionUpdate").setValueState("None");
                    sap.ui.getCore().byId("idConditionDescupdate").setValueState("None");
                    sap.ui.getCore().byId("idShiftLengthupdate").setValueState("None");
                    sap.ui.getCore().byId("idProductionCycleupdate").setValueState("None");
                    sap.ui.getCore().byId("idShiftDaysupdate").setValueState("None");
                    sap.ui.getCore().byId("idcycleYearupdate").setValueState("None");

                } else {
                    if (condition == "") {
                        sap.ui.getCore().byId("idConditionUpdate").setValueState("Error");
                        sap.ui.getCore().byId("idConditionUpdate").setValueStateText(this.oResourceBundle.getText("ERROR_CONDITION"));
                    } else {
                        sap.ui.getCore().byId("idConditionUpdate").setValueState("None");
                    }
                    if (conDescrip == "") {
                        sap.ui.getCore().byId("idConditionDescupdate").setValueState("Error");
                        sap.ui.getCore().byId("idConditionDescupdate").setValueStateText(this.oResourceBundle.getText("ERROR_CONDITION_DESC"));
                    } else {
                        sap.ui.getCore().byId("idConditionDescupdate").setValueState("None");
                    }
                    if (shiftLen == "" || shiftLen > 24) {
                        sap.ui.getCore().byId("idShiftLengthupdate").setValueState("Error");
                        sap.ui.getCore().byId("idShiftLengthupdate").setValueStateText(this.oResourceBundle.getText("ERROR_SHIFT_LENGTH"));
                    } else {
                        sap.ui.getCore().byId("idShiftLengthupdate").setValueState("None");
                    }
                    if (productionCycle == "" || productionCycle > 365) {
                        sap.ui.getCore().byId("idProductionCycleupdate").setValueState("Error");
                        sap.ui.getCore().byId("idProductionCycleupdate").setValueStateText(this.oResourceBundle.getText("ERROR_PRODUCTION_CYCLE"));
                    } else {
                        sap.ui.getCore().byId("idProductionCycleupdate").setValueState("None");
                    }
                    if (shiftInDays == "" || shiftInDays > (24 / shiftLen)) {
                        sap.ui.getCore().byId("idShiftDaysupdate").setValueState("Error");
                        sap.ui.getCore().byId("idShiftDaysupdate").setValueStateText(this.oResourceBundle.getText("ERROR_SHIFT_DAYS") + " < 24/" + shiftLen + ", " + this.oResourceBundle.getText("ERROR_LESS_THAN") + Number((24 / shiftLen).toFixed(3)));
                    } else {
                        sap.ui.getCore().byId("idShiftDaysupdate").setValueState("None");
                    }
                    if (cycleInYear == "" || cycleInYear > iCycInYearCeiling || cycleInYear < 0) {
                        sap.ui.getCore().byId("idcycleYearupdate").setValueState("Error");
                        sap.ui.getCore().byId("idcycleYearupdate").setValueStateText(this.oResourceBundle.getText("ERROR_CYCLE_IN_YEAR") + " " + iCycInYearCeiling);
                    } else {
                        sap.ui.getCore().byId("idcycleYearupdate").setValueState("None");
                    }
                }
            },
             // Line standard copy Create Cycles EventsDB function
             AddStandardCyclesEventsDBupdate: function (_oEvent) {

                var lossCat = sap.ui.getCore().byId("idLossCatupdate").getValue();
                var subCat = sap.ui.getCore().byId("idSubCatupdate").getValue(); //getSelectedKey();
                var crewSize = Number(sap.ui.getCore().byId("idExpectedCrewSizeupdate").getValue());
                var ExpFrequency = Number(sap.ui.getCore().byId("idExpectedFrequpdate").getValue());
                var ExpEventDur = Number(sap.ui.getCore().byId("idExpectEventDurationupdate").getValue());
                if (lossCat != "" && subCat != "" && ExpFrequency != "" && ExpEventDur != "") {
                    var obj = {};
                    obj.lossCat = lossCat;
                    obj.subCat = subCat;
                    obj.expectedCrewSize = Number(crewSize.toFixed(3));
                    obj.expectedFreqPerCycle = Number(ExpFrequency.toFixed(3));
                    obj.expectedEvtDur = Number(ExpEventDur.toFixed(3));

                    if (this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesEvtDataNav") == undefined) {
                        var aCurrentData = [];
                        aCurrentData.push(obj);
                    }
                    else {
                        var aCurrentData = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesEvtDataNav");
                        aCurrentData.push(obj);
                    }
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav", aCurrentData);
                    sap.ui.getCore().byId("idLossCatupdate").setValueState("None");
                    sap.ui.getCore().byId("idSubCatupdate").setValueState("None");
                    sap.ui.getCore().byId("idExpectedFrequpdate").setValueState("None");
                    sap.ui.getCore().byId("idExpectEventDurationupdate").setValueState("None");
                    sap.ui.getCore().byId("idLossCatupdate").setValue("");
                    sap.ui.getCore().byId("idSubCatupdate").setValue("");
                    sap.ui.getCore().byId("idExpectedCrewSizeupdate").setValue("");
                    sap.ui.getCore().byId("idExpectedFrequpdate").setValue("");
                    sap.ui.getCore().byId("idExpectEventDurationupdate").setValue("");
                    sap.ui.getCore().byId("idSubCatupdate").setEditable(false);
                    sap.ui.getCore().byId("idExpectedCrewSizeupdate").setEditable(false);
                    sap.ui.getCore().byId("idExpectedFrequpdate").setEditable(false);
                    sap.ui.getCore().byId("idExpectEventDurationupdate").setEditable(false);

                } else {
                    if (lossCat == "") {
                        sap.ui.getCore().byId("idLossCatupdate").setValueState("Error");
                        sap.ui.getCore().byId("idLossCatupdate").setValueStateText(this.oResourceBundle.getText("ERROR_LOSS_CATEGORY"));
                    } else {
                        sap.ui.getCore().byId("idLossCatupdate").setValueState("None");
                    }
                    if (subCat == "") {
                        sap.ui.getCore().byId("idSubCatupdate").setValueState("Error");
                        sap.ui.getCore().byId("idSubCatupdate").setValueStateText(this.oResourceBundle.getText("ERROR_SUB_CATEGORY"));
                    } else {
                        sap.ui.getCore().byId("idSubCatupdate").setValueState("None");
                    }
                    if (ExpFrequency == "") {
                        sap.ui.getCore().byId("idExpectedFrequpdate").setValueState("Error");
                        sap.ui.getCore().byId("idExpectedFrequpdate").setValueStateText(this.oResourceBundle.getText("ERROR_EXPECTED_FREQUENCY"));
                    } else {
                        sap.ui.getCore().byId("idExpectedFrequpdate").setValueState("None");
                    }
                    if (ExpEventDur == "") {
                        sap.ui.getCore().byId("idExpectEventDurationupdate").setValueState("Error");
                        sap.ui.getCore().byId("idExpectEventDurationupdate").setValueStateText(this.oResourceBundle.getText("ERROR_EXP_EVENT_DUR"));
                    } else {
                        sap.ui.getCore().byId("idExpectEventDurationupdate").setValueState("None");
                    }
                }
            },
            AddStandardAnnualEventsDBupdate: function (_oEvent) {
                var lossCat = sap.ui.getCore().byId("idAnnualLossCatupdate").getSelectedKey();
                var subCat = sap.ui.getCore().byId("idAnnualSubCatupdate").getValue();   //getSelectedKey();
                var crewSize = Number(Number(sap.ui.getCore().byId("idAnnualCrewSizeupdate").getValue()).toFixed(3));
                var ExpFrequency = Number(Number(sap.ui.getCore().byId("idAnnaulFrequpdate").getValue()).toFixed(3));
                var ExpEventDur = Number(Number(sap.ui.getCore().byId("idAnnualEventDurupdate").getValue()).toFixed(3));
                var cycleInYear = Number(Number(sap.ui.getCore().byId("idAnnualCycleYearupdate").getValue()).toFixed(3));

                // if (lossCat == "" && subCat == "" && crewSize == "" && ExpFrequency == "" && ExpEventDur == "" && cycleInYear == "") {
                //     var obj = {};
                //     obj.lossCat = lossCat;
                //     obj.subCat = subCat;
                //     obj.expectedCrewSize = Number(crewSize);
                //     obj.expectedFrequency = Number(ExpFrequency);
                //     obj.expectedEvtDur = Number(ExpEventDur);
                //     obj.cyclesInYear = Number(cycleInYear);
                // if (this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav") == undefined) {
                //     var aCurrentData = [];
                //     aCurrentData.push(obj);
                // }
                // else {
                //     var aCurrentData = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav");
                //     aCurrentData.push(obj);
                // }
                // this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav", aCurrentData);
                // } else {

                if (lossCat == "") {
                    sap.ui.getCore().byId("idAnnualLossCatupdate").setValueState("Error");
                    sap.ui.getCore().byId("idAnnualLossCatupdate").setValueStateText(this.oResourceBundle.getText("ERROR_LOSS_CATEGORY"));
                } else {
                    sap.ui.getCore().byId("idAnnualLossCatupdate").setValueState("None");
                }
                if (subCat == "") {
                    sap.ui.getCore().byId("idAnnualSubCatupdate").setValueState("Error");
                    sap.ui.getCore().byId("idAnnualSubCatupdate").setValueStateText(this.oResourceBundle.getText("ERROR_SUB_CATEGORY"));
                } else {
                    sap.ui.getCore().byId("idAnnualSubCatupdate").setValueState("None");
                }
                if (crewSize == "") {
                    sap.ui.getCore().byId("idAnnualCrewSizeupdate").setValueState("Error");
                    sap.ui.getCore().byId("idAnnualCrewSizeupdate").setValueStateText(this.oResourceBundle.getText("ERROR_EXPECTED_CREWSIZE"));
                } else {
                    sap.ui.getCore().byId("idAnnualCrewSizeupdate").setValueState("None");
                }
                if (ExpFrequency == "") {
                    sap.ui.getCore().byId("idAnnaulFrequpdate").setValueState("Error");
                    sap.ui.getCore().byId("idAnnaulFrequpdate").setValueStateText(this.oResourceBundle.getText("ERROR_EXPECTED_FREQUENCY"));
                } else {
                    sap.ui.getCore().byId("idAnnaulFrequpdate").setValueState("None");
                }
                if (ExpEventDur == "") {
                    sap.ui.getCore().byId("idAnnualEventDurupdate").setValueState("Error");
                    sap.ui.getCore().byId("idAnnualEventDurupdate").setValueStateText(this.oResourceBundle.getText("ERROR_EXP_EVENT_DUR"));
                } else {
                    sap.ui.getCore().byId("idAnnualEventDurupdate").setValueState("None");
                }
                if (cycleInYear == "") {
                    sap.ui.getCore().byId("idAnnualCycleYearupdate").setValueState("Error");
                    sap.ui.getCore().byId("idAnnualCycleYearupdate").setValueStateText(this.oResourceBundle.getText("ERROR_CYCLE_IN_YEAR"));
                } else {
                    sap.ui.getCore().byId("idAnnualCycleYearupdate").setValueState("None");
                }
                if (lossCat != "" && subCat != "" && crewSize != "" && ExpFrequency != "" && ExpEventDur != "" && cycleInYear != "") {
                    var obj = {};
                    obj.lossCat = lossCat;
                    obj.subCat = subCat;
                    obj.expectedCrewSize = Number(crewSize);
                    obj.expectedFrequency = Number(ExpFrequency);
                    obj.expectedEvtDur = Number(ExpEventDur);
                    obj.cyclesInYear = Number(cycleInYear);

                    if (this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav") == undefined) {
                        var aCurrentData = [];
                        aCurrentData.push(obj);
                    }
                    else {
                        var aCurrentData = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav");
                        aCurrentData.push(obj);
                    }
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav", aCurrentData);

                    sap.ui.getCore().byId("idAnnualLossCatupdate").setValueState("None");
                    sap.ui.getCore().byId("idAnnualSubCatupdate").setValueState("None");
                    sap.ui.getCore().byId("idAnnualCrewSizeupdate").setValueState("None");
                    sap.ui.getCore().byId("idAnnaulFrequpdate").setValueState("None");
                    sap.ui.getCore().byId("idAnnualEventDurupdate").setValueState("None");
                    sap.ui.getCore().byId("idAnnualCycleYearupdate").setValueState("None");

                    sap.ui.getCore().byId("idAnnualLossCatupdate").setValue("");
                    sap.ui.getCore().byId("idAnnualSubCatupdate").setValue("");
                    sap.ui.getCore().byId("idAnnualCrewSizeupdate").setValue("");
                    sap.ui.getCore().byId("idAnnaulFrequpdate").setValue("");
                    sap.ui.getCore().byId("idAnnualEventDurupdate").setValue("");
                    sap.ui.getCore().byId("idAnnualCycleYearupdate").setValue("");

                    sap.ui.getCore().byId("idAnnualSubCatupdate").setEditable(false);
                    sap.ui.getCore().byId("idAnnualCrewSizeupdate").setEditable(false);
                    sap.ui.getCore().byId("idAnnaulFrequpdate").setEditable(false);
                    sap.ui.getCore().byId("idAnnualEventDurupdate").setEditable(false);
                    sap.ui.getCore().byId("idAnnualCycleYearupdate").setEditable(false);
                }
                // }
            },
            //////////////////Copy create add functions  start/////////////////////////////////////////////////////////////////////
            // Line standard  copycreate step2 Add Functionality 
            AddStandardCyclesDBCopy: function (_oEvent) {

                var condition = sap.ui.getCore().byId("idConditionCopy").getValue();
                var conDescrip = sap.ui.getCore().byId("idConditionDescCopy").getValue();
                var shiftLen = Number(sap.ui.getCore().byId("idShiftLengthCopy").getValue());
                var productionCycle = Number(sap.ui.getCore().byId("idProductionCycleCopy").getValue());
                var shiftInDays = Number(sap.ui.getCore().byId("idShiftDaysCopy").getValue());
                var cycleInYear = Number(sap.ui.getCore().byId("idcycleYearCopy").getValue());

                //calculcated fields(additional fields not shown in screen) for cycles DB 
                var shiftInCycleInt = Number(productionCycle.toFixed(3)) * Number(shiftInDays.toFixed(3));
                var cycleHoursInt = Number(shiftInCycleInt.toFixed(3)) * Number(shiftLen.toFixed(3));
                var totalOccupiedTimeInt = Number(cycleHoursInt.toFixed(3)) * Number(cycleInYear.toFixed(3));

                var obj = {};
                obj.condition = condition;
                obj.conditionDesc = conDescrip;
                obj.shiftLength = Number(shiftLen.toFixed(3));
                obj.prodCyclesInDays = Number(productionCycle.toFixed(3));
                obj.shiftsInDays = Number(shiftInDays.toFixed(3));
                obj.cyclesInYear = Number(cycleInYear.toFixed(3));
                //calculcated fields(additional fields not shown in screen) for cycles DB 
                obj.shiftsInCycle = Number(shiftInCycleInt.toFixed(3));
                obj.cycleHrs = Number(cycleHoursInt.toFixed(3));
                obj.totalOccupiedTime = Number(totalOccupiedTimeInt.toFixed(3));

                var iSum = 0;
                var iCycInYearCeiling;
                if (this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesDataNav") == undefined) {
                    iCycInYearCeiling = Number((365 / obj.prodCyclesInDays).toFixed(3));
                }
                else {
                    var aCyclesDbData = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesDataNav");
                    for (var i = 0; i < aCyclesDbData.length; i++) {
                        iSum = Number((aCyclesDbData[i].prodCyclesInDays * aCyclesDbData[i].cyclesInYear).toFixed(3)) + iSum;
                    }
                    iCycInYearCeiling = Number((((365 - iSum)) / obj.prodCyclesInDays).toFixed(3));
                }

                if (condition != "" && conDescrip != "" && shiftLen != "" && shiftLen <= 24 && productionCycle != "" && productionCycle <= 365 && shiftInDays != "" && shiftInDays <= (24 / shiftLen) && cycleInYear != "" && cycleInYear <= iCycInYearCeiling && cycleInYear > 0) {
                    if (this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesDataNav") == undefined) {
                        var aCurrentData = [];
                        aCurrentData.push(obj);
                    }
                    else {
                        var aCurrentData = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesDataNav");
                        aCurrentData.push(obj);
                    }
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav", aCurrentData);
                    sap.ui.getCore().byId("idConditionCopy").setValue("");
                    sap.ui.getCore().byId("idConditionDescCopy").setValue("");
                    sap.ui.getCore().byId("idShiftLengthCopy").setValue("");
                    sap.ui.getCore().byId("idProductionCycleCopy").setValue("");
                    sap.ui.getCore().byId("idShiftDaysCopy").setValue("");
                    sap.ui.getCore().byId("idcycleYearCopy").setValue("");

                    sap.ui.getCore().byId("idConditionCopy").setValueState("None");
                    sap.ui.getCore().byId("idConditionDescCopy").setValueState("None");
                    sap.ui.getCore().byId("idShiftLengthCopy").setValueState("None");
                    sap.ui.getCore().byId("idProductionCycleCopy").setValueState("None");
                    sap.ui.getCore().byId("idShiftDaysCopy").setValueState("None");
                    sap.ui.getCore().byId("idcycleYearCopy").setValueState("None");

                } else {
                    if (condition == "") {
                        sap.ui.getCore().byId("idConditionCopy").setValueState("Error");
                        sap.ui.getCore().byId("idConditionCopy").setValueStateText(this.oResourceBundle.getText("ERROR_CONDITION"));
                    } else {
                        sap.ui.getCore().byId("idConditionCopy").setValueState("None");
                    }
                    if (conDescrip == "") {
                        sap.ui.getCore().byId("idConditionDescCopy").setValueState("Error");
                        sap.ui.getCore().byId("idConditionDescCopy").setValueStateText(this.oResourceBundle.getText("ERROR_CONDITION_DESC"));
                    } else {
                        sap.ui.getCore().byId("idConditionDescCopy").setValueState("None");
                    }
                    if (shiftLen == "" || shiftLen > 24) {
                        sap.ui.getCore().byId("idShiftLengthCopy").setValueState("Error");
                        sap.ui.getCore().byId("idShiftLengthCopy").setValueStateText(this.oResourceBundle.getText("ERROR_SHIFT_LENGTH"));
                    } else {
                        sap.ui.getCore().byId("idShiftLengthCopy").setValueState("None");
                    }
                    if (productionCycle == "" || productionCycle > 365) {
                        sap.ui.getCore().byId("idProductionCycleCopy").setValueState("Error");
                        sap.ui.getCore().byId("idProductionCycleCopy").setValueStateText(this.oResourceBundle.getText("ERROR_PRODUCTION_CYCLE"));
                    } else {
                        sap.ui.getCore().byId("idProductionCycleCopy").setValueState("None");
                    }
                    if (shiftInDays == "" || shiftInDays > (24 / shiftLen)) {
                        sap.ui.getCore().byId("idShiftDaysCopy").setValueState("Error");
                        sap.ui.getCore().byId("idShiftDaysCopy").setValueStateText(this.oResourceBundle.getText("ERROR_SHIFT_DAYS") + " < 24/" + shiftLen + ", " + this.oResourceBundle.getText("ERROR_LESS_THAN") + Number((24 / shiftLen).toFixed(3)));
                    } else {
                        sap.ui.getCore().byId("idShiftDaysCopy").setValueState("None");
                    }
                    if (cycleInYear == "" || cycleInYear > iCycInYearCeiling || cycleInYear < 0) {
                        sap.ui.getCore().byId("idcycleYearCopy").setValueState("Error");
                        sap.ui.getCore().byId("idcycleYearCopy").setValueStateText(this.oResourceBundle.getText("ERROR_CYCLE_IN_YEAR") + " " + iCycInYearCeiling);
                    } else {
                        sap.ui.getCore().byId("idcycleYearCopy").setValueState("None");
                    }
                }
            },

            // Line standard copy Create Cycles EventsDB function
            AddStandardCyclesEventsDBCopy: function (oEvent) {

                var lossCat = sap.ui.getCore().byId("idLossCatCopy").getSelectedKey();
                var subCat = sap.ui.getCore().byId("idSubCatCopy").getValue(); //getSelectedKey();
                var crewSize = Number(sap.ui.getCore().byId("idExpectedCrewSizeCopy").getValue());
                var ExpFrequency = Number(sap.ui.getCore().byId("idExpectedFreqCopy").getValue());
                var ExpEventDur = Number(sap.ui.getCore().byId("idExpectEventDurationCopy").getValue());
                if (lossCat != "" && subCat != "" && ExpFrequency != "" && ExpEventDur != "") {
                    var obj = {};
                    obj.lossCat = lossCat;
                    obj.subCat = subCat;
                    obj.expectedCrewSize = Number(crewSize.toFixed(3));
                    obj.expectedFreqPerCycle = Number(ExpFrequency.toFixed(3));
                    obj.expectedEvtDur = Number(ExpEventDur.toFixed(3));

                    if (this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesEvtDataNav") == undefined) {
                        var aCurrentData = [];
                        aCurrentData.push(obj);
                    }
                    else {
                        var aCurrentData = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesEvtDataNav");
                        aCurrentData.push(obj);
                    }
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav", aCurrentData);
                    sap.ui.getCore().byId("idLossCatCopy").setValueState("None");
                    sap.ui.getCore().byId("idSubCatCopy").setValueState("None");
                    sap.ui.getCore().byId("idExpectedFreqCopy").setValueState("None");
                    sap.ui.getCore().byId("idExpectEventDurationCopy").setValueState("None");
                    sap.ui.getCore().byId("idLossCatCopy").setValue("");
                    sap.ui.getCore().byId("idSubCatCopy").setValue("");
                    sap.ui.getCore().byId("idExpectedCrewSizeCopy").setValue("");
                    sap.ui.getCore().byId("idExpectedFreqCopy").setValue("");
                    sap.ui.getCore().byId("idExpectEventDurationCopy").setValue("");
                    sap.ui.getCore().byId("idSubCatCopy").setEditable(false);
                    sap.ui.getCore().byId("idExpectedCrewSizeCopy").setEditable(false);
                    sap.ui.getCore().byId("idExpectedFreqCopy").setEditable(false);
                    sap.ui.getCore().byId("idExpectEventDurationCopy").setEditable(false);

                } else {
                    if (lossCat == "") {
                        sap.ui.getCore().byId("idLossCatCopy").setValueState("Error");
                        sap.ui.getCore().byId("idLossCatCopy").setValueStateText(this.oResourceBundle.getText("ERROR_LOSS_CATEGORY"));
                    } else {
                        sap.ui.getCore().byId("idLossCatCopy").setValueState("None");
                    }
                    if (subCat == "") {
                        sap.ui.getCore().byId("idSubCatCopy").setValueState("Error");
                        sap.ui.getCore().byId("idSubCatCopy").setValueStateText(this.oResourceBundle.getText("ERROR_SUB_CATEGORY"));
                    } else {
                        sap.ui.getCore().byId("idSubCatCopy").setValueState("None");
                    }
                    if (ExpFrequency == "") {
                        sap.ui.getCore().byId("idExpectedFreqCopy").setValueState("Error");
                        sap.ui.getCore().byId("idExpectedFreqCopy").setValueStateText(this.oResourceBundle.getText("ERROR_EXPECTED_FREQUENCY"));
                    } else {
                        sap.ui.getCore().byId("idExpectedFreqCopy").setValueState("None");
                    }
                    if (ExpEventDur == "") {
                        sap.ui.getCore().byId("idExpectEventDurationCopy").setValueState("Error");
                        sap.ui.getCore().byId("idExpectEventDurationCopy").setValueStateText(this.oResourceBundle.getText("ERROR_EXP_EVENT_DUR"));
                    } else {
                        sap.ui.getCore().byId("idExpectEventDurationCopy").setValueState("None");
                    }
                }
            },
            // Line standard Create step4  AnnualEventsDB Add function 
            AddStandardAnnualEventsDBCopy: function (oEvent) {
                var lossCat = sap.ui.getCore().byId("idAnnualLossCatCopy").getSelectedKey();
                var subCat = sap.ui.getCore().byId("idAnnualSubCatCopy").getValue();   //getSelectedKey();
                var crewSize = Number(Number(sap.ui.getCore().byId("idAnnualCrewSizeCopy").getValue()).toFixed(3));
                var ExpFrequency = Number(Number(sap.ui.getCore().byId("idAnnaulFreqCopy").getValue()).toFixed(3));
                var ExpEventDur = Number(Number(sap.ui.getCore().byId("idAnnualEventDurCopy").getValue()).toFixed(3));
                var cycleInYear = Number(Number(sap.ui.getCore().byId("idAnnualCycleYearCopy").getValue()).toFixed(3));

                // if (lossCat == "" && subCat == "" && crewSize == "" && ExpFrequency == "" && ExpEventDur == "" && cycleInYear == "") {
                //     var obj = {};
                //     obj.lossCat = lossCat;
                //     obj.subCat = subCat;
                //     obj.expectedCrewSize = Number(crewSize);
                //     obj.expectedFrequency = Number(ExpFrequency);
                //     obj.expectedEvtDur = Number(ExpEventDur);
                //     obj.cyclesInYear = Number(cycleInYear);
                // if (this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav") == undefined) {
                //     var aCurrentData = [];
                //     aCurrentData.push(obj);
                // }
                // else {
                //     var aCurrentData = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav");
                //     aCurrentData.push(obj);
                // }
                // this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav", aCurrentData);
                // } else {

                if (lossCat == "") {
                    sap.ui.getCore().byId("idAnnualLossCatCopy").setValueState("Error");
                    sap.ui.getCore().byId("idAnnualLossCatCopy").setValueStateText(this.oResourceBundle.getText("ERROR_LOSS_CATEGORY"));
                } else {
                    sap.ui.getCore().byId("idAnnualLossCatCopy").setValueState("None");
                }
                if (subCat == "") {
                    sap.ui.getCore().byId("idAnnualSubCatCopy").setValueState("Error");
                    sap.ui.getCore().byId("idAnnualSubCatCopy").setValueStateText(this.oResourceBundle.getText("ERROR_SUB_CATEGORY"));
                } else {
                    sap.ui.getCore().byId("idAnnualSubCatCopy").setValueState("None");
                }
                if (crewSize == "") {
                    sap.ui.getCore().byId("idAnnualCrewSizeCopy").setValueState("Error");
                    sap.ui.getCore().byId("idAnnualCrewSizeCopy").setValueStateText(this.oResourceBundle.getText("ERROR_EXPECTED_CREWSIZE"));
                } else {
                    sap.ui.getCore().byId("idAnnualCrewSizeCopy").setValueState("None");
                }
                if (ExpFrequency == "") {
                    sap.ui.getCore().byId("idAnnaulFreqCopy").setValueState("Error");
                    sap.ui.getCore().byId("idAnnaulFreqCopy").setValueStateText(this.oResourceBundle.getText("ERROR_EXPECTED_FREQUENCY"));
                } else {
                    sap.ui.getCore().byId("idAnnaulFreqCopy").setValueState("None");
                }
                if (ExpEventDur == "") {
                    sap.ui.getCore().byId("idAnnualEventDurCopy").setValueState("Error");
                    sap.ui.getCore().byId("idAnnualEventDurCopy").setValueStateText(this.oResourceBundle.getText("ERROR_EXP_EVENT_DUR"));
                } else {
                    sap.ui.getCore().byId("idAnnualEventDurCopy").setValueState("None");
                }
                if (cycleInYear == "") {
                    sap.ui.getCore().byId("idAnnualCycleYearCopy").setValueState("Error");
                    sap.ui.getCore().byId("idAnnualCycleYearCopy").setValueStateText(this.oResourceBundle.getText("ERROR_CYCLE_IN_YEAR"));
                } else {
                    sap.ui.getCore().byId("idAnnualCycleYearCopy").setValueState("None");
                }
                if (lossCat != "" && subCat != "" && crewSize != "" && ExpFrequency != "" && ExpEventDur != "" && cycleInYear != "") {
                    var obj = {};
                    obj.lossCat = lossCat;
                    obj.subCat = subCat;
                    obj.expectedCrewSize = Number(crewSize);
                    obj.expectedFrequency = Number(ExpFrequency);
                    obj.expectedEvtDur = Number(ExpEventDur);
                    obj.cyclesInYear = Number(cycleInYear);

                    if (this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav") == undefined) {
                        var aCurrentData = [];
                        aCurrentData.push(obj);
                    }
                    else {
                        var aCurrentData = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav");
                        aCurrentData.push(obj);
                    }
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav", aCurrentData);

                    sap.ui.getCore().byId("idAnnualLossCatCopy").setValueState("None");
                    sap.ui.getCore().byId("idAnnualSubCatCopy").setValueState("None");
                    sap.ui.getCore().byId("idAnnualCrewSizeCopy").setValueState("None");
                    sap.ui.getCore().byId("idAnnaulFreqCopy").setValueState("None");
                    sap.ui.getCore().byId("idAnnualEventDurCopy").setValueState("None");
                    sap.ui.getCore().byId("idAnnualCycleYearCopy").setValueState("None");

                    sap.ui.getCore().byId("idAnnualLossCatCopy").setValue("");
                    sap.ui.getCore().byId("idAnnualSubCatCopy").setValue("");
                    sap.ui.getCore().byId("idAnnualCrewSizeCopy").setValue("");
                    sap.ui.getCore().byId("idAnnaulFreqCopy").setValue("");
                    sap.ui.getCore().byId("idAnnualEventDurCopy").setValue("");
                    sap.ui.getCore().byId("idAnnualCycleYearCopy").setValue("");

                    sap.ui.getCore().byId("idAnnualSubCatCopy").setEditable(false);
                    sap.ui.getCore().byId("idAnnualCrewSizeCopy").setEditable(false);
                    sap.ui.getCore().byId("idAnnaulFreqCopy").setEditable(false);
                    sap.ui.getCore().byId("idAnnualEventDurCopy").setEditable(false);
                    sap.ui.getCore().byId("idAnnualCycleYearCopy").setEditable(false);
                }
                // }
            },

            //////////////////Copy create add functionality end ////////////////////////////////////////////////////////////////////

            // Line standard select Update Cycles EventsDB function
            selectStandardCyclesEventDB: function (oEvent) {
                sap.ui.getCore().byId("idLossCatUpdate").setEditable(true);
                sap.ui.getCore().byId("idSubCatUpdate").setEditable(true);
                sap.ui.getCore().byId("idExpectedCrewSizeUpdate").setEditable(true);
                sap.ui.getCore().byId("idExpectedFreqUpdate").setEditable(true);
                sap.ui.getCore().byId("idExpectEventDurationUpdate").setEditable(true);

                iSelectedRowIndex = sap.ui.getCore().byId("idCycleDB2Update").getSelectedIndex();

                sap.ui.getCore().byId("idLossCatUpdate").setValue("" + this.getView().getModel("cycleEventsDBModel").getProperty("/cycleEventsData/" + iSelectedRowIndex + "/LossCategory"));
                sap.ui.getCore().byId("idSubCatUpdate").setValue("" + this.getView().getModel("cycleEventsDBModel").getProperty("/cycleEventsData/" + iSelectedRowIndex + "/SubCategory"));
                sap.ui.getCore().byId("idExpectedCrewSizeUpdate").setValue("" + this.getView().getModel("cycleEventsDBModel").getProperty("/cycleEventsData/" + iSelectedRowIndex + "/CrewSize"));
                sap.ui.getCore().byId("idExpectedFreqUpdate").setValue("" + this.getView().getModel("cycleEventsDBModel").getProperty("/cycleEventsData/" + iSelectedRowIndex + "/frequency"));
                sap.ui.getCore().byId("idExpectEventDurationUpdate").setValue("" + this.getView().getModel("cycleEventsDBModel").getProperty("/cycleEventsData/" + iSelectedRowIndex + "/eventDuration"));

            },

            // Line standard Update Cycles EventsDB function
            updateStandardCyclesEventDB: function (oEvent) {
                this.getView().getModel("cycleEventsDBModel").setProperty("/cycleEventsData/" + iSelectedRowIndex + "/LossCategory", sap.ui.getCore().byId("idLossCatUpdate").getValue());
                this.getView().getModel("cycleEventsDBModel").setProperty("/cycleEventsData/" + iSelectedRowIndex + "/SubCategory", sap.ui.getCore().byId("idSubCatUpdate").getValue());
                this.getView().getModel("cycleEventsDBModel").setProperty("/cycleEventsData/" + iSelectedRowIndex + "/CrewSize", sap.ui.getCore().byId("idExpectedCrewSizeUpdate").getValue());
                this.getView().getModel("cycleEventsDBModel").setProperty("/cycleEventsData/" + iSelectedRowIndex + "/frequency", sap.ui.getCore().byId("idExpectedFreqUpdate").getValue());
                this.getView().getModel("cycleEventsDBModel").setProperty("/cycleEventsData/" + iSelectedRowIndex + "/eventDuration", sap.ui.getCore().byId("idExpectEventDurationUpdate").getValue());

                sap.ui.getCore().byId("idLossCatUpdate").setEditable(false);
                sap.ui.getCore().byId("idSubCatUpdate").setEditable(false);
                sap.ui.getCore().byId("idExpectedCrewSizeUpdate").setEditable(false);
                sap.ui.getCore().byId("idExpectedFreqUpdate").setEditable(false);
                sap.ui.getCore().byId("idExpectEventDurationUpdate").setEditable(false);
            },

            // Line standard
            selectStandardAnnualEventDB: function (oEvent) {
                sap.ui.getCore().byId("idAnnualLossCatUpdate").setEditable(true);
                sap.ui.getCore().byId("idAnnualSubCatUpdate").setEditable(true);
                sap.ui.getCore().byId("idAnnualCycleYearUpdate").setEditable(true);
                sap.ui.getCore().byId("idAnnaulFreqUpdate").setEditable(true);
                sap.ui.getCore().byId("idAnnualEventDurUpdate").setEditable(true);
                sap.ui.getCore().byId("idAnnualCrewSizeUpdate").setEditable(true);

                iSelectedRowIndex = sap.ui.getCore().byId("idCycleDB3Update").getSelectedIndex();
                sap.ui.getCore().byId("idAnnualLossCatUpdate").setValue("" + this.getView().getModel("cycleAnnualEventDBModel").getProperty("/lineData/" + iSelectedRowIndex + "/Condition"));
                sap.ui.getCore().byId("idAnnualSubCatUpdate").setValue("" + this.getView().getModel("cycleAnnualEventDBModel").getProperty("/lineData/" + iSelectedRowIndex + "/Conditiondescr"));
                sap.ui.getCore().byId("idAnnualCycleYearUpdate").setValue("" + this.getView().getModel("cycleAnnualEventDBModel").getProperty("/lineData/" + iSelectedRowIndex + "/shiftlength"));
                sap.ui.getCore().byId("idAnnaulFreqUpdate").setValue("" + this.getView().getModel("cycleAnnualEventDBModel").getProperty("/lineData/" + iSelectedRowIndex + "/ProductionCylceInDays"));
                sap.ui.getCore().byId("idAnnualEventDurUpdate").setValue("" + this.getView().getModel("cycleAnnualEventDBModel").getProperty("/lineData/" + iSelectedRowIndex + "/ShiftinDays"));
                sap.ui.getCore().byId("idAnnualCrewSizeUpdate").setValue("" + this.getView().getModel("cycleAnnualEventDBModel").getProperty("/lineData/" + iSelectedRowIndex + "/Cycleinyears"));
            },

            // Line standard
            updateStandardAnnualEventDB: function (oEvent) {
                this.getView().getModel("cycleAnnualEventDBModel").setProperty("/lineData/" + iSelectedRowIndex + "/Condition", sap.ui.getCore().byId("idAnnualLossCatUpdate").getValue());
                this.getView().getModel("cycleAnnualEventDBModel").setProperty("/lineData/" + iSelectedRowIndex + "/Conditiondescr", sap.ui.getCore().byId("idAnnualSubCatUpdate").getValue());
                this.getView().getModel("cycleAnnualEventDBModel").setProperty("/lineData/" + iSelectedRowIndex + "/shiftlength", sap.ui.getCore().byId("idAnnualCycleYearUpdate").getValue());
                this.getView().getModel("cycleAnnualEventDBModel").setProperty("/lineData/" + iSelectedRowIndex + "/ProductionCylceInDays", sap.ui.getCore().byId("idAnnaulFreqUpdate").getValue());
                this.getView().getModel("cycleAnnualEventDBModel").setProperty("/lineData/" + iSelectedRowIndex + "/ShiftinDays", sap.ui.getCore().byId("idAnnualEventDurUpdate").getValue());
                this.getView().getModel("cycleAnnualEventDBModel").setProperty("/lineData/" + iSelectedRowIndex + "/Cycleinyears", sap.ui.getCore().byId("idAnnualCrewSizeUpdate").getValue());

                sap.ui.getCore().byId("idAnnualLossCatUpdate").setEditable(false);
                sap.ui.getCore().byId("idAnnualSubCatUpdate").setEditable(false);
                sap.ui.getCore().byId("idAnnualCycleYearUpdate").setEditable(false);
                sap.ui.getCore().byId("idAnnaulFreqUpdate").setEditable(false);
                sap.ui.getCore().byId("idAnnualEventDurUpdate").setEditable(false);
                sap.ui.getCore().byId("idAnnualCrewSizeUpdate").setEditable(false);

            },

            // Line standard
            selectStandardCyclesDB: function (oEvent) {
                sap.ui.getCore().byId("idConditionUpdate").setEditable(true);
                sap.ui.getCore().byId("idConditionDescUpdate").setEditable(true);
                sap.ui.getCore().byId("idShiftLengthUpdate").setEditable(true);
                sap.ui.getCore().byId("idProductionCycleUpdate").setEditable(true);
                sap.ui.getCore().byId("idShiftDaysUpdate").setEditable(true);
                sap.ui.getCore().byId("idcycleYearUpdate").setEditable(true);

                iSelectedRowIndex = sap.ui.getCore().byId("idCycleDB1Update").getSelectedIndex();
                sap.ui.getCore().byId("idConditionUpdate").setValue("" + this.getView().getModel("cycleAnnualEventDBModel").getProperty("/lineData/" + iSelectedRowIndex + "/Condition"));
                sap.ui.getCore().byId("idConditionDescUpdate").setValue("" + this.getView().getModel("cycleAnnualEventDBModel").getProperty("/lineData/" + iSelectedRowIndex + "/Conditiondescr"));
                sap.ui.getCore().byId("idShiftLengthUpdate").setValue("" + this.getView().getModel("cycleAnnualEventDBModel").getProperty("/lineData/" + iSelectedRowIndex + "/shiftlength"));
                sap.ui.getCore().byId("idProductionCycleUpdate").setValue("" + this.getView().getModel("cycleAnnualEventDBModel").getProperty("/lineData/" + iSelectedRowIndex + "/ProductionCylceInDays"));
                sap.ui.getCore().byId("idShiftDaysUpdate").setValue("" + this.getView().getModel("cycleAnnualEventDBModel").getProperty("/lineData/" + iSelectedRowIndex + "/ShiftinDays"));
                sap.ui.getCore().byId("idcycleYearUpdate").setValue("" + this.getView().getModel("cycleAnnualEventDBModel").getProperty("/lineData/" + iSelectedRowIndex + "/Cycleinyears"));

            },

            // Line standard
            updateStandardCyclesDB: function (oEvent) {
                this.getView().getModel("cycleDBModel").setProperty("/lineData/" + iSelectedRowIndex + "/Condition", sap.ui.getCore().byId("idConditionUpdate").getValue());
                this.getView().getModel("cycleDBModel").setProperty("/lineData/" + iSelectedRowIndex + "/Conditiondescr", sap.ui.getCore().byId("idConditionDescUpdate").getValue());
                this.getView().getModel("cycleDBModel").setProperty("/lineData/" + iSelectedRowIndex + "/shiftlength", sap.ui.getCore().byId("idShiftLengthUpdate").getValue());
                this.getView().getModel("cycleDBModel").setProperty("/lineData/" + iSelectedRowIndex + "/ProductionCylceInDays", sap.ui.getCore().byId("idProductionCycleUpdate").getValue());
                this.getView().getModel("cycleDBModel").setProperty("/lineData/" + iSelectedRowIndex + "/ShiftinDays", sap.ui.getCore().byId("idShiftDaysUpdate").getValue());
                this.getView().getModel("cycleDBModel").setProperty("/lineData/" + iSelectedRowIndex + "/Cycleinyears", sap.ui.getCore().byId("idcycleYearUpdate").getValue());

                sap.ui.getCore().byId("idConditionUpdate").setEditable(false);
                sap.ui.getCore().byId("idConditionDescUpdate").setEditable(false);
                sap.ui.getCore().byId("idShiftLengthUpdate").setEditable(false);
                sap.ui.getCore().byId("idProductionCycleUpdate").setEditable(false);
                sap.ui.getCore().byId("idShiftDaysUpdate").setEditable(false);
                sap.ui.getCore().byId("idcycleYearUpdate").setEditable(false);
            },

            ////////////////////////////////////////////Line create delete row items////////////////////////////////////////////////////

            fnLineCyclesDeleteItem: function (oEvent) {
                var iItem = oEvent.getSource().getParent().getBindingContext("createLineStandardModel").sPath.slice(24);
                //'/materialData/0'      standardCycleData
                var aCurrentData = this.getView().getModel("createLineStandardModel").getProperty("/LineHdrToCyclesDataNav");
                var aNewData = aCurrentData.splice(iItem, 1);
                this.getView().getModel("createLineStandardModel").setProperty("/LineHdrToCyclesDataNav", aCurrentData);
            },
            fnLineCyclesEventDeleteItem: function (oEvent) {
                var iItem = oEvent.getSource().getParent().getBindingContext("createLineStandardModel").sPath.slice(27);
                //'/materialData/0'      standardCycleData
                var aCurrentData = this.getView().getModel("createLineStandardModel").getProperty("/LineHdrToCyclesEvtDataNav");
                var aNewData = aCurrentData.splice(iItem, 1);
                this.getView().getModel("createLineStandardModel").setProperty("/LineHdrToCyclesEvtDataNav", aCurrentData);
            },
            fnLineAnnualEventDeleteItem: function (oEvent) {
                var iItem = oEvent.getSource().getParent().getBindingContext("createLineStandardModel").sPath.slice(27);
                //'/materialData/0'      standardCycleData
                var aCurrentData = this.getView().getModel("createLineStandardModel").getProperty("/LineHdrToAnnualEvtDataNav");
                var aNewData = aCurrentData.splice(iItem, 1);
                this.getView().getModel("createLineStandardModel").setProperty("/LineHdrToAnnualEvtDataNav", aCurrentData);
            },
            ///////////////////////////////Line Copy create delete functions///////////////////////////////////////////

            fnLineCopyCreateCyclesDeleteItem: function (oEvent) {
                var iItem = oEvent.getSource().getParent().getBindingContext("lineStandardUpdateModel").sPath.slice(24);
                //'/materialData/0'      standardCycleData
                var aCurrentData = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesDataNav");
                var aNewData = aCurrentData.splice(iItem, 1);
                this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav", aCurrentData);

            },
            fnLineCopyCreateCyclesEventDeleteItem: function (oEvent) {
                var iItem = oEvent.getSource().getParent().getBindingContext("lineStandardUpdateModel").sPath.slice(27);
                //'/materialData/0'      standardCycleData
                var aCurrentData = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesEvtDataNav");
                var aNewData = aCurrentData.splice(iItem, 1);
                this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav", aCurrentData);
            },
            fnLineCopyCreateAnnualEventDeleteItem: function (oEvent) {
                var iItem = oEvent.getSource().getParent().getBindingContext("lineStandardUpdateModel").sPath.slice(27);
                //'/materialData/0'      standardCycleData
                var aCurrentData = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav");
                var aNewData = aCurrentData.splice(iItem, 1);
                this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav", aCurrentData);
            },
            ///////////////////////////////Line Update delete items functions////////////////////////////////////////////////
            fnLineUpdateCyclesDeleteItem: function (oEvent) {
                var iItem = oEvent.getSource().getParent().getBindingContext("lineStandardUpdateModel").sPath.slice(24);
                //'/materialData/0'      standardCycleData
                var aCurrentData = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesDataNav");
                if (aCurrentData.length > 1) {
                    var aNewData = aCurrentData.splice(iItem, 1);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav", aCurrentData);

                    if (this.getView().getModel("lineStandardUpdateModel").getProperty("/deleteLineStdCyclesDb") == undefined) {
                        var aDeleteRowId = [];
                        if(aNewData[0].ID)
                        aDeleteRowId.push(aNewData[0].ID);
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/deleteLineStdCyclesDb", aDeleteRowId);
                    } else {
                        var aDeleteRowId = this.getView().getModel("lineStandardUpdateModel").getProperty("/deleteLineStdCyclesDb");
                        if(aNewData[0].ID)
                        aDeleteRowId.push(aNewData[0].ID);
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/deleteLineStdCyclesDb", aDeleteRowId);
                    }
                } else {
                    var message = this.oResourceBundle.getText("WARNING_DELETE_CYCLE");
                    this.onShowWarning(message);
                }

            },
            fnLineUpdateCyclesEventDeleteItem: function (oEvent) {
                var iItem = oEvent.getSource().getParent().getBindingContext("lineStandardUpdateModel").sPath.slice(27);
                //'/materialData/0'      standardCycleData
                var aCurrentData = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesEvtDataNav");
                if (aCurrentData.length > 1) {
                    var aNewData = aCurrentData.splice(iItem, 1);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav", aCurrentData);
                    if (this.getView().getModel("lineStandardUpdateModel").getProperty("/deleteLineStdCycleEvtDb") == undefined) {
                        var aDeleteRowId = [];
                        if(aNewData[0].ID)
                        aDeleteRowId.push(aNewData[0].ID);
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/deleteLineStdCycleEvtDb", aDeleteRowId);
                    } else {
                        var aDeleteRowId = this.getView().getModel("lineStandardUpdateModel").getProperty("/deleteLineStdCycleEvtDb");
                        if(aNewData[0].ID)
                        aDeleteRowId.push(aNewData[0].ID);
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/deleteLineStdCycleEvtDb", aDeleteRowId);
                    }
                } else {
                    var message = this.oResourceBundle.getText("WARNING_DELETE_CYCLE");
                    this.onShowWarning(message);
                }

            },
            fnLineUpdateAnnualEventDeleteItem: function (oEvent) {
                var iItem = oEvent.getSource().getParent().getBindingContext("lineStandardUpdateModel").sPath.slice(27);
                //'/materialData/0'      standardCycleData
                var aCurrentData = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav");
                var aNewData = aCurrentData.splice(iItem, 1);
                this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav", aCurrentData);
                if (this.getView().getModel("lineStandardUpdateModel").getProperty("/deleteLineStdAnnualEvtDb") == undefined) {
                    var aDeleteRowId = [];
                    if(aNewData[0].ID)
                    aDeleteRowId.push(aNewData[0].ID);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/deleteLineStdAnnualEvtDb", aDeleteRowId);
                } else {
                    var aDeleteRowId = this.getView().getModel("lineStandardUpdateModel").getProperty("/deleteLineStdAnnualEvtDb");
                    if(aNewData[0].ID)
                    aDeleteRowId.push(aNewData[0].ID);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/deleteLineStdAnnualEvtDb", aDeleteRowId);
                }
            },
            /////////////////////////////////////////Select Standard dropdown///////////////////////////////////////////////////////////

            // Line standard filter button pressed           
            onFilterPressed: function (evt) {
                if (toggle == 1) {
                    this.getView().byId("idPanel").setVisible(true);
                    // 
                    this.getView().byId("idPanel").setExpandAnimation(true);
                    this.getView().byId("idPanel").setExpanded(true);//render content
                    this.getView().byId("idPanel").setExpandable(true);// while closing gettting animation
                    //    this.getView().byId("idPanel").setExpanded(true);//render content
                    // this.getView().byId("idPanel").setExpandAnimation(true);

                    this.getView().byId("idLineStandard").setVisible(true);
                    this.getView().byId("idLineStandard21").setVisible(true);
                    this.getView().byId("idLineStandard213").setVisible(true);
                    toggle = 2;
                } else if (toggle == 2) {
                    // this.getView().byId("idPanel").setVisible(false);
                    toggle = 1;
                    this.getView().byId("idPanel").setExpandAnimation(true);
                    this.getView().byId("idPanel").setExpanded(false);
                    this.getView().byId("idPanel").setExpandable(true);
                    this.getView().byId("idLineStandard").setVisible(false);
                    this.getView().byId("idLineStandard21").setVisible(false);
                    this.getView().byId("idLineStandard213").setVisible(false);
                }
            },
            handleCopyChangeValidfrom: function () {
                var oValidFrom = sap.ui.getCore().byId("idCopyHeaderCreateValidFrom");
                var oModifiedFrom = sap.ui.getCore().byId("idCopyHeaderModifiedFrom");
                if (oValidFrom && oModifiedFrom) {
                    var sValidFromDate = oValidFrom.getDateValue();
                    oModifiedFrom.setDateValue(sValidFromDate);
                }
            },
            onStandardCopyCreate: function () {
                this._isConfirming = false;
                if (!this._oLineCopyCreateDialog) {
                    this._oLineCopyCreateDialog = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.StandardCopyCreate", this);
                    this.getView().addDependent(this._oLineCopyCreateDialog);
                }
                this._oLineCopyCreateDialog.open();

                // POPup wizard discard progress
                var oWizard = sap.ui.getCore().byId("idCopyCreateLineWizard");
                var oFirstStep = oWizard.getSteps()[0];
                oWizard.discardProgress(oFirstStep);
                // scroll to top
                // oWizard.goToStep(oFirstStep);
                // invalidate first step
                oFirstStep.setValidated(true);

                ///////////////////clearing the input values and stteing the state to none//////////////////////

                sap.ui.getCore().byId("idSubCatCopy").setEditable(false);
                sap.ui.getCore().byId("idAnnualSubCatCopy").setEditable(false);
                // set value empty

                sap.ui.getCore().byId("idConditionCopy").setValue("");
                sap.ui.getCore().byId("idConditionDescCopy").setValue("");
                sap.ui.getCore().byId("idShiftLengthCopy").setValue("");
                sap.ui.getCore().byId("idProductionCycleCopy").setValue("");
                sap.ui.getCore().byId("idShiftDaysCopy").setValue("");
                sap.ui.getCore().byId("idcycleYearCopy").setValue("");
                sap.ui.getCore().byId("idLossCatCopy").setValue("");
                sap.ui.getCore().byId("idSubCatCopy").setValue("");
                sap.ui.getCore().byId("idExpectedCrewSizeCopy").setValue("");
                sap.ui.getCore().byId("idExpectedFreqCopy").setValue("");
                sap.ui.getCore().byId("idExpectEventDurationCopy").setValue("");
                sap.ui.getCore().byId("idAnnualLossCatCopy").setValue("");
                sap.ui.getCore().byId("idAnnualSubCatCopy").setValue("");
                sap.ui.getCore().byId("idAnnualCycleYearCopy").setValue("");
                sap.ui.getCore().byId("idAnnaulFreqCopy").setValue("");
                sap.ui.getCore().byId("idAnnualEventDurCopy").setValue("");
                sap.ui.getCore().byId("idAnnualCrewSizeCopy").setValue("");

                sap.ui.getCore().byId("idConditionCopy").setValueState("None");
                sap.ui.getCore().byId("idConditionDescCopy").setValueState("None");
                sap.ui.getCore().byId("idShiftLengthCopy").setValueState("None");
                sap.ui.getCore().byId("idProductionCycleCopy").setValueState("None");
                sap.ui.getCore().byId("idShiftDaysCopy").setValueState("None");
                sap.ui.getCore().byId("idcycleYearCopy").setValueState("None");
                sap.ui.getCore().byId("idLossCatCopy").setValueState("None");
                sap.ui.getCore().byId("idSubCatCopy").setValueState("None");
                sap.ui.getCore().byId("idExpectedCrewSizeCopy").setValueState("None");
                sap.ui.getCore().byId("idExpectedFreqCopy").setValueState("None");
                sap.ui.getCore().byId("idExpectEventDurationCopy").setValueState("None");
                sap.ui.getCore().byId("idAnnualLossCatCopy").setValueState("None");
                sap.ui.getCore().byId("idAnnualSubCatCopy").setValueState("None");
                sap.ui.getCore().byId("idAnnualCycleYearCopy").setValueState("None");
                sap.ui.getCore().byId("idAnnaulFreqCopy").setValueState("None");
                sap.ui.getCore().byId("idAnnualEventDurCopy").setValueState("None");
                sap.ui.getCore().byId("idAnnualCrewSizeCopy").setValueState("None");

                sap.ui.getCore().byId("idLossCatCopy").setEditable(true);
                sap.ui.getCore().byId("idSubCatCopy").setEditable(false);
                sap.ui.getCore().byId("idExpectedCrewSizeCopy").setEditable(false);
                sap.ui.getCore().byId("idExpectedFreqCopy").setEditable(false);
                sap.ui.getCore().byId("idExpectEventDurationCopy").setEditable(false);

                sap.ui.getCore().byId("idAnnualSubCatCopy").setEditable(false);
                sap.ui.getCore().byId("idAnnualCycleYearCopy").setEditable(false);
                sap.ui.getCore().byId("idAnnaulFreqCopy").setEditable(false);
                sap.ui.getCore().byId("idAnnualEventDurCopy").setEditable(false);
                sap.ui.getCore().byId("idAnnualCrewSizeCopy").setEditable(false);
                //////////////////////////////////////////////////////////////////////////////////////////////////

                tableIndex = this.getView().byId("idLineTable")._aSelectedPaths[0];

                BusyIndicator.show(0);
                var url = "/ETY_RESOURCE_SHSet";
                var oFilterPlant = new Filter({
                    filters: [
                        new Filter("Werks", FilterOperator.EQ, oCopyCreatePlant)
                    ]
                });
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        filters: [oFilterPlant],
                        success: function (oData) {
                            BusyIndicator.hide();
                            // Create and set the JSONModel with the data received
                            var oModelResource = new sap.ui.model.json.JSONModel();
                            oModelResource.setData(oData);
                            this.getView().setModel(oModelResource, "resourceModelCopy");
                        }.bind(this),
                        error: function (oError) {
                            BusyIndicator.hide();
                            // Handle errors
                            MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }

                var oCopyCreatePlant = sap.ui.getCore().byId("idCopyHeaderCreatePlant");
                if (oCopyCreatePlant != undefined) {
                    var sPlant = oCopyCreatePlant.getSelectedKey();
                }
                var oModelLineLossCat = new sap.ui.model.json.JSONModel();
                oModelLineLossCat.loadData("odata/v4/data-services/LineRelatedLossCatDB?$apply=groupby((lossCat,plant))&$filter=plant eq '" + sPlant + "'&$select=lossCat,subCat");
                oModelLineLossCat.setSizeLimit(100);
                this.getView().setModel(oModelLineLossCat, "lineLossCatModel");

                this._fnReadLineStdSelectedRowData();
            },

            _fnReadLineStdSelectedRowData: function () {

                if (this.getView().byId("idLineTable").getSelectedItems()[0] != undefined) {
                    var sPath = this.getView().byId("idLineTable").getSelectedItems()[0].getBindingContext("lineStandardHeaderModel").sPath;
                }
                else if (iSelectedRowIndex != undefined) {
                    var sPath = "/value/" + iSelectedRowIndex;
                }
                else if (iLineApproveSelIndex != undefined) {
                    var sPath = iLineApproveSelIndex;
                }
                else if (iLineExecutorSelIndex != undefined) {
                    var sPath = iLineExecutorSelIndex;
                }

                var oData = this.getView().getModel("lineStandardHeaderModel").getProperty(sPath);
                var sId = oData.ID;
                var slineStdNo = oData.lineStdNo;
                approverLevel = oData.stdApprLvl;

                var that = this;
                BusyIndicator.show();
                var aPlantData = this.getView().getModel("plantModel1").getData().results;
                var plantIds = [];
                for (var i = 0; i < aPlantData.length; i++) {
                    var plant = aPlantData[i].Werks;
                    plantIds.push(plant);
                }
                const plantsParam = plantIds.join(',');

                var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                var nbId = newData[0].Username;
                var zone = newData[0].Zone;

                if ((role === 'C') || (role === "S")){
                    var currentRole = "Creator/Editor"
                }
                if (role ==='A') {
                    var currentRole = "Approver"
                }
                if ((role === 'V')|| (role === "E")) {
                    var currentRole = "Executor/Viewer"
                }
                var sUrl = "odata/v4/data-services/LineRelStandardHeadersDB(ID=" + sId + ",lineStdNo='" + slineStdNo + "')?$expand=LineHdrToCyclesDataNav,LineHdrToCyclesEvtDataNav,LineHdrToAnnualEvtDataNav";

                $.get({
                    url: sUrl,
                    method: 'GET',
                    headers: {
                        'x-username': nbId,
                        'x-zone': zone,
                        'x-plants': plantsParam,
                        'x-role': currentRole
                    }
                }).done(function (data) {
                    // 'data' here should contain the response from the OData endpoint                    
                    BusyIndicator.hide();
                    // Process or display the 'data' object as 
                    // Total Planned DT Loss calculation  for Create with template, Approver, Executor 
                    var TotalPlannedDTLoss, CycleEventPlannedDTLoss = 0, AnnualCyclePlannedDTLoss = 0;
                    if (data.LineHdrToCyclesEvtDataNav.length != 0 || data.LineHdrToCyclesEvtDataNav != undefined) {
                        var CycleEventData = data.LineHdrToCyclesEvtDataNav;
                        for (var i = 0; i < CycleEventData.length; i++) {
                            CycleEventPlannedDTLoss = CycleEventData[i].plannedDtLoss + CycleEventPlannedDTLoss;
                        }

                    }
                    if (data.LineHdrToAnnualEvtDataNav.length != 0 || data.LineHdrToAnnualEvtDataNav != undefined) {
                        var AnnualCycleEventData = data.LineHdrToAnnualEvtDataNav;
                        for (var i = 0; i < AnnualCycleEventData.length; i++) {
                            AnnualCyclePlannedDTLoss = AnnualCycleEventData[i].plannedDtLoss + AnnualCyclePlannedDTLoss;
                        }

                    }
                    TotalPlannedDTLoss = Number(Number(CycleEventPlannedDTLoss + AnnualCyclePlannedDTLoss).toFixed(3));
                    data.TotalPlannedDTLoss = TotalPlannedDTLoss;

                    var oTableModel = new sap.ui.model.json.JSONModel(data);
                    that.getView().setModel(oTableModel, "lineStandardUpdateModel");
                    //Setting model at component level
                    that.getOwnerComponent().setModel(oTableModel, "lineStandardUpdateModel");
                    // alert(JSON.stringify(data)); // Convert data to string for alert
                }).fail(function (xhr, status, error) {
                    BusyIndicator.hide();
                    // Handle errors if the request fails
                    MessageToast.show(that.oResourceBundle.getText("UPDATE_DATA_READ_FAILED"));

                });

            },
            fnReviewToContentCopyPlant: function () {

                var oCopyCreatePlant = sap.ui.getCore().byId("idCopyHeaderCreatePlant").getSelectedKey();
                BusyIndicator.show(0);
                var url = "/ETY_RESOURCE_SHSet";
                var oFilterPlant = new Filter({
                    filters: [
                        new Filter("Werks", FilterOperator.EQ, oCopyCreatePlant)
                    ]
                });
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        filters: [oFilterPlant],
                        success: function (oData) {
                            BusyIndicator.hide();
                            // Create and set the JSONModel with the data received
                            var oModelResource = new sap.ui.model.json.JSONModel();
                            oModelResource.setData(oData);
                            this.getView().setModel(oModelResource, "resourceModelCopy");
                        }.bind(this),
                        error: function (oError) {
                            BusyIndicator.hide();
                            // Handle errors
                            MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
            },

            onCopyCreate: function (oEvent) {
                if (this._oLineCopyCreateDialog) {
                    this._oLineCopyCreateDialog.close();
                }

            },
            // on click of menu in line standard  a popover opens to show options to user
            onMenuLine: function (oEvent) {
                this._selectedRowStatus = null;
                // Global variable to get selected row index,which required by other button inside menu popup, on click menu button, in the Line Standard Header table,
                iSelectedRowIndex = oEvent.getSource().getBindingContext("lineStandardHeaderModel").sPath.slice(7);

                if (!this._oPopover) {
                    this._oPopover = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.PopoverLine", this);
                    this.getView().addDependent(this._oPopover);
                }
                tableIndex = this.getView().byId("idLineTable")._aSelectedPaths[0];
                this._oPopover.openBy(oEvent.getSource());
                var sSelectedRowPath = oEvent.getSource().getBindingContext("lineStandardHeaderModel").sPath
                var oLineHeaderTableData = this.getView().getModel("lineStandardHeaderModel").getProperty(sSelectedRowPath);
                this._lineStdNo = oLineHeaderTableData.lineStdNo;
                this._selectedRowStatus = oLineHeaderTableData.status;

                if (oLineHeaderTableData.status === "Under Review" || oLineHeaderTableData.status === "Archived") {
                    sap.ui.getCore().byId("idLineHeaderEdit").setVisible(false);
                    sap.ui.getCore().byId("idLineHeaderView").setVisible(false);
                    sap.ui.getCore().byId("idLineHeaderReview").setVisible(true);
                }
                else {
                    sap.ui.getCore().byId("idLineHeaderEdit").setVisible(true);
                    sap.ui.getCore().byId("idLineHeaderView").setVisible(true);
                    sap.ui.getCore().byId("idLineHeaderReview").setVisible(false);
                }

            },
            onReviewMenuArchive: function (oEvent) {
                if (!this._AutomaticArchievingLineStd) {
                    this._AutomaticArchievingLineStd = sap.ui.xmlfragment(
                        "l8gttpmgllpstdui.view.fragment.AutomaticArchievingLinestd",
                        this
                    );
                    this.getView().addDependent(this._AutomaticArchievingLineStd);
                }
                this._AutomaticArchievingLineStd.open();
                this._fnReadLineStdSelectedRowData()
                // Access elements inside the fragment and set properties based on status
                if (this._selectedRowStatus === "Archived") {
                    // Only "Re-work" and "Cancel" buttons should be visible
                    sap.ui.getCore().byId("idLineStdActualButton").setVisible(false);
                    sap.ui.getCore().byId("idLineStdArchiveButton").setVisible(false);
                    sap.ui.getCore().byId("idLineStdReworkButton").setVisible(true);
                    sap.ui.getCore().byId("idLineStdCancelButton").setVisible(true);
                    sap.ui.getCore().byId("idLineStdReworkButton").setText("Revert");
                } else if (this._selectedRowStatus === "Under Review") {
                    // All four buttons should be visible
                    sap.ui.getCore().byId("idLineStdActualButton").setVisible(true);
                    sap.ui.getCore().byId("idLineStdArchiveButton").setVisible(true);
                    sap.ui.getCore().byId("idLineStdReworkButton").setVisible(true);
                    sap.ui.getCore().byId("idLineStdCancelButton").setVisible(true);
                    sap.ui.getCore().byId("idLineStdReworkButton").setText("Re-work");
                } else {
                    // Default case: all buttons hidden except "Cancel"
                    sap.ui.getCore().byId("idLineStdActualButton").setVisible(false);
                    sap.ui.getCore().byId("idLineStdArchiveButton").setVisible(false);
                    sap.ui.getCore().byId("idLineStdReworkButton").setVisible(false);
                    sap.ui.getCore().byId("idLineStdCancelButton").setVisible(true);
                   
                }
                this._AutomaticArchievingLineStd.open();
            },
            fncloseReviewarchiving: function () {
                if (this._AutomaticArchievingLineStd) {
                    this._AutomaticArchievingLineStd.close();
                }
            },

            onLineMenuApprove: function (oEvent) {
                if (!this._ApproverReviewLine) {
                    this._ApproverReviewLine = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.ApproverReviewLineStd", this);
                    this.getView().addDependent(this._ApproverReviewLine);
                }
                iLineApproveSelIndex = oEvent.getSource().getBindingContext("lineStandardHeaderModel").sPath.slice();
                this._ApproverReviewLine.open();
                this._fnReadLineStdSelectedRowData();
            },
            onRework: function (oEvent) {
                if (!this._reworkComment) {
                    this._reworkComment = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.PopoverApproverComment", this);
                    this.getView().addDependent(this._reworkComment);
                }
                this._reworkComment.open();
            },
            fnRework: function (oEvent) {
                var that = this;
                if (this.getView().byId("idLineTable").getSelectedItems()[0] != undefined) {
                    var sPath = this.getView().byId("idLineTable").getSelectedItems()[0].getBindingContext("lineStandardHeaderModel").sPath;
                }
                else {
                    var sPath = iLineApproveSelIndex;
                }

                var oData = this.getView().getModel("lineStandardHeaderModel").getProperty(sPath);
                var sID = oData.ID;
                var sLineStdNo = oData.lineStdNo;

                var postData = {
                    "lineStdNo": sLineStdNo,
                    "status": "Re-Work",
                    "stdApprLvl": 0,
                    "currentApprStdLevel": approverLevel,
                    "reworkComment": sap.ui.getCore().byId("idReworkComment").getValue()
                }

                //  var sUrl = "odata/v4/data-services/LineRelStandardHeadersDB(ID=" + sID + ",lineStdNo='" + sLineStdNo + "')";
                var sUrl = "odata/v4/data-services/onReWorkLineStd";
                //POST
                BusyIndicator.show();
                $.ajax({
                    url: sUrl,
                    type: "POST",
                    data: JSON.stringify(postData),
                    contentType: "application/json",
                    dataType: "json",
                }).done(function (_response) {
                    BusyIndicator.hide();
                    MessageToast.show(that.oResourceBundle.getText("REWORK_COMMNT_SENT"));
                    var message = that.oResourceBundle.getText("LINE_STD_REJECTED_SUCCESS") + "\n Line Standard no :" + sLineStdNo;
                    that.onShowSuccess(message);
                    sap.ui.getCore().byId("idReworkComment").setValue("");
                    ///////////////////////////////////    After successful POSt, read call to fetch data///////////////////////////
                    that.fnReadLineStdApproverTableData();
                    that.getView().getModel("createLineStandardModel").setData({});

                    sap.ui.getCore().byId("wizardLineNavContainer").to(sap.ui.getCore().byId("wizardLineContentPage"));
                    sap.ui.getCore().byId("CreateLineWizard").goToStep(sap.ui.getCore().byId("LineTypeStep"));
                    sap.ui.getCore().byId("LineTypeStep").setValidated(true);
                }).fail(function (xhr, _status, _error) {
                    BusyIndicator.hide();
                    MessageToast.show(xhr.responseJSON.error.message + " " + that.oResourceBundle.getText("REWORK_COOMNT_NOTSENT"));
                    var message = that.oResourceBundle.getText("LINE_STD_REJECTED_FAIL") + "\n" + xhr.responseJSON.error.code + ":" + xhr.responseJSON.error.message;
                    that.onShowError(message);
                    that.fnReadLineStdApproverTableData();
                    // alert("Error in POST request: " + error);
                });
                ///////////////////////////////////////////////////////////////////////
                this.fnReworkPopupClose();

            },
            fnLineSubmitForApproval: function (_evt) {
                var that = this;
                if (this.getView().byId("idLineTable").getSelectedItems()[0] != undefined) {
                    var sPath = this.getView().byId("idLineTable").getSelectedItems()[0].getBindingContext("lineStandardHeaderModel").sPath;
                }
                else {
                    var sPath = "/value/" + iSelectedRowIndex;
                }
                var oData = this.getView().getModel("lineStandardHeaderModel").getProperty(sPath);
                var sID = oData.ID;
                var sLineStdNo = oData.lineStdNo;
                var postData = {
                    "status": "Under Appr",
                    "stdApprLvl": 1
                };
                var sUrl = "odata/v4/data-services/LineRelStandardHeadersDB(ID=" + sID + ",lineStdNo='" + sLineStdNo + "')";
                //POST
                BusyIndicator.show();
                $.ajax({
                    url: sUrl,
                    type: "PATCH",
                    data: JSON.stringify(postData),
                    contentType: "application/json",
                    dataType: "json",
                }).done(function (response) {
                    BusyIndicator.hide();
                    MessageToast.show(that.oResourceBundle.getText("SUBMITTED_FOR_APPROVAL"));
                    var message = that.oResourceBundle.getText("LINE_STD_SUBMITTED_APPROVAL_SUCCESS") + "\n Line Standard no : " + sLineStdNo;
                    that.onShowSuccess(message);
                    ///////////////////////////////////    After successful POSt, read call to fetch data///////////////////////////
                    that.fnReadLineStdHeaderTableData();;
                }).fail(function (xhr, status, error) {
                    BusyIndicator.hide();
                    MessageToast.show(xhr.responseJSON.error.message + " " + that.oResourceBundle.getText("SUBMIT_FORAPPROVAL_FAIL"));
                    var message = that.oResourceBundle.getText("LINE_STD_SUBMITTED_APPROVAL_FAIL");
                    that.onShowError(message);
                    that.fnReadLineStdHeaderTableData();;
                });

            },
            fnLineSubmitForApproval1: function (evt) {
                var that = this;
                var aSelectedItems = this.getView().byId("idLineTable").getSelectedItems();
                var aUpdateLineStdHdrstatusData = [];
                for (var i = 0; i < aSelectedItems.length; i++) {
                    var sPath = aSelectedItems[i].getBindingContext("lineStandardHeaderModel").sPath;
                    var oData = this.getView().getModel("lineStandardHeaderModel").getProperty(sPath);
                    var obj = {}
                    obj.lineStdNo = oData.lineStdNo,
                        obj.status = "Under Appr",
                        obj.stdApprLvl = 1,
                        obj.executionState = 0
                    aUpdateLineStdHdrstatusData.push(obj);
                }

                var postData = {
                    updateLineStdHdrstatusData: aUpdateLineStdHdrstatusData
                };

                var sUrl = "odata/v4/data-services/upsertLineStdStatusItems";
                //POST
                BusyIndicator.show();
                $.ajax({
                    url: sUrl,
                    type: "POST",
                    data: JSON.stringify(postData),
                    contentType: "application/json",
                    dataType: "json",
                }).done(function (response) {
                    BusyIndicator.hide();
                    MessageToast.show(that.oResourceBundle.getText("SUBMITTED_FOR_APPROVAL"));
                    var message = that.oResourceBundle.getText("LINE_STD_SUBMITTED_APPROVAL_SUCCESS2");
                    that.onShowSuccess(message);
                    ///////////////////////////////////    After successful POSt, read call to fetch data///////////////////////////
                    that.fnReadLineStdHeaderTableData();;
                    //initial setting for Line table button
                    that.getView().byId("idLineCopyCreate").setEnabled(false);
                    that.getView().byId("idArchive").setEnabled(false);
                    that.getView().byId("idCreate").setEnabled(true);
                    that.getView().byId("idSubmitForApproval").setEnabled(false);

                }).fail(function (xhr, status, error) {
                    BusyIndicator.hide();
                    MessageToast.show(xhr.responseJSON.error.message + " " + that.oResourceBundle.getText("SUBMIT_FORAPPROVAL_FAIL"));
                    var message = that.oResourceBundle.getText("LINE_STD_SUBMITTED_APPROVAL_FAIL2") + "\n Code :" + xhr.responseJSON.error.code + "Message :" + xhr.responseJSON.error.message;
                    that.onShowError(message);
                    that.fnReadLineStdHeaderTableData();;
                    that.getView().byId("idLineTable").removeSelections(true);

                    //initial setting for Line table button
                    that.getView().byId("idLineCopyCreate").setEnabled(false);
                    that.getView().byId("idArchive").setEnabled(false);
                    that.getView().byId("idCreate").setEnabled(true);
                    that.getView().byId("idSubmitForApproval").setEnabled(false);
                });

            },
            // Line standard view rework display function
            fnShowReworkComment(oEvent) {
                if (oEvent.getSource().getBindingContext("lineStandardHeaderModel") != undefined) {
                    var iSelectedIndex = oEvent.getSource().getBindingContext("lineStandardHeaderModel").sPath.slice(7);
                    var comment = this.getView().getModel("lineStandardHeaderModel").getProperty("/value/" + iSelectedIndex + "/reworkComment");
                    if (comment) {
                        if (!this._oPopoverCommentDisplay) {
                            this._oPopoverCommentDisplay = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.ApproverCommentDisplay", this);
                            this.getView().addDependent(this._oPopoverCommentDisplay);
                        }
                        //oEvent.getSource()
                        this._oPopoverCommentDisplay.openBy(oEvent.getSource());
                        sap.ui.getCore().byId("idLineApprCommentDisplay").setVisible(true);
                        sap.ui.getCore().byId("idProdApprCommentDisplay").setVisible(false);
                        sap.ui.getCore().byId("idLineApprCommentDisplay").setText(comment);
                        MessageToast.show(comment);
                    }
                }
            },
            onLineMenuExecute: function (oEvent) {
                if (!this._ExecutorReviewLine) {
                    this._ExecutorReviewLine = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.ExecutorReviewLineStd", this);
                    this.getView().addDependent(this._ExecutorReviewLine);
                }
                iLineExecutorSelIndex = oEvent.getSource().getBindingContext("lineStandardHeaderModel").sPath.slice();
                this._ExecutorReviewLine.open();
                this._fnReadLineStdSelectedRowData();// To read data for executor
            },
            onView: function (evt) {
                if (evt.getSource().getBindingContext("lineStandardHeaderModel") != undefined) {
                    iSelectedRowIndex = evt.getSource().getBindingContext("lineStandardHeaderModel").sPath.slice(7);
                }
                var tableIndex = iSelectedRowIndex;
                var sSelectedlineStdNo = this.getView().getModel("lineStandardHeaderModel").getProperty("/value/" + tableIndex + "/lineStdNo");

                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                roleVal = (role === "V") ? "V" : "E";
                oRouter.navTo("onViewStandard", {
                    lineStdNo: sSelectedlineStdNo,
                    roleVal: roleVal
                });

            },
            fnLineStandardTableRowSelected: function (_oEvent) {

                var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                var nbId = newData[0].Username;

                var aSelectedItems = this.getView().byId("idLineTable").getSelectedItems();
                var iLineTableRowSelected = this.getView().byId("idLineTable").getSelectedItems().length;
                var iSubApprStatus = 0, iArchStatus = 0;     
                for (var i = 0; i < iLineTableRowSelected; i++) {
                    var sPath = aSelectedItems[i].getBindingContext("lineStandardHeaderModel").sPath;
                    var oData = this.getView().getModel("lineStandardHeaderModel").getProperty(sPath);
                    if (oData.status != "Created" && oData.status != "Modified") {
                        iSubApprStatus = 1;
                    }
                    if (oData.status == "Archived") {
                        iArchStatus = 1;
                    }
                }
                if (iLineTableRowSelected == 1) {
                    this.getView().byId("idLineCopyCreate").setEnabled(true);
                    if (iArchStatus != 1) {
                        this.getView().byId("idArchive").setEnabled(true);
                    } else {
                        this.getView().byId("idArchive").setEnabled(false);
                    }
                    this.getView().byId("idCreate").setEnabled(false);
                    if (iSubApprStatus != 1 && role != "V") {
                        this.getView().byId("idSubmitForApproval").setEnabled(true);
                    } else {
                        this.getView().byId("idSubmitForApproval").setEnabled(false);
                    }
                }
                if (iLineTableRowSelected < 1) {
                    this.getView().byId("idLineCopyCreate").setEnabled(false);
                    this.getView().byId("idArchive").setEnabled(false);    
                    this.getView().byId("idCreate").setEnabled(true);
                    this.getView().byId("idSubmitForApproval").setEnabled(false);
                }
                if (iLineTableRowSelected >= 2) {
                    this.getView().byId("idLineCopyCreate").setEnabled(false);
                    this.getView().byId("idSubmitForApproval").setEnabled(true);
                    if (iSubApprStatus != 1 && role != "V") {
                        this.getView().byId("idSubmitForApproval").setEnabled(true);
                    } else {
                        this.getView().byId("idSubmitForApproval").setEnabled(false);
                    }
                    if (iArchStatus != 1) {
                        this.getView().byId("idArchive").setEnabled(true);
                    } else {
                        this.getView().byId("idArchive").setEnabled(false);
                    }
                }
            },

            onStandardCreate: function () {
                this._isConfirming = false;
                if (!this._LineCreate) {
                    this._LineCreate = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.StandardCreate", this);
                    this.getView().addDependent(this._LineCreate);
                }
                this._LineCreate.open();
                var oWizard = sap.ui.getCore().byId("CreateLineWizard");
                var oFirstStep = oWizard.getSteps()[0];
                oWizard.discardProgress(oFirstStep);
                // scroll to top
                oWizard.goToStep(oFirstStep);
                // invalidate first step
                oFirstStep.setValidated(true);
                sap.ui.getCore().byId("idHeaderCreateValidFrom").setDateValue(new Date());
                sap.ui.getCore().byId("idHeaderCreateModifiedFrom").setDateValue(new Date());
                sap.ui.getCore().byId("idHeaderCreateValidTo").setValue("Dec 31, 9999");
                this._oNavContainer = this.byId("wizardNavContainer");

                sap.ui.getCore().byId("idLossCat").setEditable(true);
                sap.ui.getCore().byId("idSubCat").setEditable(false);
                sap.ui.getCore().byId("idExpectedCrewSize").setEditable(false);
                sap.ui.getCore().byId("idExpectedFreq").setEditable(false);
                sap.ui.getCore().byId("idExpectEventDuration").setEditable(false);

                this.getView().getModel("lineLossCatModel").setProperty("/value", []);
            },
            handleValidfromcreateChange: function () {
                var oValidFrom = sap.ui.getCore().byId("idHeaderCreateValidFrom");
                var oModifiedFrom = sap.ui.getCore().byId("idHeaderCreateModifiedFrom");
                if (oValidFrom && oModifiedFrom) {
                    var sValidFromDate = oValidFrom.getDateValue();
                    oModifiedFrom.setDateValue(sValidFromDate);
                }
            },

            fnPlantFilterSelection: function (_evt) {
                var sPlant = this.getView().byId("idLineFilterPlant").getSelectedKey();
                var url = "/ETY_RESOURCE_SHSet";
                var oFilterPlant = new Filter({
                    filters: [
                        new Filter("Werks", FilterOperator.EQ, sPlant)
                    ]
                });
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        filters: [oFilterPlant],
                        success: function (oData) {
                            // Create and set the JSONModel with the data received
                            var oModelResource = new sap.ui.model.json.JSONModel();
                            oModelResource.setData(oData);
                            this.getView().setModel(oModelResource, "resourceFilterModel");
                        }.bind(this),
                        error: function (oError) {
                            // Handle errors
                            MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
            },

            // function for plant selection in the create standard dialog step1
            fnPlantSelection: function () {
                var oCreateResource = sap.ui.getCore().byId("idHeaderCreateResource");
                if (oCreateResource != undefined) {
                    oCreateResource.setEditable(true);
                }
                var oModelResource = new sap.ui.model.json.JSONModel();
                var oCreatePlant = sap.ui.getCore().byId("idHeaderCreatePlant");
                sap.ui.getCore().byId("idLossCat").setValue("");
                sap.ui.getCore().byId("idSubCat").setValue("");
                sap.ui.getCore().byId("idAnnualLossCat").setValue("");
                sap.ui.getCore().byId("idAnnualSubCat").setValue("");
                sap.ui.getCore().byId("idSubCat").setEditable(false);
                sap.ui.getCore().byId("idAnnualSubCat").setEditable(false);

                if (oCreatePlant != "undefined") {
                    // step1
                    oCreateResource.setEditable(true);
                    sap.ui.getCore().byId("idHeaderCreateResource").setValue("");
                    sap.ui.getCore().byId("idHeaderCreateCostCenter").setValue("");
                    //step3
                    sap.ui.getCore().byId("idLossCat").setValue("");
                    sap.ui.getCore().byId("idSubCat").setValue("");
                    //step4
                    sap.ui.getCore().byId("idAnnualLossCat").setValue("");
                    sap.ui.getCore().byId("idAnnualSubCat").setValue("");
                    var sPlant = oCreatePlant.getValue();
                }

                if (sPlant === "") {

                    //step1
                    sap.ui.getCore().byId("idHeaderCreateResource").setEditable(false);
                    // step3
                    sap.ui.getCore().byId("idSubCat").setEditable(false);
                    //step4
                    sap.ui.getCore().byId("idAnnualLossCatLabel").setRequired(false);
                    sap.ui.getCore().byId("idAnnualSubCatLabel").setRequired(false);
                    sap.ui.getCore().byId("idAnnualCycleYearLabel").setRequired(false);
                    sap.ui.getCore().byId("idAnnaulFreqLabel").setRequired(false);
                    sap.ui.getCore().byId("idAnnualEventDurLabel").setRequired(false);
                    sap.ui.getCore().byId("idAnnualCrewSizeLabel").setRequired(false);

                    sap.ui.getCore().byId("idAnnualSubCat").setEditable(false);
                    sap.ui.getCore().byId("idAnnualCycleYear").setEditable(false);
                    sap.ui.getCore().byId("idAnnaulFreq").setEditable(false);
                    sap.ui.getCore().byId("idAnnualEventDur").setEditable(false);
                    sap.ui.getCore().byId("idAnnualCrewSize").setEditable(false);
                    //step4
                    sap.ui.getCore().byId("idAnnualSubCat").setValue("");

                }

                var url = "/ETY_RESOURCE_SHSet";
                var oFilterPlant = new Filter({
                    filters: [
                        new Filter("Werks", FilterOperator.EQ, sPlant)
                    ]
                });
                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        filters: [oFilterPlant],
                        success: function (oData) {
                            // Create and set the JSONModel with the data received
                            var oModelResource = new sap.ui.model.json.JSONModel();
                            oModelResource.setData(oData);
                            this.getView().setModel(oModelResource, "resourceModel");
                            this.fnLineLossCat();
                        }.bind(this),
                        error: function (oError) {
                            // Handle errors
                            MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
                        }
                    });
                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }

            },
            fnPlantSelectionCopy: function (evt) {

                var oCopyCreatePlant = sap.ui.getCore().byId("idCopyHeaderCreatePlant");
                sap.ui.getCore().byId("idLossCatCopy").setValue("");
                sap.ui.getCore().byId("idSubCatCopy").setValue("");
                sap.ui.getCore().byId("idAnnualLossCatCopy").setValue("");
                sap.ui.getCore().byId("idAnnualSubCatCopy").setValue("");
                sap.ui.getCore().byId("idSubCatCopy").setEditable(false);
                sap.ui.getCore().byId("idAnnualSubCatCopy").setEditable(false);

                if (oCopyCreatePlant != undefined) {
                    var sPlant = oCopyCreatePlant.getSelectedKey();

                    sap.ui.getCore().byId("idCopyHeaderCreateResource").setValue("");
                    sap.ui.getCore().byId("idCopyHeaderCreateCostCenter").setValue("");
                    sap.ui.getCore().byId("idLossCatCopy").setValue("");
                    sap.ui.getCore().byId("idSubCatCopy").setValue("");
                    sap.ui.getCore().byId("idAnnualLossCatCopy").setValue("");
                    sap.ui.getCore().byId("idAnnualSubCatCopy").setValue("");

                    if (sPlant == "") {
                        sap.ui.getCore().byId("idSubCatCopy").setEditable(false);
                        sap.ui.getCore().byId("idAnnualSubCatCopy").setEditable(false);
                        sap.ui.getCore().byId("idCopyHeaderCreateResource").setEditable(false);
                    } else {
                        sap.ui.getCore().byId("idCopyHeaderCreateResource").setEditable(true);;
                    }

                    if (this.getView().getModel("lineStandardUpdateModel") != undefined) {
                        for (var i = 0; i < this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesEvtDataNav").length; i++) {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/lossCat", "");
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/subCat", "");
                        }

                        for (var i = 0; i < this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav").length; i++) {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/lossCat", "");
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/subCat", "");
                        }
                    }

                    var url = "/ETY_RESOURCE_SHSet";
                    var oFilterPlant = new Filter({
                        filters: [
                            new Filter("Werks", FilterOperator.EQ, sPlant)
                        ]
                    });
                    if (oODataModel) {
                        oODataModel.read(url, {
                            headers: mHeaders,
                            filters: [oFilterPlant],
                            success: function (oData) {
                                // Create and set the JSONModel with the data received
                                var oModelResource = new sap.ui.model.json.JSONModel();
                                oModelResource.setData(oData);
                                this.getView().setModel(oModelResource, "resourceModelCopy");
                                this.fnCopyCreateLossCat();
                            }.bind(this),
                            error: function (oError) {
                                // Handle errors
                                MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
                            }
                        });
                    } else {
                        MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                    }

                }

            },

            fnLineLossCat: function (_evt) {
                var oModelLineLossCat = new sap.ui.model.json.JSONModel();
                if (sap.ui.getCore().byId("idHeaderCreatePlant") != undefined) {
                    var sPlant = sap.ui.getCore().byId("idHeaderCreatePlant").getSelectedKey();
                }
                oModelLineLossCat.loadData("odata/v4/data-services/LineRelatedLossCatDB?$apply=groupby((lossCat,plant))&$filter=plant eq '" + sPlant + "'&$select=lossCat,subCat");
                oModelLineLossCat.setSizeLimit(100);
                this.getView().setModel(oModelLineLossCat, "lineLossCatModel");
            },
            fnCopyCreateLossCat: function (_evt) {

                var oModelLineLossCat = new sap.ui.model.json.JSONModel();
                var oCopyCreatePlant = sap.ui.getCore().byId("idCopyHeaderCreatePlant");
                if (oCopyCreatePlant != undefined) {
                    var sPlant = oCopyCreatePlant.getSelectedKey();
                }
                oModelLineLossCat.loadData("odata/v4/data-services/LineRelatedLossCatDB?$apply=groupby((lossCat,plant))&$filter=plant eq '" + sPlant + "'&$select=lossCat,subCat");
                oModelLineLossCat.setSizeLimit(100);
                this.getView().setModel(oModelLineLossCat, "lineCopyLossCatModel");
            },
            fnUpdateCreateLossCat: function (_evt) {

                var oModelLineLossCat = new sap.ui.model.json.JSONModel();
                var oCopyCreatePlant = sap.ui.getCore().byId("idStandardHeaderPlant");
                if (oCopyCreatePlant != undefined) {
                    var sPlant = oCopyCreatePlant.getSelectedKey();
                }
                oModelLineLossCat.loadData("odata/v4/data-services/LineRelatedLossCatDB?$apply=groupby((lossCat,plant))&$filter=plant eq '" + sPlant + "'&$select=lossCat,subCat");
                oModelLineLossCat.setSizeLimit(100);
                this.getView().setModel(oModelLineLossCat, "lineUpdateLossCatModel");

            },
            fnUpdateLossCat: function (_evt) {

                var oModelLineLossCat = new sap.ui.model.json.JSONModel();
                var oCopyCreatePlant = sap.ui.getCore().byId("idStandardHeaderPlant");
                if (oCopyCreatePlant != undefined) {
                    var sPlant = oCopyCreatePlant.getValue();
                }
                oModelLineLossCat.loadData("odata/v4/data-services/LineRelatedLossCatDB?$apply=groupby((lossCat,plant))&$filter=plant eq '" + sPlant + "'&$select=lossCat,subCat");
                oModelLineLossCat.setSizeLimit(100);
                this.getView().setModel(oModelLineLossCat, "lineUpdateLossCatModel");


            },

            fnLineSubCat: function (evt) {

                if (sap.ui.getCore().byId("idHeaderCreatePlant") != undefined) {

                    var sPlant = sap.ui.getCore().byId("idHeaderCreatePlant").getSelectedKey();
                    var sLossCat = sap.ui.getCore().byId("idLossCat").getValue();
                    if (sLossCat == "") {
                        sap.ui.getCore().byId("idSubCat").setValue("");
                        sap.ui.getCore().byId("idSubCat").setEditable(false);
                        sap.ui.getCore().byId("idExpectedCrewSize").setEditable(false);
                        sap.ui.getCore().byId("idExpectedCrewSize").setValue("");
                        sap.ui.getCore().byId("idExpectedFreq").setEditable(false);
                        sap.ui.getCore().byId("idExpectedFreq").setValue("");
                        sap.ui.getCore().byId("idExpectEventDuration").setEditable(false);
                        sap.ui.getCore().byId("idExpectEventDuration").setValue("");
                    } else {
                        sap.ui.getCore().byId("idSubCat").setEditable(true);
                        sap.ui.getCore().byId("idSubCat").setValue("");
                        sap.ui.getCore().byId("idExpectedCrewSize").setEditable(true);
                        sap.ui.getCore().byId("idExpectedCrewSize").setValue("");
                        sap.ui.getCore().byId("idExpectedFreq").setEditable(true);
                        sap.ui.getCore().byId("idExpectedFreq").setValue("");
                        sap.ui.getCore().byId("idExpectEventDuration").setEditable(true);
                        sap.ui.getCore().byId("idExpectEventDuration").setValue("");

                        sap.ui.getCore().byId("idLossCat").setValueState("None");
                        sap.ui.getCore().byId("idSubCat").setValueState("None");
                        sap.ui.getCore().byId("idExpectedCrewSize").setValueState("None");
                        sap.ui.getCore().byId("idExpectedFreq").setValueState("None");
                        sap.ui.getCore().byId("idExpectEventDuration").setValueState("None");
                    }
                }
                var oModelLineSubCat = new sap.ui.model.json.JSONModel();
                oModelLineSubCat.loadData("odata/v4/data-services/LineRelatedLossCatDB?$filter=plant eq '" + sPlant + "' and lossCat eq '" + sLossCat + "'&$select=subCat");
                oModelLineSubCat.setSizeLimit(100);
                this.getView().setModel(oModelLineSubCat, "lineSubCatModel");

            },

            // Copy create dialog step3 Loss category on selected function
            fnLineCopySubCat: function (evt) {

                if (sap.ui.getCore().byId("idCopyHeaderCreatePlant") != undefined) {
                    // sap.ui.getCore().byId("idSubCatCopy").setEditable(true);
                    // sap.ui.getCore().byId("idSubCatCopy").setValue("");
                    var sPlant = sap.ui.getCore().byId("idCopyHeaderCreatePlant").getSelectedKey();
                    var sLossCat = sap.ui.getCore().byId("idLossCatCopy").getValue();
                }
                if (sLossCat == "") {
                    sap.ui.getCore().byId("idSubCatCopy").setValue("");
                    sap.ui.getCore().byId("idExpectedCrewSizeCopy").setValue("");
                    sap.ui.getCore().byId("idExpectedFreqCopy").setValue("");
                    sap.ui.getCore().byId("idExpectEventDurationCopy").setValue("");

                    sap.ui.getCore().byId("idSubCatCopy").setEditable(false);
                    sap.ui.getCore().byId("idExpectedCrewSizeCopy").setEditable(false);
                    sap.ui.getCore().byId("idExpectedFreqCopy").setEditable(false);
                    sap.ui.getCore().byId("idExpectEventDurationCopy").setEditable(false);

                } else {
                    sap.ui.getCore().byId("idSubCatCopy").setValue("");
                    sap.ui.getCore().byId("idExpectedCrewSizeCopy").setValue("");
                    sap.ui.getCore().byId("idExpectedFreqCopy").setValue("");
                    sap.ui.getCore().byId("idExpectEventDurationCopy").setValue("");

                    sap.ui.getCore().byId("idSubCatCopy").setEditable(true);
                    sap.ui.getCore().byId("idExpectedCrewSizeCopy").setEditable(true);
                    sap.ui.getCore().byId("idExpectedFreqCopy").setEditable(true);
                    sap.ui.getCore().byId("idExpectEventDurationCopy").setEditable(true);

                    sap.ui.getCore().byId("idSubCatCopy").setValueState("None");
                    sap.ui.getCore().byId("idExpectedCrewSizeCopy").setValueState("None");
                    sap.ui.getCore().byId("idExpectedFreqCopy").setValueState("None");
                    sap.ui.getCore().byId("idExpectEventDurationCopy").setValueState("None");


                }

                var oModelLineSubCat = new sap.ui.model.json.JSONModel();
                oModelLineSubCat.loadData("odata/v4/data-services/LineRelatedLossCatDB?$filter=plant eq '" + sPlant + "' and lossCat eq '" + sLossCat + "'&$select=subCat");
                oModelLineSubCat.setSizeLimit(100);
                this.getView().setModel(oModelLineSubCat, "lineCopyCycleSubCatModel");

            },

            fnCopySubCat: function (evt) {
                var oCopyCreatePlant = sap.ui.getCore().byId("idCopyHeaderCreatePlant");
                if (oCopyCreatePlant != undefined) {
                    var sPlant = oCopyCreatePlant.getSelectedKey();
                    var sLossCatPath = evt.getSource().getBindingContext("lineStandardUpdateModel").sPath;
                    var sLossCat = this.getView().getModel("lineStandardUpdateModel").getProperty(sLossCatPath + "/lossCat");
                    this.getView().getModel("lineStandardUpdateModel").setProperty(sLossCatPath + "/subCat", "");

                    for (var i = 0; i < this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesEvtDataNav").length; i++) {
                        if (i != sLossCatPath.slice(27)) {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/lossCatEditable", false);
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/subCatEditable", false);
                        }
                    }
                    for (var i = 0; i < this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav").length; i++) {
                        if (i != sLossCatPath.slice(27)) {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/lossCatEditable", false);
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/subCatEditable", false);
                        }
                    }
                }

                var oModelLineSubCat = new sap.ui.model.json.JSONModel();
                oModelLineSubCat.loadData("odata/v4/data-services/LineRelatedLossCatDB?$filter=plant eq '" + sPlant + "' and lossCat eq '" + sLossCat + "'&$select=subCat");
                oModelLineSubCat.setSizeLimit(100);
                this.getView().setModel(oModelLineSubCat, "lineCopySubCatModel");
            },
            fnLineUpdateSubCat: function (_evt) {

                if (sap.ui.getCore().byId("idStandardHeaderPlant") != undefined) {
                    // sap.ui.getCore().byId("idSubCatCopy").setEditable(true);
                    // sap.ui.getCore().byId("idSubCatCopy").setValue("");
                    var sPlant = sap.ui.getCore().byId("idStandardHeaderPlant").getValue();
                    var sLossCat = sap.ui.getCore().byId("idLossCatupdate").getValue();
                }
                if (sLossCat == "") {
                    sap.ui.getCore().byId("idSubCatupdate").setValue("");
                    sap.ui.getCore().byId("idExpectedCrewSizeupdate").setValue("");
                    sap.ui.getCore().byId("idExpectedFrequpdate").setValue("");
                    sap.ui.getCore().byId("idExpectEventDurationupdate").setValue("");

                    sap.ui.getCore().byId("idSubCatupdate").setEditable(false);
                    sap.ui.getCore().byId("idExpectedCrewSizeupdate").setEditable(false);
                    sap.ui.getCore().byId("idExpectedFrequpdate").setEditable(false);
                    sap.ui.getCore().byId("idExpectEventDurationupdate").setEditable(false);

                } else {
                    sap.ui.getCore().byId("idSubCatupdate").setValue("");
                    sap.ui.getCore().byId("idExpectedCrewSizeupdate").setValue("");
                    sap.ui.getCore().byId("idExpectedFrequpdate").setValue("");
                    sap.ui.getCore().byId("idExpectEventDurationupdate").setValue("");

                    sap.ui.getCore().byId("idSubCatupdate").setEditable(true);
                    sap.ui.getCore().byId("idExpectedCrewSizeupdate").setEditable(true);
                    sap.ui.getCore().byId("idExpectedFrequpdate").setEditable(true);
                    sap.ui.getCore().byId("idExpectEventDurationupdate").setEditable(true);

                    sap.ui.getCore().byId("idSubCatupdate").setValueState("None");
                    sap.ui.getCore().byId("idExpectedCrewSizeupdate").setValueState("None");
                    sap.ui.getCore().byId("idExpectedFrequpdate").setValueState("None");
                    sap.ui.getCore().byId("idExpectEventDurationupdate").setValueState("None");


                }

                var oModelLineSubCat = new sap.ui.model.json.JSONModel();
                oModelLineSubCat.loadData("odata/v4/data-services/LineRelatedLossCatDB?$filter=plant eq '" + sPlant + "' and lossCat eq '" + sLossCat + "'&$select=subCat");
                oModelLineSubCat.setSizeLimit(100);
                this.getView().setModel(oModelLineSubCat, "lineupdateCycleSubCatModel");

            },

            fnUpdateSubCat: function (evt) {
                var oUpdatePlant = sap.ui.getCore().byId("idStandardHeaderPlant");
                if (oUpdatePlant != undefined) {
                    var sPlant = oUpdatePlant.getValue();
                    var sLossCatPath = evt.getSource().getBindingContext("lineStandardUpdateModel").sPath;
                    var sLossCat = this.getView().getModel("lineStandardUpdateModel").getProperty(sLossCatPath + "/lossCat");
                    this.getView().getModel("lineStandardUpdateModel").setProperty(sLossCatPath + "/subCat", "");
                    for (var i = 0; i < this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesEvtDataNav").length; i++) {
                        if (i != sLossCatPath.slice(27)) {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/lossCatEditable", false);
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/subCatEditable", false);
                        }
                    }

                    for (var i = 0; i < this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav").length; i++) {
                        if (i != sLossCatPath.slice(27)) {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/lossCatEditable", false);
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/subCatEditable", false);
                        }
                    }
                }
                var oModelLineSubCat = new sap.ui.model.json.JSONModel();
                oModelLineSubCat.loadData("odata/v4/data-services/LineRelatedLossCatDB?$filter=plant eq '" + sPlant + "' and lossCat eq '" + sLossCat + "'&$select=subCat");
                oModelLineSubCat.setSizeLimit(100);
                this.getView().setModel(oModelLineSubCat, "lineUpdateSubCatModel");
            },

            fnCopyEventSubCat: function (evt) {
                for (var i = 0; i < this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesEvtDataNav").length; i++) {
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/lossCatEditable", true);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/subCatEditable", true);
                }
                for (var i = 0; i < this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav").length; i++) {
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/lossCatEditable", true);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/subCatEditable", true);
                }
                if (this.getView().getModel("lineCopySubCatModel") != undefined) {
                    this.getView().getModel("lineCopySubCatModel").setData({ "value": [{ subCat: "" }] });
                }
            },
            fnUpdateEventSubCat: function (evt) {
                for (var i = 0; i < this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesEvtDataNav").length; i++) {
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/lossCatEditable", true);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/subCatEditable", true);
                }
                for (var i = 0; i < this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav").length; i++) {
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/lossCatEditable", true);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/subCatEditable", true);
                }
                if (this.getView().getModel("lineUpdateSubCatModel") != undefined) {
                    this.getView().getModel("lineUpdateSubCatModel").setData({ "value": [{ subCat: "" }] });
                }
            },
            fnLineAnnualSubCat: function (evt) {
                if (sap.ui.getCore().byId("idAnnualLossCat").getValue() != "") {
                    sap.ui.getCore().byId("idAnnualLossCatLabel").setRequired(true);
                    sap.ui.getCore().byId("idAnnualSubCatLabel").setRequired(true);
                    sap.ui.getCore().byId("idAnnualCycleYearLabel").setRequired(true);
                    sap.ui.getCore().byId("idAnnaulFreqLabel").setRequired(true);
                    sap.ui.getCore().byId("idAnnualEventDurLabel").setRequired(true);
                    sap.ui.getCore().byId("idAnnualCrewSizeLabel").setRequired(true);

                    sap.ui.getCore().byId("idAnnualSubCat").setEditable(true);
                    sap.ui.getCore().byId("idAnnualCycleYear").setEditable(true);
                    sap.ui.getCore().byId("idAnnaulFreq").setEditable(true);
                    sap.ui.getCore().byId("idAnnualEventDur").setEditable(true);
                    sap.ui.getCore().byId("idAnnualCrewSize").setEditable(true);


                    sap.ui.getCore().byId("idAnnualSubCat").setValue("");
                    sap.ui.getCore().byId("idAnnualCycleYear").setValue("");
                    sap.ui.getCore().byId("idAnnaulFreq").setValue("");
                    sap.ui.getCore().byId("idAnnualEventDur").setValue("");
                    sap.ui.getCore().byId("idAnnualCrewSize").setValue("");

                    sap.ui.getCore().byId("idAnnualLossCat").setValueState("None");
                    sap.ui.getCore().byId("idAnnualSubCat").setValueState("None");
                    sap.ui.getCore().byId("idAnnualCrewSize").setValueState("None");
                    sap.ui.getCore().byId("idAnnaulFreq").setValueState("None");
                    sap.ui.getCore().byId("idAnnualEventDur").setValueState("None");
                    sap.ui.getCore().byId("idAnnualCycleYear").setValueState("None");
                }
                else {
                    sap.ui.getCore().byId("idAnnualLossCatLabel").setRequired(false);
                    sap.ui.getCore().byId("idAnnualSubCatLabel").setRequired(false);
                    sap.ui.getCore().byId("idAnnualCycleYearLabel").setRequired(false);
                    sap.ui.getCore().byId("idAnnaulFreqLabel").setRequired(false);
                    sap.ui.getCore().byId("idAnnualEventDurLabel").setRequired(false);
                    sap.ui.getCore().byId("idAnnualCrewSizeLabel").setRequired(false);

                    sap.ui.getCore().byId("idAnnualSubCat").setEditable(false);
                    sap.ui.getCore().byId("idAnnualCycleYear").setEditable(false);
                    sap.ui.getCore().byId("idAnnaulFreq").setEditable(false);
                    sap.ui.getCore().byId("idAnnualEventDur").setEditable(false);
                    sap.ui.getCore().byId("idAnnualCrewSize").setEditable(false);

                    sap.ui.getCore().byId("idAnnualSubCat").setValue("");
                    sap.ui.getCore().byId("idAnnualCycleYear").setValue("");
                    sap.ui.getCore().byId("idAnnaulFreq").setValue("");
                    sap.ui.getCore().byId("idAnnualEventDur").setValue("");
                    sap.ui.getCore().byId("idAnnualCrewSize").setValue("");

                }
                var oModelLineAnnualSubCat = new sap.ui.model.json.JSONModel();
                var sPlant = sap.ui.getCore().byId("idHeaderCreatePlant").getSelectedKey();
                var sLossCat = sap.ui.getCore().byId("idAnnualLossCat").getValue();
                oModelLineAnnualSubCat.loadData("odata/v4/data-services/LineRelatedLossCatDB?$filter=plant eq '" + sPlant + "' and lossCat eq '" + sLossCat + "'&$select=subCat");
                oModelLineAnnualSubCat.setSizeLimit(100);
                this.getView().setModel(oModelLineAnnualSubCat, "lineAnnualSubCatModel");

            },

            //create copy  step4  Loss cat on selected function
            fnLineAnnualSubCatCopy: function (evt) {

                if (sap.ui.getCore().byId("idAnnualLossCatCopy").getValue() != "") {

                    sap.ui.getCore().byId("idAnnualLossCatLabelCopy").setRequired(true);
                    sap.ui.getCore().byId("idAnnualSubCatLabelCopy").setRequired(true);
                    sap.ui.getCore().byId("idAnnualCycleYearLabelCopy").setRequired(true);
                    sap.ui.getCore().byId("idAnnaulFreqLabelCopy").setRequired(true);
                    sap.ui.getCore().byId("idAnnualEventDurLabelCopy").setRequired(true);
                    sap.ui.getCore().byId("idAnnualCrewSizeLabelCopy").setRequired(true);

                    sap.ui.getCore().byId("idAnnualSubCatCopy").setEditable(true);
                    sap.ui.getCore().byId("idAnnualCycleYearCopy").setEditable(true);
                    sap.ui.getCore().byId("idAnnaulFreqCopy").setEditable(true);
                    sap.ui.getCore().byId("idAnnualEventDurCopy").setEditable(true);
                    sap.ui.getCore().byId("idAnnualCrewSizeCopy").setEditable(true);

                    sap.ui.getCore().byId("idAnnualSubCatCopy").setValue("");
                    sap.ui.getCore().byId("idAnnualCrewSizeCopy").setValue("");
                    sap.ui.getCore().byId("idAnnaulFreqCopy").setValue("");
                    sap.ui.getCore().byId("idAnnualEventDurCopy").setValue("");
                    sap.ui.getCore().byId("idAnnualCycleYearCopy").setValue("");

                    sap.ui.getCore().byId("idAnnualLossCatCopy").setValueState("None");
                    sap.ui.getCore().byId("idAnnualSubCatCopy").setValueState("None");
                    sap.ui.getCore().byId("idAnnualCrewSizeCopy").setValueState("None");
                    sap.ui.getCore().byId("idAnnaulFreqCopy").setValueState("None");
                    sap.ui.getCore().byId("idAnnualEventDurCopy").setValueState("None");
                    sap.ui.getCore().byId("idAnnualCycleYearCopy").setValueState("None");
                }
                else {
                    sap.ui.getCore().byId("idAnnualLossCatLabelCopy").setRequired(false);
                    sap.ui.getCore().byId("idAnnualSubCatLabelCopy").setRequired(false);
                    sap.ui.getCore().byId("idAnnualCycleYearLabelCopy").setRequired(false);
                    sap.ui.getCore().byId("idAnnaulFreqLabelCopy").setRequired(false);
                    sap.ui.getCore().byId("idAnnualEventDurLabelCopy").setRequired(false);
                    sap.ui.getCore().byId("idAnnualCrewSizeLabelCopy").setRequired(false);

                    sap.ui.getCore().byId("idAnnualSubCatCopy").setEditable(false);
                    sap.ui.getCore().byId("idAnnualCycleYearCopy").setEditable(false);
                    sap.ui.getCore().byId("idAnnaulFreqCopy").setEditable(false);
                    sap.ui.getCore().byId("idAnnualEventDurCopy").setEditable(false);
                    sap.ui.getCore().byId("idAnnualCrewSizeCopy").setEditable(false);

                    sap.ui.getCore().byId("idAnnualSubCatCopy").setValue("");
                    sap.ui.getCore().byId("idAnnualCrewSizeCopy").setValue("");
                    sap.ui.getCore().byId("idAnnaulFreqCopy").setValue("");
                    sap.ui.getCore().byId("idAnnualEventDurCopy").setValue("");
                    sap.ui.getCore().byId("idAnnualCycleYearCopy").setValue("");

                }

                var oModelLineAnnualSubCat = new sap.ui.model.json.JSONModel();
                var sPlant = sap.ui.getCore().byId("idCopyHeaderCreatePlant").getSelectedKey();
                var sLossCat = sap.ui.getCore().byId("idAnnualLossCatCopy").getValue();
                oModelLineAnnualSubCat.loadData("odata/v4/data-services/LineRelatedLossCatDB?$filter=plant eq '" + sPlant + "' and lossCat eq '" + sLossCat + "'&$select=subCat");
                oModelLineAnnualSubCat.setSizeLimit(100);
                this.getView().setModel(oModelLineAnnualSubCat, "lineCopyAnnualSubCatModel");

            },
            fnLineAnnualSubCatupdate: function (_evt) {

                if (sap.ui.getCore().byId("idAnnualLossCatupdate").getValue() != "") {

                    sap.ui.getCore().byId("idAnnualLossCatLabelupdate").setRequired(true);
                    sap.ui.getCore().byId("idAnnualSubCatLabelupdate").setRequired(true);
                    sap.ui.getCore().byId("idAnnualCycleYearLabelupdate").setRequired(true);
                    sap.ui.getCore().byId("idAnnaulFreqLabelupdate").setRequired(true);
                    sap.ui.getCore().byId("idAnnualEventDurLabelupdate").setRequired(true);
                    sap.ui.getCore().byId("idAnnualCrewSizeLabelupdate").setRequired(true);

                    sap.ui.getCore().byId("idAnnualSubCatupdate").setEditable(true);
                    sap.ui.getCore().byId("idAnnualCycleYearupdate").setEditable(true);
                    sap.ui.getCore().byId("idAnnaulFrequpdate").setEditable(true);
                    sap.ui.getCore().byId("idAnnualEventDurupdate").setEditable(true);
                    sap.ui.getCore().byId("idAnnualCrewSizeupdate").setEditable(true);

                    sap.ui.getCore().byId("idAnnualSubCatupdate").setValue("");
                    sap.ui.getCore().byId("idAnnualCrewSizeupdate").setValue("");
                    sap.ui.getCore().byId("idAnnaulFrequpdate").setValue("");
                    sap.ui.getCore().byId("idAnnualEventDurupdate").setValue("");
                    sap.ui.getCore().byId("idAnnualCycleYearupdate").setValue("");

                    sap.ui.getCore().byId("idAnnualLossCatupdate").setValueState("None");
                    sap.ui.getCore().byId("idAnnualSubCatupdate").setValueState("None");
                    sap.ui.getCore().byId("idAnnualCrewSizeupdate").setValueState("None");
                    sap.ui.getCore().byId("idAnnaulFrequpdate").setValueState("None");
                    sap.ui.getCore().byId("idAnnualEventDurupdate").setValueState("None");
                    sap.ui.getCore().byId("idAnnualCycleYearupdate").setValueState("None");
                }
                else {
                    sap.ui.getCore().byId("idAnnualLossCatLabelupdate").setRequired(false);
                    sap.ui.getCore().byId("idAnnualSubCatLabelupdate").setRequired(false);
                    sap.ui.getCore().byId("idAnnualCycleYearLabelupdate").setRequired(false);
                    sap.ui.getCore().byId("idAnnaulFreqLabelupdate").setRequired(false);
                    sap.ui.getCore().byId("idAnnualEventDurLabelupdate").setRequired(false);
                    sap.ui.getCore().byId("idAnnualCrewSizeLabelupdate").setRequired(false);

                    sap.ui.getCore().byId("idAnnualSubCatupdate").setEditable(false);
                    sap.ui.getCore().byId("idAnnualCycleYearupdate").setEditable(false);
                    sap.ui.getCore().byId("idAnnaulFrequpdate").setEditable(false);
                    sap.ui.getCore().byId("idAnnualEventDurupdate").setEditable(false);
                    sap.ui.getCore().byId("idAnnualCrewSizeupdate").setEditable(false);

                    sap.ui.getCore().byId("idAnnualSubCatupdate").setValue("");
                    sap.ui.getCore().byId("idAnnualCrewSizeupdate").setValue("");
                    sap.ui.getCore().byId("idAnnaulFrequpdate").setValue("");
                    sap.ui.getCore().byId("idAnnualEventDurupdate").setValue("");
                    sap.ui.getCore().byId("idAnnualCycleYearupdate").setValue("");

                }

                var oModelLineAnnualSubCat = new sap.ui.model.json.JSONModel();
                var sPlant = sap.ui.getCore().byId("idStandardHeaderPlant").getValue();
                var sLossCat = sap.ui.getCore().byId("idAnnualLossCatupdate").getValue();
                oModelLineAnnualSubCat.loadData("odata/v4/data-services/LineRelatedLossCatDB?$filter=plant eq '" + sPlant + "' and lossCat eq '" + sLossCat + "'&$select=subCat");
                oModelLineAnnualSubCat.setSizeLimit(100);
                this.getView().setModel(oModelLineAnnualSubCat, "lineupdateAnnualSubCatModel");
            },
            _fnDateFormat: function (val) {

                if (val != null) {
                    var iDay = ('0' + val.getDate()).slice(-2);
                    var iMonth = ('0' + (val.getMonth() + 1)).slice(-2);
                    var iYear = (val + "").substring(11, 15);
                }
                return iYear + "-" + iMonth + "-" + iDay;
            },
            _fnDateFormatDDMMYYYY: function (val) {
                if (val != null) {
                    var iDay = ('0' + val.getDate()).slice(-2);
                    var iMonth = ('0' + (val.getMonth() + 1)).slice(-2);
                    var iYear = (val + "").substring(11, 15);
                }
                return iDay + "-" + iMonth + "-" + iYear;
            },

            //  Function to create new line standard
            fnCreateLineStandard: function (oEvent) {
                
                // Set flag for Cancel confirmation
                this._isConfirming = true;
                var that = this;
                var sPlant = sap.ui.getCore().byId("idHeaderCreatePlant").getSelectedKey();
                var sResource = sap.ui.getCore().byId("idHeaderCreateResource").getValue();
                var sCostCenter = sap.ui.getCore().byId("idHeaderCreateCostCenter").getValue();
                var dValidFrom = sap.ui.getCore().byId("idHeaderCreateValidFrom").getDateValue();
                var dModifiedFrom = sap.ui.getCore().byId("idHeaderCreateModifiedFrom").getDateValue();
                var dValidTo = sap.ui.getCore().byId("idHeaderCreateValidTo").getDateValue();

                if (sPlant == "") {
                    sap.ui.getCore().byId("idHeaderCreatePlant").setValueState("Error");
                    sap.ui.getCore().byId("idHeaderCreatePlant").setValueStateText(this.oResourceBundle.getText("ERROR_PLANT_CREATE"));
                } else {
                    sap.ui.getCore().byId("idHeaderCreatePlant").setValueState("None");
                }
                if (sResource == "") {
                    sap.ui.getCore().byId("idHeaderCreateResource").setValueState("Error");
                    sap.ui.getCore().byId("idHeaderCreateResource").setValueStateText(this.oResourceBundle.getText("ERROR_RESOURCE_CREATE"));
                } else {
                    sap.ui.getCore().byId("idHeaderCreateResource").setValueState("None");
                }
                if (sCostCenter == "") {
                    sap.ui.getCore().byId("idHeaderCreateCostCenter").setValueState("Error");
                    sap.ui.getCore().byId("idHeaderCreateCostCenter").setValueStateText(this.oResourceBundle.getText("ERROR_COSTCENTER_CREATE"));
                } else {

                    sap.ui.getCore().byId("idHeaderCreateCostCenter").setValueState("None");
                }
                if (dValidFrom == "") {
                    sap.ui.getCore().byId("idHeaderCreateValidFrom").setValueState("Error");
                    sap.ui.getCore().byId("idHeaderCreateValidFrom").setValueStateText(this.oResourceBundle.getText("ERROR_VALIDFROM_CREATE"));
                } else {
                    sap.ui.getCore().byId("idHeaderCreateValidFrom").setValueState("None");
                }
                if (dValidTo == "") {
                    sap.ui.getCore().byId("idHeaderCreateValidTo").setValueState("Error");
                    sap.ui.getCore().byId("idHeaderCreateValidTo").setValueStateText(this.oResourceBundle.getText("ERROR_VALIDTO_CREATE"));
                } else {
                    sap.ui.getCore().byId("idHeaderCreateValidTo").setValueState("None");
                }

                if (sPlant != "" && sResource != "" && sCostCenter != "" && dValidFrom != "" && dValidTo != "") {
                    sap.ui.getCore().byId("idHeaderCreatePlant").setValueState("None");
                    sap.ui.getCore().byId("idHeaderCreateResource").setValueState("None");
                    sap.ui.getCore().byId("idHeaderCreateCostCenter").setValueState("None");
                    sap.ui.getCore().byId("idHeaderCreateValidFrom").setValueState("None");
                    sap.ui.getCore().byId("idHeaderCreateValidTo").setValueState("None");
                    var postData = this.getView().getModel("createLineStandardModel").getData();
                    var sLineStdNoValidFrom = this._fnDateFormatDDMMYYYY(dValidFrom);
                    postData.validFrom = this._fnDateFormat(dValidFrom);
                    postData.modifiedFrom = this._fnDateFormat(dModifiedFrom);
                    postData.lineStdNo = "LR_" + sPlant + "_" + sResource + "_" + sLineStdNoValidFrom;
                    postData.configNo = sPlant + "_LR_" + sResource + "_" + sCostCenter;
                    postData.plant = sPlant;
                    postData.resource = sResource;
                    postData.costCenter = sCostCenter;
                    postData.status = "Created";
                    postData.validTo = this._fnDateFormat(dValidTo);

                    if (this.getView().getModel("createLineStandardModel").getProperty("/LineHdrToAnnualEvtDataNav") == undefined) {
                        postData.LineHdrToAnnualEvtDataNav = [];
                    }


                    var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                    var zone = newData[0].Zone;

                    postData.stdApprLvl = 0;
                    postData.executionState = 0;
                    postData.executorsIDs = [];
                    postData.auditInfoChannel = zone;
                    //var sUrl="odata/v4/data-services/LineRelStandardHeadersDB";
                    var sUrl = "odata/v4/data-services/createLineStdItems";
                    //POST
                    BusyIndicator.show();
                    $.ajax({
                        url: sUrl,
                        type: "POST",
                        data: JSON.stringify(postData),
                        contentType: "application/json",
                        dataType: "json",
                    }).done(function (response) {
                        BusyIndicator.hide();
                        MessageToast.show(that.oResourceBundle.getText("LINE_STD_CREATED_SUCCESS"));
                        var message = that.oResourceBundle.getText("NEW_LINE_STD_SUCCESS") + "\n Plant :" + response.value[0].plant + ", Resource :" + response.value[0].resource + ", CostCenter :" + response.value[0].costCenter;
                        that.onShowSuccess(message);
                        that.fnReadLineStdHeaderTableData();;

                        ///////////////////////////////////    After successful POSt, read call to fetch data///////////////////////////
                        that.getView().getModel("createLineStandardModel").setData({});
                        that.getOwnerComponent().getModel("createLineStandardModel").setData({});
                        sap.ui.getCore().byId("wizardLineNavContainer").to(sap.ui.getCore().byId("wizardLineContentPage"));
                        sap.ui.getCore().byId("CreateLineWizard").goToStep(sap.ui.getCore().byId("LineTypeStep"));
                        sap.ui.getCore().byId("LineTypeStep").setValidated(true);

                    }).fail(function (xhr, status, error) {
                        BusyIndicator.hide();
                        MessageToast.show(xhr.responseJSON.error.message + "" + that.oResourceBundle.getText("LINE_STD_CREATED_FAIL"));
                        var message = that.oResourceBundle.getText("NEW_LINE_STD_ERROR") + "\n" + xhr.responseJSON.error.code + ":" + xhr.responseJSON.error.message;
                        that.onShowError(message);
                    });
                    ///////////////////////////////////////////////////////////////////////

                    if (this._LineCreate) {
                        this._LineCreate.close();

                        sap.ui.getCore().byId("idHeaderCreateResource").setEditable(false);
                        sap.ui.getCore().byId("idSubCat").setEditable(false);
                        sap.ui.getCore().byId("idAnnualSubCat").setEditable(false);

                        sap.ui.getCore().byId("idHeaderCreatePlant").setValueState("None");
                        sap.ui.getCore().byId("idHeaderCreateResource").setValueState("None");
                        sap.ui.getCore().byId("idHeaderCreateCostCenter").setValueState("None");
                        sap.ui.getCore().byId("idHeaderCreateValidFrom").setValueState("None");
                        sap.ui.getCore().byId("idHeaderCreateValidTo").setValueState("None");

                        sap.ui.getCore().byId("idHeaderCreatePlant").setValue("");
                        sap.ui.getCore().byId("idHeaderCreateResource").setValue("");
                        sap.ui.getCore().byId("idHeaderCreateCostCenter").setValue("");
                        sap.ui.getCore().byId("idCondition").setValue("");
                        sap.ui.getCore().byId("idConditionDesc").setValue("");
                        sap.ui.getCore().byId("idShiftLength").setValue("");
                        sap.ui.getCore().byId("idProductionCycle").setValue("");
                        sap.ui.getCore().byId("idShiftDays").setValue("");
                        sap.ui.getCore().byId("idcycleYear").setValue("");
                        sap.ui.getCore().byId("idLossCat").setValue("");
                        sap.ui.getCore().byId("idSubCat").setValue("");
                        sap.ui.getCore().byId("idExpectedCrewSize").setValue("");
                        sap.ui.getCore().byId("idExpectedFreq").setValue("");
                        sap.ui.getCore().byId("idExpectEventDuration").setValue("");
                        sap.ui.getCore().byId("idAnnualLossCat").setValue("");
                        sap.ui.getCore().byId("idAnnualSubCat").setValue("");
                        sap.ui.getCore().byId("idAnnualCycleYear").setValue("");
                        sap.ui.getCore().byId("idAnnaulFreq").setValue("");
                        sap.ui.getCore().byId("idAnnualEventDur").setValue("");
                        sap.ui.getCore().byId("idAnnualCrewSize").setValue("");

                        sap.ui.getCore().byId("idAnnualLossCatLabel").setRequired(false);
                        sap.ui.getCore().byId("idAnnualSubCatLabel").setRequired(false);
                        sap.ui.getCore().byId("idAnnualCycleYearLabel").setRequired(false);
                        sap.ui.getCore().byId("idAnnaulFreqLabel").setRequired(false);
                        sap.ui.getCore().byId("idAnnualEventDurLabel").setRequired(false);
                        sap.ui.getCore().byId("idAnnualCrewSizeLabel").setRequired(false);

                        sap.ui.getCore().byId("idAnnualSubCat").setEditable(false);
                        sap.ui.getCore().byId("idAnnualCycleYear").setEditable(false);
                        sap.ui.getCore().byId("idAnnaulFreq").setEditable(false);
                        sap.ui.getCore().byId("idAnnualEventDur").setEditable(false);
                        sap.ui.getCore().byId("idAnnualCrewSize").setEditable(false);
                    }

                } else {
                    MessageToast.show(oResourceBundle.getText("ERROR_MAND_FIELDS"));
                }
            },
            //  Function to copy create new line standard
            fnCopyCreateLineStandard: function (_oEvent) {                
                // Set flag for Cancel confirmation
                this._isConfirming = true;
                var that = this;
                // Model data got from read particular row linestdno in the header table
                var oPostData = this.getView().getModel("lineStandardUpdateModel").getData();
                var oLinestdHeaderdata = this.getView().getModel("lineStandardHeaderModel").getProperty("/value/");
                var sDateText = sap.ui.getCore().byId("idCopyValidFromCreateReview").getText();
                var parts = sDateText.split("-");
                var dvalidfrom = `${parts[2]}-${parts[1]}-${parts[0]}`;
                for (var y = 0; y < oLinestdHeaderdata.length; y++) {
                    if(oPostData.plant === oLinestdHeaderdata[y].plant && dvalidfrom === oLinestdHeaderdata[y].validFrom){
                        sap.m.MessageBox.warning("Please chnage the Valid from date or Plant as this record is alredy exist");
                        return;
                    }
                
                }
                var sLineStdNoValidFrom = this._fnDateFormatDDMMYYYY(sap.ui.getCore().byId("idCopyHeaderCreateValidFrom").getDateValue());
                oPostData.lineStdNo = "LR_" + oPostData.plant + "_" + oPostData.resource + "_" + sLineStdNoValidFrom;
                oPostData.configNo = oPostData.plant + "_LR_" + oPostData.resource + "_" + oPostData.costCenter;
                oPostData.status = "Created";


                var LineHdrToCyclesDataNav = [];
                for (var i = 0; i < oPostData.LineHdrToCyclesDataNav.length; i++) {
                    var oTemp = {};
                    oTemp.condition = oPostData.LineHdrToCyclesDataNav[i].condition;
                    oTemp.conditionDesc = oPostData.LineHdrToCyclesDataNav[i].conditionDesc;
                    oTemp.shiftLength = oPostData.LineHdrToCyclesDataNav[i].shiftLength;
                    oTemp.prodCyclesInDays = oPostData.LineHdrToCyclesDataNav[i].prodCyclesInDays;
                    oTemp.shiftsInDays = oPostData.LineHdrToCyclesDataNav[i].shiftsInDays;
                    oTemp.cyclesInYear = oPostData.LineHdrToCyclesDataNav[i].cyclesInYear;
                    oTemp.shiftsInCycle = oPostData.LineHdrToCyclesDataNav[i].shiftsInCycle;
                    oTemp.cycleHrs = oPostData.LineHdrToCyclesDataNav[i].cycleHrs;
                    oTemp.totalOccupiedTime = oPostData.LineHdrToCyclesDataNav[i].totalOccupiedTime;
                    oTemp.lineStdNo = oPostData.lineStdNo;
                    oTemp.status = "Created";

                    LineHdrToCyclesDataNav.push(oTemp);

                }

                var oPayload = {};

                oPayload.plant = oPostData.plant
                oPayload.resource = oPostData.resource
                oPayload.costCenter = oPostData.costCenter
                oPayload.lineStdNo = oPostData.lineStdNo;
                oPayload.configNo = oPostData.configNo;
                oPayload.status = "Created";

                var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                var zone = newData[0].Zone;

                oPayload.stdApprLvl = 0;
                oPayload.executionState = 0;
                oPayload.executorsIDs = [];
                oPayload.auditInfoChannel = zone;


                oPayload.validTo = oPostData.validTo;
                oPayload.validFrom = oPostData.validFrom;
                oPayload.modifiedFrom = oPostData.modifiedFrom;

                oPayload.prodCyclesInDays = oPostData.prodCyclesInDays;
                oPayload.totalOccupiedTime = oPostData.totalOccupiedTime;
                oPayload.plannedDtLoss = oPostData.plannedDtLoss;
                oPayload.cycleHrs = oPostData.cycleHrs;
                oPayload.cyclesInYear = oPostData.cyclesInYear;
                oPayload.shiftsInCycle = oPostData.shiftsInCycle;
                oPayload.shiftsInDay = oPostData.shiftsInDay;

                oPayload.LineHdrToCyclesDataNav = LineHdrToCyclesDataNav;
                oPayload.LineHdrToCyclesEvtDataNav = oPostData.LineHdrToCyclesEvtDataNav;
                oPayload.LineHdrToAnnualEvtDataNav = oPostData.LineHdrToAnnualEvtDataNav;

                //var sUrl="odata/v4/data-services/LineRelStandardHeadersDB";
                var sUrl = "odata/v4/data-services/createLineStdItems";

                //POST
                BusyIndicator.show();
                $.ajax({
                    url: sUrl,
                    type: "POST",
                    data: JSON.stringify(oPayload),
                    contentType: "application/json",
                    dataType: "json",
                }).done(function (response) {
                    BusyIndicator.hide();
                    MessageToast.show(that.oResourceBundle.getText("LINE_STD_CREATED_SUCCESS"));
                    var message = that.oResourceBundle.getText("NEW_LINE_STD_SUCCESS") + "\n Plant :" + response.value[0].plant + ", Resource :" + response.value[0].resource + ", CostCenter :" + response.value[0].costCenter;
                    that.onShowSuccess(message);

                    //initial setting for Line table button
                    that.getView().byId("idLineTable").removeSelections(true);
                    that.getView().byId("idLineCopyCreate").setEnabled(false);
                    that.getView().byId("idArchive").setEnabled(false);
                    that.getView().byId("idCreate").setEnabled(true);
                    that.getView().byId("idSubmitForApproval").setEnabled(false);
                    ///////////////////////////////////    After successful POSt, read call to fetch data///////////////////////////
                    that.fnReadLineStdHeaderTableData();;
                }).fail(function (xhr, status, error) {
                    BusyIndicator.hide();
                    MessageToast.show(xhr.responseJSON.error.message + " " + that.oResourceBundle.getText("LINE_STD_CREATED_FAIL"));
                    var message = that.oResourceBundle.getText("NEW_LINE_STD_ERROR") + "\n" + xhr.responseJSON.error.code + ":" + xhr.responseJSON.error.message;
                    that.onShowError(message);

                    //initial setting for Line table button
                    that.getView().byId("idLineTable").removeSelections(true);
                    that.getView().byId("idLineCopyCreate").setEnabled(false);
                    that.getView().byId("idArchive").setEnabled(false);
                    that.getView().byId("idCreate").setEnabled(true);
                    that.getView().byId("idSubmitForApproval").setEnabled(false);
                });
                ///////////////////////////////////////////////////////////////////////
                if (this._LineCreate) {
                    this._LineCreate.close();
                }
                for (var i = 0; i < this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesEvtDataNav").length; i++) {
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/lossCatEditable", true);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/subCatEditable", true);
                }

                for (var i = 0; i < this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav").length; i++) {
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/lossCatEditable", true);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/subCatEditable", true);
                }

                this.onCopyCreate(); // function call to close the copycreate dialog

            },
            fnLineStandardUpdate: function (oEvent) {                
                // Set flag for Cancel confirmation
                this._isConfirming = true;

                if (this.getView().getModel("lineStandardUpdateModel").getProperty("/deleteLineStdCyclesDb") == undefined) {
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/deleteLineStdCyclesDb", [])
                }
                if (this.getView().getModel("lineStandardUpdateModel").getProperty("/deleteLineStdCycleEvtDb") == undefined) {
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/deleteLineStdCycleEvtDb", [])
                }
                if (this.getView().getModel("lineStandardUpdateModel").getProperty("/deleteLineStdAnnualEvtDb") == undefined) {
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/deleteLineStdAnnualEvtDb", [])
                }

                var that = this;
                if (this.getView().byId("idLineTable").getSelectedItems()[0] != undefined) {
                    var sPath = this.getView().byId("idLineTable").getSelectedItems()[0].getBindingContext("lineStandardHeaderModel").sPath;
                }
                else {
                    var sPath = "/value/" + iSelectedRowIndex;
                }
                // var sPath = this.getView().byId("idLineTable").getSelectedItems()[0].getBindingContext("lineStandardHeaderModel").sPath;
                var oData = this.getView().getModel("lineStandardHeaderModel").getProperty(sPath);
                var oPostData = this.getView().getModel("lineStandardUpdateModel").getData();

                var obj = {};
                obj.ID = oData.ID
                obj.lineStdNo = oData.lineStdNo
                obj.validTo = this._fnDateFormat(sap.ui.getCore().byId("idStandardHeaderValidTo").getDateValue());
                obj.modifiedFrom = this._fnDateFormat(sap.ui.getCore().byId("idStandardHeaderupdateModifiedFrom").getDateValue());
                obj.prodCyclesInDays = oPostData.prodCyclesInDays
                obj.shiftsInDay = oPostData.shiftsInDay
                obj.shiftsInCycle = oPostData.shiftsInCycle
                obj.cycleHrs = oPostData.cycleHrs
                obj.cyclesInYear = oPostData.cyclesInYear
                obj.totalOccupiedTime = oPostData.totalOccupiedTime
                obj.plannedDtLoss = oPostData.plannedDtLoss
                obj.status = "Modified"
                obj.reworkComment = null
                obj.stdApprLvl = 0;
                obj.executionState = 0;
                obj.executorsIDs = [];

                var updateLineStdHdrDb = [];
                updateLineStdHdrDb.push(obj);
                oPostData.updateLineStdHdrDb = updateLineStdHdrDb;

                var oUpdateData = {};
                oUpdateData.updateLineStdHdrDb = oPostData.updateLineStdHdrDb;
                oUpdateData.updateLineStdCyclesDb = [];
                oUpdateData.updateLineStdCycleEvtDb = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesEvtDataNav");
                for (var x = 0; x < oUpdateData.updateLineStdCycleEvtDb.length; x++) {
                    var oTempoLineStdCycleEvtDb = oUpdateData.updateLineStdCycleEvtDb[x];
                    oTempoLineStdCycleEvtDb.lineStdNo = oData.lineStdNo;
                    oUpdateData.updateLineStdCycleEvtDb[x]=oTempoLineStdCycleEvtDb;
                }
                oUpdateData.updateLineStdAnnualEvtDb = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav");
                for (var y = 0; y < oUpdateData.updateLineStdAnnualEvtDb.length; y++) {
                    var oTempLineStdAnnualEvtDb = oUpdateData.updateLineStdAnnualEvtDb[y];
                    oTempLineStdAnnualEvtDb.lineStdNo = oData.lineStdNo;
                    oUpdateData.updateLineStdAnnualEvtDb[y]=oTempLineStdAnnualEvtDb;
                }
                oUpdateData.deleteLineStdCyclesDb = oPostData.deleteLineStdCyclesDb || [];
                oUpdateData.deleteLineStdCycleEvtDb = oPostData.deleteLineStdCycleEvtDb || [];
                oUpdateData.deleteLineStdAnnualEvtDb = oPostData.deleteLineStdAnnualEvtDb || [];

                for (var i = 0; i < oPostData.LineHdrToCyclesDataNav.length; i++) {

                    var oTemp = {};
                    oTemp.ID = oPostData.LineHdrToCyclesDataNav[i].ID;
                    oTemp.condition = oPostData.LineHdrToCyclesDataNav[i].condition;
                    oTemp.conditionDesc = oPostData.LineHdrToCyclesDataNav[i].conditionDesc;
                    oTemp.shiftLength = oPostData.LineHdrToCyclesDataNav[i].shiftLength;
                    oTemp.prodCyclesInDays = oPostData.LineHdrToCyclesDataNav[i].prodCyclesInDays;
                    oTemp.shiftsInCycle = oPostData.LineHdrToCyclesDataNav[i].shiftsInCycle;
                    oTemp.shiftsInDays = oPostData.LineHdrToCyclesDataNav[i].shiftsInDays;
                    oTemp.cyclesInYear = Number(oPostData.LineHdrToCyclesDataNav[i].cyclesInYear);
                    oTemp.cycleHrs = oPostData.LineHdrToCyclesDataNav[i].cycleHrs;
                    oTemp.totalOccupiedTime = oPostData.LineHdrToCyclesDataNav[i].totalOccupiedTime;
                    oTemp.lineStdNo = oData.lineStdNo;
                    //3-09-2024 rightnow required in poc
                    oTemp.status = "Modified"

                    oUpdateData.updateLineStdCyclesDb.push(oTemp);

                }


                //POST
                BusyIndicator.show();
                $.ajax({
                    url: "odata/v4/data-services/updateLineStdItems",
                    type: "POST",
                    data: JSON.stringify(oUpdateData),
                    contentType: "application/json",
                    dataType: "json",
                }).done(function (response) {
                    BusyIndicator.hide();
                    that.fnReadLineStdHeaderTableData();;
                    MessageToast.show(that.oResourceBundle.getText("LINE_STD_UPDATE_SUCCESS"));
                    var message = that.oResourceBundle.getText("SLCT_LINE_UPDATE_SUCESS") + "\n";
                    that.onShowSuccess(message);

                    //initial setting for Line table button
                    that.getView().byId("idLineTable").removeSelections(true);
                    that.getView().byId("idLineCopyCreate").setEnabled(false);
                    that.getView().byId("idArchive").setEnabled(false);
                    that.getView().byId("idCreate").setEnabled(true);
                    that.getView().byId("idSubmitForApproval").setEnabled(false);
                    ///////////////////////////////////    After successful POSt, read call to fetch data///////////////////////////
                    //  that.fnReadLineStdHeaderTableData();;
                }).fail(function (xhr, status, error) {
                    BusyIndicator.hide();
                    var message = that.oResourceBundle.getText("lineStandardUpdateError") + "\n" + xhr.responseJSON.error.code + ":" + xhr.responseJSON.error.message;
                    that.onShowError(message);
                    MessageToast.show(that.oResourceBundle.getText("lineStandardUpdateError"));
                    //initial setting for Line table button
                    that.getView().byId("idLineTable").removeSelections(true);
                    that.getView().byId("idLineCopyCreate").setEnabled(false);
                    that.getView().byId("idArchive").setEnabled(false);
                    that.getView().byId("idCreate").setEnabled(true);
                    that.getView().byId("idSubmitForApproval").setEnabled(false);
                });
                ///////////////////////////////////////////////////////////////////////

                this._LineEdit.close();
                for (var i = 0; i < this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesEvtDataNav").length; i++) {
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/lossCatEditable", true);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/subCatEditable", true);
                }
                for (var i = 0; i < this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav").length; i++) {
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/lossCatEditable", true);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/subCatEditable", true);
                }
            },

            onEdit: function (oEvent) {
                this._isConfirming = false;
                if (!this._LineEdit) {
                    this._LineEdit = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.StandardUpdate", this);
                    this.getView().addDependent(this._LineEdit);
                }

                ////////// navigate to content screen in the update dialog/////
                sap.ui.getCore().byId("wizardNavContainerUpdate").to(sap.ui.getCore().byId("wizardContentPageUpdate"));
                var oWizard = sap.ui.getCore().byId("CreateProductWizardUpdate");
                var oFirstStep = oWizard.getSteps()[0];
                oWizard.discardProgress(oFirstStep);
                // scroll to top
                // oWizard.goToStep(oFirstStep);
                // invalidate first step
                oFirstStep.setValidated(true);
                ////////////////////////////////////////////////////////
                tableIndex = this.getView().byId("idLineTable")._aSelectedPaths[0];
                var sTableRowIndex = iSelectedRowIndex;
                this._LineEdit.open(oEvent.getSource());
                this._fnReadLineStdSelectedRowData();
                this.fnUpdateLossCat();

                var oModelLineLossCat = new sap.ui.model.json.JSONModel();
                var oCopyCreatePlant = this.getView().getModel("lineStandardHeaderModel").getProperty("/value/" + sTableRowIndex + "/plant");
                oModelLineLossCat.loadData("odata/v4/data-services/LineRelatedLossCatDB?$apply=groupby((lossCat,plant))&$filter=plant eq '" + oCopyCreatePlant + "'&$select=lossCat,subCat");
                oModelLineLossCat.setSizeLimit(100);
                this.getView().setModel(oModelLineLossCat, "lineUpdateLossCatModel");
            },
            onSubmit: function () {
                sap.ui.getCore().byId("idPopoverArchiving").setVisible(true);
                sap.ui.getCore().byId("idPopoverCancel").setVisible(false);
                sap.ui.getCore().byId("idPopoverAdd").setVisible(false);
            },

            backToWizardContent: function () {
                if (sap.ui.getCore().byId("wizardLineNavContainer") != undefined) {
                    sap.ui.getCore().byId("wizardLineNavContainer").backToPage(sap.ui.getCore().byId("wizardLineContentPage"));
                }
                if (sap.ui.getCore().byId("wizardNavContainerUpdate") != undefined) {
                    sap.ui.getCore().byId("wizardNavContainerUpdate").backToPage(sap.ui.getCore().byId("wizardContentPageUpdate"));
                }
                if (sap.ui.getCore().byId("wizardCopyLineNavContainer") != undefined) {
                    sap.ui.getCore().byId("wizardCopyLineNavContainer").backToPage(sap.ui.getCore().byId("idCopywizardLineContentPage"));
                }
                if (sap.ui.getCore().byId("wizardNavContainerLineApprover") != undefined) {
                    this._ApproverReviewLine.close();
                }
                if (sap.ui.getCore().byId("wizardNavContainerLineExecutor") != undefined) {
                    this._ExecutorReviewLine.close();
                }

            },
            // Wizard navigation from review page to step 1, 
            editStepOneLineCreate: function (evt) {
                sap.ui.getCore().byId("wizardLineNavContainer").to(sap.ui.getCore().byId("wizardLineContentPage"));
                sap.ui.getCore().byId("CreateLineWizard").goToStep(sap.ui.getCore().byId("LineTypeStep"));
            },
            editStepTwoLineCreate: function (evt) {
                sap.ui.getCore().byId("wizardLineNavContainer").backToPage(sap.ui.getCore().byId("wizardLineContentPage"));
                sap.ui.getCore().byId("CreateLineWizard").goToStep(sap.ui.getCore().byId("LineInfoStep"));
            },
            editStepThreeLineCreate: function (evt) {
                sap.ui.getCore().byId("wizardLineNavContainer").backToPage(sap.ui.getCore().byId("wizardLineContentPage"));
                sap.ui.getCore().byId("CreateLineWizard").goToStep(sap.ui.getCore().byId("OptionalInfoStep"));
            },
            editStepFourLineCreate: function (evt) {
                sap.ui.getCore().byId("wizardLineNavContainer").backToPage(sap.ui.getCore().byId("wizardLineContentPage"));
                sap.ui.getCore().byId("CreateLineWizard").goToStep(sap.ui.getCore().byId("LineAnnualEventsStep"));
            },
            //////////////////////////////////////////Line Copy Create//////////////////////////////////////////////
            _fnCopyCreateStepOneData: function () {
                sap.ui.getCore().byId("idCopyHeaderCreatePlant").setValue(this.getView().getModel("lineStandardUpdateModel").getProperty("/plant"));
                sap.ui.getCore().byId("idCopyHeaderCreatePlant").setSelectedKey(this.getView().getModel("lineStandardUpdateModel").getProperty("/plant"));
                sap.ui.getCore().byId("idCopyHeaderCreateResource").setValue(this.getView().getModel("lineStandardUpdateModel").getProperty("/resource"));
                sap.ui.getCore().byId("idCopyHeaderCreateCostCenter").setValue(this.getView().getModel("lineStandardUpdateModel").getProperty("/costCenter"));
                sap.ui.getCore().byId("idCopyHeaderCreateValidFrom").setValue(this.getView().getModel("lineStandardUpdateModel").getProperty("/validFrom"));
                sap.ui.getCore().byId("idCopyHeaderModifiedFrom").setValue(this.getView().getModel("lineStandardUpdateModel").getProperty("/modifiedFrom"));
                sap.ui.getCore().byId("idCopyHeaderCreateValidTo").setValue(this.getView().getModel("lineStandardUpdateModel").getProperty("/validTo"));

            },
            editStepOneLineCopyCreate: function (_evt) {
                sap.ui.getCore().byId("wizardCopyLineNavContainer").to(sap.ui.getCore().byId("idCopywizardLineContentPage"));
                sap.ui.getCore().byId("idCopyCreateLineWizard").goToStep(sap.ui.getCore().byId("idCopyLineTypeStep"));
                this._fnCopyCreateStepOneData();
                this.fnCopyCreateLossCat();
                this.fnReviewToContentCopyPlant();
            },
            editStepTwoLineCopyCreate: function (_evt) {
                sap.ui.getCore().byId("wizardCopyLineNavContainer").to(sap.ui.getCore().byId("idCopywizardLineContentPage"));
                sap.ui.getCore().byId("idCopyCreateLineWizard").goToStep(sap.ui.getCore().byId("idCopyLineInfoStep"));
                this._fnCopyCreateStepOneData();
                this.fnCopyCreateLossCat();
                this.fnReviewToContentCopyPlant();
            },
            editStepThreeLineCopyCreate: function (evt) {
                sap.ui.getCore().byId("wizardCopyLineNavContainer").to(sap.ui.getCore().byId("idCopywizardLineContentPage"));
                sap.ui.getCore().byId("idCopyCreateLineWizard").goToStep(sap.ui.getCore().byId("idCopyOptionalInfoStep"));
                this._fnCopyCreateStepOneData();
                this.fnCopyCreateLossCat();
                this.fnReviewToContentCopyPlant();
            },
            editStepFourLineCopyCreate: function (evt) {
                sap.ui.getCore().byId("wizardCopyLineNavContainer").to(sap.ui.getCore().byId("idCopywizardLineContentPage"));
                sap.ui.getCore().byId("idCopyCreateLineWizard").goToStep(sap.ui.getCore().byId("idCopyLineAnnualEventsStep"));
                this._fnCopyCreateStepOneData();
                this.fnCopyCreateLossCat();
                this.fnReviewToContentCopyPlant();
            },
            ////////////////////////////////////////// LineUpdate//////////////////////////////////////////////
            editStepOneLineUpdate: function (evt) {
                sap.ui.getCore().byId("wizardNavContainerUpdate").backToPage(sap.ui.getCore().byId("wizardContentPageUpdate"));
                sap.ui.getCore().byId("CreateProductWizardUpdate").goToStep(sap.ui.getCore().byId("ProductTypeStepUpdate"));
            },
            editStepTwoLineUpdate: function (evt) {
                sap.ui.getCore().byId("wizardNavContainerUpdate").backToPage(sap.ui.getCore().byId("wizardContentPageUpdate"));
                sap.ui.getCore().byId("CreateProductWizardUpdate").goToStep(sap.ui.getCore().byId("ProductInfoStepUpdate"));
            },
            editStepThreeLineUpdate: function (evt) {
                sap.ui.getCore().byId("wizardNavContainerUpdate").backToPage(sap.ui.getCore().byId("wizardContentPageUpdate"));
                sap.ui.getCore().byId("CreateProductWizardUpdate").goToStep(sap.ui.getCore().byId("OptionalInfoStepUpdate"));
            },
            editStepFourLineUpdate: function (evt) {
                sap.ui.getCore().byId("wizardNavContainerUpdate").backToPage(sap.ui.getCore().byId("wizardContentPageUpdate"));
                sap.ui.getCore().byId("CreateProductWizardUpdate").goToStep(sap.ui.getCore().byId("PricingStepUpdate"));
            },
            editStepOne: function () {
                if (sap.ui.getCore().byId("wizardLineNavContainer") != undefined) {
                    sap.ui.getCore().byId("wizardLineNavContainer").to(sap.ui.getCore().byId("wizardLineContentPage"));
                    sap.ui.getCore().byId("CreateLineWizard").goToStep(sap.ui.getCore().byId("LineTypeStep"));
                }
                if (sap.ui.getCore().byId("wizardNavContainerUpdate") != undefined) {
                    sap.ui.getCore().byId("wizardNavContainerUpdate").backToPage(sap.ui.getCore().byId("wizardContentPageUpdate"));
                    sap.ui.getCore().byId("CreateProductWizardUpdate").goToStep(sap.ui.getCore().byId("ProductTypeStepUpdate"));
                }
                //Line Copy create Wizard navigation from review to step 1
                if (sap.ui.getCore().byId("wizardCopyLineNavContainer") != undefined) {
                    sap.ui.getCore().byId("wizardCopyLineNavContainer").to(sap.ui.getCore().byId("idCopywizardLineContentPage"));
                    sap.ui.getCore().byId("idCopyCreateLineWizard").goToStep(sap.ui.getCore().byId("idCopyLineTypeStep"));
                }

            },
            editStepTwo: function () {
                if (sap.ui.getCore().byId("wizardLineNavContainer") != undefined) {
                    sap.ui.getCore().byId("wizardLineNavContainer").backToPage(sap.ui.getCore().byId("wizardLineContentPage"));
                    sap.ui.getCore().byId("CreateLineWizard").goToStep(sap.ui.getCore().byId("LineInfoStep"));
                }
                if (sap.ui.getCore().byId("wizardNavContainerUpdate") != undefined) {
                    sap.ui.getCore().byId("wizardNavContainerUpdate").backToPage(sap.ui.getCore().byId("wizardContentPageUpdate"));
                    sap.ui.getCore().byId("CreateProductWizardUpdate").goToStep(sap.ui.getCore().byId("ProductInfoStepUpdate"));
                }
                // Wizard navigation from review page to step2 on click of edit
                if (sap.ui.getCore().byId("wizardCopyLineNavContainer") != undefined) {
                    sap.ui.getCore().byId("wizardCopyLineNavContainer").to(sap.ui.getCore().byId("idCopywizardLineContentPage"));
                    sap.ui.getCore().byId("idCopyCreateLineWizard").goToStep(sap.ui.getCore().byId("idCopyLineInfoStep"));
                }
            },
            editStepThree: function () {
                if (sap.ui.getCore().byId("wizardLineNavContainer") != undefined) {
                    sap.ui.getCore().byId("wizardLineNavContainer").backToPage(sap.ui.getCore().byId("wizardLineContentPage"));
                    sap.ui.getCore().byId("CreateLineWizard").goToStep(sap.ui.getCore().byId("OptionalInfoStep"));
                }
                if (sap.ui.getCore().byId("wizardNavContainerUpdate") != undefined) {
                    sap.ui.getCore().byId("wizardNavContainerUpdate").backToPage(sap.ui.getCore().byId("wizardContentPageUpdate"));
                    sap.ui.getCore().byId("CreateProductWizardUpdate").goToStep(sap.ui.getCore().byId("OptionalInfoStepUpdate"));
                }
                //Wizard navigation from review page to step 3 on click of edit
                if (sap.ui.getCore().byId("wizardCopyNavContainer") != undefined) {
                    sap.ui.getCore().byId("wizardCopyNavContainer").to(sap.ui.getCore().byId("copyWizardContentPage"));
                    sap.ui.getCore().byId("copyCreateProductWizard").goToStep(sap.ui.getCore().byId("copyPricingStep"));
                }
                if (sap.ui.getCore().byId("wizardCopyLineNavContainer") != undefined) {
                    sap.ui.getCore().byId("wizardCopyLineNavContainer").to(sap.ui.getCore().byId("idCopywizardLineContentPage"));
                    sap.ui.getCore().byId("idCopyCreateLineWizard").goToStep(sap.ui.getCore().byId("idCopyOptionalInfoStep"));
                }
            },
            editStepFour: function () {
                if (sap.ui.getCore().byId("wizardLineNavContainer") != undefined) {
                    sap.ui.getCore().byId("wizardLineNavContainer").backToPage(sap.ui.getCore().byId("wizardLineContentPage"));
                    sap.ui.getCore().byId("CreateLineWizard").goToStep(sap.ui.getCore().byId("LineAnnualEventsStep"));
                }
                if (sap.ui.getCore().byId("wizardNavContainerUpdate") != undefined) {
                    sap.ui.getCore().byId("wizardNavContainerUpdate").backToPage(sap.ui.getCore().byId("wizardContentPageUpdate"));
                    sap.ui.getCore().byId("CreateProductWizardUpdate").goToStep(sap.ui.getCore().byId("PricingStepUpdate"));
                }
                if (sap.ui.getCore().byId("wizardCopyLineNavContainer") != undefined) {
                    sap.ui.getCore().byId("wizardCopyLineNavContainer").to(sap.ui.getCore().byId("idCopywizardLineContentPage"));
                    sap.ui.getCore().byId("idCopyCreateLineWizard").goToStep(sap.ui.getCore().byId("idCopyLineAnnualEventsStep"));
                }
            },
            fnReworkPopupClose: function (evt) {
                if (this._reworkComment) {
                    this._reworkComment.close();
                    sap.ui.getCore().byId("idReworkComment").setValue("");
                }
                if (this._ApproverReviewLine) {
                    this._ApproverReviewLine.close();
                }

            },
            handleCloseButton: function (oEvent) {
                if (this._isConfirming) {
                    return; // Prevent multiple confirmation dialogs
                }
            
                this._isConfirming = true;
            
                // Confirmation Dialog
                var that = this;
                sap.m.MessageBox.confirm("Are you sure you want to close this dialog? All unsaved changes will be lost.", {
                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
                    onClose: function (sAction) {
                        that._isConfirming = false; // Reset the flag
            
                        if (sAction === sap.m.MessageBox.Action.YES) {
                            // Proceed with the existing logic
                            if (that._LineCreate) {
                                that.getView().getModel("createLineStandardModel").setData({});
            
                                sap.ui.getCore().byId("idAnnualLossCatLabel").setRequired(false);
                                sap.ui.getCore().byId("idAnnualSubCatLabel").setRequired(false);
                                sap.ui.getCore().byId("idAnnualCycleYearLabel").setRequired(false);
                                sap.ui.getCore().byId("idAnnaulFreqLabel").setRequired(false);
                                sap.ui.getCore().byId("idAnnualEventDurLabel").setRequired(false);
                                sap.ui.getCore().byId("idAnnualCrewSizeLabel").setRequired(false);
            
                                sap.ui.getCore().byId("idAnnualSubCat").setEditable(false);
                                sap.ui.getCore().byId("idAnnualCycleYear").setEditable(false);
                                sap.ui.getCore().byId("idAnnaulFreq").setEditable(false);
                                sap.ui.getCore().byId("idAnnualEventDur").setEditable(false);
                                sap.ui.getCore().byId("idAnnualCrewSize").setEditable(false);
            
                                sap.ui.getCore().byId("wizardLineNavContainer").to(sap.ui.getCore().byId("wizardLineContentPage"));
                                sap.ui.getCore().byId("CreateLineWizard").goToStep(sap.ui.getCore().byId("LineTypeStep"));
            
                                var oWizard = sap.ui.getCore().byId("CreateLineWizard");
                                var oFirstStep = oWizard.getSteps()[0];
                                oWizard.discardProgress(oFirstStep);
                                oWizard.goToStep(oFirstStep);
                                oFirstStep.setValidated(true);
            
                                that.getView().getModel("createLineStandardModel").setData({});
                                sap.ui.getCore().byId("idHeaderCreatePlant").setValue("");
                                sap.ui.getCore().byId("idHeaderCreateResource").setValue("");
                                sap.ui.getCore().byId("idHeaderCreateCostCenter").setValue("");
                                sap.ui.getCore().byId("idCondition").setValue("");
                                sap.ui.getCore().byId("idConditionDesc").setValue("");
                                sap.ui.getCore().byId("idShiftLength").setValue("");
                                sap.ui.getCore().byId("idProductionCycle").setValue("");
                                sap.ui.getCore().byId("idShiftDays").setValue("");
                                sap.ui.getCore().byId("idcycleYear").setValue("");
                                sap.ui.getCore().byId("idLossCat").setValue("");
                                sap.ui.getCore().byId("idSubCat").setValue("");
                                sap.ui.getCore().byId("idExpectedCrewSize").setValue("");
                                sap.ui.getCore().byId("idExpectedFreq").setValue("");
                                sap.ui.getCore().byId("idExpectEventDuration").setValue("");
                                sap.ui.getCore().byId("idAnnualLossCat").setValue("");
                                sap.ui.getCore().byId("idAnnualSubCat").setValue("");
                                sap.ui.getCore().byId("idAnnualCycleYear").setValue("");
                                sap.ui.getCore().byId("idAnnaulFreq").setValue("");
                                sap.ui.getCore().byId("idAnnualEventDur").setValue("");
                                sap.ui.getCore().byId("idAnnualCrewSize").setValue("");
            
                                sap.ui.getCore().byId("idHeaderCreatePlant").setValueState("None");
                                sap.ui.getCore().byId("idHeaderCreateResource").setValueState("None");
                                sap.ui.getCore().byId("idHeaderCreateCostCenter").setValueState("None");
                                sap.ui.getCore().byId("idCondition").setValueState("None");
                                sap.ui.getCore().byId("idConditionDesc").setValueState("None");
                                sap.ui.getCore().byId("idShiftLength").setValueState("None");
                                sap.ui.getCore().byId("idProductionCycle").setValueState("None");
                                sap.ui.getCore().byId("idShiftDays").setValueState("None");
                                sap.ui.getCore().byId("idcycleYear").setValueState("None");
                                sap.ui.getCore().byId("idLossCat").setValueState("None");
                                sap.ui.getCore().byId("idSubCat").setValueState("None");
                                sap.ui.getCore().byId("idExpectedCrewSize").setValueState("None");
                                sap.ui.getCore().byId("idExpectedFreq").setValueState("None");
                                sap.ui.getCore().byId("idExpectEventDuration").setValueState("None");
                                sap.ui.getCore().byId("idAnnualLossCat").setValueState("None");
                                sap.ui.getCore().byId("idAnnualSubCat").setValueState("None");
                                sap.ui.getCore().byId("idAnnualCycleYear").setValueState("None");
                                sap.ui.getCore().byId("idAnnaulFreq").setValueState("None");
                                sap.ui.getCore().byId("idAnnualEventDur").setValueState("None");
                                sap.ui.getCore().byId("idAnnualCrewSize").setValueState("None");
            
                                that._LineCreate.close();
                            }
            
                            if (that._oPopover) {
                                that._oPopover.close();
                            }
            
                            if (that._oPopoverCommentDisplay) {
                                that._oPopoverCommentDisplay.close();
                            }
            
                            if (that._ApproverReviewLine) {
                                that._ApproverReviewLine.close();
                            }
            
                            if (that._ExecutorReviewLine) {
                                that._ExecutorReviewLine.close();
                            }
                        }
                    }
                });
            },
            // function for CANCEL button in Create with Template
            fnHandleCloseButtonCopyCreate: function () {
                if (this._isConfirming) {
                    return;
                }
                this._isConfirming = true;
            
                var that = this;
            
                // Confirmation Dialog
                sap.m.MessageBox.confirm("Are you sure you want to close this dialog? All unsaved changes will be lost.", {
                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
                    onClose: function (sAction) {
                        // Reset the flag only after the confirmation dialog is fully handled
                        that._isConfirming = true;
            
                        if (sAction === sap.m.MessageBox.Action.YES) {
                            // Reset loss category and sub-category editability for event data
                            var lineStandardUpdateModel = that.getView().getModel("lineStandardUpdateModel");
            
                            var cycleData = lineStandardUpdateModel.getProperty("/LineHdrToCyclesEvtDataNav");
                            for (var i = 0; i < cycleData.length; i++) {
                                lineStandardUpdateModel.setProperty(`/LineHdrToCyclesEvtDataNav/${i}/lossCatEditable`, true);
                                lineStandardUpdateModel.setProperty(`/LineHdrToCyclesEvtDataNav/${i}/subCatEditable`, true);
                            }
            
                            var annualData = lineStandardUpdateModel.getProperty("/LineHdrToAnnualEvtDataNav");
                            for (var i = 0; i < annualData.length; i++) {
                                lineStandardUpdateModel.setProperty(`/LineHdrToAnnualEvtDataNav/${i}/lossCatEditable`, true);
                                lineStandardUpdateModel.setProperty(`/LineHdrToAnnualEvtDataNav/${i}/subCatEditable`, true);
                            }
            
                            // Close the dialog and navigate
                            sap.ui.getCore().byId("wizardCopyLineNavContainer").to(sap.ui.getCore().byId("wizardCopyLineReviewPage"));
                            if (that._oLineCopyCreateDialog) {
                                that._oLineCopyCreateDialog.close();
                            }
                        } else {
                            // If the user clicks 'NO', reset the flag immediately to allow the next operation
                            that._isConfirming = false;
                        }
                    }
                });
            },
            // function for CANCEL button in edit screen
            fnHandleCloseButtonEdit: function () {
                if (this._isConfirming) {
                    return; // Prevent multiple confirmation dialogs
                }
            
                this._isConfirming = true;
            
                // Confirmation Dialog
                var that = this;
                sap.m.MessageBox.confirm("Are you sure you want to close this dialog? All unsaved changes will be lost.", {
                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
                    onClose: function (sAction) {       
                        if (sAction === sap.m.MessageBox.Action.YES) {
                        
                            // Reset loss category and sub-category editability for event data
                            var lineStandardUpdateModel = that.getView().getModel("lineStandardUpdateModel");
            
                            var cycleData = lineStandardUpdateModel.getProperty("/LineHdrToCyclesEvtDataNav");
                            for (var i = 0; i < cycleData.length; i++) {
                                lineStandardUpdateModel.setProperty(`/LineHdrToCyclesEvtDataNav/${i}/lossCatEditable`, true);
                                lineStandardUpdateModel.setProperty(`/LineHdrToCyclesEvtDataNav/${i}/subCatEditable`, true);
                            }
            
                            var annualData = lineStandardUpdateModel.getProperty("/LineHdrToAnnualEvtDataNav");
                            for (var i = 0; i < annualData.length; i++) {
                                lineStandardUpdateModel.setProperty(`/LineHdrToAnnualEvtDataNav/${i}/lossCatEditable`, true);
                                lineStandardUpdateModel.setProperty(`/LineHdrToAnnualEvtDataNav/${i}/subCatEditable`, true);
                            }
                            that._LineEdit.close();
                        }else {
                            this._isConfirming = false;
                        }
                    }
                });
            },
            onExecuteLine: function () {
                this._ExecutorReviewLine.close();
            },
            onApproveLine: function () {                
                // Set flag for Cancel confirmation
                this._isConfirming = true;
                var that = this;
                var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                var nbId = newData[0].Username;

                if (this.getView().byId("idLineTable").getSelectedItems()[0] != undefined) {
                    var sPath = this.getView().byId("idLineTable").getSelectedItems()[0].getBindingContext("lineStandardHeaderModel").sPath;
                }
                else {
                    var sPath = iLineApproveSelIndex;
                }
                var oData = this.getView().getModel("lineStandardHeaderModel").getProperty(sPath);
                var sStdNo = oData.lineStdNo;
                var sConfig = oData.configNo;

                var payload = {
                    "stdNo": sStdNo,
                    "configNo": sConfig,
                    "currentApprStdLevel": approverLevel
                }

                BusyIndicator.show();
                $.ajax({
                    url: "odata/v4/data-services/onApproveLineStd",
                    type: "POST",
                    data: JSON.stringify(payload),
                    contentType: "application/json",
                    dataType: "json",
                    headers: {
                        'x-username': nbId
                    }

                }).done(function (_response) {
                    BusyIndicator.hide();
                    MessageToast.show(that.oResourceBundle.getText("SLCT_LINE_APPROVED"));
                    var message = that.oResourceBundle.getText("SLCT_LINE_APPR_SUCCESS") + "\n";
                    that.onShowSuccess(message);
                    that.fnReadLineStdApproverTableData();
                }).fail(function (xhr, _status, _error) {
                    BusyIndicator.hide();
                    MessageToast.show(xhr.responseJSON.error.message + " " + that.oResourceBundle.getText("SLCT_LINE_APPROVED_FAIL"));
                    var message = that.oResourceBundle.getText("SLCT_LINE_APPR_FAIL") + "\n" + xhr.responseJSON.error.code + ":" + xhr.responseJSON.error.message;
                    that.onShowError(message);
                    that.fnReadLineStdApproverTableData();
                });
                this._ApproverReviewLine.close();
            },
            onLinestdActualpress: function () {
                var that = this;
                var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                var nbId = newData[0].Username;
                
                // Role assignment logic
                if ((role === 'C')|| (role === "S")) {
                    var currentRole = "Creator/Editor";  
                } else if (role === 'A') {
                    var currentRole  = "Approver";
                } else if (role === 'V' || role === 'E') {
                    var currentRole  = "Executor/Viewer";
                }
                var payload = {
                    "lineStdNo": this._lineStdNo
                };
                BusyIndicator.show();
                $.ajax({
                    url: "odata/v4/data-services/actualLineStdByCreator",
                    type: "POST",
                    data: JSON.stringify(payload),
                    contentType: "application/json",
                    dataType: "json",
                    headers: {
                        "x-username": nbId,
                        "x-role": currentRole
                    }
                }).done(function (response) {
                    BusyIndicator.hide();
                    MessageToast.show(response.value || "Successfully sent line standard.");
                    
                    that.fnReadLineStdHeaderTableData();
                    that.fncloseReviewarchiving();
                }).fail(function (xhr) {
                    BusyIndicator.hide();
                    var errorMessage = xhr.responseJSON?.error?.message || "Failed to send line standard.";
                    MessageToast.show(errorMessage);
                    
                    that.fnReadLineStdHeaderTableData();
                    that.fncloseReviewarchiving();
                });

            },
            onLineStdArchivePress: function () {
                var that = this;
                var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                var nbId = newData[0].Username;
                // Role assignment logic
                if ((role === 'C')|| (role === "S")) {
                    var currentRole = "Creator/Editor";
                } else if (role === 'A') {
                    var currentRole = "Approver";
                } else if (role === 'V' || role === 'E') {
                    var currentRole = "Executor/Viewer";
                }
                var lineStdNos = Array.isArray(this._lineStdNo) ? this._lineStdNo : [this._lineStdNo];
                var payload = {
                    lineStdNos: lineStdNos
                };
                BusyIndicator.show();
                $.ajax({
                    url: "odata/v4/data-services/archiveLineStdItems", // Update if a different endpoint is needed
                    type: "POST",
                    data: JSON.stringify(payload),
                    contentType: "application/json",
                    dataType: "json",
                    headers: {
                        "x-username": nbId,
                        "x-role": currentRole
                    }
                }).done(function (_response) {
                    BusyIndicator.hide();
                    MessageToast.show(that.oResourceBundle.getText("LINE_STD_ARCHIVED"));
                    var message = that.oResourceBundle.getText("SELECT_LINE_ARCHIVED_SUCCESS");
                    that.onShowSuccess(message);
                    
                    that.fnReadLineStdHeaderTableData();
                    // Reset Line table button settings
                    that.getView().byId("idLineTable").removeSelections(true);
                    that.getView().byId("idLineCopyCreate").setEnabled(false);
                    that.getView().byId("idArchive").setEnabled(false);
                    that.getView().byId("idCreate").setEnabled(true);
                    that.getView().byId("idSubmitForApproval").setEnabled(false);
                    that.fncloseReviewarchiving();
                }).fail(function (xhr, _status, _error) {
                    BusyIndicator.hide();
                    MessageToast.show(xhr.responseJSON.error.message + "" + that.oResourceBundle.getText("LINE_STD_ARCHIVED_FAIL"));
                    var message = that.oResourceBundle.getText("SELECT_LINE_ARCHIVED_FAIL") + "\n" + xhr.responseJSON.error.code + ":" + xhr.responseJSON.error.message;
                    that.onShowError(message);
                    // Reset Line table button settings
                    that.getView().byId("idLineTable").removeSelections(true);
                    that.getView().byId("idLineCopyCreate").setEnabled(false);
                    that.getView().byId("idArchive").setEnabled(false);
                    that.getView().byId("idCreate").setEnabled(true);
                    that.getView().byId("idSubmitForApproval").setEnabled(false);
                    that.fncloseReviewarchiving();
                });
            },
            onLinestdReworkpress: function () {
                var that = this;
                var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                var nbId = newData[0].Username;
                // Role assignment logic
                if ((role === 'C') || (role === "S")){
                    var currentRole = "Creator/Editor";
                } else if (role === 'A') {
                    var currentRole = "Approver";
                } else if (role === 'V' || role === 'E') {
                    var currentRole = "Executor/Viewer";
                }
                var payload = {
                    "lineStdNo": this._lineStdNo
                };
                BusyIndicator.show();
                $.ajax({
                    url: "odata/v4/data-services/reworkLineStdByCreator",
                    type: "POST",
                    data: JSON.stringify(payload),
                    contentType: "application/json",
                    dataType: "json",
                    headers: {
                        "x-username": nbId,
                        "x-role": currentRole
                    }
                }).done(function (response) {
                    BusyIndicator.hide();
                    MessageToast.show(response.value || "Successfully sent line standard.");
                    
                    that.fnReadLineStdHeaderTableData();
                    that.fncloseReviewarchiving();
                }).fail(function (xhr) {
                    BusyIndicator.hide();
                    var errorMessage = xhr.responseJSON?.error?.message || "Failed to send line standard.";
                    MessageToast.show(errorMessage);
                    
                    that.fnReadLineStdHeaderTableData();
                    that.fncloseReviewarchiving();
                });

            },

            // Create line standard step1 validation
            additionalInfoValidation: function () {

                var sCostCenter = sap.ui.getCore().byId("idHeaderCreateCostCenter").getValue();
                var dValidFrom = sap.ui.getCore().byId("idHeaderCreateValidFrom").getValue();
                var dValidTo = sap.ui.getCore().byId("idHeaderCreateValidTo").getValue();

                if (resource != "" && plant != "" && sCostCenter != "" && dValidFrom != "" && dValidTo != "") {
                    sap.ui.getCore().byId("CreateLineWizard").validateStep(sap.ui.getCore().byId("LineTypeStep"));
                }
                else {
                    sap.ui.getCore().byId("CreateLineWizard").invalidateStep(sap.ui.getCore().byId("LineTypeStep"));
                    if (resource == "") {
                        sap.ui.getCore().byId("CreateLineWizard").setCurrentStep(sap.ui.getCore().byId("LineTypeStep"));
                        sap.ui.getCore().byId("idHeaderCreateResource").setValueState("Error");
                        sap.ui.getCore().byId("idHeaderCreateResource").setValueStateText(this.oResourceBundle.getText("ENTER_LINE_APPROVER_ERROR"));
                    } else {
                        sap.ui.getCore().byId("idHeaderCreateResource").setValueState("None");
                    }
                    if (plant == "") {
                        sap.ui.getCore().byId("CreateLineWizard").setCurrentStep(sap.ui.getCore().byId("LineTypeStep"));
                        sap.ui.getCore().byId("idHeaderCreatePlant").setValueState("Error");
                        sap.ui.getCore().byId("idHeaderCreatePlant").setValueStateText(this.oResourceBundle.getText("ENTER_LINE_APPR_JOB_ERROR"));
                    } else {
                        sap.ui.getCore().byId("idHeaderCreatePlant").setValueState("None");
                    }
                    if (sCostCenter == "") {
                        sap.ui.getCore().byId("CreateLineWizard").setCurrentStep(sap.ui.getCore().byId("LineTypeStep"));
                        sap.ui.getCore().byId("idHeaderCreateCostCenter").setValueState("Error");
                        sap.ui.getCore().byId("idHeaderCreateCostCenter").setValueStateText(this.oResourceBundle.getText("ENTER_LINE_APPR_BACKUP_ERROR"));
                    } else {
                        sap.ui.getCore().byId("idHeaderCreateCostCenter").setValueState("None");
                    }
                    if (dValidFrom == "") {
                        sap.ui.getCore().byId("CreateLineWizard").setCurrentStep(sap.ui.getCore().byId("LineTypeStep"));
                        sap.ui.getCore().byId("idHeaderCreateValidFrom").setValueState("Error");
                        sap.ui.getCore().byId("idHeaderCreateValidFrom").setValueStateText(this.oResourceBundle.getText("ENTER_LINE_APPR_LEVEL_ERROR"));
                    } else {
                        sap.ui.getCore().byId("idHeaderCreateValidFrom").setValueState("None");
                    }
                    if (dValidTo == "") {
                        sap.ui.getCore().byId("CreateLineWizard").setCurrentStep(sap.ui.getCore().byId("LineTypeStep"));
                        sap.ui.getCore().byId("idHeaderCreateValidTo").setValueState("Error");
                        sap.ui.getCore().byId("idHeaderCreateValidTo").setValueStateText(this.oResourceBundle.getText("ENTER_LINE_APPR_LEVEL_ERROR"));
                    } else {
                        sap.ui.getCore().byId("idHeaderCreateValidTo").setValueState("None");
                    }
                }
            },
            onResourceSelection: function () {
                if (sap.ui.getCore().byId("idHeaderCreatePlant") != undefined) {
                    var plant = sap.ui.getCore().byId("idHeaderCreatePlant").getSelectedItem().getKey();
                    var resource = sap.ui.getCore().byId("idHeaderCreateResource").getSelectedItem().getKey();
                }
                var url = `/ETY_CostCentre_ValueHelpSet(Werks='${plant}',Arbpl='${resource}')`;

                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        success: function (oData) {
                            // Create and set the JSONModel with the data received
                            var oModelCostcenter = new sap.ui.model.json.JSONModel();
                            oModelCostcenter.setData(oData);
                            this.getView().setModel(oModelCostcenter, "costcenterModel");
                        }.bind(this),
                        error: function (oError) {
                            // Handle errors
                            MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
                        }
                    });

                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
            },
            fnResourceCopySelection: function (evt) {
                if (sap.ui.getCore().byId("idCopyHeaderCreatePlant") != undefined) {
                    var plant = sap.ui.getCore().byId("idCopyHeaderCreatePlant").getSelectedKey();
                    var resource = sap.ui.getCore().byId("idCopyHeaderCreateResource").getValue();
                }
                var url = `/ETY_CostCentre_ValueHelpSet(Werks='${plant}',Arbpl='${resource}')`;

                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        success: function (oData) {
                            // Create and set the JSONModel with the data received
                            var oModelCostcenter = new sap.ui.model.json.JSONModel();
                            oModelCostcenter.setData(oData);
                            this.getView().setModel(oModelCostcenter, "costcenterCopyModel");
                        }.bind(this),
                        error: function (oError) {
                            // Handle errors
                            MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
                        }
                    });

                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
            },

            fnResourceFilterSelection: function (evt) {
                var plant = this.getView().byId("idLineFilterPlant").getSelectedKey();
                var resource = this.getView().byId("idLineFilterResource").getValue();
                var url = `/ETY_CostCentre_ValueHelpSet(Werks='${plant}',Arbpl='${resource}')`;

                if (oODataModel) {
                    oODataModel.read(url, {
                        headers: mHeaders,
                        success: function (oData) {
                            // Create and set the JSONModel with the data received
                            var oModelCostcenter = new sap.ui.model.json.JSONModel();
                            oModelCostcenter.setData(oData);
                            this.getView().setModel(oModelCostcenter, "costcenterFilterModel");
                        }.bind(this),
                        error: function (oError) {
                            // Handle errors
                            MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
                        }
                    });

                } else {
                    MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
                }
            },

            // create, copycreate, edit screen Review button function
            wizardCompletedHandler: function () {
                /////////////////////////////// Validation for Step 1 in Create dialog///////////////////////////
                var sPlant = sap.ui.getCore().byId("idHeaderCreatePlant").getSelectedKey();
                var sResource = sap.ui.getCore().byId("idHeaderCreateResource").getValue();
                var sCostCenter = sap.ui.getCore().byId("idHeaderCreateCostCenter").getValue();
                var dValidFrom = sap.ui.getCore().byId("idHeaderCreateValidFrom").getDateValue();
                var dModifiedFrom = sap.ui.getCore().byId("idHeaderCreateModifiedFrom").getDateValue();
                var dValidTo = sap.ui.getCore().byId("idHeaderCreateValidTo").getDateValue();

                if (sPlant == "") {
                    sap.ui.getCore().byId("idHeaderCreatePlant").setValueState("Error");
                    sap.ui.getCore().byId("idHeaderCreatePlant").setValueStateText(this.oResourceBundle.getText("ERROR_PLANT_CREATE"));
                } else {
                    sap.ui.getCore().byId("idHeaderCreatePlant").setValueState("None");
                }
                if (sResource == "") {
                    sap.ui.getCore().byId("idHeaderCreateResource").setValueState("Error");
                    sap.ui.getCore().byId("idHeaderCreateResource").setValueStateText(this.oResourceBundle.getText("ERROR_RESOURCE_CREATE"));
                } else {
                    sap.ui.getCore().byId("idHeaderCreateResource").setValueState("None");
                }
                if (sCostCenter == "") {
                    sap.ui.getCore().byId("idHeaderCreateCostCenter").setValueState("Error");
                    sap.ui.getCore().byId("idHeaderCreateCostCenter").setValueStateText(this.oResourceBundle.getText("ERROR_COSTCENTER_CREATE"));
                } else {
                    sap.ui.getCore().byId("idHeaderCreateCostCenter").setValueState("None");
                }
                if (dValidFrom == "") {
                    sap.ui.getCore().byId("idHeaderCreateValidFrom").setValueState("Error");
                    sap.ui.getCore().byId("idHeaderCreateValidFrom").setValueStateText(this.oResourceBundle.getText("ERROR_VALIDFROM_CREATE"));
                } else {
                    sap.ui.getCore().byId("idHeaderCreateValidFrom").setValueState("None");
                }
                if (dValidTo == "") {
                    sap.ui.getCore().byId("idHeaderCreateValidTo").setValueState("Error");
                    sap.ui.getCore().byId("idHeaderCreateValidTo").setValueStateText(this.oResourceBundle.getText("ERROR_VALIDTO_CREATE"));
                } else {
                    sap.ui.getCore().byId("idHeaderCreateValidTo").setValueState("None");
                }


                ///////////////////////////////////Validation for Step 1 create dialog end//////////////////////

                var iCycleDbLen = this.getView().getModel("createLineStandardModel").getProperty("/LineHdrToCyclesDataNav");
                var icycleEventDbLen = this.getView().getModel("createLineStandardModel").getProperty("/LineHdrToCyclesEvtDataNav");

                if (sPlant == "" || sResource == "" || sCostCenter == "" || dValidFrom == "" || dValidTo == "" || iCycleDbLen == undefined || icycleEventDbLen == undefined) {
                    var step = "";
                    if (sPlant == "" || sResource == "" || sCostCenter == "" || dValidFrom == "" || dValidTo == "") {
                        step = step + " step1";
                    }
                    if (iCycleDbLen == undefined) {
                        step = step + " step2";
                    }
                    if (icycleEventDbLen == undefined) {
                        step = step + " step3";
                    }
                    // if (icycleAnnualEventDbLen == undefined) {
                    //     step = step + " step4";
                    // }
                    MessageToast.show(this.oResourceBundle.getText("MAND_LINE_ERROR_FIELDS") + " " + step + ", step4 (optional)");
                } else {
                    //  Line Create function last review button  

                    if (sap.ui.getCore().byId("wizardLineNavContainer") != undefined) {
                        sap.ui.getCore().byId("wizardLineNavContainer").to(sap.ui.getCore().byId("wizardLineReviewPage"));

                        var avgProdCycle, avgShiftInDay, avgShiftInCycle, avgCycleHours, shiftlength = 0, totOccupiedTime = 0, cycleInYearInt = 0,
                            shiftInCycleInt = 0, cycleHoursInt = 0, totOccupiedTimeInt = 0, shiftInCycle = 0, cycleHours = 0,
                            totOccupiedTime = 0, cycleInYear = 0, shiftInDayInt = 0, prodCycleInt = 0, shiftInDay = 0, prodCycle = 0, iLineApproveSelIndex;

                        var sCreatePlant = sap.ui.getCore().byId("idHeaderCreatePlant").getSelectedKey();
                        var sCreateResource = sap.ui.getCore().byId("idHeaderCreateResource").getValue();
                        var sCreateValidFrom = this._fnDateFormatDDMMYYYY(sap.ui.getCore().byId("idHeaderCreateValidFrom").getDateValue());
                        var sCreateModifiedFrom = this._fnDateFormatDDMMYYYY(sap.ui.getCore().byId("idHeaderCreateModifiedFrom").getDateValue());
                        var sLineStdNoValidFrom = this._fnDateFormatDDMMYYYY(sap.ui.getCore().byId("idHeaderCreateValidFrom").getDateValue());
                        var sLineStdNo = "LR_" + sCreatePlant + "_" + sCreateResource + "_" + sLineStdNoValidFrom;


                        var aRow = this.getView().getModel("createLineStandardModel").getData().LineHdrToCyclesDataNav.length;
                        for (var i = 0; i < aRow; i++) {
                            shiftInDayInt = Number(this.getView().getModel("createLineStandardModel").getData().LineHdrToCyclesDataNav[i].shiftsInDays);
                            prodCycleInt = Number(this.getView().getModel("createLineStandardModel").getData().LineHdrToCyclesDataNav[i].prodCyclesInDays)
                            shiftInDay = Number(this.getView().getModel("createLineStandardModel").getData().LineHdrToCyclesDataNav[i].shiftsInDays) + shiftInDay;
                            prodCycle = Number(this.getView().getModel("createLineStandardModel").getData().LineHdrToCyclesDataNav[i].prodCyclesInDays) + prodCycle;
                            shiftlength = Number(this.getView().getModel("createLineStandardModel").getData().LineHdrToCyclesDataNav[i].shiftLength);
                            cycleInYearInt = Number(this.getView().getModel("createLineStandardModel").getData().LineHdrToCyclesDataNav[i].cyclesInYear);

                            // calculcation field not shown in screen for 2rd step in create  
                            shiftInCycleInt = Number((shiftInDayInt * prodCycleInt).toFixed(3));
                            cycleHoursInt = Number((shiftInCycleInt * shiftlength).toFixed(3));
                            totOccupiedTimeInt = Number((cycleHoursInt * cycleInYearInt).toFixed(3));

                            this.getView().getModel("createLineStandardModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/shiftsInCycle", shiftInCycleInt);
                            this.getView().getModel("createLineStandardModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/cycleHrs", cycleHoursInt);
                            this.getView().getModel("createLineStandardModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/totalOccupiedTime", totOccupiedTimeInt);
                            this.getView().getModel("createLineStandardModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/lineStdNo", sLineStdNo)
                            this.getView().getModel("createLineStandardModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/status", "Created")

                            shiftInCycle = Number((shiftInCycleInt + shiftInCycle).toFixed(3));
                            cycleHours = Number((cycleHoursInt + cycleHours).toFixed(3));
                            totOccupiedTime = Number((totOccupiedTimeInt + totOccupiedTime).toFixed(3));
                            cycleInYear = Number((cycleInYearInt + cycleInYear).toFixed(3));
                        }
                        avgProdCycle = Number((prodCycle / aRow).toFixed(3));
                        avgShiftInDay = Number((shiftInDay / aRow).toFixed(3));
                        // avgShiftInCycle = Number((shiftInCycle / aRow).toFixed(3));
                        avgShiftInCycle = Number((avgShiftInDay * avgProdCycle).toFixed(3));
                        avgCycleHours = Number((totOccupiedTime / cycleInYear).toFixed(3));
                        // avgCycleHours = Number((totOccupiedTime / avgShiftInCycle).toFixed(3));
                        totOccupiedTime = Number(totOccupiedTime.toFixed(3));


                        sap.ui.getCore().byId("idPlantCreateReview").setText(sCreatePlant);
                        sap.ui.getCore().byId("idResourceCreateReview").setText(sCreateResource);
                        sap.ui.getCore().byId("idCostCenterCreateReview").setText(sap.ui.getCore().byId("idHeaderCreateCostCenter").getValue());
                        sap.ui.getCore().byId("idValidFromCreateReview").setText(sCreateValidFrom);
                        sap.ui.getCore().byId("idModifiedFromCreateReview").setText(sCreateModifiedFrom);
                        sap.ui.getCore().byId("idValidToCreateReview").setText(this._fnDateFormatDDMMYYYY(sap.ui.getCore().byId("idHeaderCreateValidTo").getDateValue()));

                        var postData = this.getView().getModel("createLineStandardModel").getData();
                        postData.prodCyclesInDays = avgProdCycle;
                        postData.shiftsInDay = avgShiftInDay;
                        postData.shiftsInCycle = avgShiftInCycle;
                        postData.cycleHrs = avgCycleHours;
                        postData.cyclesInYear = cycleInYear;
                        postData.totalOccupiedTime = totOccupiedTime;

                        var CreateCycleEventTotPlanDtLoss = 0, CreateAnnualCycleEventTotPlanDtLoss = 0;
                        var LineHdrToCyclesEvtDataNav = postData.LineHdrToCyclesEvtDataNav;
                        for (var i = 0; i < LineHdrToCyclesEvtDataNav.length; i++) {
                            LineHdrToCyclesEvtDataNav[i].expectedDurPerCycle = Number(Number(LineHdrToCyclesEvtDataNav[i].expectedFreqPerCycle * LineHdrToCyclesEvtDataNav[i].expectedEvtDur * postData.cyclesInYear).toFixed(3));
                            LineHdrToCyclesEvtDataNav[i].expectedLbrHrsPerCycle = Number(Number(LineHdrToCyclesEvtDataNav[i].expectedCrewSize * LineHdrToCyclesEvtDataNav[i].expectedDurPerCycle).toFixed(3));
                            LineHdrToCyclesEvtDataNav[i].cyclesInYear = Number(Number(postData.cyclesInYear).toFixed(3));
                            LineHdrToCyclesEvtDataNav[i].expectedTotLbrHrs = Number(Number(LineHdrToCyclesEvtDataNav[i].cyclesInYear * LineHdrToCyclesEvtDataNav[i].expectedLbrHrsPerCycle).toFixed(3));
                            LineHdrToCyclesEvtDataNav[i].cycleHrs = Number(Number(postData.cycleHrs).toFixed(3));
                            LineHdrToCyclesEvtDataNav[i].plannedDtLoss = Number(Number(((LineHdrToCyclesEvtDataNav[i].expectedDurPerCycle / postData.totalOccupiedTime) * postData.cyclesInYear) * 100).toFixed(3));
                            LineHdrToCyclesEvtDataNav[i].lineStdNo = sLineStdNo;
                            LineHdrToCyclesEvtDataNav[i].status = "Created";
                            CreateCycleEventTotPlanDtLoss = CreateCycleEventTotPlanDtLoss + LineHdrToCyclesEvtDataNav[i].plannedDtLoss;
                        }
                        postData.LineHdrToCyclesEvtDataNav = LineHdrToCyclesEvtDataNav;

                        var LineHdrToAnnualEvtDataNav = postData.LineHdrToAnnualEvtDataNav;
                        if (LineHdrToAnnualEvtDataNav != undefined) {
                            for (var i = 0; i < LineHdrToAnnualEvtDataNav.length; i++) {

                                LineHdrToAnnualEvtDataNav[i].expectedDurPerYear = Number(Number(LineHdrToAnnualEvtDataNav[i].expectedFrequency * LineHdrToAnnualEvtDataNav[i].expectedEvtDur).toFixed(3));
                                LineHdrToAnnualEvtDataNav[i].expectedLbrHrPerYear = Number(Number(LineHdrToAnnualEvtDataNav[i].expectedCrewSize * LineHdrToAnnualEvtDataNav[i].expectedDurPerYear).toFixed(3));
                                LineHdrToAnnualEvtDataNav[i].totOccupiedHrs = Number(Number(postData.totalOccupiedTime).toFixed(3));
                                LineHdrToAnnualEvtDataNav[i].plannedDtLoss = Number(Number((LineHdrToAnnualEvtDataNav[i].expectedDurPerYear / LineHdrToAnnualEvtDataNav[i].totOccupiedHrs) * 100).toFixed(3));
                                LineHdrToAnnualEvtDataNav[i].lineStdNo = sLineStdNo;
                                LineHdrToAnnualEvtDataNav[i].status = "Created";

                                CreateAnnualCycleEventTotPlanDtLoss = CreateAnnualCycleEventTotPlanDtLoss + LineHdrToAnnualEvtDataNav[i].plannedDtLoss;

                            }
                            postData.LineHdrToAnnualEvtDataNav = LineHdrToAnnualEvtDataNav;
                        }

                        this.getView().getModel("createLineStandardModel").setData(postData);

                        var TotPlannedDTLoss = Number(Number(CreateCycleEventTotPlanDtLoss + CreateAnnualCycleEventTotPlanDtLoss).toFixed(3));
                        sap.ui.getCore().byId("idCreateTotPlanDTLoss").setText(TotPlannedDTLoss);
                        this.getView().getModel("createLineStandardModel").setProperty("/plannedDtLoss", TotPlannedDTLoss);
                    }
                    if (sap.ui.getCore().byId("wizardNavContainerUpdate") != undefined) {
                    }

                }
                if (sap.ui.getCore().byId("wizardProdUpdateNavContainer") != undefined) {
                    sap.ui.getCore().byId("wizardProdUpdateNavContainer").to(sap.ui.getCore().byId("wizardUpdateReviewPage"));
                }
                if (sap.ui.getCore().byId("wizardCopyNavContainer") != undefined) {
                    sap.ui.getCore().byId("wizardCopyNavContainer").to(sap.ui.getCore().byId("wizardCopyReviewPage"));
                    // sap.ui.getCore().byId("copyCreateProductWizard").goToStep(sap.ui.getCore().byId("copyProductTypeStep"));
                }

                // wizardNavContainerUpdate
            },

            // on click of Review button in copycreate dialog
            fnCopyCreatewizardCompletedHandler: function (_oEvent) {
                //////////////////////////////////////////Validtion for Edit Dialog start/////////////////////////////////////////////////////
                //step1     
                var sPlant = sap.ui.getCore().byId("idCopyHeaderCreatePlant").getSelectedKey();
                if (sPlant == "") {
                    sap.ui.getCore().byId("idCopyHeaderCreatePlant").setValueState("Error");
                    sap.ui.getCore().byId("idCopyHeaderCreatePlant").setValueStateText(this.oResourceBundle.getText("ERROR_PLANT_CREATE"));
                } else {
                    sap.ui.getCore().byId("idCopyHeaderCreatePlant").setValueState("None");
                }
                var sResource = sap.ui.getCore().byId("idCopyHeaderCreateResource").getValue();
                if (sResource == "") {
                    sap.ui.getCore().byId("idCopyHeaderCreateResource").setValueState("Error");
                    sap.ui.getCore().byId("idCopyHeaderCreateResource").setValueStateText(this.oResourceBundle.getText("ERROR_RESOURCE_CREATE"));
                } else {
                    sap.ui.getCore().byId("idCopyHeaderCreateResource").setValueState("None");
                }
                var dValidFrom = sap.ui.getCore().byId("idCopyHeaderCreateValidFrom").getDateValue();
                if (dValidFrom == null) {
                    sap.ui.getCore().byId("idCopyHeaderCreateValidFrom").setValueState("Error");
                    sap.ui.getCore().byId("idCopyHeaderCreateValidFrom").setValueStateText(this.oResourceBundle.getText(ERROR_VALIDFROM_CREATE));
                } else {
                    sap.ui.getCore().byId("idCopyHeaderCreateValidFrom").setValueState("None");
                }
                var dValidTo = sap.ui.getCore().byId("idCopyHeaderCreateValidTo").getDateValue();
                if (dValidTo == null) {
                    sap.ui.getCore().byId("idCopyHeaderCreateValidTo").setValueState("Error");
                    sap.ui.getCore().byId("idCopyHeaderCreateValidTo").setValueStateText(this.oResourceBundle.getText("ERROR_VALIDTO_CREATE"));
                } else {
                    sap.ui.getCore().byId("idCopyHeaderCreateValidTo").setValueState("None");
                }
                var oLinestdHeaderdata = this.getView().getModel("lineStandardHeaderModel").getProperty("/value/");
                for (var y = 0; y < oLinestdHeaderdata.length; y++) {
                    if(sPlant === oLinestdHeaderdata[y].plant && this._fnDateFormat(new Date(dValidFrom))===oLinestdHeaderdata[y].validFrom){
                        sap.m.MessageBox.warning("Please chnage the Valid from date or Plant as this record is alredy exist");
                        return;
                    }
                
                }
                //step2

                var iCycleDbData = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesDataNav");
                var iCycleDbError = 0;
                for (var i = 0; i < iCycleDbData.length; i++) {
                    var condition = iCycleDbData[i].condition;
                    var conDescrip = iCycleDbData[i].conditionDesc;
                    var shiftLen = Number(iCycleDbData[i].shiftLength);
                    var productionCycle = Number(iCycleDbData[i].prodCyclesInDays);
                    var shiftInDays = Number(iCycleDbData[i].shiftsInDays);
                    var cycleInYear = Number(iCycleDbData[i].cyclesInYear);

                    var iSum = 0;
                    var iCycInYearCeiling;
                    // if (this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesDataNav") == undefined) {                   
                    //     iCycInYearCeiling= Number((365/productionCycle).toFixed(3));                  
                    // }
                    // else {                  
                    var aCyclesDbDataCopy = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesDataNav");
                    for (var j = 0; j < aCyclesDbDataCopy.length; j++) {
                        if (i != j) {
                            iSum = Number((aCyclesDbDataCopy[j].prodCyclesInDays * aCyclesDbDataCopy[j].cyclesInYear).toFixed(3)) + iSum;
                        }
                    }
                    iCycInYearCeiling = Number((((365 - iSum)) / productionCycle).toFixed(3));
                    // }



                    if (condition == "") {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateCondition", "Error");
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateTextCondition", this.oResourceBundle.getText("ERROR_CONDITION"));
                        iCycleDbError = 1;
                    } else {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateCondition", "None");
                    }
                    if (conDescrip == "") {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateConDescription", "Error");
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateTextConDescription", this.oResourceBundle.getText("ERROR_CONDITION_DESC"));
                        iCycleDbError = 1;
                    } else {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateConDescription", "None");
                    }

                    if (shiftLen == "" || shiftLen > 24) {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateShiftLen", "Error");
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateTextShiftLen", this.oResourceBundle.getText("ERROR_SHIFT_LENGTH"));
                        iCycleDbError = 1;
                    } else {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateShiftLen", "None");
                    }
                    if (productionCycle == "" || productionCycle > 365) {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateProductionCycle", "Error");
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateTextProductionCycle", this.oResourceBundle.getText("ERROR_PRODUCTION_CYCLE"));
                        iCycleDbError = 1;
                    } else {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateProductionCycle", "None");
                    }
                    if (shiftInDays == "" || shiftInDays > (24 / shiftLen)) {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateShiftInDays", "Error");
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateTextShiftInDays", this.oResourceBundle.getText("ERROR_SHIFT_DAYS_2") + this.oResourceBundle.getText("ERROR_LESS_THAN") + Number((24 / Number(shiftLen.toFixed(3))).toFixed(3)));
                        iCycleDbError = 1;
                    } else {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateShiftInDays", "None");
                    }
                    if (cycleInYear == "" || cycleInYear > iCycInYearCeiling || cycleInYear < 0) {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateCycleInYear", "Error");
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateTextCycleInYear", this.oResourceBundle.getText("ERROR_CYCLE_IN_YEAR_2") + " " + iCycInYearCeiling);
                        iCycleDbError = 1;
                    } else {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateCycleInYear", "None");
                    }
                }

                var aCycleEventDbData = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesEvtDataNav");
                var iCycleEventsDbError = 0;
                for (var i = 0; i < aCycleEventDbData.length; i++) {
                    var lossCat = aCycleEventDbData[i].lossCat;
                    var subCat = aCycleEventDbData[i].subCat;
                    var crewSize = Number(aCycleEventDbData[i].expectedCrewSize);
                    var ExpFrequency = Number(aCycleEventDbData[i].expectedFreqPerCycle);
                    var ExpEventDur = Number(aCycleEventDbData[i].expectedEvtDur);
                    // var cycleInYear = iCycleDbData[i].cyclesInYear;

                    if (lossCat == "") {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateLossCat", "Error");
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateTextLossCat", this.oResourceBundle.getText("ERROR_LOSS_CATEGORY"));
                        iCycleEventsDbError = 1;
                    } else {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateLossCat", "None");
                    }
                    if (subCat == "") {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateSubCat", "Error");
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateTextSubCat", this.oResourceBundle.getText("ERROR_SUB_CATEGORY"));
                        iCycleEventsDbError = 1;
                    } else {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateSubCat", "None");
                    }
                    if (ExpFrequency == "") {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateExpFrequency", "Error");
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateTextExpFrequency", this.oResourceBundle.getText("ERROR_EXPECTED_FREQUENCY"));
                        iCycleEventsDbError = 1;
                    } else {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateExpFrequency", "None");
                    }
                    if (ExpEventDur == "") {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateExpEventDur", "Error");
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateTextExpEventDur", this.oResourceBundle.getText("ERROR_EXP_EVENT_DUR"));
                        iCycleEventsDbError = 1;
                    } else {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateExpEventDur", "None");
                    }
                }

                var acycleAnnualEventDbLen = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav");
                var iCycleAnnualDbError = 0;
                if (acycleAnnualEventDbLen != undefined) {
                    for (var i = 0; i < acycleAnnualEventDbLen.length; i++) {

                        var lossCat = acycleAnnualEventDbLen[i].lossCat;
                        var subCat = acycleAnnualEventDbLen[i].subCat;
                        var crewSize = acycleAnnualEventDbLen[i].expectedCrewSize;
                        var ExpFrequency = Number(acycleAnnualEventDbLen[i].expectedFrequency);
                        var ExpEventDur = Number(acycleAnnualEventDbLen[i].expectedEvtDur);
                        var cycleInYear = Number(acycleAnnualEventDbLen[i].cyclesInYear);

                        if (lossCat == "") {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateLossCat", "Error");
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateTextLossCat", this.oResourceBundle.getText("ERROR_LOSS_CATEGORY"));
                            iCycleAnnualDbError = 1;
                        } else {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateLossCat", "None");
                        }
                        if (subCat == "") {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateSubCat", "Error");
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateTextSubCat", this.oResourceBundle.getText("ERROR_SUB_CATEGORY"));
                            iCycleAnnualDbError = 1;
                        } else {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateSubCat", "None");
                        }
                        if (crewSize == "") {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateCrewSize", "Error");
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateTextCrewSize", this.oResourceBundle.getText("ERROR_EXPECTED_CREWSIZE"));
                            iCycleAnnualDbError = 1;
                        } else {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateCrewSize", "None");
                        }
                        if (ExpFrequency == "") {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateExpFrequency", "Error");
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateTextExpFrequency", this.oResourceBundle.getText("ERROR_EXPECTED_FREQUENCY"));
                            iCycleAnnualDbError = 1;
                        } else {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateExpFrequency", "None");
                        }
                        if (ExpEventDur == "") {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateExpEventDur", "Error");
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateTextExpFrequency", this.oResourceBundle.getText("ERROR_EXP_EVENT_DUR"));
                            iCycleAnnualDbError = 1;
                        } else {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateExpEventDur", "None");
                        }
                        if (cycleInYear == "") {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateCycleInYear", "Error");
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateTextCycleInYear", this.oResourceBundle.getText("ERROR_CYCLE_IN_YEAR"));
                            iCycleAnnualDbError = 1;
                        } else {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateCycleInYear", "None");
                        }
                    }
                }

                if (dValidTo == null || sPlant == "" || sResource == "" || dValidFrom == null || iCycleDbError == 1 || iCycleEventsDbError == 1 || iCycleAnnualDbError == 1) {
                    var step = "";
                    if (dValidTo == null || sPlant == "" || sResource == "" || dValidFrom == null) {
                        step = step + "step1";
                    }
                    if (iCycleDbError == 1) {
                        step = step + "step2";
                    }
                    if (iCycleEventsDbError == 1){
                        step = step + "step3";
                    }
                    if (iCycleAnnualDbError == 1){
                        step = step + "step4";
                    }
                    MessageToast.show(this.oResourceBundle.getText("MAND_LINE_ERROR_FIELDS") + " " + step);
                } else {

                    ///////////////////////////////////////////////////////// Validation End ////////////////////////////////////////////////////////
                    sap.ui.getCore().byId("wizardCopyLineNavContainer").to(sap.ui.getCore().byId("wizardCopyLineReviewPage"));

                    //////////////////////////////Calculcated fields///////////////////////////////////////////
                    this.getView().getModel("lineStandardUpdateModel").getData();

                    var avgProdCycle, avgShiftInDay, avgShiftInCycle, avgCycleHours, shiftlength = 0, totOccupiedTime = 0, cycleInYearInt = 0,
                        shiftInCycleInt = 0, cycleHoursInt = 0, totOccupiedTimeInt = 0, shiftInCycle = 0, cycleHours = 0,
                        totOccupiedTime = 0, cycleInYear = 0, shiftInDayInt = 0, prodCycleInt = 0, shiftInDay = 0, prodCycle = 0, iLineApproveSelIndex;

                    var aRow = this.getView().getModel("lineStandardUpdateModel").getData().LineHdrToCyclesDataNav.length;
                    for (var i = 0; i < aRow; i++) {
                        shiftInDayInt = Number(this.getView().getModel("lineStandardUpdateModel").getData().LineHdrToCyclesDataNav[i].shiftsInDays);
                        prodCycleInt = Number(this.getView().getModel("lineStandardUpdateModel").getData().LineHdrToCyclesDataNav[i].prodCyclesInDays)
                        shiftInDay = Number(this.getView().getModel("lineStandardUpdateModel").getData().LineHdrToCyclesDataNav[i].shiftsInDays) + shiftInDay;
                        prodCycle = Number(this.getView().getModel("lineStandardUpdateModel").getData().LineHdrToCyclesDataNav[i].prodCyclesInDays) + prodCycle;
                        shiftlength = Number(this.getView().getModel("lineStandardUpdateModel").getData().LineHdrToCyclesDataNav[i].shiftLength);
                        cycleInYearInt = Number(this.getView().getModel("lineStandardUpdateModel").getData().LineHdrToCyclesDataNav[i].cyclesInYear);

                        // step2 extra column not shown in screen
                        shiftInCycleInt = Number((shiftInDayInt * prodCycleInt).toFixed(3));
                        cycleHoursInt = Number((shiftInCycleInt * shiftlength).toFixed(3));
                        totOccupiedTimeInt = Number((cycleHoursInt * cycleInYearInt).toFixed(3));

                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/shiftsInCycle", shiftInCycleInt);
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/cycleHrs", cycleHoursInt);
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/totalOccupiedTime", totOccupiedTimeInt);

                        shiftInCycle = Number((shiftInCycleInt + shiftInCycle).toFixed(3));
                        cycleHours = Number((cycleHoursInt + cycleHours).toFixed(3));
                        totOccupiedTime = Number((totOccupiedTimeInt + totOccupiedTime).toFixed(3));
                        cycleInYear = Number((cycleInYearInt + cycleInYear).toFixed(3));
                    }
                    avgProdCycle = Number((prodCycle / aRow).toFixed(3));
                    avgShiftInDay = Number((shiftInDay / aRow).toFixed(3));
                    //avgShiftInCycle = Number((shiftInCycle / aRow).toFixed(3));
                    avgShiftInCycle = Number((avgShiftInDay * avgProdCycle).toFixed(3));
                    avgCycleHours = Number((totOccupiedTime / cycleInYear).toFixed(3));
                    // avgCycleHours = Number((totOccupiedTime / avgShiftInCycle).toFixed(3));
                    totOccupiedTime = Number((totOccupiedTime.toFixed(3)));

                    this.getView().getModel("lineStandardUpdateModel").setProperty("/prodCyclesInDays", avgProdCycle);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/shiftsInDay", avgShiftInDay);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/shiftsInCycle", avgShiftInCycle);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/cycleHrs", avgCycleHours);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/totalOccupiedTime", totOccupiedTime);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/cyclesInYear", cycleInYear);
                    //////////////////////////////////////////////////////////////////////////////////////////////  

                    var sLinePlant = sap.ui.getCore().byId("idCopyHeaderCreatePlant").getSelectedKey();
                    var sLineResource = sap.ui.getCore().byId("idCopyHeaderCreateResource").getValue();
                    var sLineValidFrom = this._fnDateFormat(sap.ui.getCore().byId("idCopyHeaderCreateValidFrom").getDateValue());
                    var sLineModifiedFrom = this._fnDateFormat(sap.ui.getCore().byId("idCopyHeaderModifiedFrom").getDateValue());
                    var sLineStdNoValidFrom = this._fnDateFormatDDMMYYYY(sap.ui.getCore().byId("idCopyHeaderCreateValidFrom").getDateValue());
                    var sLineStdNo = "LR_" + sLinePlant + "_" + sLineResource + "_" + sLineStdNoValidFrom;

                    this.getView().getModel("lineStandardUpdateModel").setProperty("/plant", sLinePlant);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/resource", sLineResource);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/costCenter", sap.ui.getCore().byId("idCopyHeaderCreateCostCenter").getValue());
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/validFrom", sLineValidFrom);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/modifiedFrom", sLineModifiedFrom);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/validTo", this._fnDateFormat(sap.ui.getCore().byId("idCopyHeaderCreateValidTo").getDateValue()));


                    var oPostData = this.getView().getModel("lineStandardUpdateModel").getData();

                    var CopyCreateCycleEventTotPlanDtLoss = 0, CopyCreateAnnualCycleEventTotPlanDtLoss = 0;
                    var LineHdrToCyclesEvtDataNav = [];
                    for (var i = 0; i < oPostData.LineHdrToCyclesEvtDataNav.length; i++) {

                        var oTemp = {};
                        oTemp.lossCat = oPostData.LineHdrToCyclesEvtDataNav[i].lossCat;
                        oTemp.subCat = oPostData.LineHdrToCyclesEvtDataNav[i].subCat;
                        oTemp.expectedCrewSize = Number(Number(oPostData.LineHdrToCyclesEvtDataNav[i].expectedCrewSize).toFixed(3));
                        oTemp.expectedFreqPerCycle = Number(Number(oPostData.LineHdrToCyclesEvtDataNav[i].expectedFreqPerCycle).toFixed(3));
                        oTemp.expectedEvtDur = Number(Number(oPostData.LineHdrToCyclesEvtDataNav[i].expectedEvtDur).toFixed(3));

                        // calculcated fields for cycles event db in copycreate screen
                        oTemp.expectedDurPerCycle = Number(Number(oPostData.LineHdrToCyclesEvtDataNav[i].expectedFreqPerCycle * Number(oPostData.LineHdrToCyclesEvtDataNav[i].expectedEvtDur * oPostData.cyclesInYear)).toFixed(3));
                        oTemp.expectedLbrHrsPerCycle = Number(Number(oPostData.LineHdrToCyclesEvtDataNav[i].expectedCrewSize * oTemp.expectedDurPerCycle).toFixed(3));
                        oTemp.cyclesInYear = Number(Number(oPostData.cyclesInYear).toFixed(3));
                        oTemp.expectedTotLbrHrs = Number(Number(oTemp.cyclesInYear * oTemp.expectedLbrHrsPerCycle).toFixed(3));
                        oTemp.cycleHrs = Number(Number(oPostData.cycleHrs).toFixed(3));
                        oTemp.plannedDtLoss = Number(Number(((oTemp.expectedDurPerCycle / oPostData.totalOccupiedTime) * Number(oPostData.cyclesInYear)) * 100).toFixed(3));
                        oTemp.lineStdNo = sLineStdNo;
                        oTemp.status = "Created";

                        LineHdrToCyclesEvtDataNav.push(oTemp);

                        CopyCreateCycleEventTotPlanDtLoss = CopyCreateCycleEventTotPlanDtLoss + oTemp.plannedDtLoss;

                    }

                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav", LineHdrToCyclesEvtDataNav);

                    var LineHdrToAnnualEvtDataNav = [];
                    for (var i = 0; i < oPostData.LineHdrToAnnualEvtDataNav.length; i++) {

                        var oTemp = {};
                        oTemp.lossCat = oPostData.LineHdrToAnnualEvtDataNav[i].lossCat;
                        oTemp.subCat = oPostData.LineHdrToAnnualEvtDataNav[i].subCat;
                        oTemp.cyclesInYear = Number(Number(oPostData.LineHdrToAnnualEvtDataNav[i].cyclesInYear).toFixed(3));
                        oTemp.expectedCrewSize = Number(Number(oPostData.LineHdrToAnnualEvtDataNav[i].expectedCrewSize).toFixed(3));
                        oTemp.expectedFrequency = Number(Number(oPostData.LineHdrToAnnualEvtDataNav[i].expectedFrequency).toFixed(3));
                        oTemp.expectedEvtDur = Number(Number(oPostData.LineHdrToAnnualEvtDataNav[i].expectedEvtDur).toFixed(3));

                        // calculcated fields for cycles Annual event db in copycreate screen

                        oTemp.expectedDurPerYear = Number(Number(oPostData.LineHdrToAnnualEvtDataNav[i].expectedFrequency * Number(oPostData.LineHdrToAnnualEvtDataNav[i].expectedEvtDur)).toFixed(3));
                        oTemp.expectedLbrHrPerYear = Number(Number(oPostData.LineHdrToAnnualEvtDataNav[i].expectedCrewSize * oTemp.expectedDurPerYear).toFixed(3));
                        oTemp.totOccupiedHrs = Number(Number(oPostData.totalOccupiedTime).toFixed(3));
                        oTemp.plannedDtLoss = Number(Number((oTemp.expectedDurPerYear / oTemp.totOccupiedHrs) * 100).toFixed(3));
                        oTemp.lineStdNo = sLineStdNo;
                        oTemp.status = "Created";
                        LineHdrToAnnualEvtDataNav.push(oTemp);

                        CopyCreateAnnualCycleEventTotPlanDtLoss = CopyCreateAnnualCycleEventTotPlanDtLoss + oTemp.plannedDtLoss;

                    }

                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav", LineHdrToAnnualEvtDataNav);

                    var TotPlannedDTLoss = Number(Number(CopyCreateCycleEventTotPlanDtLoss + CopyCreateAnnualCycleEventTotPlanDtLoss).toFixed(3));
                    this.getOwnerComponent().getModel("lineStandardUpdateModel").setProperty("/TotalPlannedDTLoss", TotPlannedDTLoss);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/plannedDtLoss", TotPlannedDTLoss);

                    // sap.ui.getCore().byId("idCopyCreateTotPlanDTLoss").setText(TotPlannedDTLoss);

                }

            },
            fnUpdatewizardCompletedHandler: function (oEvent) {
                //////////////////////////////////////////Validtion for Edit Dialog start/////////////////////////////////////////////////////
                //step1     
                //////////////////////////////////////////Validation for Edit Dialog start/////////////////////////////////////////////////////
                // Step 1 - Date Validation for 'Valid From' and 'Modified From'
                var validFromDate = sap.ui.getCore().byId("idStandardHeaderupdateValidFrom").getValue();
                var modifiedFromDate = sap.ui.getCore().byId("idStandardHeaderupdateModifiedFrom").getValue();
                
                // Reset the time part of both dates by creating new Date objects with the same year, month, and date
                var validFrom = new Date(validFromDate);
                var modifiedFrom = new Date(modifiedFromDate);
                
                // Set the time part to 00:00:00 for both dates
                validFrom.setHours(0, 0, 0, 0);
                modifiedFrom.setHours(0, 0, 0, 0);
                
                if (modifiedFrom < validFrom) {
                    sap.m.MessageBox.error("'Modified From' date cannot be older than 'Valid From' date.");
                    return;
                }
                var dValidTo = sap.ui.getCore().byId("idStandardHeaderValidTo").getDateValue();
                if (dValidTo == null) {
                    sap.ui.getCore().byId("idStandardHeaderValidTo").setValueState("Error");
                    sap.ui.getCore().byId("idStandardHeaderValidTo").setValueStateText(this.oResourceBundle.getText("ERROR_VALIDTO_CREATE"));
                } else {
                    sap.ui.getCore().byId("idStandardHeaderValidTo").setValueState("None");
                }
                //step2   
                var iCycleDbError = 0;
                var iCycleDbData = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesDataNav");

                for (var i = 0; i < iCycleDbData.length; i++) {
                    var condition = iCycleDbData[i].condition;
                    var conDescrip = iCycleDbData[i].conditionDesc;
                    var shiftLen = Number(iCycleDbData[i].shiftLength);
                    var productionCycle = Number(iCycleDbData[i].prodCyclesInDays);
                    var shiftInDays = Number(iCycleDbData[i].shiftsInDays);
                    var cycleInYear = Number(iCycleDbData[i].cyclesInYear);

                    var iSum = 0;
                    var iCycInYearCeiling;
                    // if (this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesDataNav") == undefined) {                   
                    //     iCycInYearCeiling= Number((365/productionCycle).toFixed(3));                  
                    // }
                    // else {                  
                    var aCyclesDbDataEdit = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesDataNav");
                    for (var j = 0; j < aCyclesDbDataEdit.length; j++) {
                        if (i != j) {
                            iSum = Number((aCyclesDbDataEdit[j].prodCyclesInDays * aCyclesDbDataEdit[j].cyclesInYear).toFixed(3)) + iSum;
                        }
                    }
                    iCycInYearCeiling = Number((((365 - iSum)) / productionCycle).toFixed(3));
                    // }	



                    if (condition == "") {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateCondition", "Error");
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateTextCondition", this.oResourceBundle.getText("ERROR_CONDITION"));
                        iCycleDbError = 1;
                    } else {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateCondition", "None");
                    }
                    if (conDescrip == "") {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateConDescription", "Error");
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateTextConDescription", this.oResourceBundle.getText("ERROR_CONDITION_DESC"));
                        iCycleDbError = 1;
                    } else {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateConDescription", "None");
                    }
                    if (shiftLen == "" || shiftLen > 24) {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateShiftLen", "Error");
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateTextShiftLen", this.oResourceBundle.getText("ERROR_SHIFT_LENGTH"));
                        iCycleDbError = 1;
                    } else {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateShiftLen", "None");
                    }
                    if (productionCycle == "" || productionCycle > 365) {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateProductionCycle", "Error");
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateTextProductionCycle", this.oResourceBundle.getText("ERROR_PRODUCTION_CYCLE"));
                        iCycleDbError = 1;
                    } else {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateProductionCycle", "None");

                    }
                    if (shiftInDays == "" || shiftInDays > (24 / shiftLen)) {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateShiftInDays", "Error");
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateTextShiftInDays", this.oResourceBundle.getText("ERROR_SHIFT_DAYS_2") + this.oResourceBundle.getText("ERROR_LESS_THAN") + Number((24 / Number((shiftLen).toFixed(3))).toFixed(3)));
                        iCycleDbError = 1;
                    } else {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateShiftInDays", "None");
                    }
                    if (cycleInYear == "" || cycleInYear > iCycInYearCeiling || cycleInYear < 0) {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateCycleInYear", "Error");
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateTextCycleInYear", this.oResourceBundle.getText("ERROR_CYCLE_IN_YEAR_2") + " " + iCycInYearCeiling);
                        iCycleDbError = 1;
                    } else {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/valueStateCycleInYear", "None");

                    }
                }

                var aCycleEventDbData = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesEvtDataNav");
                var iCycleEventsDbError = 0;
                for (var i = 0; i < aCycleEventDbData.length; i++) {
                    var lossCat = aCycleEventDbData[i].lossCat;
                    var subCat = aCycleEventDbData[i].subCat;
                    var crewSize = Number(aCycleEventDbData[i].expectedCrewSize);
                    var ExpFrequency = Number(aCycleEventDbData[i].expectedFreqPerCycle);
                    var ExpEventDur = Number(aCycleEventDbData[i].expectedEvtDur);

                    if (lossCat == "") {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateLossCat", "Error");
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateTextLossCat", "Select/Enter the loss category");
                        iCycleEventsDbError = 1;
                    } else {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateLossCat", "None");
                    }
                    if (subCat == "") {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateSubCat", "Error");
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateTextSubCat", "Select/Enter the sub category");
                        iCycleEventsDbError = 1;
                    } else {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateSubCat", "None");
                    }
                    if (ExpFrequency == "") {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateExpFrequency", "Error");
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateTextExpFrequency", "Enter the expected frequency");
                        iCycleEventsDbError = 1;
                    } else {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateExpFrequency", "None");
                    }
                    if (ExpEventDur == "") {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateExpEventDur", "Error");
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateTextExpEventDur", "Enter the expected event duration");
                        iCycleEventsDbError = 1;
                    } else {
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/valueStateExpEventDur", "None");
                    }
                }

                var acycleAnnualEventDbLen = this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav");
                var iCycleAnnualDbError = 0;
                if (acycleAnnualEventDbLen != undefined) {
                    for (var i = 0; i < acycleAnnualEventDbLen.length; i++) {
                        var lossCat = acycleAnnualEventDbLen[i].lossCat;
                        var subCat = acycleAnnualEventDbLen[i].subCat;
                        var crewSize = Number(acycleAnnualEventDbLen[i].expectedCrewSize);
                        var ExpFrequency = Number(acycleAnnualEventDbLen[i].expectedFrequency);
                        var ExpEventDur = Number(acycleAnnualEventDbLen[i].expectedEvtDur);
                        var cycleInYear = Number(acycleAnnualEventDbLen[i].cyclesInYear);

                        if (lossCat == "") {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateLossCat", "Error");
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateTextLossCat", this.oResourceBundle.getText("ERROR_LOSS_CATEGORY"));
                            iCycleAnnualDbError = 1;
                        } else {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateLossCat", "None");
                        }
                        if (subCat == "") {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateSubCat", "Error");
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateTextSubCat", this.oResourceBundle.getText("ERROR_SUB_CATEGORY"));
                            iCycleAnnualDbError = 1;
                        } else {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateSubCat", "None");
                        }
                        if (crewSize == "") {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateCrewSize", "Error");
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateTextCrewSize", this.oResourceBundle.getText("ERROR_EXPECTED_CREWSIZE"));
                            iCycleAnnualDbError = 1;
                        } else {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateCrewSize", "None");
                        }
                        if (ExpFrequency == "") {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateExpFrequency", "Error");
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateTextExpFrequency", this.oResourceBundle.getText("ERROR_EXPECTED_FREQUENCY"));
                            iCycleAnnualDbError = 1;
                        } else {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateExpFrequency", "None");
                        }
                        if (ExpEventDur == "") {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateExpEventDur", "Error");
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateTextExpEventDur", this.oResourceBundle.getText("ERROR_EXPECTED_DURATION"));
                            iCycleAnnualDbError = 1;
                        } else {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateExpEventDur", "None");
                        }
                        if (cycleInYear == "") {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateCycleInYear", "Error");
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateTextCycleInYear", this.oResourceBundle.getText("ERROR_CYCLE_IN_YEAR"));
                            iCycleAnnualDbError = 1;
                        } else {
                            this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/valueStateCycleInYear", "None");
                        }
                    }
                }

                if (dValidTo == null || iCycleDbError == 1 || iCycleEventsDbError == 1 || iCycleAnnualDbError == 1) {
                    var step = "";
                    if (dValidTo == null) {
                        step = step + " step1";
                    }
                    if (iCycleDbError == 1) {
                        step = step + " step2";
                    }
                    if (iCycleEventsDbError == 1) {
                        step = step + " step3";
                    }
                    if (iCycleAnnualDbError == 1) {
                        step = step + " step4";
                    }
                    MessageToast.show(this.oResourceBundle.getText("MAND_LINE_ERROR_FIELDS") + " " + step);
                } else {

                    ///////////////////////////////////////////////////////// Validation End ////////////////////////////////////////////////////////
                    sap.ui.getCore().byId("wizardNavContainerUpdate").to(sap.ui.getCore().byId("wizardReviewPageUpdate"));

                    var avgProdCycle, avgShiftInDay, avgShiftInCycle, avgCycleHours, shiftlength = 0, totOccupiedTime = 0, cycleInYearInt = 0,
                        shiftInCycleInt = 0, cycleHoursInt = 0, totOccupiedTimeInt = 0, shiftInCycle = 0, cycleHours = 0,
                        totOccupiedTime = 0, cycleInYear = 0, shiftInDayInt = 0, prodCycleInt = 0, shiftInDay = 0, prodCycle = 0, iLineApproveSelIndex;

                    var aRow = this.getView().getModel("lineStandardUpdateModel").getData().LineHdrToCyclesDataNav.length;
                    for (var i = 0; i < aRow; i++) {
                        shiftInDayInt = Number(this.getView().getModel("lineStandardUpdateModel").getData().LineHdrToCyclesDataNav[i].shiftsInDays);
                        prodCycleInt = Number(this.getView().getModel("lineStandardUpdateModel").getData().LineHdrToCyclesDataNav[i].prodCyclesInDays)
                        shiftInDay = Number(this.getView().getModel("lineStandardUpdateModel").getData().LineHdrToCyclesDataNav[i].shiftsInDays) + shiftInDay;
                        prodCycle = Number(this.getView().getModel("lineStandardUpdateModel").getData().LineHdrToCyclesDataNav[i].prodCyclesInDays) + prodCycle;
                        shiftlength = Number(this.getView().getModel("lineStandardUpdateModel").getData().LineHdrToCyclesDataNav[i].shiftLength);
                        cycleInYearInt = Number(this.getView().getModel("lineStandardUpdateModel").getData().LineHdrToCyclesDataNav[i].cyclesInYear);

                        // calculcated fields not shown in cycles db screen
                        shiftInCycleInt = Number((shiftInDayInt * prodCycleInt).toFixed(3));
                        cycleHoursInt = Number((shiftInCycleInt * shiftlength).toFixed(3));
                        totOccupiedTimeInt = Number((cycleHoursInt * cycleInYearInt).toFixed(3));

                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/shiftsInCycle", shiftInCycleInt);
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/cycleHrs", cycleHoursInt);
                        this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesDataNav/" + i + "/totalOccupiedTime", totOccupiedTimeInt);

                        shiftInCycle = Number((shiftInCycleInt + shiftInCycle).toFixed(3));
                        cycleHours = Number((cycleHoursInt + cycleHours).toFixed(3));
                        totOccupiedTime = Number((totOccupiedTimeInt + totOccupiedTime).toFixed(3));
                        cycleInYear = Number((cycleInYearInt + cycleInYear).toFixed(3));
                    }

                    // fields show in headers
                    avgProdCycle = Number((prodCycle / aRow).toFixed(3));
                    avgShiftInDay = Number((shiftInDay / aRow).toFixed(3));
                    // avgShiftInCycle = Number((shiftInCycle / aRow).toFixed(3));
                    avgShiftInCycle = Number((avgShiftInDay * avgProdCycle).toFixed(3));

                    avgCycleHours = Number((totOccupiedTime / cycleInYear).toFixed(3));
                    //avgCycleHours = Number((totOccupiedTime / avgShiftInCycle).toFixed(3));
                    totOccupiedTime = Number((totOccupiedTime.toFixed(3)));

                    this.getView().getModel("lineStandardUpdateModel").setProperty("/validTo", this._fnDateFormat(sap.ui.getCore().byId("idStandardHeaderValidTo").getDateValue()));
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/modifiedFrom", this._fnDateFormat(sap.ui.getCore().byId("idStandardHeaderupdateModifiedFrom").getDateValue()));
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/prodCyclesInDays", avgProdCycle);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/shiftsInDay", avgShiftInDay);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/shiftsInCycle", avgShiftInCycle);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/cycleHrs", avgCycleHours);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/totalOccupiedTime", totOccupiedTime);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/cyclesInYear", cycleInYear);
                    var oPostData = this.getView().getModel("lineStandardUpdateModel").getData();
                    var EditCycleEventTotPlanDtLoss = 0, EditAnnualCycleEventTotPlanDtLoss = 0;
                    var LineHdrToCyclesEvtDataNav = [];
                    for (var i = 0; i < oPostData.LineHdrToCyclesEvtDataNav.length; i++) {
                        var oTemp = {};

                        oTemp.ID = oPostData.LineHdrToCyclesEvtDataNav[i].ID;
                        oTemp.lossCat = oPostData.LineHdrToCyclesEvtDataNav[i].lossCat;
                        oTemp.subCat = oPostData.LineHdrToCyclesEvtDataNav[i].subCat;
                        oTemp.expectedCrewSize = oPostData.LineHdrToCyclesEvtDataNav[i].expectedCrewSize;
                        oTemp.expectedFreqPerCycle = oPostData.LineHdrToCyclesEvtDataNav[i].expectedFreqPerCycle;
                        oTemp.expectedEvtDur = oPostData.LineHdrToCyclesEvtDataNav[i].expectedEvtDur;
                        oTemp.cycleHrs = oPostData.LineHdrToCyclesEvtDataNav[i].cycleHrs;
                        // oTemp.cyclesInYear = oPostData.LineHdrToCyclesEvtDataNav[i].cyclesInYear;
                        oTemp.cyclesInYear = cycleInYear;
                        oTemp.expectedDurPerCycle = oPostData.LineHdrToCyclesEvtDataNav[i].expectedDurPerCycle;
                        oTemp.expectedLbrHrsPerCycle = oPostData.LineHdrToCyclesEvtDataNav[i].expectedLbrHrsPerCycle;
                        oTemp.expectedTotLbrHrs = oPostData.LineHdrToCyclesEvtDataNav[i].expectedTotLbrHrs;
                        oTemp.plannedDtLoss = oPostData.LineHdrToCyclesEvtDataNav[i].plannedDtLoss;
                        //3-09-2024 rightnow required in poc
                        oTemp.status = "Modified"

                        oTemp.expectedDurPerCycle = Number(Number(oTemp.expectedFreqPerCycle * oTemp.expectedEvtDur * oTemp.cyclesInYear).toFixed(3));
                        oTemp.expectedLbrHrsPerCycle = Number(Number(oTemp.expectedCrewSize * oTemp.expectedDurPerCycle).toFixed(3));
                        oTemp.cyclesInYear = Number(Number(oPostData.cyclesInYear).toFixed(3));
                        oTemp.expectedTotLbrHrs = Number(Number(oTemp.cyclesInYear * oTemp.expectedLbrHrsPerCycle).toFixed(3));
                        oTemp.cycleHrs = Number(Number(oPostData.cycleHrs).toFixed(3));
                        oTemp.plannedDtLoss = Number(Number(((oTemp.expectedDurPerCycle / oPostData.totalOccupiedTime) * oPostData.cyclesInYear) * 100).toFixed(3));

                        EditCycleEventTotPlanDtLoss = EditCycleEventTotPlanDtLoss + oTemp.plannedDtLoss;

                        LineHdrToCyclesEvtDataNav.push(oTemp);

                    }
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav", LineHdrToCyclesEvtDataNav);
                    var LineHdrToAnnualEvtDataNav = [];
                    for (var i = 0; i < oPostData.LineHdrToAnnualEvtDataNav.length; i++) {
                        var oTemp = {};
                        oTemp.ID = oPostData.LineHdrToAnnualEvtDataNav[i].ID;
                        oTemp.cyclesInYear = oPostData.LineHdrToAnnualEvtDataNav[i].cyclesInYear;
                        oTemp.expectedCrewSize = oPostData.LineHdrToAnnualEvtDataNav[i].expectedCrewSize;
                        oTemp.expectedDurPerYear = oPostData.LineHdrToAnnualEvtDataNav[i].expectedDurPerYear;
                        oTemp.expectedEvtDur = oPostData.LineHdrToAnnualEvtDataNav[i].expectedEvtDur;
                        oTemp.expectedFrequency = oPostData.LineHdrToAnnualEvtDataNav[i].expectedFrequency;
                        oTemp.expectedLbrHrPerYear = oPostData.LineHdrToAnnualEvtDataNav[i].expectedLbrHrPerYear;
                        oTemp.lossCat = oPostData.LineHdrToAnnualEvtDataNav[i].lossCat;
                        oTemp.plannedDtLoss = oPostData.LineHdrToAnnualEvtDataNav[i].plannedDtLoss;
                        oTemp.subCat = oPostData.LineHdrToAnnualEvtDataNav[i].subCat;
                        oTemp.totOccupiedHrs = oPostData.LineHdrToAnnualEvtDataNav[i].totOccupiedHrs;
                        //3-09-2024 rightnow required in poc
                        oTemp.status = "Modified"

                        oTemp.expectedDurPerYear = Number(Number(oTemp.expectedFrequency * oTemp.expectedEvtDur).toFixed(3));
                        oTemp.expectedLbrHrPerYear = Number(Number(oTemp.expectedCrewSize * oTemp.expectedDurPerYear).toFixed(3));
                        oTemp.totOccupiedHrs = Number(Number(oPostData.totalOccupiedTime).toFixed(3));
                        oTemp.plannedDtLoss = Number(Number((oTemp.expectedDurPerYear / oTemp.totOccupiedHrs) * 100).toFixed(3));

                        EditAnnualCycleEventTotPlanDtLoss = EditAnnualCycleEventTotPlanDtLoss + oTemp.plannedDtLoss;
                        LineHdrToAnnualEvtDataNav.push(oTemp);
                    }
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav", LineHdrToAnnualEvtDataNav);

                    var TotPlannedDTLoss = Number(Number(EditCycleEventTotPlanDtLoss + EditAnnualCycleEventTotPlanDtLoss).toFixed(3));
                    sap.ui.getCore().byId("idEditTotPlanDTLoss").setText(TotPlannedDTLoss);
                    this.getView().getModel("lineStandardUpdateModel").setProperty("/plannedDtLoss", TotPlannedDTLoss);
                    //////////////////////////////////////////////////////////////////////////////////////////////                 

                }

            },
            fnStandardArchiveConfirm: function () {
                var that = this;
                sap.m.MessageBox.confirm(that.oResourceBundle.getText("SELECT_LINE_STD_ARCHIVE_CONFORM"), {
                    title: "Confirm",
                    onClose: function (oAction) {
                        if (oAction === sap.m.MessageBox.Action.OK) {
                            that.fnStandardArchive();
                        }
                        else {
                            MessageToast.show(that.oResourceBundle.getText("ARCHIVE_CANCELED"))
                        }
                    },
                    actions: [sap.m.MessageBox.Action.OK,
                    sap.m.MessageBox.Action.CANCEL],
                    emphasizedAction: sap.m.MessageBox.Action.OK,
                    initialFocus: null,
                    textDirection: sap.ui.core.TextDirection.Inherit,
                    dependentOn: null
                });
            },


            fnStandardArchive: function () {
                var that = this;
                var lineStdNos = [];
                var getSelectedArcCount = this.getView().byId("idLineTable").getSelectedItems().length;
                for (var i = 0; i < getSelectedArcCount; i++) {
                    var sPath = this.getView().byId("idLineTable").getSelectedItems()[i].getBindingContext("lineStandardHeaderModel").sPath;
                    var oData = this.getView().getModel("lineStandardHeaderModel").getProperty(sPath);
                    var std = oData.lineStdNo;
                    lineStdNos.push(std);
                }
                var payload = {
                    lineStdNos: lineStdNos
                };
                var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
                var nbId = newData[0].Username;
                // Role assignment logic
                if ((role === 'C')|| (role === "S")) {
                    var currentRole = "Creator/Editor";
                } else if (role === 'A') {
                    var currentRole = "Approver";
                } else if (role === 'V' || role === 'E') {
                    var currentRole = "Executor/Viewer";
                }
                BusyIndicator.show();
                $.ajax({
                    url: "odata/v4/data-services/archiveLineStdItems",
                    type: "POST",
                    data: JSON.stringify(payload),
                    contentType: "application/json",
                    dataType: "json",
                    headers: {
                        "x-username": nbId,
                        "x-role": currentRole
                    }
                }).done(function (_response) {
                    BusyIndicator.hide();
                    MessageToast.show(that.oResourceBundle.getText("LINE_STD_ARCHIVED"));
                    var message = that.oResourceBundle.getText("SELECT_LINE_ARCHIVED_SUCCESS");
                    that.onShowSuccess(message);
                    
                    that.fnReadLineStdHeaderTableData();
                    //initial setting for Line table button
                    that.getView().byId("idLineTable").removeSelections(true);
                    that.getView().byId("idLineCopyCreate").setEnabled(false);
                    that.getView().byId("idArchive").setEnabled(false);
                    that.getView().byId("idCreate").setEnabled(true);
                    that.getView().byId("idSubmitForApproval").setEnabled(false);
                }).fail(function (xhr, _status, _error) {
                    BusyIndicator.hide();
                    MessageToast.show(xhr.responseJSON.error.message + "" + that.oResourceBundle.getText("LINE_STD_ARCHIVED_FAIL"));
                    var message = that.oResourceBundle.getText("SELECT_LINE_ARCHIVED_FAIL") + "\n" + xhr.responseJSON.error.code + ":" + xhr.responseJSON.error.message;
                    that.onShowError(message);
                    //initial setting for Line table button
                    that.getView().byId("idLineTable").removeSelections(true);
                    that.getView().byId("idLineCopyCreate").setEnabled(false);
                    that.getView().byId("idArchive").setEnabled(false);
                    that.getView().byId("idCreate").setEnabled(true);
                    that.getView().byId("idSubmitForApproval").setEnabled(false);
                });
            },
            handleChangeValidFrom: function (oEvent) {
                var sFrom = this._fnDateFormat(oEvent.getParameter("from")),
                    sTo = this._fnDateFormat(oEvent.getParameter("to"));
                this.getView().getModel("LineStandardFilterModel").setProperty("/validFrom", { from: sFrom, to: sTo });
            },
            handleChangeModifiedFrom: function (oEvent) {
                var sFrom = this._fnDateFormat(oEvent.getParameter("from")),
                    sTo = this._fnDateFormat(oEvent.getParameter("to"));
                this.getView().getModel("LineStandardFilterModel").setProperty("/validFrom", { from: sFrom, to: sTo });
            },
            handleChangeValidTo: function (oEvent) {
                var sFrom = this._fnDateFormat(oEvent.getParameter("from")),
                    sTo = this._fnDateFormat(oEvent.getParameter("to"));
                this.getView().getModel("LineStandardFilterModel").setProperty("/validTo", { from: sFrom, to: sTo });
            },
            handleChangeCreatedOn: function (oEvent) {
                var sFrom = this._fnDateFormat(oEvent.getParameter("from")),
                    sTo = this._fnDateFormat(oEvent.getParameter("to"));
                this.getView().getModel("LineStandardFilterModel").setProperty("/createdOn", { from: sFrom, to: sTo });
            },
            handleChangeLastChangedOn: function (oEvent) {
                var sFrom = this._fnDateFormat(oEvent.getParameter("from")),
                    sTo = this._fnDateFormat(oEvent.getParameter("to"));
                this.getView().getModel("LineStandardFilterModel").setProperty("/lastChangedOn", { from: sFrom, to: sTo });
            },
            onRoleSheetButtonPress: function(oEvent){
                var oButton = oEvent.getSource();
			    this.byId("actionSheet").openBy(oButton);
                var newData = sap.ui.getCore().getModel("loginUserModel").getData();
                for (var i = 0; i< newData.results.length; i++){
                    var authType = newData.results[i].AuthType;
                    if (authType === "C"){
                        this.getView().byId("creatorId").setVisible(true);
                    }else if (authType === "V"){
                        this.getView().byId("viewerId").setVisible(true);
                    }else if (authType === "S"){
                        this.getView().byId("semicreatorId").setVisible(false);
                    }else{
                    this.getView().byId("approverId").setVisible(true);
                    }
                }
            },
            fnGetCreatorData: function(){
                BusyIndicator.show(0);             
                role = "C";
                this.fnReadLineStdHeaderTableData();              
            },
            fnGetViewerData: function(){
                role = "V";
                this.fnReadLineStdViewerTableData();                      
            },
            fnGetApproverData: function(){
                BusyIndicator.show(0);               
                role = "A";
                this.fnReadLineStdApproverTableData();
            },
            fnGetSemicreatorData: function(){
                BusyIndicator.show(0);
                role = "S";
                this.fnReadLineStdHeaderTableData();
            },
            fnGetExecutorData: function(){
                BusyIndicator.show(0);
                role = "E";
                this.fnReadLineStdExecutorTableData();
            },
            onRefreshData: function(){
                if (role === "V"){
                    this.fnReadLineStdViewerTableData();
                }else if ((role === "C") || (role === "S")){      
                    this.fnReadLineStdHeaderTableData();
                }else if (role === "A"){
                    this.fnReadLineStdApproverTableData();
                }else{
                    this.fnReadLineStdExecutorTableData();
                }
        }
        });
    });