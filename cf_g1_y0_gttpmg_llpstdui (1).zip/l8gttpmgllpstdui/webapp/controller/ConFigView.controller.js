sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	'sap/ui/core/BusyIndicator',
	'sap/m/MessageToast',
	"l8gttpmgllpstdui/controller/BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function (_Controller, _History, BusyIndicator, MessageToast, BaseController, Filter, FilterOperator, MessageBox) {
		"use strict";
		var tableIndex, oODataModel, apikey, toggle = 1;
		var mHeaders = [];
		return BaseController.extend("l8gttpmgllpstdui.controller.ConFigView", {
			onInit: function () {
				const oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				const oHistory = sap.ui.core.routing.History.getInstance();
				const sPreviousHash = oHistory.getPreviousHash();
				this.oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				oODataModel = this.getOwnerComponent().getModel();
				this.onPlantLoadData();
				oRouter.getRoute("ConFigView").attachPatternMatched(this.onObjectMatched, this);
				// If there is no previous hash, navigate to HomeView
				if (sPreviousHash === undefined) {
					oRouter.navTo("RouteHomeView", true);
				} else {
					oRouter.getRoute("LineStandardView").attachPatternMatched(this.onObjectMatched, this);
				}
				var sStandardUrl = "odata/v4/data-services/ListOptionTxt?$filter=setId eq 'STANDARD_TYPE'&$orderby=auditInfoCreatedOn asc&$select=label,ID";
				$.ajax({
					url: sStandardUrl,
					method: "GET",
					success: function (oData) {
						// Prepare the model data
						var aStandardData = oData.value.map(function (item) {
							return { standard: item.label };
						});

						// Bind the data to the standardModel
						var oStandardModel = new sap.ui.model.json.JSONModel({ data: aStandardData });
						this.getView().setModel(oStandardModel, "standardModel");
						this.getOwnerComponent().setModel(oStandardModel, "standardModel");
					}.bind(this),
					error: function (oError) {
						console.error("Error fetching Standard Type data:", oError);
						MessageToast.show(this.oResourceBundle.getText("ERROR_FETCHING_STANDARD_TYPE"));
					}.bind(this),
				});

			},
			onObjectMatched(_oEvent) {
				var parts = sap.ui.core.routing.History.getInstance().getPreviousHash().split('/');    
               var firstPart = parts[0];
               if(firstPart !== "specificConFigView"){
				this.fnReadConfigurationData();
				oODataModel = this.getOwnerComponent().getModel();
				this.getView().byId("idConfigTable").clearSelection();
				this.getView().byId("idConfigEdit").setVisible(true);
				this.getView().byId("idConfigDelete").setVisible(true);
				this.getView().byId("idConfigSubmit").setVisible(false);
				this.getView().byId("idConfigCancel").setVisible(false);
				this.getView().byId("idConfigAdd").setEnabled(true);
				this.getView().byId("idConfigPane").setVisible(true);
				this.getView().byId("idConfigPane").setExpanded(false);
				this.getView().byId("idConfigPlantComboBox").setValue("");
				this.getView().byId("idStandardTypeComboBox").setSelectedItems([]);
				this.getView().byId("idConfigResourceComboBox").setValue("");
				this.getView().byId("idConfigCostCenterFilter").setValue("");
				this.getView().byId("idApprovalSlaInput").setValue("");
				this.getView().byId("idExecutionSlaInput").setValue("");
				this.getView().byId("idRevisionPeriodInput").setValue("");
				this.getView().byId("idArchivingPeriodInput").setValue("");

				//Model created to display data in the create popup standard field dropdown
				var standardTypeModel = new sap.ui.model.json.JSONModel();
				standardTypeModel.setData({ "standardTypeData": [{ StandardType: "Line Standard" }, { StandardType: "Product Standard" }] });
				this.getView().setModel(standardTypeModel, "standardTypeModel");
				var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
				var nbId = newData[0].Username;
				// var role = newData[0].AuthType;
				var zone = newData[0].Zone;
				var currentURL = window.location.href;
				var url = new URL(currentURL);
				var host = url.host;
				var oResourceBundle = this.getView().getModel("util").getResourceBundle();
				if (host.startsWith("dev") || host.startsWith("poc")) {
					apikey = oResourceBundle.getText("apiKey_Dev");
				} else if (host.startsWith("ppd")) {
					apikey = oResourceBundle.getText("apiKey_PPD");
				} else {
					apikey = oResourceBundle.getText("apiKey_PRD");
				}
				var alias = zone === "AOA" ? oResourceBundle.getText("zoneAOA_Alias") :
					zone === "EUR" ? oResourceBundle.getText("zoneEUR_Alias") :
						zone === "AMS" ? oResourceBundle.getText("zoneAMS_Alias") :
							"";
				mHeaders = {
					"apikey": apikey,
					"username": nbId,
					"sysali": alias
				};
			}
		},
			onconfigfilerpress: function () {
				if (toggle == 1) {
					this.getView().byId("idConfigPane").setVisible(true);
					this.getView().byId("idConfigPane").setExpanded(true);
					this.getView().byId("idConfigBox").setVisible(true);
					this.getView().byId("idconfigBox21").setVisible(true);
					this.getView().byId("idconfigPanelOverflowToolbar").setVisible(true);
					toggle = 2;
				} else if (toggle == 2) {
					this.getView().byId("idConfigPane").setVisible(true);
					this.getView().byId("idConfigPane").setExpanded(false);
					toggle = 1;
					this.getView().byId("idConfigBox").setVisible(false);
					this.getView().byId("idconfigBox21").setVisible(false);
					this.getView().byId("idconfigPanelOverflowToolbar").setVisible(false);
				}
			},

			// function to enable edit and delete button,called when a row is selected in the table 
			fnConfigTableRowSelected: function (_evt) {
				var aRowSelected = this.getView().byId("idConfigTable").getSelectedIndices();
				if (aRowSelected.length > 0) {
					this.getView().byId("idConfigEdit").setEnabled(true);
					this.getView().byId("idConfigDelete").setEnabled(true);
					this.getView().byId("idConfigAdd").setEnabled(false);
				} else {
					this.getView().byId("idConfigEdit").setEnabled(false);
					this.getView().byId("idConfigDelete").setEnabled(false);
					this.getView().byId("idConfigAdd").setEnabled(true);
				}
			},
			// function to read data for the configuration table
			fnReadConfigurationData: function (sUrl) {
				var that = this;
				BusyIndicator.show();
				if (!sUrl) {
					sUrl = "odata/v4/data-services/ConfigurationHeadersDB?$orderby=auditInfoModifiedOn desc";
				}
				$.get(sUrl).done(function (data) {
					// 'data' here should contain the response from the OData endpoint                   
					BusyIndicator.hide();
					// Process or display the 'data' object as needed
					var oTableModel = new sap.ui.model.json.JSONModel(data)
					that.getView().setModel(oTableModel, "configModel");
					//Setting model at component level
					that.getOwnerComponent().setModel(oTableModel, "configModel");
					MessageToast.show(that.oResourceBundle.getText("CONFIG_LOADED_SUCCESS"));
					// alert(JSON.stringify(data)); // Convert data to string for alert
				}).fail(function (_xhr, _status, _error) {
					BusyIndicator.hide();
					// Handle errors if the request fails
					MessageToast.show(that.oResourceBundle.getText("CONFIG_LOADING_FAIL"));
				});
			},
			onPlantLoadData: function () {
				var url = "/ETY_PLANT_SHSet";
				if (oODataModel) {
					oODataModel.read(url, {
						headers: mHeaders,
						success: function (oData) {
							var oModelPlant = new sap.ui.model.json.JSONModel();
							oModelPlant.setData(oData);
							oModelPlant.setSizeLimit(3000);
							this.getView().setModel(oModelPlant, "plantModel1");
							MessageToast.show(this.oResourceBundle.getText("PLANT_DATA_SUCCESS"));
						}.bind(this),
						error: function (oError) {
							// Handle errors
							MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_LOAD_PLANT"), oError);
						}.bind(this),
					});
				} else {
					MessageToast.show(this.oResourceBundle.getText("ERROR_ODATA_FAIL"));
				}
			},
			onNavBack: function (_oEvent) {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("RouteHomeView", true);
			},

			// function to navigate to specific config view
			fnMenu: function (evt) {
				var tableIndex = evt.getSource().getBindingContext("configModel").sPath.slice(7);
				var sSelectedConfigNo = this.getView().getModel("configModel").getProperty("/value/" + tableIndex + "/configNo");
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("specificConFigView", { configNo: sSelectedConfigNo }, true);
			},
			fnAdd: function (_evt) {
				if (!this._oPopover4) {
					this._oPopover4 = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.ConfigCreate", this);
					this.getView().addDependent(this._oPopover4);
				}
				this._oPopover4.open();
			},
			onConfigSearchPress: function () {
				var oView = this.getView();
				var sUrl = "odata/v4/data-services/ConfigurationHeadersDB?$orderby=auditInfoModifiedOn desc&$filter=(";

				var oPlantComboBox = oView.byId("idConfigPlantComboBox").getSelectedKey();
				var count = 0;
				if (oPlantComboBox != "") {
					sUrl = sUrl + "contains(plant,'" + oPlantComboBox + "')";
					count++;
				}
				var oResourceComboBox = oView.byId("idConfigResourceComboBox").getValue();
				if (oResourceComboBox != "") {
					if (count != 0) {
						sUrl = sUrl + " and contains(resource,'" + oResourceComboBox + "')"
					}
					else {
						sUrl = sUrl + " contains(resource,'" + oResourceComboBox + "')";
						count++;
					}
				}
				var oCostCenterMultiComboBox = oView.byId("idConfigCostCenterFilter").getValue();
				if (oCostCenterMultiComboBox != "") {
					if (count != 0) {
						sUrl = sUrl + " and contains(costCenter,'" + oCostCenterMultiComboBox + "')";
					}
					else {
						sUrl = sUrl + " contains(costCenter,'" + oCostCenterMultiComboBox + "')";
						count++;
					}

				}
				var oStandardComboBox = oView.byId("idStandardTypeComboBox").getSelectedItems();
				if (oStandardComboBox.length > 0) {
					for (var i = 0; i < oStandardComboBox.length; i++) {
						if (count != 0) {
							if (i == 0) {
								sUrl = sUrl + " and (standardType eq '" + oStandardComboBox[i].mProperties.text + "'";
							}
							else {
								sUrl = sUrl + " or standardType eq '" + oStandardComboBox[i].mProperties.text + "'";
							}

						}
						else {
							sUrl = sUrl + "(standardType eq '" + oStandardComboBox[i].mProperties.text + "'";
							count++;
						}
						if (i == oStandardComboBox.length - 1) {
							sUrl = sUrl + ")";
						}

					}
				}
				var iValid = 0;
				if (this.getView().byId("idApprovalSlaInput").getValue() != "") {
					var sApprslaindays = this.getView().byId("idApprovalSlaInput").getValue();
					var patternRange = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                    var patternComma = /^[0-9]*(\.\d{1,3})?(,[0-9]*(\.\d{1,3})?)*$/;
					if (patternRange.test(sApprslaindays)) {
                        this.getView().byId("idApprovalSlaInput").setValueState("None");
                        var sApprslaindaysList = sApprslaindays.split('-');
                    if (sApprslaindaysList.length === 2) {
                        var sApprslaindaysMin = sApprslaindaysList[0];
                        var sApprslaindaysMax = sApprslaindaysList[1];
                    }
                    if (count !== 0) {
                        sUrl = sUrl + " and approvalSLAInDays ge " + sApprslaindaysMin + " and approvalSLAInDays le " + sApprslaindaysMax;
                    }
                    else {
                        sUrl = sUrl + " approvalSLAInDays ge " + sApprslaindaysMin + " and approvalSLAInDays le " + sApprslaindaysMax;
                        count++;
                    }
					}
					else if (patternComma.test(sApprslaindays)) {
						this.getView().byId("idApprovalSlaInput").setValueState("None");
	
						var aValues = sApprslaindays.split(',');
						var sOrConditions = aValues.map(function (value) {
							return "approvalSLAInDays eq " + value.trim();
						}).join(" or ");
	
						if (count != 0) {
							sUrl = sUrl + " and (" + sOrConditions + ")";
						} else {
							sUrl = sUrl + " (" + sOrConditions + ")";
							count++;
						}
					} else {
						this.getView().byId("idApprovalSlaInput").setValueState("Error");
						this.getView().byId("idApprovalSlaInput").setValueStateText("Enter a valid range like 1-2 or Coma seperator like (1,2), only integers allowed, no decimals or letters.");
						iValid = 1;
					}
				}
				if (this.getView().byId("idExecutionSlaInput").getValue() != "") {
					var sExesladays = this.getView().byId("idExecutionSlaInput").getValue();
					var patternRange = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                    var patternComma = /^[0-9]*(\.\d{1,3})?(,[0-9]*(\.\d{1,3})?)*$/;
					if (patternRange.test(sExesladays)) {
                        this.getView().byId("idExecutionSlaInput").setValueState("None");
                        var sExesladaysList = sExesladays.split('-');
                    if (sExesladaysList.length === 2) {
                        var executionSLAInDaysMin = sExesladaysList[0];
                        var executionSLAInDaysMax = sExesladaysList[1];
                    }
                    if (count !== 0) {
                        sUrl = sUrl + " and executionSLAInDays ge " + executionSLAInDaysMin + " and executionSLAInDays le " + executionSLAInDaysMax;
                    }
                    else {
                        sUrl = sUrl + " executionSLAInDays ge " + executionSLAInDaysMin + " and executionSLAInDays le " + executionSLAInDaysMax;
                        count++;
                    }
					}else if (patternComma.test(sExesladays)) {
						this.getView().byId("idExecutionSlaInput").setValueState("None");
	
						var aValues = sExesladays.split(',');
						var sOrConditions = aValues.map(function (value) {
							return "executionSLAInDays eq " + value.trim();
						}).join(" or ");
	
						if (count != 0) {
							sUrl = sUrl + " and (" + sOrConditions + ")";
						} else {
							sUrl = sUrl + " (" + sOrConditions + ")";
							count++;
						}
					}
				    else {
						this.getView().byId("idExecutionSlaInput").setValueState("Error");
						this.getView().byId("idExecutionSlaInput").setValueStateText("Enter a valid range like 1-2 or Coma seperator like (1,2), only integers allowed, no decimals or letters.");
						iValid = 1;
					}
				}
				if (this.getView().byId("idRevisionPeriodInput").getValue() != "") {
					var sRevperiodmonth = this.getView().byId("idRevisionPeriodInput").getValue();
					var patternRange = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                    var patternComma = /^[0-9]*(\.\d{1,3})?(,[0-9]*(\.\d{1,3})?)*$/;
					if (patternRange.test(sRevperiodmonth)) {
                        this.getView().byId("idRevisionPeriodInput").setValueState("None");
                        var sRevperiodmonthsList = sRevperiodmonth.split('-');
                    if (sRevperiodmonthsList.length === 2) {
                        var revisionPrdMnthMin = sRevperiodmonthsList[0];
                        var revisionPrdMnthMax = sRevperiodmonthsList[1];
                    }
                    if (count !== 0) {
                        sUrl = sUrl + " and revisionPrdMnth ge " + revisionPrdMnthMin + " and revisionPrdMnth le " + revisionPrdMnthMax;
                    }
                    else {
                        sUrl = sUrl + " revisionPrdMnth ge " + revisionPrdMnthMin + " and revisionPrdMnth le " + revisionPrdMnthMax;
                        count++;
                    }
					}else if (patternComma.test(sRevperiodmonth)) {
						this.getView().byId("idRevisionPeriodInput").setValueState("None");
	
						var aValues = sRevperiodmonth.split(',');
						var sOrConditions = aValues.map(function (value) {
							return "revisionPrdMnth eq " + value.trim();
						}).join(" or ");
	
						if (count != 0) {
							sUrl = sUrl + " and (" + sOrConditions + ")";
						} else {
							sUrl = sUrl + " (" + sOrConditions + ")";
							count++;
						}
					}
					 else {
						this.getView().byId("idRevisionPeriodInput").setValueState("Error");
						this.getView().byId("idRevisionPeriodInput").setValueStateText("Enter a valid range like 1-2 or Coma seperator like (1,2), only integers allowed, no decimals or letters.");
						iValid = 1;
					}
				}
				if (this.getView().byId("idArchivingPeriodInput").getValue() != "") {
					var sArchivingmonth = this.getView().byId("idArchivingPeriodInput").getValue();
					var patternRange = /^[0-9]*(\.\d{1,3})?\-[0-9]*(\.\d{1,3})?$/;
                    var patternComma = /^[0-9]*(\.\d{1,3})?(,[0-9]*(\.\d{1,3})?)*$/;
					if (patternRange.test(sArchivingmonth)) {
                        this.getView().byId("idRevisionPeriodInput").setValueState("None");
                        var sArchivingmonthList = sArchivingmonth.split('-');
                    if (sArchivingmonthList.length === 2) {
                        var archivingPrdMnthMin = sArchivingmonthList[0];
                        var archivingPrdMnthMax = sArchivingmonthList[1];
                    }
                    if (count !== 0) {
                        sUrl = sUrl + " and archivingPrdMnth ge " + archivingPrdMnthMin + " and archivingPrdMnth le " + archivingPrdMnthMax;
                    }
                    else {
                        sUrl = sUrl + " archivingPrdMnth ge " + archivingPrdMnthMin + " and archivingPrdMnth le " + archivingPrdMnthMax;
                        count++;
                    }
					}else if (patternComma.test(sArchivingmonth)) {
						this.getView().byId("idArchivingPeriodInput").setValueState("None");
	
						var aValues = sArchivingmonth.split(',');
						var sOrConditions = aValues.map(function (value) {
							return "archivingPrdMnth eq " + value.trim();
						}).join(" or ");
	
						if (count != 0) {
							sUrl = sUrl + " and (" + sOrConditions + ")";
						} else {
							sUrl = sUrl + " (" + sOrConditions + ")";
							count++;
						}
					}
					 else {
						this.getView().byId("idArchivingPeriodInput").setValueState("Error");
						this.getView().byId("idArchivingPeriodInput").setValueStateText("Enter a valid range like 1-2 or Coma Seperator like (1,2), only integers allowed, no decimals or letters.");
						iValid = 1;
					}
				}
				sUrl = sUrl + ")";
				if (iValid === 0) {
					var allFieldsEmpty = true;
					var mandatoryFields = [
						"idConfigPlantComboBox", "idConfigResourceComboBox",
						"idConfigCostCenterFilter", "idApprovalSlaInput", "idExecutionSlaInput",
						"idRevisionPeriodInput", "idArchivingPeriodInput"
					];
					mandatoryFields.forEach(function (fieldId) {
						var fieldValue = oView.byId(fieldId).getValue();
						if (fieldValue && fieldValue.trim() !== "") {
							allFieldsEmpty = false;
						}
					});
					// Special handling for MultiComboBox (idStandardTypeComboBox)
					var selectedItems = oView.byId("idStandardTypeComboBox").getSelectedItems();
					if (selectedItems && selectedItems.length > 0) {
						allFieldsEmpty = false;
					}

					if (allFieldsEmpty) {
						var message = this.oResourceBundle.getText("BLANK_PRODSTD_SEARCH");
						this.onShowWarning(message);
					} else {
						this.fnReadConfigurationData(sUrl);
					}
				}
			},
			onConfigFilterReset: function () {
				var oView = this.getView();
				var aFieldsToReset = [
					"idConfigPlantComboBox", "idStandardTypeComboBox", "idConfigResourceComboBox",
					"idConfigCostCenterFilter", "idApprovalSlaInput", "idExecutionSlaInput",
					"idRevisionPeriodInput", "idArchivingPeriodInput", "idStandardTypeComboBox"
				];
				aFieldsToReset.forEach(function (sId) {
					var oField = oView.byId(sId);
					if (oField) {
						oField.setValue('');
					}
				});
				this.getView().byId("idApprovalSlaInput").setValueState("None");
				this.getView().byId("idExecutionSlaInput").setValueState("None");
				this.getView().byId("idRevisionPeriodInput").setValueState("None");
				this.getView().byId("idArchivingPeriodInput").setValueState("None");
				var oStandardComboBox = oView.byId("idStandardTypeComboBox");
				if (oStandardComboBox) {
					oStandardComboBox.setSelectedItems([]);
				}
				var oResourceModel = this.getView().getModel("resourceModel");
				if (oResourceModel) {
					var aResults = oResourceModel.getProperty("/results");

					if (aResults) {
						oResourceModel.setProperty("/results", []);
					} else {
						oResourceModel.setData({ results: [] });
					}
				}
				this.fnReadConfigurationData();
			},
			fnPlantSelection: function () {
				sap.ui.getCore().byId("idConfigResource").setValue("");
				sap.ui.getCore().byId("idCostCenter").setValue("");
				var sPlant = sap.ui.getCore().byId("idConfigPlant").getValue();
				var url = "/ETY_RESOURCE_SHSet";
				var oFilterPlant = new Filter({
					filters: [
						new Filter("Werks", FilterOperator.EQ, sPlant)
					]
				});
				if (oODataModel) {
					oODataModel.read(url, {
						headers: mHeaders,
						filters: [oFilterPlant],
						success: function (oData) {
							// Create and set the JSONModel with the data received
							var oModelResource = new sap.ui.model.json.JSONModel();
							oModelResource.setData(oData);
							this.getView().setModel(oModelResource, "resourceModel");
						}.bind(this),
						error: function (oError) {
							// Handle errors
							MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
						}.bind(this),
					});
				} else {
					MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
				}
			},
			fnFilterPlantSelection: function () {
				var sPlant = this.getView().byId("idConfigPlantComboBox").getSelectedKey();
				this.getView().byId("idConfigResourceComboBox").setValue("");
				this.getView().byId("idConfigCostCenterFilter").setValue("");
				var url = "/ETY_RESOURCE_SHSet";
				var oFilterPlant = new Filter({
					filters: [
						new Filter("Werks", FilterOperator.EQ, sPlant)
					]
				});
				if (oODataModel) {
					oODataModel.read(url, {
						headers: mHeaders,
						filters: [oFilterPlant],
						success: function (oData) {
							// Create and set the JSONModel with the data received
							var oModelResource = new sap.ui.model.json.JSONModel();
							oModelResource.setData(oData);
							this.getView().setModel(oModelResource, "resourceModel");
						}.bind(this),
						error: function (oError) {
							// Handle errors
							MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
						}.bind(this),
					});
				} else {
					MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
				}
			},
			onResourceSelection: function () {
				var resource = sap.ui.getCore().byId("idConfigResource").getSelectedItem().getKey();
				var plant = sap.ui.getCore().byId("idConfigPlant").getSelectedItem().getKey();
				var url = `/ETY_CostCentre_ValueHelpSet(Werks='${plant}',Arbpl='${resource}')`;

				if (oODataModel) {
					oODataModel.read(url, {
						headers: mHeaders,
						success: function (oData) {
							// Create and set the JSONModel with the data received
							var oModelCostcenter = new sap.ui.model.json.JSONModel();
							oModelCostcenter.setData(oData);
							this.getView().setModel(oModelCostcenter, "costcenterModel");
						}.bind(this),
						error: function (oError) {
							// Handle errors
							MessageToast.show(this.oResourceBundle.getText("ERROR_FAIL_DATA"), oError);
						}.bind(this),
					});

				} else {
					MessageToast.show(this.oResourceBundle.getText("ERROR_ODATA_FAIL"));

				}
			},
			onFilterResourceSelection: function () {
				var that = this;
				var plant = this.getView().byId("idConfigPlantComboBox").getSelectedKey();
				var resource = this.getView().byId("idConfigResourceComboBox").getValue();
				if (resource === "") {
					this.getView().byId("idConfigCostCenterFilter").setValue();
				} else {
					var url = `/ETY_CostCentre_ValueHelpSet(Werks='${plant}',Arbpl='${resource}')`;
					BusyIndicator.show(0);
					if (oODataModel) {
						oODataModel.read(url, {
							headers: mHeaders,
							success: function (oData) {
								// Create and set the JSONModel with the data received
								var oModelCostcenter = new sap.ui.model.json.JSONModel();
								oModelCostcenter.setData(oData);
								this.getView().setModel(oModelCostcenter, "costcenterFilterModel");
								BusyIndicator.hide();
							}.bind(this),
							error: function (jqXHR) {
								let errorMessage = jqXHR.responseText ?
									JSON.parse(jqXHR.responseText).error.message.value : that.oResourceBundle.getText("UNKNOWN_ERROR_OCCURRED");
								// Handle errors
								MessageToast.show(that.oResourceBundle.getText("ERROR_FAIL_DATA") + " " + errorMessage);
								BusyIndicator.hide();
							}
						});

					} else {
						MessageToast.show(that.oResourceBundle.getText("ERROR_ODATA_FAIL"));
					}
				}
			},

			// Configuration screen create function           
			fnCreate: function (_evt) {
				var that = this;
				var splant = sap.ui.getCore().byId("idConfigPlant").getSelectedKey();
				var sStandardtype = sap.ui.getCore().byId("idConfigStandardType").getValue();
				var sResource = sap.ui.getCore().byId("idConfigResource").getValue();
				var nRevisionPerMonth = sap.ui.getCore().byId("idConfigRevisionPeriod").getValue();
				var nArchivingPerMonth = sap.ui.getCore().byId("idConfigArchivingPeriod").getValue();
				var sCostCenter = sap.ui.getCore().byId("idCostCenter").getValue();
				var iApprovalSLA = sap.ui.getCore().byId("idApprovalSLA").getValue();
				var iExecutionSLA = sap.ui.getCore().byId("idExecutionSLA").getValue();
				var sStandardtypeShort;
				if (sStandardtype === "Line Standard") {
					sStandardtypeShort = "LR"
				}
				if (sStandardtype === "Product Standard") {
					sStandardtypeShort = "PR"
				}

				if (splant !== "" && sStandardtype !== "" && sResource !== "" && sCostCenter !== "" && (nRevisionPerMonth > 0 && nRevisionPerMonth !== "") && (nArchivingPerMonth > 0 && nArchivingPerMonth !== "")) {

					var postData = {
						configNo: splant + "_" + sStandardtypeShort + "_" + sResource + "_" + sCostCenter,
						plant: splant,
						standardType: sStandardtype,
						resource: sResource,
						costCenter: sCostCenter,
						approvalSLAInDays: parseInt((iApprovalSLA), 10),
						executionSLAInDays: parseInt((iExecutionSLA), 10),
						revisionPrdMnth: parseInt((nRevisionPerMonth), 10),
						archivingPrdMnth: parseInt((nArchivingPerMonth), 10)
					};
					//POST
					BusyIndicator.show();
					$.ajax({
						url: "odata/v4/data-services/ConfigurationHeadersDB",
						type: "POST",
						data: JSON.stringify(postData),
						contentType: "application/json",
						dataType: "json",
					}).done(function (response) {
						BusyIndicator.hide();
						var message = that.oResourceBundle.getText("NEW_CONFIG_CREATED_SUCCESS") + "\nfor Plant :" + response.plant + ", Resource :" + response.resource
							+ ",\n CostCenter :" + response.costCenter + ",Standard Type :" + response.standardType;
						that.onShowSuccess(message);
						MessageToast.show(that.oResourceBundle.getText("CONFIG_CREATE_SUCCESS") + "" + response.plant + ", Resource :" + response.resource + ", CostCenter :" + response.costCenter + ", StandardType :" + response.standardType + "" + that.oResourceBundle.getText("CREATED_SUCCESFULLY"));

						///////////////////////////////////    After successful POSt, read call to fetch data///////////////////////////
						that.fnReadConfigurationData();
					}).fail(function (xhr, _status, _error) {
						BusyIndicator.hide();
						MessageToast.show(that.oResourceBundle.getText("CONFIG_NOT_CREATED"));
						var message = that.oResourceBundle.getText("CONFIG_CREATE_FAIL") + "\n" + xhr.responseJSON.error.code + ":" + xhr.responseJSON.error.message + ",\nfor plant :" + postData.plant + ", resource :" + postData.resource
							+ ",\n costcenter :" + postData.costCenter + ",standardtype :" + postData.standardType;
						that.onShowError(message);
					});
					///////////////////////////////////////////////////////////////////////                  
					this._oPopover4.close();
					sap.ui.getCore().byId("idConfigPlant").setValue("");
					sap.ui.getCore().byId("idConfigStandardType").setValue("");
					sap.ui.getCore().byId("idConfigResource").setValue("");
					sap.ui.getCore().byId("idConfigRevisionPeriod").setValue("");
					sap.ui.getCore().byId("idConfigArchivingPeriod").setValue("");
					sap.ui.getCore().byId("idCostCenter").setValue("");
					sap.ui.getCore().byId("idApprovalSLA").setValue("");
					sap.ui.getCore().byId("idExecutionSLA").setValue("");
				}
				else {
					if (splant === "") {
						sap.ui.getCore().byId("idConfigPlant").setValueState("Error");
						sap.ui.getCore().byId("idConfigPlant").setValueStateText(this.oResourceBundle.getText("ENTER_CONFIG_PLANT_ERROR"));
					} else {
						sap.ui.getCore().byId("idConfigPlant").setValueState("None");
					}
					if (sResource === "") {
						sap.ui.getCore().byId("idConfigResource").setValueState("Error");
						sap.ui.getCore().byId("idConfigResource").setValueStateText(this.oResourceBundle.getText("ENTER_CONFIG_RESOURCE_ERROR"));
					} else {
						sap.ui.getCore().byId("idConfigResource").setValueState("None");
					}
					if (sCostCenter === "") {
						sap.ui.getCore().byId("idCostCenter").setValueState("Error");
						sap.ui.getCore().byId("idCostCenter").setValueStateText(this.oResourceBundle.getText("ENTER_CONFIG_COSTCENTER_ERROR"));

					} else {
						sap.ui.getCore().byId("idCostCenter").setValueState("None");
					}
					if (sStandardtype === "") {
						sap.ui.getCore().byId("idConfigStandardType").setValueState("Error");
						sap.ui.getCore().byId("idConfigStandardType").setValueStateText(this.oResourceBundle.getText("ENTER_CONFIG_STDTYPE_ERROR"));
					} else {
						sap.ui.getCore().byId("idConfigStandardType").setValueState("None");
					}
					if (nRevisionPerMonth <= 0 || nRevisionPerMonth === "") {
                        sap.ui.getCore().byId("idConfigRevisionPeriod").setValueState("Error");
                        sap.ui.getCore().byId("idConfigRevisionPeriod").setValueStateText(this.oResourceBundle.getText("REVISION_PEROID_ERROR"));
                    }
                    else {
                        sap.ui.getCore().byId("idConfigRevisionPeriod").setValueState("None");
                    }
                    if (nArchivingPerMonth <= 0 || nArchivingPerMonth === "") {
                        sap.ui.getCore().byId("idConfigArchivingPeriod").setValueState("Error");
                        sap.ui.getCore().byId("idConfigArchivingPeriod").setValueStateText(this.oResourceBundle.getText("ARCHIVING_PEROID_ERROR"));
                    }
                    else {
                        sap.ui.getCore().byId("idConfigArchivingPeriod").setValueState("None");
                    }
				}
			},
			handleCloseButton: function (_oEvent) {
				if (this._oPopoverDeleteRow) {
					this._oPopoverDeleteRow.close();
				}
				if (this._oPopover4) {
					sap.ui.getCore().byId("idConfigPlant").setValue("");
					sap.ui.getCore().byId("idConfigStandardType").setValue("");
					sap.ui.getCore().byId("idConfigResource").setValue("");
					sap.ui.getCore().byId("idConfigRevisionPeriod").setValue("");
					sap.ui.getCore().byId("idConfigArchivingPeriod").setValue("");
					sap.ui.getCore().byId("idCostCenter").setValue("");
					sap.ui.getCore().byId("idApprovalSLA").setValue("");
					sap.ui.getCore().byId("idExecutionSLA").setValue("");

					sap.ui.getCore().byId("idConfigPlant").setValueState("None");
					sap.ui.getCore().byId("idConfigStandardType").setValueState("None");
					sap.ui.getCore().byId("idConfigResource").setValueState("None");
					sap.ui.getCore().byId("idCostCenter").setValueState("None");
					sap.ui.getCore().byId("idConfigArchivingPeriod").setValueState("None");
                    sap.ui.getCore().byId("idConfigRevisionPeriod").setValueState("None");

					this._oPopover4.close();
				}
			},
			fnEdit: function (_oEvent) {
				for (var i = 0; i < this.getView().getModel("configModel").getProperty("/value").length; i++) {
					this.getView().getModel("configModel").setProperty("/value/" + i + "/enable", false);
					this.getView().getModel("configModel").setProperty("/value/" + i + "/edit", false);
				}
				var tableIndex = this.getView().byId("idConfigTable").getSelectedIndices();
				for (var j = 0; j < tableIndex.length; j++) {
					this.getView().getModel("configModel").setProperty("/value/" + tableIndex[j] + "/enable", true);
					this.getView().getModel("configModel").setProperty("/value/" + tableIndex[j] + "/edit", true);
				}
				this.getView().byId("idConfigEdit").setVisible(false);
				this.getView().byId("idConfigSubmit").setVisible(true);
				this.getView().byId("idConfigCancel").setVisible(true);
				this.getView().byId("idConfigDelete").setEnabled(false);
				this.getView().byId("idConfigAdd").setEnabled(false);
			},
			// function called on click of submit button to update configurations
			fnSubmit: function () {
				var that = this;
			
				///////////////////////////////////New Payload for Multi Update////////////////////////////////////////////
				var tableIndex = this.getView().byId("idConfigTable").getSelectedIndices();
				var aUpdateData = [];
				var isMondatoryMissed = false;
				for (var i = 0; i < tableIndex.length; i++) {
				 var currentObj = {};
			
				 currentObj.ID = this.getView().getModel("configModel").getProperty("/value/" + tableIndex[i] + "/ID");
				 currentObj.approvalSLAInDays = parseInt((this.getView().getModel("configModel").getProperty("/value/" + tableIndex[i] + "/approvalSLAInDays")), 10);
				 currentObj.executionSLAInDays = parseInt((this.getView().getModel("configModel").getProperty("/value/" + tableIndex[i] + "/executionSLAInDays")), 10);
				 currentObj.revisionPrdMnth = parseInt((this.getView().getModel("configModel").getProperty("/value/" + tableIndex[i] + "/revisionPrdMnth")), 10);
				 currentObj.archivingPrdMnth = parseInt((this.getView().getModel("configModel").getProperty("/value/" + tableIndex[i] + "/archivingPrdMnth")), 10);
			
				 if (currentObj.revisionPrdMnth <= 0 || currentObj.revisionPrdMnth === "" || Number.isNaN(currentObj.revisionPrdMnth)) {
				  var message = that.oResourceBundle.getText("REVISION_PEROID_ERROR");
				  this.getView().getModel("configModel").setProperty("/value/" + tableIndex[i] + "/revisionPrdMnth_ValueState", "Error");
				  this.getView().getModel("configModel").setProperty("/value/" + tableIndex[i] + "/revisionPrdMnth_ValueStateText", message);
				  isMondatoryMissed = true;
				  break;
				 }
				 else {
				  isMondatoryMissed = false;
				  this.getView().getModel("configModel").setProperty("/value/" + tableIndex[i] + "/revisionPrdMnth_ValueState", "None");
				 }
				 if (currentObj.archivingPrdMnth <= 0 || currentObj.archivingPrdMnth === "" || Number.isNaN(currentObj.archivingPrdMnth)) {
				  var message = that.oResourceBundle.getText("ARCHIVING_PEROID_ERROR");
				  this.getView().getModel("configModel").setProperty("/value/" + tableIndex[i] + "/archivingPrdMnth_ValueState", "Error");
				  this.getView().getModel("configModel").setProperty("/value/" + tableIndex[i] + "/archivingPrdMnth_ValueStateText", message);
				  isMondatoryMissed = true;
				  break;
				 }
				 else {
				  isMondatoryMissed = false;
				  this.getView().getModel("configModel").setProperty("/value/" + tableIndex[i] + "/archivingPrdMnth_ValueState", "None");
				 }
				 aUpdateData.push(currentObj);
			
				 if (isMondatoryMissed)
				  this.getView().getModel("configModel").setProperty("/value/" + tableIndex[i] + "/edit", false);
			
				}
				if(isMondatoryMissed) 
				 return; 
				this.getView().byId("idConfigEdit").setVisible(true);
				this.getView().byId("idConfigSubmit").setVisible(false);
				this.getView().byId("idConfigCancel").setVisible(false);
				this.getView().byId("idConfigDelete").setEnabled(true);
				this.getView().byId("idConfigAdd").setEnabled(true);
				for (var j = 0; j < this.getView().getModel("configModel").getProperty("/value").length; j++) {
					this.getView().getModel("configModel").setProperty("/value/" + j + "/enable", true);
					this.getView().getModel("configModel").setProperty("/value/" + j + "/edit", false);
				}

				var oPayload = { "updateData": aUpdateData };
				var updateUrl = "odata/v4/data-services/updateConfigItems";
				////////////////////////////////////New Payload for Multi Update/////////////////////////////////////////////
				BusyIndicator.show()
				$.ajax({
					url: updateUrl,
					type: "POST",
					contentType: "application/json",
					data: JSON.stringify(oPayload)
				}).done(function (_data) {
					BusyIndicator.hide();
					MessageToast.show(that.oResourceBundle.getText("CONFIG_UPDATED"));
					var message = that.oResourceBundle.getText("CONFIG_UPDATE_SUCCESS");
					that.onShowSuccess(message);
					that.fnReadConfigurationData();
					that.getView().byId("idConfigTable").clearSelection();
				}).fail(function (_xhr, _status, _error) {
					MessageToast.show(that.oResourceBundle.getText("CONFIG_NOT_UPDATED"));
					var message = that.oResourceBundle.getText("CONFIG_UPDATE_FAIL");
					that.onShowError(message);
					BusyIndicator.hide();
					that.fnReadConfigurationData();
				});
				/////////////////////////////////////////////////////////////////////////////////////////////////////////
			},
			fnCancel: function () {
				this.getView().byId("idConfigDelete").setEnabled(true);
				this.getView().byId("idConfigEdit").setVisible(true);
				this.getView().byId("idConfigSubmit").setVisible(false);
				this.getView().byId("idConfigCancel").setVisible(false);
				this.getView().byId("idConfigDelete").setEnabled(true);
				this.getView().byId("idConfigAdd").setEnabled(true);
				tableIndex = this.getView().byId("idConfigTable").getSelectedIndices();
				for (var i = 0; i < tableIndex.length; i++) {
					this.getView().getModel("configModel").setProperty("/value/" + tableIndex[i] + "/edit", false);
				}
				this.getView().byId("idConfigTable").clearSelection();
				this.fnReadConfigurationData();
			},
			// fnDelete: function () {
			// 	if (!this._oPopoverDeleteRow) {
			// 		this._oPopoverDeleteRow = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.PopoverDeleteRecordsLine", this);
			// 		this.getView().addDependent(this._oPopoverDeleteRow);
			// 	}
			// 	this._oPopoverDeleteRow.open();
			// },
			OnConfigViewDelete: function () {
				sap.m.MessageBox.confirm(
					this.oResourceBundle.getText("DELETE_CONFIRMATION"), // Message
					{
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
						onClose: function (sAction) { // Callback when the dialog is closed
							if (sAction === MessageBox.Action.YES) {
								//DELETE single row                
								var deleteUrl = "odata/v4/data-services/deleteConfigItems";
								var tableIndex = this.getView().byId("idConfigTable").getSelectedIndices();
								var aRowConfigNo = [];
								for (var i = 0; i < tableIndex.length; i++) {
									aRowConfigNo.push(this.getView().getModel("configModel").getProperty("/value/" + tableIndex[i] + "/configNo"));
								}
								var oPayload = { "ConfigNos": aRowConfigNo };
								var that = this;
								BusyIndicator.show();
								$.ajax({
									url: deleteUrl,
									type: "POST",
									contentType: "application/json",
									data: JSON.stringify(oPayload)
								}).done(function (_data) {
									BusyIndicator.hide();
									that.fnReadConfigurationData();
									MessageToast.show(that.oResourceBundle.getText("CONFIG_DELETED"));
									var message = that.oResourceBundle.getText("CONFIG_SELECT_SUCCESS");
									that.onShowSuccess(message);
								}).fail(function (_xhr, _status, _error) {
									BusyIndicator.hide();
									MessageToast.show(that.oResourceBundle.getText("CONFIG_DEELTE_FAIL"));
									var message = that.oResourceBundle.getText("CONFIG_SELECT_FAIL");
									that.onShowError(message);
								});



							}
						}.bind(this)
					}
				);

			},

			// //function to delete rows in the table
			// handleAcceptButton: function () {
			// 	//DELETE single row                
			// 	var deleteUrl = "odata/v4/data-services/deleteConfigItems";
			// 	var tableIndex = this.getView().byId("idConfigTable").getSelectedIndices();
			// 	var aRowConfigNo = [];
			// 	for (var i = 0; i < tableIndex.length; i++) {
			// 		aRowConfigNo.push(this.getView().getModel("configModel").getProperty("/value/" + tableIndex[i] + "/configNo"));
			// 	}
			// 	var oPayload = { "ConfigNos": aRowConfigNo };
			// 	var that = this;
			// 	BusyIndicator.show();
			// 	$.ajax({
			// 		url: deleteUrl,
			// 		type: "POST",
			// 		contentType: "application/json",
			// 		data: JSON.stringify(oPayload)
			// 	}).done(function (_data) {
			// 		BusyIndicator.hide();
			// 		that.fnReadConfigurationData();
			// 		MessageToast.show(that.oResourceBundle.getText("CONFIG_DELETED"));
			// 		var message = that.oResourceBundle.getText("CONFIG_SELECT_SUCCESS");
			// 		that.onShowSuccess(message);
			// 	}).fail(function (_xhr, _status, _error) {
			// 		BusyIndicator.hide();
			// 		MessageToast.show(that.oResourceBundle.getText("CONFIG_DEELTE_FAIL"));
			// 		var message = that.oResourceBundle.getText("CONFIG_SELECT_FAIL");
			// 		that.onShowError(message);
			// 	});
			// 	this._oPopoverDeleteRow.close()
			// },
			onShowWarning: function (message) {
				sap.m.MessageBox.warning(
					message, {
					title: "Warning",
					actions: [sap.m.MessageBox.Action.OK],
					onClose: function () { }
				}
				);
			},
			onShowSuccess: function (message) {
				sap.m.MessageBox.success(
					message, {
					title: "Success",
					actions: [sap.m.MessageBox.Action.OK],
					onClose: function () { }
				}
				);
			},
			onShowError: function (message) {
				sap.m.MessageBox.error(
					message, {
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK],
					onClose: function () { }
				}
				);
			},

		});
	});
