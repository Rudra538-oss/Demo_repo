sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	'sap/ui/core/BusyIndicator',
	'sap/m/MessageToast',
	"l8gttpmgllpstdui/model/formatter",
	"l8gttpmgllpstdui/controller/BaseController",
	"sap/m/MessageBox"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function (Controller, History, BusyIndicator, MessageToast, formatter, BaseController, MessageBox) {
		"use strict";
		var tableIndex, roleVal, lineStdNo;
		return BaseController.extend("l8gttpmgllpstdui.controller.ViewStandard", {
			formatter: formatter,
			onInit: function () {

				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				const oHistory = sap.ui.core.routing.History.getInstance();
				const sPreviousHash = oHistory.getPreviousHash();
				oRouter.getRoute("onViewStandard").attachPatternMatched(this.onObjectMatched, this);
				// If there is no previous hash, navigate to HomeView
				if (sPreviousHash === undefined) {
					oRouter.navTo("RouteHomeView", true);
				} else {
					oRouter.getRoute("LineStandardView").attachPatternMatched(this.onObjectMatched, this);
				}
				this.oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			},
			onObjectMatched: function (oEvent) {
				lineStdNo = oEvent.getParameter("arguments").lineStdNo;
				roleVal = oEvent.getParameter("arguments").roleVal;

				this.fnReadCyclesDbData();
				this.fnReadCycleEventsDbData();
				this.fnReadAnnualEventDbData();
				this.fnViewLossCat();

				this.getView().byId("idtab1Edit").setVisible(true);
				this.getView().byId("idtab1Delete").setVisible(true);
				this.getView().byId("idLineViewCycleSubmit").setVisible(false);
				this.getView().byId("idLineViewCycleCancel").setVisible(false);

				this.getView().byId("idtab2Edit").setVisible(true);
				this.getView().byId("idtab2Delete").setVisible(true);
				this.getView().byId("idLineViewCycleEventSubmit").setVisible(false);
				this.getView().byId("idLineViewCycleEventCancel").setVisible(false);

				this.getView().byId("idtab3Edit").setVisible(true);
				this.getView().byId("idtab3Delete").setVisible(true);
				this.getView().byId("idLineViewAnnualCycleEventSubmit").setVisible(false);
				this.getView().byId("idLineViewAnnualCycleEventCancel").setVisible(false);

				this.getView().byId("idSecificStandard").clearSelection();
				this.getView().byId("idCycleEventsDB").clearSelection();
				this.getView().byId("idCycleAnnualDB").clearSelection();

				var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
				var nbId = newData[0].Username;
				var role = newData[0].AuthType;
				var zone = newData[0].Zone;

				if (roleVal === "V") {

					this.getView().byId("idtab1Edit").setVisible(false);
					this.getView().byId("idtab1Delete").setVisible(false);

					this.getView().byId("idtab2Edit").setVisible(false);
					this.getView().byId("idtab2Delete").setVisible(false);

					this.getView().byId("idtab3Edit").setVisible(false);
					this.getView().byId("idtab3Delete").setVisible(false);

					this.getView().byId("idSecificStandard").setSelectionMode("None");
					this.getView().byId("idCycleEventsDB").setSelectionMode("None");
					this.getView().byId("idCycleAnnualDB").setSelectionMode("None");

				}


				var aLineStdData = this.getOwnerComponent().getModel("lineStandardHeaderModel").getData().value;
				var aSpecificLineStdHeaderData = aLineStdData.filter(function (val) {
					if (val.lineStdNo == lineStdNo)
						return val;
				});

				var viewHeaderModel = new sap.ui.model.json.JSONModel();
				viewHeaderModel.setData(aSpecificLineStdHeaderData[0]);
				this.getView().setModel(viewHeaderModel, "viewHeaderModel");

				this.getView().byId("idPlant").setText(aSpecificLineStdHeaderData[0].plant);
				this.getView().byId("idRes").setText(aSpecificLineStdHeaderData[0].resource);
				this.getView().byId("idStandard").setText(aSpecificLineStdHeaderData[0].lineStdNo);
				this.getView().byId("idCostCenter").setText(aSpecificLineStdHeaderData[0].costCenter);
				this.getView().byId("idStatus").setText(aSpecificLineStdHeaderData[0].status);
				this.getView().byId("idValidTo").setText(this._fnDatFormat(aSpecificLineStdHeaderData[0].validTo));
				this.getView().byId("idValidFrom").setText(this._fnDatFormat(aSpecificLineStdHeaderData[0].validFrom));
				this.getView().byId("idLineModifedFrom").setText(this._fnDatFormat(aSpecificLineStdHeaderData[0].modifiedFrom));
				this.getView().byId("idLastChange").setText(this._fnDatFormat(aSpecificLineStdHeaderData[0].lastChangedOn));
				this.getView().byId("idCreatedOn").setText(this._fnDatFormat(aSpecificLineStdHeaderData[0].createdOn));


			},
			_fnDatFormat: function (val) {
				var iDay = parseInt(val.substring(8, 10));
				var iMonth = val.substring(5, 7);
				var iYear = parseInt(val.substring(0, 4));
				return iDay + "-" + iMonth + "-" + iYear;
			},
			// function to enable edit and delete button in the Line View CyclesDBTable Row Selected,called when a row is selected in the table 
			fnLineViewCyclesDBTableRowSelected: function (evt) {
				var aRowSelected = this.getView().byId("idSecificStandard").getSelectedIndices();
				if (aRowSelected.length > 0) {
					this.getView().byId("idtab1Edit").setEnabled(true);
					this.getView().byId("idtab1Delete").setEnabled(true);
				} else {
					this.getView().byId("idtab1Edit").setEnabled(false);
					this.getView().byId("idtab1Delete").setEnabled(false);
				}

			},
			// function to enable edit and delete button in the Line View Cycle Event Table Row Selected,called when a row is selected in the table 
			fnLineViewCycleEventTableRowSelected: function (evt) {
				var aRowSelected = this.getView().byId("idCycleEventsDB").getSelectedIndices();
				if (aRowSelected.length > 0) {
					this.getView().byId("idtab2Edit").setEnabled(true);
					this.getView().byId("idtab2Delete").setEnabled(true);
				} else {
					this.getView().byId("idtab2Edit").setEnabled(false);
					this.getView().byId("idtab2Delete").setEnabled(false);
				}
			},
			// function to enable edit and delete button in the Line View Annual Event Table Row Selected,called when a row is selected in the table 
			fnLineViewAnnualEventTableRowSelected: function (evt) {
				var aRowSelected = this.getView().byId("idCycleAnnualDB").getSelectedIndices();
				if (aRowSelected.length > 0) {
					this.getView().byId("idtab3Edit").setEnabled(true);
					this.getView().byId("idtab3Delete").setEnabled(true);
				} else {
					this.getView().byId("idtab3Edit").setEnabled(false);
					this.getView().byId("idtab3Delete").setEnabled(false);
				}
			},
			fnReadCyclesDbData: function () {
				if(lineStdNo!== undefined){
				var that = this;
				BusyIndicator.show();
				$.get("odata/v4/data-services/LineRelStandardCyclesDB?$filter=lineStdNo eq '" + lineStdNo + "'").done(function (data) {
					// 'data' here should contain the response from the OData endpoint                    
					BusyIndicator.hide();
					// Process or display the 'data' object as needed
					var oTableModel = new sap.ui.model.json.JSONModel(data)
					that.getView().setModel(oTableModel, "LineStdCycleDBModel");
					//Setting model at component level
					that.getOwnerComponent().setModel(oTableModel, "LineStdCycleDBModel");
					var iLineStdCyclesDBDataCount = that.getView().getModel("LineStdCycleDBModel").getData().value.length;
					MessageToast.show(that.oResourceBundle.getText("CYCLES_DB_LINE_LOADED_SUCCESS"));
					that.getView().byId("idLineStdCyclesDBTab").setCount(iLineStdCyclesDBDataCount);
				}).fail(function (xhr, status, error) {
					BusyIndicator.hide();
					// Handle errors if the request fails
					MessageToast.show(that.oResourceBundle.getText("CYCLES_DB_LINE_LOADED_FAIL"));
					// alert("Error fetching OData: " + error);
				});
			}

		},
			fnReadCycleEventsDbData: function () {
				if(lineStdNo!== undefined){
				var that = this;
				BusyIndicator.show();
				$.get("odata/v4/data-services/LineRelStandardCycleEventDB?$filter=lineStdNo eq '" + lineStdNo + "'").done(function (data) {
					// 'data' here should contain the response from the OData endpoint                    
					BusyIndicator.hide();
					// Process or display the 'data' object as needed
					var oTableModel = new sap.ui.model.json.JSONModel(data)
					that.getView().setModel(oTableModel, "lineStdCycleEventDbModel");
					//Setting model at component level
					that.getOwnerComponent().setModel(oTableModel, "lineStdCycleEventDbModel");
					var iLineStdCycleEventDbCount = that.getView().getModel("lineStdCycleEventDbModel").getData().value.length;
					MessageToast.show(that.oResourceBundle.getText("LINE_STD_EVENT_DB_LOAD_SUCCESS"));
					that.getView().byId("idLineStdCycleEventsDBTab").setCount(iLineStdCycleEventDbCount);

				}).fail(function (xhr, status, error) {
					BusyIndicator.hide();
					// Handle errors if the request fails
					MessageToast.show(that.oResourceBundle.getText("LINE_STD_EVENT_DB_LOAD_FAIL"));

				});
			}

		},
			fnReadAnnualEventDbData: function () {
				if(lineStdNo!== undefined){
				var that = this;
				BusyIndicator.show();
				$.get("odata/v4/data-services/LineRelStandardAnnualEventDB?$filter=lineStdNo eq '" + lineStdNo + "'").done(function (data) {

					BusyIndicator.hide();
					var oTableModel = new sap.ui.model.json.JSONModel(data)
					that.getView().setModel(oTableModel, "lineStdAnnualEventDbModel");
					//Setting model at component level
					that.getOwnerComponent().setModel(oTableModel, "lineStdAnnualEventDbModel");
					MessageToast.show(that.oResourceBundle.getText("LINE_STD_ANNUAL_CYCLESDB_LOAD_SUCCESS"));
					var lineStdAnnualEventDbDataCount = that.getView().getModel("lineStdAnnualEventDbModel").getData().value.length;
					that.getView().byId("idLineStdAnnualEventDBTab").setCount(lineStdAnnualEventDbDataCount);

				}).fail(function (xhr, status, error) {
					BusyIndicator.hide();
					// Handle errors if the request fails
					MessageToast.show(that.oResourceBundle.getText("CONFIG_LOADING_FAIL"));

				});
			}
		},
			onNavBack: function () {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("LineStandardView", true);
			},
			onMenu: function (evt) {
				if (!this._oPopover2) {
					this._oPopover2 = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.PopoverStandard", this);
					this.getView().addDependent(this._oPopover2);
				}

				this._oPopover2.openBy(evt.getSource());
				tableIndex = this.getView().byId("idSecificStandard").getSelectedIndex();
			},
			handleCloseButton: function (oEvent) {
				if (this._oPopoverDeleteRow) {
					this._oPopoverDeleteRow.close();
				}
				if (this._oPopover2) {
					this._oPopover2.close();
				}
			},
			onEdit: function (oEvent) {
				this.getView().byId("idtab1Edit").setVisible(false);
				this.getView().byId("idLineViewCycleSubmit").setVisible(true);
				this.getView().byId("idLineViewCycleCancel").setVisible(true);
				this.getView().byId("idtab1Delete").setEnabled(false);

				var tableIndex = this.getView().byId("idSecificStandard").getSelectedIndices();
				for (var i = 0; i < tableIndex.length; i++) {
					this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/enable", true);
					this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/edit", true);
				}
			},

			// Cycle DB Submit function
			onSubmit: function () {
				var that = this;
				var tableIndex = this.getView().byId("idSecificStandard").getSelectedIndices();
				var aCyclesDBData = this.getView().getModel("LineStdCycleDBModel").getProperty("/value");

				var iCycleDbError = 0; //  kept outside for loop to find is there or not, if there values come to 1
				for (var i = 0; i < tableIndex.length; i++) {
					///////////////////Cycles DB validation   start /////////////////////////////////                    
					var condition = aCyclesDBData[tableIndex[i]].condition;
					var conDescrip = aCyclesDBData[tableIndex[i]].conditionDesc;
					var shiftLen = Number(aCyclesDBData[tableIndex[i]].shiftLength);
					var productionCycle = Number(aCyclesDBData[tableIndex[i]].prodCyclesInDays);
					var shiftInDays = Number(aCyclesDBData[tableIndex[i]].shiftsInDays);
					var cycleInYear = Number(aCyclesDBData[tableIndex[i]].cyclesInYear);

					var iSum = 0;
					var iCycInYearCeiling;
					// if (this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesDataNav") == undefined) {                   
					//     iCycInYearCeiling= Number((365/productionCycle).toFixed(3));                  
					// }
					// else {                  
					var aCyclesDbDataEdit = this.getView().getModel("LineStdCycleDBModel").getProperty("/value");
					for (var j = 0; j < aCyclesDbDataEdit.length; j++) {
						if (tableIndex[i] != j) {
							iSum = Number((aCyclesDbDataEdit[j].prodCyclesInDays * aCyclesDbDataEdit[j].cyclesInYear).toFixed(3)) + iSum;
						}
					}
					iCycInYearCeiling = Number((((365 - iSum)) / productionCycle).toFixed(3));
					// }
					if (condition == "") {
						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/valueStateCondition", "Error");
						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/valueStateTextCondition", this.oResourceBundle.getText("ERROR_CONDITION"));
						iCycleDbError = 1;
					} else {
						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/valueStateCondition", "None");
					}
					if (conDescrip == "") {
						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/valueStateConDescription", "Error");
						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/valueStateTextConDescription", this.oResourceBundle.getText("ERROR_CONDITION_DESC"));
						iCycleDbError = 1;
					} else {
						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/valueStateConDescription", "None");
					}
					if (shiftLen == "" || shiftLen > 24) {
						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/valueStateShiftLen", "Error");
						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/valueStateTextShiftLen", this.oResourceBundle.getText("ERROR_SHIFT_LENGTH"));
						iCycleDbError = 1;
					} else {
						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/valueStateShiftLen", "None");
					}
					if (productionCycle == "" || productionCycle > 365) {
						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/valueStateProductionCycle", "Error");
						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/valueStateTextProductionCycle", this.oResourceBundle.getText("ERROR_PRODUCTION_CYCLE"));
						iCycleDbError = 1;
					} else {
						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/valueStateProductionCycle", "None");
					}
					if (shiftInDays == "" || shiftInDays > (24 / shiftLen)) {
						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/valueStateShiftInDays", "Error");
						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/valueStateTextShiftInDays", this.oResourceBundle.getText("ERROR_SHIFT_DAYS_2") + this.oResourceBundle.getText("ERROR_LESS_THAN") + (24 / Number(shiftLen.toFixed(3))).toFixed(3));
						iCycleDbError = 1;
					} else {
						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/valueStateShiftInDays", "None");
					}
					if (cycleInYear == "" || cycleInYear > iCycInYearCeiling || cycleInYear < 0) {
						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/valueStateCycleInYear", "Error");
						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/valueStateTextCycleInYear", this.oResourceBundle.getText("ERROR_CYCLE_IN_YEAR_2") + " " + iCycInYearCeiling);
						iCycleDbError = 1;
					} else {
						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/valueStateCycleInYear", "None");
					}
					///////////////////Cycles DB validation END///////////////////////////////////////////////

				}

				if (iCycleDbError == 1) {
					MessageToast.show(this.oResourceBundle.getText("MAND_LINE_ERROR_VIEW_STD"));
				} else {
					this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/enable", true);
					this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndex[i] + "/edit", true);
					this.getView().byId("idtab1Edit").setVisible(true);
					this.getView().byId("idLineViewCycleSubmit").setVisible(false);
					this.getView().byId("idLineViewCycleCancel").setVisible(false);
					this.getView().byId("idtab1Delete").setEnabled(true);

					////////////////////////Calculated fields////////////////////////////////////////////////////
					var avgProdCycle, avgShiftInDay, avgShiftInCycle, avgCycleHours, shiftlength = 0, totOccupiedTime = 0, cycleInYearInt = 0,
						shiftInCycleInt = 0, cycleHoursInt = 0, totOccupiedTimeInt = 0, shiftInCycle = 0, cycleHours = 0,
						totOccupiedTime = 0, cycleInYear = 0, shiftInDayInt = 0, prodCycleInt = 0, shiftInDay = 0, prodCycle = 0, iLineApproveSelIndex;

					this.getView().getModel("LineStdCycleDBModel").getData();
					var aRow = this.getView().getModel("LineStdCycleDBModel").getData().value.length;
					for (var i = 0; i < aRow; i++) {
						shiftInDayInt = Number(this.getView().getModel("LineStdCycleDBModel").getData().value[i].shiftsInDays);
						prodCycleInt = Number(this.getView().getModel("LineStdCycleDBModel").getData().value[i].prodCyclesInDays)
						shiftInDay = Number(this.getView().getModel("LineStdCycleDBModel").getData().value[i].shiftsInDays) + shiftInDay;
						prodCycle = Number(this.getView().getModel("LineStdCycleDBModel").getData().value[i].prodCyclesInDays) + prodCycle;
						shiftlength = Number(this.getView().getModel("LineStdCycleDBModel").getData().value[i].shiftLength);
						cycleInYearInt = Number(this.getView().getModel("LineStdCycleDBModel").getData().value[i].cyclesInYear);

						// cycles DB calculated fields, not shown in screen
						shiftInCycleInt = Number((shiftInDayInt * prodCycleInt).toFixed(3));
						cycleHoursInt = Number((shiftInCycleInt * shiftlength).toFixed(3));
						totOccupiedTimeInt = Number((cycleHoursInt * cycleInYearInt).toFixed(3));

						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + i + "/shiftsInCycle", shiftInCycleInt);
						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + i + "/cycleHrs", cycleHoursInt);
						this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + i + "/totalOccupiedTime", totOccupiedTimeInt);

						shiftInCycle = Number((shiftInCycleInt + shiftInCycle).toFixed(3));
						cycleHours = Number((cycleHoursInt + cycleHours).toFixed(3));
						totOccupiedTime = Number((totOccupiedTimeInt + totOccupiedTime).toFixed(3));
						cycleInYear = Number((cycleInYearInt + cycleInYear).toFixed(3));
					}
					avgProdCycle = Number((prodCycle / aRow).toFixed(3));
					avgShiftInDay = Number((shiftInDay / aRow).toFixed(3));
					//avgShiftInCycle = Number((shiftInCycle / aRow).toFixed(3));
					avgShiftInCycle = Number((avgShiftInDay * avgProdCycle).toFixed(3));
					avgCycleHours = Number((totOccupiedTime / cycleInYear).toFixed(3));

					// avgCycleHours = Number((totOccupiedTime / avgShiftInCycle).toFixed(3));
					totOccupiedTime = totOccupiedTime;
					///////////////////////////////////////////////////////////////////////////////////////
					////////////////////////Calculated fields////////////////////////////////////////////////////
					var aLineStdData = this.getOwnerComponent().getModel("lineStandardHeaderModel").getData().value;
					var aSpecificLineStdHeaderData = aLineStdData.filter(function (val) {
						if (val.lineStdNo == lineStdNo)
							return val;
					});

					var obj = {};
					obj.ID = aSpecificLineStdHeaderData[0].ID;
					obj.lineStdNo = aSpecificLineStdHeaderData[0].lineStdNo;
					obj.validTo = aSpecificLineStdHeaderData[0].validTo;
					obj.prodCyclesInDays = avgProdCycle;
					obj.shiftsInDay = avgShiftInDay;
					obj.shiftsInCycle = avgShiftInCycle;
					obj.cycleHrs = avgCycleHours;
					obj.cyclesInYear = cycleInYear;
					obj.totalOccupiedTime = totOccupiedTime;
					obj.status = "Modified";
					obj.reworkComment = null;
					obj.stdApprLvl = 0;
					obj.executionState = 0;
					obj.executorsIDs = [];


					var updateLineStdHdrDb = [];
					updateLineStdHdrDb.push(obj);

					var oPostData = {};

					var aCycleDbData = [];
					var aStdCycleDbData = this.getView().getModel("LineStdCycleDBModel").getProperty("/value");
					for (var i = 0; i < aStdCycleDbData.length; i++) {
						var oStdCyclesDbData = {};
						oStdCyclesDbData.ID = aStdCycleDbData[i].ID;
						oStdCyclesDbData.condition = aStdCycleDbData[i].condition;
						oStdCyclesDbData.conditionDesc = aStdCycleDbData[i].conditionDesc;
						oStdCyclesDbData.shiftLength = Number(aStdCycleDbData[i].shiftLength);
						oStdCyclesDbData.prodCyclesInDays = Number(aStdCycleDbData[i].prodCyclesInDays);
						oStdCyclesDbData.shiftsInDays = Number(aStdCycleDbData[i].shiftsInDays);
						oStdCyclesDbData.shiftsInCycle = Number(aStdCycleDbData[i].shiftsInCycle);
						oStdCyclesDbData.cycleHrs = Number(aStdCycleDbData[i].cycleHrs);
						oStdCyclesDbData.cyclesInYear = Number(aStdCycleDbData[i].cyclesInYear);
						oStdCyclesDbData.totalOccupiedTime = Number(aStdCycleDbData[i].totalOccupiedTime);
						//03-09-2024 Changes required only for poc
						oStdCyclesDbData.status = "Modified";
						aCycleDbData.push(oStdCyclesDbData);

					}
					var EditCycleEventTotPlanDtLoss = 0, EditAnnualCycleEventTotPlanDtLoss = 0;
					var aCycleEventDbData = [];
					var aStdCycleEventDbData = this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value");
					for (var i = 0; i < aStdCycleEventDbData.length; i++) {
						var oStdCyclesDbData = {};
						oStdCyclesDbData.ID = aStdCycleEventDbData[i].ID;
						oStdCyclesDbData.lossCat = aStdCycleEventDbData[i].lossCat;
						oStdCyclesDbData.subCat = aStdCycleEventDbData[i].subCat;
						oStdCyclesDbData.cycleHrs = aStdCycleEventDbData[i].cycleHrs;
						oStdCyclesDbData.cyclesInYear = aStdCycleEventDbData[i].cyclesInYear;
						oStdCyclesDbData.expectedCrewSize = aStdCycleEventDbData[i].expectedCrewSize;
						oStdCyclesDbData.expectedFreqPerCycle = aStdCycleEventDbData[i].expectedFreqPerCycle;
						oStdCyclesDbData.expectedEvtDur = aStdCycleEventDbData[i].expectedEvtDur;
						oStdCyclesDbData.expectedDurPerCycle = aStdCycleEventDbData[i].expectedDurPerCycle;
						oStdCyclesDbData.plannedDtLoss = aStdCycleEventDbData[i].plannedDtLoss;
						oStdCyclesDbData.expectedLbrHrsPerCycle = aStdCycleEventDbData[i].expectedLbrHrsPerCycle;
						oStdCyclesDbData.expectedTotLbrHrs = aStdCycleEventDbData[i].expectedTotLbrHrs;
						//03-09-2024 Changes required only for poc
						oStdCyclesDbData.status = "Modified";

						oStdCyclesDbData.expectedDurPerCycle = Number(oStdCyclesDbData.expectedFreqPerCycle * oStdCyclesDbData.expectedEvtDur);
						oStdCyclesDbData.expectedLbrHrsPerCycle = Number(oStdCyclesDbData.expectedCrewSize * oStdCyclesDbData.expectedDurPerCycle);
						oStdCyclesDbData.cyclesInYear = cycleInYear; //Number(aSpecificLineStdHeaderData[0].cyclesInYear);
						oStdCyclesDbData.expectedTotLbrHrs = Number(oStdCyclesDbData.cyclesInYear * oStdCyclesDbData.expectedLbrHrsPerCycle);
						oStdCyclesDbData.cycleHrs = avgCycleHours;//(aSpecificLineStdHeaderData[0].cycleHrs);
						oStdCyclesDbData.plannedDtLoss = Number(Number(((oStdCyclesDbData.expectedDurPerCycle / aSpecificLineStdHeaderData[0].totalOccupiedTime) * aSpecificLineStdHeaderData[0].cyclesInYear) * 100).toFixed(2));

						EditCycleEventTotPlanDtLoss = Number((EditCycleEventTotPlanDtLoss + oStdCyclesDbData.plannedDtLoss).toFixed(3));

						aCycleEventDbData.push(oStdCyclesDbData);

					}
					var aCycleAnnualEventDbData = [];
					var aStdAnnualCycleEventDbData = this.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value");
					for (var i = 0; i < aStdAnnualCycleEventDbData.length; i++) {
						var oStdCyclesDbData = {};
						oStdCyclesDbData.ID = aStdAnnualCycleEventDbData[i].ID;
						oStdCyclesDbData.lossCat = aStdAnnualCycleEventDbData[i].lossCat;
						oStdCyclesDbData.subCat = aStdAnnualCycleEventDbData[i].subCat;
						oStdCyclesDbData.totOccupiedHrs = aStdAnnualCycleEventDbData[i].totOccupiedHrs;
						oStdCyclesDbData.cyclesInYear = aStdAnnualCycleEventDbData[i].cyclesInYear;
						oStdCyclesDbData.expectedCrewSize = aStdAnnualCycleEventDbData[i].expectedCrewSize;
						oStdCyclesDbData.expectedFrequency = aStdAnnualCycleEventDbData[i].expectedFrequency;
						oStdCyclesDbData.expectedEvtDur = aStdAnnualCycleEventDbData[i].expectedEvtDur;
						oStdCyclesDbData.expectedDurPerYear = aStdAnnualCycleEventDbData[i].expectedDurPerYear;
						oStdCyclesDbData.plannedDtLoss = aStdAnnualCycleEventDbData[i].plannedDtLoss;
						oStdCyclesDbData.expectedLbrHrPerYear = aStdAnnualCycleEventDbData[i].expectedLbrHrPerYear;
						//03-09-2024 Changes required only for poc
						oStdCyclesDbData.status = "Modified";

						oStdCyclesDbData.expectedDurPerYear = Number(oStdCyclesDbData.expectedFrequency * Number(oStdCyclesDbData.expectedEvtDur));
						oStdCyclesDbData.expectedLbrHrPerYear = Number(oStdCyclesDbData.expectedCrewSize * oStdCyclesDbData.expectedDurPerYear);
						oStdCyclesDbData.totOccupiedHrs = (Number(totOccupiedTime)).toFixed(3);//Number(oPostData.totalOccupiedTime);
						oStdCyclesDbData.plannedDtLoss = Number(Number((oStdCyclesDbData.expectedDurPerYear / oStdCyclesDbData.totOccupiedHrs) * 100).toFixed(2));

						EditAnnualCycleEventTotPlanDtLoss = EditAnnualCycleEventTotPlanDtLoss + oStdCyclesDbData.plannedDtLoss;
						aCycleAnnualEventDbData.push(oStdCyclesDbData);

					}

					var TotPlannedDTLoss = Number(Number(EditCycleEventTotPlanDtLoss + EditAnnualCycleEventTotPlanDtLoss).toFixed(3));

					updateLineStdHdrDb[0].plannedDtLoss = TotPlannedDTLoss;


					oPostData.updateLineStdHdrDb = updateLineStdHdrDb;
					oPostData.updateLineStdCyclesDb = aCycleDbData;
					oPostData.updateLineStdCycleEvtDb = aCycleEventDbData;
					oPostData.updateLineStdAnnualEvtDb = aCycleAnnualEventDbData;
					oPostData.deleteLineStdCyclesDb = [];
					oPostData.deleteLineStdCycleEvtDb = [];
					oPostData.deleteLineStdAnnualEvtDb = [];

					//POST
					BusyIndicator.show();
					$.ajax({
						url: "odata/v4/data-services/updateLineStdItems",
						type: "POST",
						data: JSON.stringify(oPostData),
						contentType: "application/json",
						dataType: "json",
					}).done(function (response) {
						BusyIndicator.hide();
						that.getView().byId("idSecificStandard").clearSelection();
						MessageToast.show(that.oResourceBundle.getText("LINE_EVENT_DB_UPDATE_SUCCESS"));
						var message = that.oResourceBundle.getText("LINE_EVENT_DB_UPDATE_SUCCESS");
						that.onShowSuccess(message);

						that.fnReadCycleEventsDbData();
						that.fnReadAnnualEventDbData();
						that.getView().getModel("viewHeaderModel").setProperty("/status", "Modified");
						///////////////////////////////////    After successful POSt, read call to fetch data///////////////////////////
						that.fnReadCyclesDbData();
					}).fail(function (xhr, status, error) {
						BusyIndicator.hide();
						that.getView().byId("idSecificStandard").clearSelection();
						MessageToast.show(xhr.responseJSON.error.message + "" + that.oResourceBundle.getText("LINE_EVENT_DB_NOT_UPDATED"));
						var message = xhr.responseJSON.error.message + "" + that.oResourceBundle.getText("LINE_EVENT_DB_UPDATE_FAIL");
						that.onShowError(message);
					});
				}

			},
			onCancel: function (evt) {
				this.getView().byId("idtab1Edit").setVisible(true);
				this.getView().byId("idLineViewCycleSubmit").setVisible(false);
				this.getView().byId("idLineViewCycleCancel").setVisible(false);
				this.getView().byId("idtab1Delete").setEnabled(true);
				this.getView().byId("idSecificStandard").clearSelection();

				this.fnReadCyclesDbData();

			},
			// onDelete: function () {
			// 	if (!this._oPopoverDeleteRow) {
			// 		this._oPopoverDeleteRow = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.PopoverDeleteRecordsLine", this);
			// 		this.getView().addDependent(this._oPopoverDeleteRow);
			// 	}
			// 	this._oPopoverDeleteRow.open();
			// },

			// Cycle event tab edit button function
			cycleEventEdit: function (oEvent) {
				// row selected
				var tableIndex = this.getView().byId("idCycleEventsDB").getSelectedIndices();
				for (var i = 0; i < tableIndex.length; i++) {
					this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + tableIndex[i] + "/enable", true);
					this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + tableIndex[i] + "/edit", true);
				}

				this.getView().byId("idtab2Edit").setVisible(false);
				this.getView().byId("idLineViewCycleEventSubmit").setVisible(true);
				this.getView().byId("idLineViewCycleEventCancel").setVisible(true);
				this.getView().byId("idtab2Delete").setEnabled(false);

			},
			// Loss category dropdown data read
			fnViewLossCat: function (evt) {

				var oModelLineLossCat = new sap.ui.model.json.JSONModel();
				var aLineStdData = this.getOwnerComponent().getModel("lineStandardHeaderModel").getData().value;
				var aSpecificLineStdHeaderData = aLineStdData.filter(function (val) {
					if (val.lineStdNo == lineStdNo)
						return val;
				});
				var sPlant = aSpecificLineStdHeaderData[0].plant;
				oModelLineLossCat.loadData("odata/v4/data-services/LineRelatedLossCatDB?$filter=plant eq '" + sPlant + "'&$select=lossCat,subCat");
				oModelLineLossCat.setSizeLimit(100);
				this.getView().setModel(oModelLineLossCat, "lineViewLossCatModel");

			},
			// Cycle event sub cat  function to make required fields editable
			fnViewCycleEvSubCat: function (evt) {
				var tableIndex = this.getView().byId("idCycleEventsDB").getSelectedIndices();
				for (var i = 0; i < tableIndex.length; i++) {
					this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + tableIndex[i] + "/edit", true);
					this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + tableIndex[i] + "/enable", true);
				}
				if (this.getView().getModel("lineViewSubCatModel") != undefined) {
					this.getView().getModel("lineViewSubCatModel").setData({ "value": [{ subCat: "" }] });
				}
			},
			// Cycle event sub cat  function to make required fields editable
			fnViewSubCat: function (evt) {
				var tableIndex = this.getView().byId("idCycleAnnualDB").getSelectedIndices();
				for (var i = 0; i < tableIndex.length; i++) {
					this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/edit", true);
					this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/enable", true);
				}

				if (this.getView().getModel("lineViewSubCatModel") != undefined) {
					this.getView().getModel("lineViewSubCatModel").setData({ "value": [{ subCat: "" }] });
				}
			},

			// cycle event sub cat model data read
			fnViewCycleEventLossCat: function (evt) {
				var aLineStdData = this.getOwnerComponent().getModel("lineStandardHeaderModel").getData().value;
				var aSpecificLineStdHeaderData = aLineStdData.filter(function (val) {
					if (val.lineStdNo == lineStdNo)
						return val;
				});
				var sPlant = aSpecificLineStdHeaderData[0].plant;
				var sLossCatPath = evt.getSource().getBindingContext("lineStdCycleEventDbModel").sPath;
				var sLossCat = this.getView().getModel("lineStdCycleEventDbModel").getProperty(sLossCatPath + "/lossCat");
				this.getView().getModel("lineStdCycleEventDbModel").setProperty(sLossCatPath + "/subCat", "");

				var aTableIndex = this.getView().byId("idCycleEventsDB").getSelectedIndices();

				for (var i = 0; i < aTableIndex.length; i++) {
					if (aTableIndex[i] != sLossCatPath.slice(7)) {
						this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + aTableIndex[i] + "/edit", false);
						this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + aTableIndex[i] + "/enable", false);
					}

				}

				var oModelLineSubCat = new sap.ui.model.json.JSONModel();
				oModelLineSubCat.loadData("odata/v4/data-services/LineRelatedLossCatDB?$filter=plant eq '" + sPlant + "' and lossCat eq '" + sLossCat + "'&$select=subCat");

				oModelLineSubCat.setSizeLimit(100);
				this.getView().setModel(oModelLineSubCat, "lineViewSubCatModel");
			},

			// annual event sub cat model data read
			fnViewAnnualEvLossCat: function (evt) {
				var aLineStdData = this.getOwnerComponent().getModel("lineStandardHeaderModel").getData().value;
				var aSpecificLineStdHeaderData = aLineStdData.filter(function (val) {
					if (val.lineStdNo == lineStdNo)
						return val;
				});
				var sPlant = aSpecificLineStdHeaderData[0].plant;
				var sLossCatPath = evt.getSource().getBindingContext("lineStdAnnualEventDbModel").sPath;
				var sLossCat = this.getView().getModel("lineStdAnnualEventDbModel").getProperty(sLossCatPath + "/lossCat");
				this.getView().getModel("lineStdAnnualEventDbModel").setProperty(sLossCatPath + "/subCat", "");

				var aTableIndex = this.getView().byId("idCycleAnnualDB").getSelectedIndices();

				for (var i = 0; i < aTableIndex.length; i++) {
					if (aTableIndex[i] != sLossCatPath.slice(7)) {
						this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + aTableIndex[i] + "/edit", false);
						this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + aTableIndex[i] + "/enable", false);
					}
				}
				var oModelLineSubCat = new sap.ui.model.json.JSONModel();
				oModelLineSubCat.loadData("odata/v4/data-services/LineRelatedLossCatDB?$filter=plant eq '" + sPlant + "' and lossCat eq '" + sLossCat + "'&$select=subCat");
				oModelLineSubCat.setSizeLimit(100);
				this.getView().setModel(oModelLineSubCat, "lineViewSubCatModel");
			},

			fnViewCycleEvLossCat: function (evt) {
				for (var i = 0; i < this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToCyclesEvtDataNav").length; i++) {
					this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/lossCatEditable", true);
					this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToCyclesEvtDataNav/" + i + "/subCatEditable", true);
				}
				for (var i = 0; i < this.getView().getModel("lineStandardUpdateModel").getProperty("/LineHdrToAnnualEvtDataNav").length; i++) {
					this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/lossCatEditable", true);
					this.getView().getModel("lineStandardUpdateModel").setProperty("/LineHdrToAnnualEvtDataNav/" + i + "/subCatEditable", true);
				}
				if (this.getView().getModel("lineUpdateSubCatModel") != undefined) {
					this.getView().getModel("lineUpdateSubCatModel").setData({ "value": [{ subCat: "" }] });
				}
			},

			//  Cycle Event DB Edit--> Submit function 
			cycleEventSubmit: function () {
				var that = this;
				///////////////////////////////////New Payload for Multi Update////////////////////////////////////////////
				var tableIndex = this.getView().byId("idCycleEventsDB").getSelectedIndices();
				var aUpdateData = [];
				var iCycleEventsDbError = 0;

				for (var i = 0; i < tableIndex.length; i++) {
					//////////////////Cycle Events DB validation //////////////////////////////////

					var lossCat = this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value/" + tableIndex[i] + "/lossCat");
					var subCat = this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value/" + tableIndex[i] + "/subCat");
					var crewSize = this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value/" + tableIndex[i] + "/expectedCrewSize");
					var ExpFrequency = this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value/" + tableIndex[i] + "/expectedFreqPerCycle");
					var ExpEventDur = this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value/" + tableIndex[i] + "/expectedEvtDur");

					if (lossCat == "") {
						this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateLossCat", "Error");
						this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateTextLossCat", this.oResourceBundle.getText("ERROR_LOSS_CATEGORY"));
						iCycleEventsDbError = 1;
					} else {
						this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateLossCat", "None");

					}
					if (subCat == "") {
						this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateSubCat", "Error");
						this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateTextSubCat", this.oResourceBundle.getText("ERROR_SUB_CATEGORY"));
						iCycleEventsDbError = 1;
					} else {
						this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateSubCat", "None");
					}
					if (ExpFrequency == "") {
						this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateExpFrequency", "Error");
						this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateTextExpFrequency", this.oResourceBundle.getText("ERROR_EXPECTED_FREQUENCY"));
						iCycleEventsDbError = 1;
					} else {
						this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateExpFrequency", "None");
					}
					if (ExpEventDur == "") {
						this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateExpEventDur", "Error");
						this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateTextExpEventDur", this.oResourceBundle.getText("ERROR_EXP_EVENT_DUR"));
						iCycleEventsDbError = 1;
					} else {
						this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateExpEventDur", "None");
					}
				}

				if (iCycleEventsDbError != 0) {
					MessageToast.show(this.oResourceBundle.getText("MAND_LINE_ERROR_VIEW_STD"));
				} else {
					this.getView().byId("idtab2Edit").setVisible(true);
					this.getView().byId("idLineViewCycleEventSubmit").setVisible(false);
					this.getView().byId("idLineViewCycleEventCancel").setVisible(false);
					this.getView().byId("idtab2Delete").setEnabled(true);
					//////////////////////////////////////////////////////////////////////////////////
					var aLineStdData = this.getOwnerComponent().getModel("lineStandardHeaderModel").getData().value;
					var aSpecificLineStdHeaderData = aLineStdData.filter(function (val) {
						if (val.lineStdNo == lineStdNo)
							return val;
					});

					var TotCycleEvPlanDTLoss = 0;

					for (var i = 0; i < tableIndex.length; i++) {

						var currentObj = {};
						this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + tableIndex[i] + "/edit", false);

						currentObj.ID = this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value/" + tableIndex[i] + "/ID");
						currentObj.lossCat = this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value/" + tableIndex[i] + "/lossCat");
						currentObj.subCat = this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value/" + tableIndex[i] + "/subCat");
						currentObj.expectedCrewSize = this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value/" + tableIndex[i] + "/expectedCrewSize");
						currentObj.expectedFreqPerCycle = this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value/" + tableIndex[i] + "/expectedFreqPerCycle");
						currentObj.expectedEvtDur = this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value/" + tableIndex[i] + "/expectedEvtDur");

						currentObj.expectedDurPerCycle = Number(currentObj.expectedFreqPerCycle * currentObj.expectedEvtDur);
						currentObj.expectedLbrHrsPerCycle = Number(currentObj.expectedCrewSize * currentObj.expectedDurPerCycle);
						currentObj.expectedTotLbrHrs = Number(aSpecificLineStdHeaderData[0].cyclesInYear * currentObj.expectedLbrHrsPerCycle);
						currentObj.plannedDtLoss = Number(Number(((currentObj.expectedDurPerCycle / aSpecificLineStdHeaderData[0].totalOccupiedTime) * Number(aSpecificLineStdHeaderData[0].cyclesInYear)) * 100).toFixed(2));
						aUpdateData.push(currentObj);

						TotCycleEvPlanDTLoss = TotCycleEvPlanDTLoss + currentObj.plannedDtLoss;

					}

					var aAnnualEventData = this.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value");
					var TotAnnualEventPlanDTLoss = 0;
					for (var i = 0; i < aAnnualEventData.length; i++) {
						TotAnnualEventPlanDTLoss = TotAnnualEventPlanDTLoss + aAnnualEventData[i].plannedDtLoss;
					}
					var TotalPlannedDTLoss = Number((TotCycleEvPlanDTLoss + TotAnnualEventPlanDTLoss).toFixed(3));

					var oPayload = { "updateData": aUpdateData, "lineStdID": aSpecificLineStdHeaderData[0].ID, plannedDtLoss: TotalPlannedDTLoss, "lineStdNo": lineStdNo };//,"lineStdNo":lineStdNo

					var updateUrl = "odata/v4/data-services/updateLineRelStdCycleEvtItems";
					////////////////////////////////////New Payload for Multi Update/////////////////////////////////////////////
					BusyIndicator.show()
					$.ajax({
						url: updateUrl,
						type: "POST",
						contentType: "application/json",
						data: JSON.stringify(oPayload)
					}).done(function (data) {
						BusyIndicator.hide();
						MessageToast.show(that.oResourceBundle.getText("CYCLES_DB_UPDATED"));
						var message = that.oResourceBundle.getText("CYCLES_DB_UPDATE_SUCCESS");
						that.onShowSuccess(message);
						that.getView().byId("idCycleEventsDB").clearSelection();
						that.getView().getModel("viewHeaderModel").setProperty("/status", "Modified");
						that.getView().getModel("viewHeaderModel").setProperty("/reworkComment", null);
						that.fnReadCycleEventsDbData();
					}).fail(function (xhr, status, error) {
						MessageToast.show(that.oResourceBundle.getText("CYCLES_DB_NOT_UPDATED"));
						var message = that.oResourceBundle.getText("CYCLES_DB_UPDATE_FAIL");
						that.onShowError(message);
						that.getView().byId("idCycleEventsDB").clearSelection();
						BusyIndicator.hide();
						that.fnReadCycleEventsDbData();

					});
				}
				/////////////////////////////////////////////////////////////////////////////////////////////////////////


			},
			fnCycleEventCancel: function () {
				var tableIndex = this.getView().byId("idCycleEventsDB").getSelectedIndices();
				for (var i = 0; i < tableIndex.length; i++) {
					this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + tableIndex[i] + "/enable", false);
					this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + tableIndex[i] + "/edit", false);
				}
				this.getView().byId("idCycleEventsDB").clearSelection();
				this.getView().byId("idtab2Edit").setVisible(true);
				this.getView().byId("idLineViewCycleEventSubmit").setVisible(false);
				this.getView().byId("idLineViewCycleEventCancel").setVisible(false);
				this.getView().byId("idtab2Delete").setEnabled(true);
				this.fnReadCycleEventsDbData();

			},
			// fnCycleEventDelete: function () {
			// 	if (!this._oPopoverDeleteRow) {
			// 		this._oPopoverDeleteRow = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.PopoverDeleteRecordsLine", this);
			// 		this.getView().addDependent(this._oPopoverDeleteRow);
			// 	}
			// 	this._oPopoverDeleteRow.open();
			// 	tableIndex = this.getView().byId("idCycleEventsDB").getSelectedIndex();
			// 	if (this.getView().getModel("cycleEventsDBModel") != undefined) {
			// 		var oDeleteRow = this.getView().getModel("cycleEventsDBModel").getProperty("/cycleEventsData").splice(tableIndex, 1);
			// 		var aNewData = this.getView().getModel("cycleEventsDBModel").getProperty("/cycleEventsData");
			// 		this.getView().getModel("cycleEventsDBModel").setProperty("/cycleEventsData", aNewData);
			// 	}
			// },
			OnLineStdViewCyclesdbDelete: function () {
				sap.m.MessageBox.confirm(
					this.oResourceBundle.getText("DELETE_CONFIRMATION"), // Message
					{
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
						onClose: function (sAction) { // Callback when the dialog is closed
							if (sAction === MessageBox.Action.YES) {
								////start cycledb delete/////////////

								var deleteUrl = "odata/v4/data-services/updateLineStdItems";
								var tableIndex = this.getView().byId("idSecificStandard").getSelectedIndices();
								var aRowIdNo = [];
								for (var i = 0; i < tableIndex.length; i++) {
									aRowIdNo.push(this.getView().getModel("LineStdCycleDBModel").getProperty("/value/" + tableIndex[i] + "/ID"));
								}

								////////////////////////Calculated fields////////////////////////////////////////////////////
								var avgProdCycle, avgShiftInDay, avgShiftInCycle, avgCycleHours, shiftlength = 0, totOccupiedTime = 0, cycleInYearInt = 0,
									shiftInCycleInt = 0, cycleHoursInt = 0, totOccupiedTimeInt = 0, shiftInCycle = 0, cycleHours = 0,
									totOccupiedTime = 0, cycleInYear = 0, shiftInDayInt = 0, prodCycleInt = 0, shiftInDay = 0, prodCycle = 0, iLineApproveSelIndex;

								this.getView().getModel("LineStdCycleDBModel").getData();
								var aRow = this.getView().getModel("LineStdCycleDBModel").getData().value.length;

								for (var i = 0; i < aRow; i++) {
									if (i != tableIndex[i]) {
										shiftInDayInt = Number(this.getView().getModel("LineStdCycleDBModel").getData().value[i].shiftsInDays);
										prodCycleInt = Number(this.getView().getModel("LineStdCycleDBModel").getData().value[i].prodCyclesInDays)
										shiftInDay = Number(this.getView().getModel("LineStdCycleDBModel").getData().value[i].shiftsInDays) + shiftInDay;
										prodCycle = Number(this.getView().getModel("LineStdCycleDBModel").getData().value[i].prodCyclesInDays) + prodCycle;
										shiftlength = Number(this.getView().getModel("LineStdCycleDBModel").getData().value[i].shiftLength);
										cycleInYearInt = Number(this.getView().getModel("LineStdCycleDBModel").getData().value[i].cyclesInYear);
										shiftInCycleInt = Number((shiftInDayInt * prodCycleInt).toFixed(3));
										cycleHoursInt = Number((shiftInCycleInt * shiftlength).toFixed(3));
										totOccupiedTimeInt = Number((cycleHoursInt * cycleInYearInt).toFixed(3));
										shiftInCycle = Number((shiftInCycleInt + shiftInCycle).toFixed(3));
										cycleHours = Number((cycleHoursInt + cycleHours).toFixed(3));
										totOccupiedTime = Number((totOccupiedTimeInt + totOccupiedTime).toFixed(3));
										cycleInYear = Number((cycleInYearInt + cycleInYear).toFixed(3));
									}
								}
								avgProdCycle = Number((prodCycle / aRow).toFixed(3));
								avgShiftInDay = Number((shiftInDay / aRow).toFixed(3));
								//avgShiftInCycle = Number((shiftInCycle / aRow).toFixed(3));
								avgShiftInCycle = Number((avgShiftInDay * avgProdCycle).toFixed(3));
								avgCycleHours = Number((totOccupiedTime / cycleInYear).toFixed(3));
								totOccupiedTime = Number((totOccupiedTime).toFixed(3));
								///////////////////////////////////////////////////////////////////////////////////////
								var aLineStdData = this.getOwnerComponent().getModel("lineStandardHeaderModel").getData().value;
								var aSpecificLineStdHeaderData = aLineStdData.filter(function (val) {
									if (val.lineStdNo == lineStdNo)
										return val;
								});

								var obj = {};
								obj.ID = aSpecificLineStdHeaderData[0].ID;
								obj.lineStdNo = aSpecificLineStdHeaderData[0].lineStdNo;
								// obj.status = aSpecificLineStdHeaderData[0].status;
								obj.validTo = aSpecificLineStdHeaderData[0].validTo;
								obj.prodCyclesInDays = avgProdCycle;
								obj.shiftsInDay = avgShiftInDay;
								obj.shiftsInCycle = avgShiftInCycle;
								obj.cycleHrs = avgCycleHours;
								obj.cyclesInYear = cycleInYear;
								obj.totalOccupiedTime = totOccupiedTime;
								obj.status = "Modified";
								obj.reworkComment = null;
								obj.stdApprLvl = 0;
								obj.executionState = 0;
								obj.executorsIDs = [];

								var updateLineStdHdrDb = [];
								updateLineStdHdrDb.push(obj);

								////////////////////////////////// DB payload calculation/////////////////////////////
								var aCycleDbData = [];
								var aStdCycleDbData = this.getView().getModel("LineStdCycleDBModel").getProperty("/value");
								for (var i = 0; i < aStdCycleDbData.length; i++) {
									if (i != tableIndex[i]) {
										var oStdCyclesDbData = {};
										oStdCyclesDbData.ID = aStdCycleDbData[i].ID;
										oStdCyclesDbData.condition = aStdCycleDbData[i].condition;
										oStdCyclesDbData.conditionDesc = aStdCycleDbData[i].conditionDesc;
										oStdCyclesDbData.shiftLength = Number(aStdCycleDbData[i].shiftLength);
										oStdCyclesDbData.prodCyclesInDays = Number(aStdCycleDbData[i].prodCyclesInDays);
										oStdCyclesDbData.shiftsInDays = Number(aStdCycleDbData[i].shiftsInDays);
										oStdCyclesDbData.shiftsInCycle = Number(aStdCycleDbData[i].shiftsInCycle);
										oStdCyclesDbData.cycleHrs = Number(aStdCycleDbData[i].cycleHrs);
										oStdCyclesDbData.cyclesInYear = Number(aStdCycleDbData[i].cyclesInYear);
										oStdCyclesDbData.totalOccupiedTime = Number(aStdCycleDbData[i].totalOccupiedTime);
										//03-09-2024 Changes required only for poc
										oStdCyclesDbData.status = "Modified";

										aCycleDbData.push(oStdCyclesDbData);
									}
								}
								var aCycleEventDbData = [];
								var aStdCycleEventDbData = this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value");
								for (var i = 0; i < aStdCycleEventDbData.length; i++) {
									var oStdCyclesDbData = {};
									oStdCyclesDbData.ID = aStdCycleEventDbData[i].ID;
									oStdCyclesDbData.lossCat = aStdCycleEventDbData[i].lossCat;
									oStdCyclesDbData.subCat = aStdCycleEventDbData[i].subCat;
									oStdCyclesDbData.cycleHrs = aStdCycleEventDbData[i].cycleHrs;
									oStdCyclesDbData.cyclesInYear = aStdCycleEventDbData[i].cyclesInYear;
									oStdCyclesDbData.expectedCrewSize = aStdCycleEventDbData[i].expectedCrewSize;
									oStdCyclesDbData.expectedFreqPerCycle = aStdCycleEventDbData[i].expectedFreqPerCycle;
									oStdCyclesDbData.expectedEvtDur = aStdCycleEventDbData[i].expectedEvtDur;
									oStdCyclesDbData.expectedDurPerCycle = aStdCycleEventDbData[i].expectedDurPerCycle;
									oStdCyclesDbData.plannedDtLoss = aStdCycleEventDbData[i].plannedDtLoss;
									oStdCyclesDbData.expectedLbrHrsPerCycle = aStdCycleEventDbData[i].expectedLbrHrsPerCycle;
									oStdCyclesDbData.expectedTotLbrHrs = aStdCycleEventDbData[i].expectedTotLbrHrs;
									//03-09-2024 Changes required only for poc
									oStdCyclesDbData.status = "Modified";
									aCycleEventDbData.push(oStdCyclesDbData);

								}
								var aCycleAnnualEventDbData = [];
								var aStdAnnualCycleEventDbData = this.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value");
								for (var i = 0; i < aStdAnnualCycleEventDbData.length; i++) {
									var oStdCyclesDbData = {};
									oStdCyclesDbData.ID = aStdAnnualCycleEventDbData[i].ID;
									oStdCyclesDbData.lossCat = aStdAnnualCycleEventDbData[i].lossCat;
									oStdCyclesDbData.subCat = aStdAnnualCycleEventDbData[i].subCat;
									oStdCyclesDbData.totOccupiedHrs = aStdAnnualCycleEventDbData[i].totOccupiedHrs;
									oStdCyclesDbData.cyclesInYear = aStdAnnualCycleEventDbData[i].cyclesInYear;
									oStdCyclesDbData.expectedCrewSize = aStdAnnualCycleEventDbData[i].expectedCrewSize;
									oStdCyclesDbData.expectedFrequency = aStdAnnualCycleEventDbData[i].expectedFrequency;
									oStdCyclesDbData.expectedEvtDur = aStdAnnualCycleEventDbData[i].expectedEvtDur;
									oStdCyclesDbData.expectedDurPerYear = aStdAnnualCycleEventDbData[i].expectedDurPerYear;
									oStdCyclesDbData.plannedDtLoss = aStdAnnualCycleEventDbData[i].plannedDtLoss;
									oStdCyclesDbData.expectedLbrHrPerYear = aStdAnnualCycleEventDbData[i].expectedLbrHrPerYear;
									//03-09-2024 Changes required only for poc
									oStdCyclesDbData.status = "Modified";
									//    oStdCyclesDbData.expectedTotLbrHrs=aStdAnnualCycleEventDbData[i].expectedTotLbrHrs;
									aCycleAnnualEventDbData.push(oStdCyclesDbData);

								}
								//////////////////////////////////////////////////////////////////////////////////////

								var oPayload = {};
								oPayload.updateLineStdHdrDb = updateLineStdHdrDb;
								oPayload.updateLineStdCyclesDb = aCycleDbData;
								oPayload.updateLineStdCycleEvtDb = aCycleEventDbData;
								oPayload.updateLineStdAnnualEvtDb = aCycleAnnualEventDbData;
								oPayload.deleteLineStdCyclesDb = aRowIdNo;
								oPayload.deleteLineStdCycleEvtDb = [];
								oPayload.deleteLineStdAnnualEvtDb = [];


								var TotPlannedDTLoss, EditCycleEventTotPlanDtLoss = 0, EditAnnualCycleEventTotPlanDtLoss = 0;

								var updateLineStdCycleEvtDb = oPayload.updateLineStdCycleEvtDb;
								for (var i = 0; i < updateLineStdCycleEvtDb.length; i++) {

									updateLineStdCycleEvtDb[i].expectedDurPerCycle = Number(updateLineStdCycleEvtDb[i].expectedFreqPerCycle * updateLineStdCycleEvtDb[i].expectedEvtDur);
									updateLineStdCycleEvtDb[i].expectedLbrHrsPerCycle = Number(updateLineStdCycleEvtDb[i].expectedCrewSize * updateLineStdCycleEvtDb[i].expectedDurPerCycle);
									updateLineStdCycleEvtDb[i].cyclesInYear = Number(oPayload.cyclesInYear);
									updateLineStdCycleEvtDb[i].expectedTotLbrHrs = Number(updateLineStdCycleEvtDb[i].cyclesInYear * updateLineStdCycleEvtDb[i].expectedLbrHrsPerCycle);
									updateLineStdCycleEvtDb[i].cycleHrs = Number(oPayload.cycleHrs);
									updateLineStdCycleEvtDb[i].plannedDtLoss = Number(Number(((updateLineStdCycleEvtDb[i].expectedDurPerCycle / oPayload.totalOccupiedTime) * oPayload.cyclesInYear) * 100).toFixed(2));

									EditCycleEventTotPlanDtLoss = EditCycleEventTotPlanDtLoss + updateLineStdCycleEvtDb[i].plannedDtLoss;
								}

								var updateLineStdAnnualEvtDb = oPayload.updateLineStdAnnualEvtDb;
								for (var i = 0; i < updateLineStdAnnualEvtDb.length; i++) {

									updateLineStdAnnualEvtDb[i].expectedDurPerYear = Number(updateLineStdAnnualEvtDb[i].expectedFrequency * updateLineStdAnnualEvtDb[i].expectedEvtDur);
									updateLineStdAnnualEvtDb[i].expectedLbrHrPerYear = Number(updateLineStdAnnualEvtDb[i].expectedCrewSize * updateLineStdAnnualEvtDb[i].expectedDurPerYear);
									updateLineStdAnnualEvtDb[i].totOccupiedHrs = Number(oPayload.totalOccupiedTime);
									updateLineStdAnnualEvtDb[i].plannedDtLoss = Number(Number((updateLineStdAnnualEvtDb[i].expectedDurPerYear / updateLineStdAnnualEvtDb[i].totOccupiedHrs) * 100).toFixed(2));

									EditAnnualCycleEventTotPlanDtLoss = EditAnnualCycleEventTotPlanDtLoss + updateLineStdAnnualEvtDb[i].plannedDtLoss;
								}
								TotPlannedDTLoss = Number(Number(EditCycleEventTotPlanDtLoss + EditAnnualCycleEventTotPlanDtLoss).toFixed(3));

								var that = this;
								BusyIndicator.show();
								$.ajax({
									url: deleteUrl,
									type: "POST",
									contentType: "application/json",
									data: JSON.stringify(oPayload)
								}).done(function (data) {
									MessageToast.show(that.oResourceBundle.getText("SELECT_LINE_CYCLESDB_DELETE"));
									var message = that.oResourceBundle.getText("SELECT_LINE_CYCLESDB_DELETE_SUCCESS");
									that.onShowSuccess(message);
									that.getView().byId("idSecificStandard").clearSelection();
									BusyIndicator.hide();
									//Read data
									that.fnReadCyclesDbData();
									that.getView().getModel("viewHeaderModel").setProperty("/status", "Modified");
									that.getView().getModel("viewHeaderModel").setProperty("/reworkComment", null);
								}).fail(function (xhr, status, error) {
									BusyIndicator.hide();
									MessageToast.show(that.oResourceBundle.getText("SELECT_LINE_CYCLESDB_NOTDELETED"));
									var message = that.oResourceBundle.getText("SELECT_LINE_CYCLESDB_DELETE_FAIL");
									that.getView().byId("idSecificStandard").clearSelection();
									that.onShowError(message);
								});
								//////////////////////////////////////////////////////////////////////////////////////////
							}
						}.bind(this)
					}
				);

			},
			OnLineStdViewCycleEventdbDelete: function () {
				sap.m.MessageBox.confirm(
					this.oResourceBundle.getText("DELETE_CONFIRMATION"), // Message
					{
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
						onClose: function (sAction) { // Callback when the dialog is closed
							if (sAction === MessageBox.Action.YES) {
								var deleteUrl = "odata/v4/data-services/deleteLineRelStdCycleEvtItems";
								var tableIndex = this.getView().byId("idCycleEventsDB").getSelectedIndices();

								// Calculation for Planned DT Loss
								var aCycleEventData = this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value");
								var TotCycleEventPlanDTLoss = 0;
								var aLineStdData = this.getOwnerComponent().getModel("lineStandardHeaderModel").getData().value;
								var aSpecificLineStdHeaderData = aLineStdData.filter(function (val) {
									if (val.lineStdNo == lineStdNo)
										return val;
								});
								for (var i = 0; i < aCycleEventData.length; i++) {
									for (var j = 0; j < tableIndex; j++) {
										if (i != tableIndex[j]) {
											TotCycleEventPlanDTLoss = TotCycleEventPlanDTLoss + aCycleEventData[i].plannedDtLoss;
										}
									}
								}

								var aAnnualEventData = this.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value");
								var TotAnnualEventPlanDTLoss = 0;
								for (var i = 0; i < aAnnualEventData.length; i++) {
									TotAnnualEventPlanDTLoss = TotAnnualEventPlanDTLoss + aAnnualEventData[i].plannedDtLoss;
								}
								var TotalPlannedDTLoss = Number((TotCycleEventPlanDTLoss + TotAnnualEventPlanDTLoss).toFixed(3));

								var aRowIdNo = [];
								for (var i = 0; i < tableIndex.length; i++) {
									aRowIdNo.push(this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value/" + tableIndex[i] + "/ID"));
								}

								var oPayload = { "IDs": aRowIdNo, "lineStdID": aSpecificLineStdHeaderData[0].ID, plannedDtLoss: TotalPlannedDTLoss, "lineStdNo": lineStdNo };//,"lineStdNo":lineStdNo
								var that = this;
								BusyIndicator.show();
								$.ajax({
									url: deleteUrl,
									type: "POST",
									contentType: "application/json",
									data: JSON.stringify(oPayload)
								}).done(function (data) {
									MessageToast.show(that.oResourceBundle.getText("SELECT_LINE_CYCLESDB_DELETE"));
									var message = that.oResourceBundle.getText("SELECT_LINE_CYCLESDB_DELETE_SUCCESS");
									that.onShowSuccess(message);
									that.getView().byId("idCycleEventsDB").clearSelection();

									that.getView().getModel("viewHeaderModel").setProperty("/status", "Modified");
									that.getView().getModel("viewHeaderModel").setProperty("/reworkComment", null);

									BusyIndicator.hide();
									that.fnReadCycleEventsDbData();
								}).fail(function (xhr, status, error) {
									BusyIndicator.hide();
									that.getView().byId("idCycleEventsDB").clearSelection();
									MessageToast.show(that.oResourceBundle.getText("SELECT_LINE_CYCLESDB_NOTDELETED"));
									var message = that.oResourceBundle.getText("SELECT_LINE_CYCLESDB_DELETE_FAIL");
									that.onShowError(message);

								});



							}
						}.bind(this)
					}
				);
				tableIndex = this.getView().byId("idCycleEventsDB").getSelectedIndex();
				if (this.getView().getModel("cycleEventsDBModel") != undefined) {
					var oDeleteRow = this.getView().getModel("cycleEventsDBModel").getProperty("/cycleEventsData").splice(tableIndex, 1);
					var aNewData = this.getView().getModel("cycleEventsDBModel").getProperty("/cycleEventsData");
					this.getView().getModel("cycleEventsDBModel").setProperty("/cycleEventsData", aNewData);
				}
			},
			OnLineStdViewAnnualEventdbDelete: function () {
				sap.m.MessageBox.confirm(
					this.oResourceBundle.getText("DELETE_CONFIRMATION"), // Message
					{
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
						onClose: function (sAction) { // Callback when the dialog is closed
							if (sAction === MessageBox.Action.YES) {
								var deleteUrl = "odata/v4/data-services/deleteLineRelStdAnnualEvtItems";
								var tableIndex = this.getView().byId("idCycleAnnualDB").getSelectedIndices();
								var aRowIdNo = [];
								for (var i = 0; i < tableIndex.length; i++) {
									aRowIdNo.push(this.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value/" + tableIndex[i] + "/ID"));
								}
								// Calculation for Planned DT Loss
								var aCycleEventData = this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value");
								var TotCycleEventPlanDTLoss = 0;
								for (var i = 0; i < aCycleEventData.length; i++) {
									TotCycleEventPlanDTLoss = TotCycleEventPlanDTLoss + aCycleEventData[i].plannedDtLoss;
								}

								var aAnnualEventData = this.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value");
								var TotAnnualEventPlanDTLoss = 0;
								var aLineStdData = this.getOwnerComponent().getModel("lineStandardHeaderModel").getData().value;
								var aSpecificLineStdHeaderData = aLineStdData.filter(function (val) {
									if (val.lineStdNo == lineStdNo)
										return val;
								});
								for (var i = 0; i < aAnnualEventData.length; i++) {
									for (var j = 0; j < tableIndex; j++) {
										if (i != tableIndex[j]) {
											TotAnnualEventPlanDTLoss = TotAnnualEventPlanDTLoss + aAnnualEventData[i].plannedDtLoss;
										}
									}

								}
								var TotalPlannedDTLoss = Number((TotCycleEventPlanDTLoss + TotAnnualEventPlanDTLoss).toFixed(3));




								var oPayload = { "IDs": aRowIdNo, "lineStdID": aSpecificLineStdHeaderData[0].ID, plannedDtLoss: TotalPlannedDTLoss, "lineStdNo": lineStdNo };//,"lineStdNo":lineStdNo
								var that = this;
								BusyIndicator.show();
								$.ajax({
									url: deleteUrl,
									type: "POST",
									contentType: "application/json",
									data: JSON.stringify(oPayload)
								}).done(function (data) {
									MessageToast.show(that.oResourceBundle.getText("SELECT_LINE_ANNUAL_EVENTDB_DELETE"));
									var message = that.oResourceBundle.getText("SELECT_LINE_ANNUAL_EVENTDB_DELETE_SUCCESS");
									that.getView().byId("idCycleAnnualDB").clearSelection();
									that.onShowSuccess(message);
									// alert("DELETE successful");
									BusyIndicator.hide();

									that.fnReadAnnualEventDbData();
									that.getView().getModel("viewHeaderModel").setProperty("/status", "Modified");
									that.getView().getModel("viewHeaderModel").setProperty("/reworkComment", null);

								}).fail(function (_xhr, _status, _error) {
									BusyIndicator.hide();
									that.getView().byId("idCycleAnnualDB").clearSelection();
									MessageToast.show(that.oResourceBundle.getText("SELECT_LINE_ANNUAL_EVENTDB_NOT_DELETED"));
									var message = that.oResourceBundle.getText("SELECT_LINE_ANNUAL_EVENTDB_DELETE_FAIL");
									that.onShowError(message);
								});



							}
						}.bind(this)
					}
				);

			},

			// //function to delete rows in the table
			// handleAcceptButton: function () {
			// 	var that = this;
			// 	var oTab = this.getView().byId("idLineViewTabBar");
			// 	var aLineStdData = this.getOwnerComponent().getModel("lineStandardHeaderModel").getData().value;
			// 	var aSpecificLineStdHeaderData = aLineStdData.filter(function (val) {
			// 		if (val.lineStdNo == lineStdNo)
			// 			return val;
			// 	});
			// 	var mainTabKey = oTab.getSelectedKey();
			// 	if (mainTabKey == "CycleEventsDB") {

			// 		//DELETE single row                   
			// 		var deleteUrl = "odata/v4/data-services/deleteLineRelStdCycleEvtItems";
			// 		var tableIndex = this.getView().byId("idCycleEventsDB").getSelectedIndices();

			// 		// Calculation for Planned DT Loss
			// 		var aCycleEventData = this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value");
			// 		var TotCycleEventPlanDTLoss = 0;
			// 		for (var i = 0; i < aCycleEventData.length; i++) {
			// 			for (var j = 0; j < tableIndex; j++) {
			// 				if (i != tableIndex[j]) {
			// 					TotCycleEventPlanDTLoss = TotCycleEventPlanDTLoss + aCycleEventData[i].plannedDtLoss;
			// 				}
			// 			}
			// 		}

			// 		var aAnnualEventData = this.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value");
			// 		var TotAnnualEventPlanDTLoss = 0;
			// 		for (var i = 0; i < aAnnualEventData.length; i++) {
			// 			TotAnnualEventPlanDTLoss = TotAnnualEventPlanDTLoss + aAnnualEventData[i].plannedDtLoss;
			// 		}
			// 		var TotalPlannedDTLoss = Number((TotCycleEventPlanDTLoss + TotAnnualEventPlanDTLoss).toFixed(3));

			// 		var aRowIdNo = [];
			// 		for (var i = 0; i < tableIndex.length; i++) {
			// 			aRowIdNo.push(this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value/" + tableIndex[i] + "/ID"));
			// 		}

			// 		var oPayload = { "IDs": aRowIdNo, "lineStdID": aSpecificLineStdHeaderData[0].ID, plannedDtLoss: TotalPlannedDTLoss, "lineStdNo": lineStdNo };//,"lineStdNo":lineStdNo
			// 		var that = this;
			// 		BusyIndicator.show();
			// 		$.ajax({
			// 			url: deleteUrl,
			// 			type: "POST",
			// 			contentType: "application/json",
			// 			data: JSON.stringify(oPayload)
			// 		}).done(function (data) {
			// 			MessageToast.show(that.oResourceBundle.getText("SELECT_LINE_CYCLESDB_DELETE"));
			// 			var message = that.oResourceBundle.getText("SELECT_LINE_CYCLESDB_DELETE_SUCCESS");
			// 			that.onShowSuccess(message);
			// 			that.getView().byId("idCycleEventsDB").clearSelection();

			// 			that.getView().getModel("viewHeaderModel").setProperty("/status", "Modified");
			// 			that.getView().getModel("viewHeaderModel").setProperty("/reworkComment", null);

			// 			BusyIndicator.hide();
			// 			that.fnReadCycleEventsDbData();
			// 		}).fail(function (xhr, status, error) {
			// 			BusyIndicator.hide();
			// 			that.getView().byId("idCycleEventsDB").clearSelection();
			// 			MessageToast.show(that.oResourceBundle.getText("SELECT_LINE_CYCLESDB_NOTDELETED"));
			// 			var message = that.oResourceBundle.getText("SELECT_LINE_CYCLESDB_DELETE_FAIL");
			// 			that.onShowError(message);

			// 		});

			// 	}
			// 	if (mainTabKey == "AnnualEventDB") {
			// 		var deleteUrl = "odata/v4/data-services/deleteLineRelStdAnnualEvtItems";
			// 		var tableIndex = this.getView().byId("idCycleAnnualDB").getSelectedIndices();
			// 		var aRowIdNo = [];
			// 		for (var i = 0; i < tableIndex.length; i++) {
			// 			aRowIdNo.push(this.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value/" + tableIndex[i] + "/ID"));
			// 		}
			// 		// Calculation for Planned DT Loss
			// 		var aCycleEventData = this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value");
			// 		var TotCycleEventPlanDTLoss = 0;
			// 		for (var i = 0; i < aCycleEventData.length; i++) {
			// 			TotCycleEventPlanDTLoss = TotCycleEventPlanDTLoss + aCycleEventData[i].plannedDtLoss;
			// 		}

			// 		var aAnnualEventData = this.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value");
			// 		var TotAnnualEventPlanDTLoss = 0;
			// 		for (var i = 0; i < aAnnualEventData.length; i++) {
			// 			for (var j = 0; j < tableIndex; j++) {
			// 				if (i != tableIndex[j]) {
			// 					TotAnnualEventPlanDTLoss = TotAnnualEventPlanDTLoss + aAnnualEventData[i].plannedDtLoss;
			// 				}
			// 			}

			// 		}
			// 		var TotalPlannedDTLoss = Number((TotCycleEventPlanDTLoss + TotAnnualEventPlanDTLoss).toFixed(3));




			// 		var oPayload = { "IDs": aRowIdNo, "lineStdID": aSpecificLineStdHeaderData[0].ID, plannedDtLoss: TotalPlannedDTLoss, "lineStdNo": lineStdNo };//,"lineStdNo":lineStdNo
			// 		var that = this;
			// 		BusyIndicator.show();
			// 		$.ajax({
			// 			url: deleteUrl,
			// 			type: "POST",
			// 			contentType: "application/json",
			// 			data: JSON.stringify(oPayload)
			// 		}).done(function (data) {
			// 			MessageToast.show(that.oResourceBundle.getText("SELECT_LINE_ANNUAL_EVENTDB_DELETE"));
			// 			var message = that.oResourceBundle.getText("SELECT_LINE_ANNUAL_EVENTDB_DELETE_SUCCESS");
			// 			that.getView().byId("idCycleAnnualDB").clearSelection();
			// 			that.onShowSuccess(message);
			// 			// alert("DELETE successful");
			// 			BusyIndicator.hide();

			// 			that.fnReadAnnualEventDbData();
			// 			that.getView().getModel("viewHeaderModel").setProperty("/status", "Modified");
			// 			that.getView().getModel("viewHeaderModel").setProperty("/reworkComment", null);

			// 		}).fail(function (xhr, status, error) {
			// 			BusyIndicator.hide();
			// 			that.getView().byId("idCycleAnnualDB").clearSelection();
			// 			MessageToast.show(that.oResourceBundle.getText("SELECT_LINE_ANNUAL_EVENTDB_NOT_DELETED"));
			// 			var message = that.oResourceBundle.getText("SELECT_LINE_ANNUAL_EVENTDB_DELETE_FAIL");
			// 			that.onShowError(message);
			// 		});

			// 		//////////////////////////////////////////////////////////////////////////////////////////
			// 	}
			// 	if (mainTabKey == "Cycles DB") {
			// 		var deleteUrl = "odata/v4/data-services/updateLineStdItems";
			// 		var tableIndex = this.getView().byId("idSecificStandard").getSelectedIndices();
			// 		var aRowIdNo = [];
			// 		for (var i = 0; i < tableIndex.length; i++) {
			// 			aRowIdNo.push(this.getView().getModel("LineStdCycleDBModel").getProperty("/value/" + tableIndex[i] + "/ID"));
			// 		}

			// 		////////////////////////Calculated fields////////////////////////////////////////////////////
			// 		var avgProdCycle, avgShiftInDay, avgShiftInCycle, avgCycleHours, shiftlength = 0, totOccupiedTime = 0, cycleInYearInt = 0,
			// 			shiftInCycleInt = 0, cycleHoursInt = 0, totOccupiedTimeInt = 0, shiftInCycle = 0, cycleHours = 0,
			// 			totOccupiedTime = 0, cycleInYear = 0, shiftInDayInt = 0, prodCycleInt = 0, shiftInDay = 0, prodCycle = 0, iLineApproveSelIndex;

			// 		this.getView().getModel("LineStdCycleDBModel").getData();
			// 		var aRow = this.getView().getModel("LineStdCycleDBModel").getData().value.length;

			// 		for (var i = 0; i < aRow; i++) {
			// 			if (i != tableIndex[i]) {
			// 				shiftInDayInt = Number(this.getView().getModel("LineStdCycleDBModel").getData().value[i].shiftsInDays);
			// 				prodCycleInt = Number(this.getView().getModel("LineStdCycleDBModel").getData().value[i].prodCyclesInDays)
			// 				shiftInDay = Number(this.getView().getModel("LineStdCycleDBModel").getData().value[i].shiftsInDays) + shiftInDay;
			// 				prodCycle = Number(this.getView().getModel("LineStdCycleDBModel").getData().value[i].prodCyclesInDays) + prodCycle;
			// 				shiftlength = Number(this.getView().getModel("LineStdCycleDBModel").getData().value[i].shiftLength);
			// 				cycleInYearInt = Number(this.getView().getModel("LineStdCycleDBModel").getData().value[i].cyclesInYear);
			// 				shiftInCycleInt = Number((shiftInDayInt * prodCycleInt).toFixed(3));
			// 				cycleHoursInt = Number((shiftInCycleInt * shiftlength).toFixed(3));
			// 				totOccupiedTimeInt = Number((cycleHoursInt * cycleInYearInt).toFixed(3));
			// 				shiftInCycle = Number((shiftInCycleInt + shiftInCycle).toFixed(3));
			// 				cycleHours = Number((cycleHoursInt + cycleHours).toFixed(3));
			// 				totOccupiedTime = Number((totOccupiedTimeInt + totOccupiedTime).toFixed(3));
			// 				cycleInYear = Number((cycleInYearInt + cycleInYear).toFixed(3));
			// 			}
			// 		}
			// 		avgProdCycle = Number((prodCycle / aRow).toFixed(3));
			// 		avgShiftInDay = Number((shiftInDay / aRow).toFixed(3));
			// 		//avgShiftInCycle = Number((shiftInCycle / aRow).toFixed(3));
			// 		avgShiftInCycle = Number((avgShiftInDay * avgProdCycle).toFixed(3));
			// 		avgCycleHours = Number((totOccupiedTime / cycleInYear).toFixed(3));
			// 		totOccupiedTime = Number((totOccupiedTime).toFixed(3));
			// 		///////////////////////////////////////////////////////////////////////////////////////
			// 		var aLineStdData = this.getOwnerComponent().getModel("lineStandardHeaderModel").getData().value;
			// 		var aSpecificLineStdHeaderData = aLineStdData.filter(function (val) {
			// 			if (val.lineStdNo == lineStdNo)
			// 				return val;
			// 		});

			// 		var obj = {};
			// 		obj.ID = aSpecificLineStdHeaderData[0].ID;
			// 		obj.lineStdNo = aSpecificLineStdHeaderData[0].lineStdNo;
			// 		// obj.status = aSpecificLineStdHeaderData[0].status;
			// 		obj.validTo = aSpecificLineStdHeaderData[0].validTo;
			// 		obj.prodCyclesInDays = avgProdCycle;
			// 		obj.shiftsInDay = avgShiftInDay;
			// 		obj.shiftsInCycle = avgShiftInCycle;
			// 		obj.cycleHrs = avgCycleHours;
			// 		obj.cyclesInYear = cycleInYear;
			// 		obj.totalOccupiedTime = totOccupiedTime;
			// 		obj.status = "Modified";
			// 		obj.reworkComment = null;
			// 		obj.stdApprLvl = 0;
			// 		obj.executionState = 0;
			// 		obj.executorsIDs = [];

			// 		var updateLineStdHdrDb = [];
			// 		updateLineStdHdrDb.push(obj);

			// 		////////////////////////////////// DB payload calculation/////////////////////////////
			// 		var aCycleDbData = [];
			// 		var aStdCycleDbData = this.getView().getModel("LineStdCycleDBModel").getProperty("/value");
			// 		for (var i = 0; i < aStdCycleDbData.length; i++) {
			// 			if (i != tableIndex[i]) {
			// 				var oStdCyclesDbData = {};
			// 				oStdCyclesDbData.ID = aStdCycleDbData[i].ID;
			// 				oStdCyclesDbData.condition = aStdCycleDbData[i].condition;
			// 				oStdCyclesDbData.conditionDesc = aStdCycleDbData[i].conditionDesc;
			// 				oStdCyclesDbData.shiftLength = Number(aStdCycleDbData[i].shiftLength);
			// 				oStdCyclesDbData.prodCyclesInDays = Number(aStdCycleDbData[i].prodCyclesInDays);
			// 				oStdCyclesDbData.shiftsInDays = Number(aStdCycleDbData[i].shiftsInDays);
			// 				oStdCyclesDbData.shiftsInCycle = Number(aStdCycleDbData[i].shiftsInCycle);
			// 				oStdCyclesDbData.cycleHrs = Number(aStdCycleDbData[i].cycleHrs);
			// 				oStdCyclesDbData.cyclesInYear = Number(aStdCycleDbData[i].cyclesInYear);
			// 				oStdCyclesDbData.totalOccupiedTime = Number(aStdCycleDbData[i].totalOccupiedTime);
			// 				//03-09-2024 Changes required only for poc
			// 				oStdCyclesDbData.status = "Modified";

			// 				aCycleDbData.push(oStdCyclesDbData);
			// 			}
			// 		}
			// 		var aCycleEventDbData = [];
			// 		var aStdCycleEventDbData = this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value");
			// 		for (var i = 0; i < aStdCycleEventDbData.length; i++) {
			// 			var oStdCyclesDbData = {};
			// 			oStdCyclesDbData.ID = aStdCycleEventDbData[i].ID;
			// 			oStdCyclesDbData.lossCat = aStdCycleEventDbData[i].lossCat;
			// 			oStdCyclesDbData.subCat = aStdCycleEventDbData[i].subCat;
			// 			oStdCyclesDbData.cycleHrs = aStdCycleEventDbData[i].cycleHrs;
			// 			oStdCyclesDbData.cyclesInYear = aStdCycleEventDbData[i].cyclesInYear;
			// 			oStdCyclesDbData.expectedCrewSize = aStdCycleEventDbData[i].expectedCrewSize;
			// 			oStdCyclesDbData.expectedFreqPerCycle = aStdCycleEventDbData[i].expectedFreqPerCycle;
			// 			oStdCyclesDbData.expectedEvtDur = aStdCycleEventDbData[i].expectedEvtDur;
			// 			oStdCyclesDbData.expectedDurPerCycle = aStdCycleEventDbData[i].expectedDurPerCycle;
			// 			oStdCyclesDbData.plannedDtLoss = aStdCycleEventDbData[i].plannedDtLoss;
			// 			oStdCyclesDbData.expectedLbrHrsPerCycle = aStdCycleEventDbData[i].expectedLbrHrsPerCycle;
			// 			oStdCyclesDbData.expectedTotLbrHrs = aStdCycleEventDbData[i].expectedTotLbrHrs;
			// 			//03-09-2024 Changes required only for poc
			// 			oStdCyclesDbData.status = "Modified";
			// 			aCycleEventDbData.push(oStdCyclesDbData);

			// 		}
			// 		var aCycleAnnualEventDbData = [];
			// 		var aStdAnnualCycleEventDbData = this.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value");
			// 		for (var i = 0; i < aStdAnnualCycleEventDbData.length; i++) {
			// 			var oStdCyclesDbData = {};
			// 			oStdCyclesDbData.ID = aStdAnnualCycleEventDbData[i].ID;
			// 			oStdCyclesDbData.lossCat = aStdAnnualCycleEventDbData[i].lossCat;
			// 			oStdCyclesDbData.subCat = aStdAnnualCycleEventDbData[i].subCat;
			// 			oStdCyclesDbData.totOccupiedHrs = aStdAnnualCycleEventDbData[i].totOccupiedHrs;
			// 			oStdCyclesDbData.cyclesInYear = aStdAnnualCycleEventDbData[i].cyclesInYear;
			// 			oStdCyclesDbData.expectedCrewSize = aStdAnnualCycleEventDbData[i].expectedCrewSize;
			// 			oStdCyclesDbData.expectedFrequency = aStdAnnualCycleEventDbData[i].expectedFrequency;
			// 			oStdCyclesDbData.expectedEvtDur = aStdAnnualCycleEventDbData[i].expectedEvtDur;
			// 			oStdCyclesDbData.expectedDurPerYear = aStdAnnualCycleEventDbData[i].expectedDurPerYear;
			// 			oStdCyclesDbData.plannedDtLoss = aStdAnnualCycleEventDbData[i].plannedDtLoss;
			// 			oStdCyclesDbData.expectedLbrHrPerYear = aStdAnnualCycleEventDbData[i].expectedLbrHrPerYear;
			// 			//03-09-2024 Changes required only for poc
			// 			oStdCyclesDbData.status = "Modified";
			// 			//    oStdCyclesDbData.expectedTotLbrHrs=aStdAnnualCycleEventDbData[i].expectedTotLbrHrs;
			// 			aCycleAnnualEventDbData.push(oStdCyclesDbData);

			// 		}
			// 		//////////////////////////////////////////////////////////////////////////////////////

			// 		var oPayload = {};
			// 		oPayload.updateLineStdHdrDb = updateLineStdHdrDb;
			// 		oPayload.updateLineStdCyclesDb = aCycleDbData;
			// 		oPayload.updateLineStdCycleEvtDb = aCycleEventDbData;
			// 		oPayload.updateLineStdAnnualEvtDb = aCycleAnnualEventDbData;
			// 		oPayload.deleteLineStdCyclesDb = aRowIdNo;
			// 		oPayload.deleteLineStdCycleEvtDb = [];
			// 		oPayload.deleteLineStdAnnualEvtDb = [];


			// 		var TotPlannedDTLoss, EditCycleEventTotPlanDtLoss = 0, EditAnnualCycleEventTotPlanDtLoss = 0;

			// 		var updateLineStdCycleEvtDb = oPayload.updateLineStdCycleEvtDb;
			// 		for (var i = 0; i < updateLineStdCycleEvtDb.length; i++) {

			// 			updateLineStdCycleEvtDb[i].expectedDurPerCycle = Number(updateLineStdCycleEvtDb[i].expectedFreqPerCycle * updateLineStdCycleEvtDb[i].expectedEvtDur);
			// 			updateLineStdCycleEvtDb[i].expectedLbrHrsPerCycle = Number(updateLineStdCycleEvtDb[i].expectedCrewSize * updateLineStdCycleEvtDb[i].expectedDurPerCycle);
			// 			updateLineStdCycleEvtDb[i].cyclesInYear = Number(oPayload.cyclesInYear);
			// 			updateLineStdCycleEvtDb[i].expectedTotLbrHrs = Number(updateLineStdCycleEvtDb[i].cyclesInYear * updateLineStdCycleEvtDb[i].expectedLbrHrsPerCycle);
			// 			updateLineStdCycleEvtDb[i].cycleHrs = Number(oPayload.cycleHrs);
			// 			updateLineStdCycleEvtDb[i].plannedDtLoss = Number(Number(((updateLineStdCycleEvtDb[i].expectedDurPerCycle / oPayload.totalOccupiedTime) * oPayload.cyclesInYear) * 100).toFixed(2));

			// 			EditCycleEventTotPlanDtLoss = EditCycleEventTotPlanDtLoss + updateLineStdCycleEvtDb[i].plannedDtLoss;
			// 		}

			// 		var updateLineStdAnnualEvtDb = oPayload.updateLineStdAnnualEvtDb;
			// 		for (var i = 0; i < updateLineStdAnnualEvtDb.length; i++) {

			// 			updateLineStdAnnualEvtDb[i].expectedDurPerYear = Number(updateLineStdAnnualEvtDb[i].expectedFrequency * updateLineStdAnnualEvtDb[i].expectedEvtDur);
			// 			updateLineStdAnnualEvtDb[i].expectedLbrHrPerYear = Number(updateLineStdAnnualEvtDb[i].expectedCrewSize * updateLineStdAnnualEvtDb[i].expectedDurPerYear);
			// 			updateLineStdAnnualEvtDb[i].totOccupiedHrs = Number(oPayload.totalOccupiedTime);
			// 			updateLineStdAnnualEvtDb[i].plannedDtLoss = Number(Number((updateLineStdAnnualEvtDb[i].expectedDurPerYear / updateLineStdAnnualEvtDb[i].totOccupiedHrs) * 100).toFixed(2));

			// 			EditAnnualCycleEventTotPlanDtLoss = EditAnnualCycleEventTotPlanDtLoss + updateLineStdAnnualEvtDb[i].plannedDtLoss;
			// 		}
			// 		TotPlannedDTLoss = Number(Number(EditCycleEventTotPlanDtLoss + EditAnnualCycleEventTotPlanDtLoss).toFixed(3));

			// 		var that = this;
			// 		BusyIndicator.show();
			// 		$.ajax({
			// 			url: deleteUrl,
			// 			type: "POST",
			// 			contentType: "application/json",
			// 			data: JSON.stringify(oPayload)
			// 		}).done(function (data) {
			// 			MessageToast.show(that.oResourceBundle.getText("SELECT_LINE_CYCLESDB_DELETE"));
			// 			var message = that.oResourceBundle.getText("SELECT_LINE_CYCLESDB_DELETE_SUCCESS");
			// 			that.onShowSuccess(message);
			// 			that.getView().byId("idSecificStandard").clearSelection();
			// 			BusyIndicator.hide();
			// 			//Read data
			// 			that.fnReadCyclesDbData();
			// 			that.getView().getModel("viewHeaderModel").setProperty("/status", "Modified");
			// 			that.getView().getModel("viewHeaderModel").setProperty("/reworkComment", null);
			// 		}).fail(function (xhr, status, error) {
			// 			BusyIndicator.hide();
			// 			MessageToast.show(that.oResourceBundle.getText("SELECT_LINE_CYCLESDB_NOTDELETED"));
			// 			var message = that.oResourceBundle.getText("SELECT_LINE_CYCLESDB_DELETE_FAIL");
			// 			that.getView().byId("idSecificStandard").clearSelection();
			// 			that.onShowError(message);
			// 		});
			// 		//////////////////////////////////////////////////////////////////////////////////////////
			// 	}
			// 	this._oPopoverDeleteRow.close()
			// },


			////////////////Cycle events DB///////////////////////////////////
			annualCycleEventEdit: function (oEvent) {
				this.getView().byId("idtab3Edit").setVisible(false);
				this.getView().byId("idLineViewAnnualCycleEventSubmit").setVisible(true);
				this.getView().byId("idLineViewAnnualCycleEventCancel").setVisible(true);
				this.getView().byId("idtab3Delete").setEnabled(false);

				var tableIndex = this.getView().byId("idCycleAnnualDB").getSelectedIndices();
				for (var i = 0; i < tableIndex.length; i++) {
					this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/enable", true);
					this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/edit", true);
				}
			},

			annualCycleEventSubmit: function () {
				var that = this;
				///////////////////////////////////New Payload for Multi Update////////////////////////////////////////////
				var tableIndex = this.getView().byId("idCycleAnnualDB").getSelectedIndices();
				var aUpdateData = [];
				/////////////////////////////////////////////////////////////////////////////////////////////////////////

				var acycleAnnualEventDbLen = this.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value");
				var iCycleAnnualDbError = 0;
				if (acycleAnnualEventDbLen != undefined) {
					for (var i = 0; i < tableIndex.length; i++) {
						var lossCat = acycleAnnualEventDbLen[tableIndex[i]].lossCat;
						var subCat = acycleAnnualEventDbLen[tableIndex[i]].subCat;
						var crewSize = Number(acycleAnnualEventDbLen[tableIndex[i]].expectedCrewSize);
						var ExpFrequency = Number(acycleAnnualEventDbLen[tableIndex[i]].expectedFrequency);
						var ExpEventDur = Number(acycleAnnualEventDbLen[tableIndex[i]].expectedEvtDur);
						var cycleInYear = Number(acycleAnnualEventDbLen[tableIndex[i]].cyclesInYear);

						if (lossCat == "") {
							this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateLossCat", "Error");
							this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateTextLossCat", this.oResourceBundle.getText("ERROR_LOSS_CATEGORY"));
							iCycleAnnualDbError = 1;
						} else {
							this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateLossCat", "None");
						}
						if (subCat == "") {
							this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateSubCat", "Error");
							this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateTextSubCat", this.oResourceBundle.getText("ERROR_SUB_CATEGORY"));
							iCycleAnnualDbError = 1;
						} else {
							this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateSubCat", "None");

						}
						if (crewSize == "") {
							this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateCrewSize", "Error");
							this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateTextCrewSize", this.oResourceBundle.getText("ERROR_EXPECTED_CREWSIZE"));
							iCycleAnnualDbError = 1;
						} else {
							this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateCrewSize", "None");
						}
						if (ExpFrequency == "") {
							this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateExpFrequency", "Error");
							this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateTextExpFrequency", this.oResourceBundle.getText("ERROR_EXPECTED_FREQUENCY"));
							iCycleAnnualDbError = 1;
						} else {
							this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateExpFrequency", "None");
						}
						if (ExpEventDur == "") {
							this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateExpEventDur", "Error");
							this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateTextExpEventDur", this.oResourceBundle.getText("ERROR_EXP_EVENT_DUR"));
							iCycleAnnualDbError = 1;
						} else {
							this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateExpEventDur", "None");
						}
						if (cycleInYear == "") {
							this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateCycleInYear", "Error");
							this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateTextCycleInYear", this.oResourceBundle.getText("ERROR_CYCLE_IN_YEAR"));
							iCycleAnnualDbError = 1;
						} else {
							this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/valueStateCycleInYear", "None");
						}
					}
				}
				if (iCycleAnnualDbError == 1) {
					MessageToast.show(this.oResourceBundle.getText("MAND_LINE_ERROR_VIEW_STD"));
				} else {

					this.getView().byId("idtab3Edit").setVisible(true);
					this.getView().byId("idLineViewAnnualCycleEventSubmit").setVisible(false);
					this.getView().byId("idLineViewAnnualCycleEventCancel").setVisible(false);
					this.getView().byId("idtab3Delete").setEnabled(true);
					//////////////////////////////////////////////////////////////////////////////////////////////////////////
					for (var i = 0; i < tableIndex.length; i++) {
						var currentObj = {};
						this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/edit", false);

						currentObj.ID = this.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value/" + tableIndex[i] + "/ID");
						currentObj.lossCat = this.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value/" + tableIndex[i] + "/lossCat");
						currentObj.subCat = this.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value/" + tableIndex[i] + "/subCat");
						currentObj.cyclesInYear = Number(Number(that.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value/" + tableIndex[i] + "/cyclesInYear")).toFixed(3));
						currentObj.expectedCrewSize = Number(Number(that.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value/" + tableIndex[i] + "/expectedCrewSize")).toFixed(3));
						currentObj.expectedFrequency = Number(Number(that.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value/" + tableIndex[i] + "/expectedFrequency")).toFixed(3));
						currentObj.expectedEvtDur = Number(Number(that.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value/" + tableIndex[i] + "/expectedEvtDur")).toFixed(3));
						currentObj.expectedDurPerYear = Number(Number(that.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value/" + tableIndex[i] + "/expectedDurPerYear")).toFixed(3));
						currentObj.plannedDtLoss = Number(Number(that.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value/" + tableIndex[i] + "/plannedDtLoss")).toFixed(3));
						currentObj.expectedLbrHrPerYear = Number(Number(that.getView().getModel("lineStdAnnualEventDbModel").getProperty("/value/" + tableIndex[i] + "/expectedLbrHrPerYear")).toFixed(3));
						aUpdateData.push(currentObj);

					}

					var aLineStdData = this.getOwnerComponent().getModel("lineStandardHeaderModel").getData().value;
					var aSpecificLineStdHeaderData = aLineStdData.filter(function (val) {
						if (val.lineStdNo == lineStdNo)
							return val;
					});

					var aCycleEventData = this.getView().getModel("lineStdCycleEventDbModel").getProperty("/value");
					var TotCycleEventPlanDTLoss = 0;
					for (var i = 0; i < aCycleEventData.length; i++) {
						TotCycleEventPlanDTLoss = TotCycleEventPlanDTLoss + aCycleEventData[i].plannedDtLoss;
					}
					var TotAnnualEventPlanDTLoss = 0;
					for (var i = 0; i < aUpdateData.length; i++) {
						aUpdateData[i].expectedDurPerYear = Number((aUpdateData[i].expectedFrequency * aUpdateData[i].expectedEvtDur).toFixed(3));
						aUpdateData[i].expectedLbrHrPerYear = Number((aUpdateData[i].expectedCrewSize * aUpdateData[i].expectedDurPerYear).toFixed(3));
						aUpdateData[i].totOccupiedHrs = Number((aSpecificLineStdHeaderData[0].totalOccupiedTime).toFixed(3));
						aUpdateData[i].plannedDtLoss = Number(((aUpdateData[i].expectedDurPerYear / aSpecificLineStdHeaderData[0].totalOccupiedTime) * 100).toFixed(2));
						TotAnnualEventPlanDTLoss = TotAnnualEventPlanDTLoss + aUpdateData[i].plannedDtLoss;
					}
					var TotalPlannedDTLoss = Number((TotCycleEventPlanDTLoss + TotAnnualEventPlanDTLoss).toFixed(3));



					var oPayload = { "updateData": aUpdateData, "lineStdID": aSpecificLineStdHeaderData[0].ID, plannedDtLoss: TotalPlannedDTLoss, "lineStdNo": lineStdNo };  //,"lineStdNo":lineStdNo
					var updateUrl = "odata/v4/data-services/updateLineRelStdAnnualEvtItems";
					////////////////////////////////////New Payload for Multi Update/////////////////////////////////////////////
					BusyIndicator.show()
					$.ajax({
						url: updateUrl,
						type: "POST",
						contentType: "application/json",
						data: JSON.stringify(oPayload)
					}).done(function (data) {
						BusyIndicator.hide();
						MessageToast.show(that.oResourceBundle.getText("SELECT_ANNUAL_DB_UPDATE"));
						var message = that.oResourceBundle.getText("SELECT_ANNUALDB_UPDATE_SUCCESS");
						that.onShowSuccess(message);
						that.getView().byId("idCycleAnnualDB").clearSelection();
						that.getView().getModel("viewHeaderModel").setProperty("/status", "Modified");
						that.getView().getModel("viewHeaderModel").setProperty("/reworkComment", null);
						that.fnReadAnnualEventDbData();

					}).fail(function (xhr, status, error) {
						MessageToast.show(that.oResourceBundle.getText("SELECT_ANNUAL_DB_NOTUPDATED"));
						var message = that.oResourceBundle.getText("SELECT_ANNUALDB_UPDATE_FAIL");
						that.onShowError(message);
						this.getView().byId("idCycleAnnualDB").clearSelection();
						BusyIndicator.hide();

						that.fnReadAnnualEventDbData();
					});
				}
			},

			fnAnnualCycleEventCancel: function (evt) {
				this.getView().byId("idCycleAnnualDB").clearSelection();
				this.getView().byId("idtab3Edit").setVisible(true);
				this.getView().byId("idLineViewAnnualCycleEventSubmit").setVisible(false);
				this.getView().byId("idLineViewAnnualCycleEventCancel").setVisible(false);
				this.getView().byId("idtab3Delete").setEnabled(true);
				tableIndex = this.getView().byId("idCycleAnnualDB").getSelectedIndices();
				for (var i = 0; i < tableIndex.length; i++) {
					this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndex[i] + "/edit", false);
				}
				this.fnReadAnnualEventDbData();

			},
			// annualCycleEventDelete: function () {
			// 	if (!this._oPopoverDeleteRow) {
			// 		this._oPopoverDeleteRow = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.PopoverDeleteRecordsLine", this);
			// 		this.getView().addDependent(this._oPopoverDeleteRow);
			// 	}
			// 	this._oPopoverDeleteRow.open();
			// },
			onRework: function (oEvent) {
				if (!this._oPopover10) {
					this._oPopover10 = sap.ui.xmlfragment("l8gttpmgllpstdui.view.fragment.PopoverApproverComment", this);
					this.getView().addDependent(this._oPopover10);
				}
				this._oPopover10.open();
			},

			// initital settings for the filters
			fnIconTabBarFilterSelected: function (oEvent) {

				var newData = this.getOwnerComponent().getModel("loginUserModel").getData().results;
				var nbId = newData[0].Username;
				var role = newData[0].AuthType;
				var zone = newData[0].Zone;

				if (role != "C") {

					this.getView().byId("idtab1Edit").setVisible(true);
					this.getView().byId("idtab1Delete").setVisible(true);
					this.getView().byId("idLineViewCycleSubmit").setVisible(false);
					this.getView().byId("idLineViewCycleCancel").setVisible(false);

					this.getView().byId("idtab2Edit").setVisible(true);
					this.getView().byId("idtab2Delete").setVisible(true);
					this.getView().byId("idLineViewCycleEventSubmit").setVisible(false);
					this.getView().byId("idLineViewCycleEventCancel").setVisible(false);

					this.getView().byId("idtab3Edit").setVisible(true);
					this.getView().byId("idtab3Delete").setVisible(true);
					this.getView().byId("idLineViewAnnualCycleEventSubmit").setVisible(false);
					this.getView().byId("idLineViewAnnualCycleEventCancel").setVisible(false);
				}


				if (roleVal === "V") {

					this.getView().byId("idtab1Edit").setVisible(false);
					this.getView().byId("idtab1Delete").setVisible(false);

					this.getView().byId("idtab2Edit").setVisible(false);
					this.getView().byId("idtab2Delete").setVisible(false);

					this.getView().byId("idtab3Edit").setVisible(false);
					this.getView().byId("idtab3Delete").setVisible(false);

					this.getView().byId("idSecificStandard").setSelectionMode("None");
					this.getView().byId("idCycleEventsDB").setSelectionMode("None");
					this.getView().byId("idCycleAnnualDB").setSelectionMode("None");

				}


				var tableIndexCycle = this.getView().byId("idSecificStandard").getSelectedIndices();
				for (var i = 0; i < tableIndexCycle.length; i++) {
					this.getView().getModel("LineStdCycleDBModel").setProperty("/value/" + tableIndexCycle[i] + "/edit", false);
				}

				var tableIndexCyEv = this.getView().byId("idCycleEventsDB").getSelectedIndices();
				for (var i = 0; i < tableIndexCyEv.length; i++) {
					this.getView().getModel("lineStdCycleEventDbModel").setProperty("/value/" + tableIndexCyEv[i] + "/edit", false);
				}
				var tableIndexAnnual = this.getView().byId("idCycleAnnualDB").getSelectedIndices();
				for (var i = 0; i < tableIndexAnnual.length; i++) {
					this.getView().getModel("lineStdAnnualEventDbModel").setProperty("/value/" + tableIndexAnnual[i] + "/edit", false);
				}
				this.getView().byId("idSecificStandard").clearSelection();
				this.getView().byId("idCycleEventsDB").clearSelection();
				this.getView().byId("idCycleAnnualDB").clearSelection();

				var oTab = this.getView().byId("idLineViewTabBar");
				var mainTabKey = oTab.getSelectedKey();
				if (mainTabKey == "CycleEventsDB") {
					this.getView().byId("idCycleEventsDB").clearSelection();
					this.fnReadCycleEventsDbData();
				}
				if (mainTabKey == "AnnualEventDB") {
					this.fnReadAnnualEventDbData();
					this.getView().byId("idCycleAnnualDB").clearSelection();
				}
				if (mainTabKey == "Cycles DB") {
					this.getView().byId("idSecificStandard").clearSelection();
					this.fnReadCyclesDbData();
				}

			},
			onShowWarning: function (message) {
				sap.m.MessageBox.warning(
					message, {
					title: "Warning",
					actions: [sap.m.MessageBox.Action.OK],
					onClose: function () { }
				}
				);
			},
			onShowSuccess: function (message) {
				sap.m.MessageBox.success(
					message, {
					title: "Success",
					actions: [sap.m.MessageBox.Action.OK],
					onClose: function () { }
				}
				);
			},
			onShowError: function (message) {
				sap.m.MessageBox.error(
					message, {
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK],
					onClose: function () { }
				}
				);
			},

		});
	});
