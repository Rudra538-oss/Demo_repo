sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "l8gttpmgllpstdui/model/formatter",
    'sap/m/MessageToast',
    "sap/ui/core/routing/History",
    ],
    function (Controller, formatter, MessageToast, History) {
    "use strict";

    return Controller.extend("l8gttpmgllpstdui.controller.BaseController", {
      formatter: formatter,
      onInit: function () {   
        //Select standard 
        var jsonModel = new sap.ui.model.json.JSONModel();
        jsonModel.setData({ "data": [{ standard: " " }, { standard: "Line Standard" }, { standard: "Product Standard" }] });
        this.getView().setModel(jsonModel, "standardModel");
        sap.ui.getCore().setModel(jsonModel, "standardModel");
      },
      // Success, Warning,Error message used in Line and Product Standard
      onShowSuccess: function (message) {
        sap.m.MessageBox.success(
            message, {
              title: "Success",
              actions: [sap.m.MessageBox.Action.OK],
              onClose: function () { }
            }
        );
      },
      onShowWarning: function (message) {
        sap.m.MessageBox.warning(
            message, {
              title: "Warning",
              actions: [sap.m.MessageBox.Action.OK],
              onClose: function () { }
            }
        );
      },
      onShowError: function (message) {
        sap.m.MessageBox.error(
            message, {
              title: "Error",
              actions: [sap.m.MessageBox.Action.OK],
              onClose: function () { }
            }
        );
      },
      fnHomeScreenNav: function () {
        const oRouter = sap.ui.core.UIComponent.getRouterFor(this);
        oRouter.navTo("RouteHomeView", true);
      }
    });
  }
);
